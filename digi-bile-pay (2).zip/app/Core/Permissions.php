<?php
declare(strict_types=1);

namespace App\Core;

/** فهرست مرکزی مجوزها و قالب نقش‌های پیش‌فرض هر شرکت */
final class Permissions
{
    public static function groups(): array
    {
        return [
            'داشبورد' => ['dashboard.view' => 'مشاهده داشبورد'],
            'شرکت‌ها' => [
                'companies.view' => 'مشاهده شرکت‌ها',
                'companies.manage' => 'مدیریت شرکت‌ها (همه مستأجرها)',
            ],
            'کاربران' => [
                'users.view' => 'مشاهده کاربران',
                'users.manage' => 'مدیریت کاربران',
            ],
            'نقش‌ها' => [
                'roles.view' => 'مشاهده نقش‌ها',
                'roles.manage' => 'مدیریت نقش‌ها',
            ],
            'مشتریان' => [
                'customers.view' => 'مشاهده مشتریان',
                'customers.manage' => 'مدیریت مشتریان',
                'wallet.topup' => 'شارژ کیف پول',
            ],
            'فروشندگان' => [
                'merchants.view' => 'مشاهده فروشندگان',
                'merchants.manage' => 'مدیریت فروشندگان',
                'settlements.manage' => 'تسویه حساب با فروشندگان',
            ],
            'محصولات' => [
                'products.view' => 'مشاهده محصولات',
                'products.manage' => 'مدیریت محصولات',
            ],
            'سفارش‌ها' => [
                'orders.view' => 'مشاهده سفارش‌ها',
                'orders.create' => 'ثبت سفارش',
            ],
            'طرح‌های تسهیلاتی' => [
                'plans.view' => 'مشاهده طرح‌ها',
                'plans.manage' => 'مدیریت طرح‌ها',
            ],
            'تسهیلات' => [
                'loans.view' => 'مشاهده تسهیلات',
                'loans.create' => 'ثبت درخواست تسهیلات',
                'loans.decide' => 'تأیید یا رد تسهیلات',
            ],
            'اقساط' => [
                'installments.view' => 'مشاهده اقساط',
                'installments.collect' => 'وصول اقساط و ثبت پیگیری',
            ],
            'حسابداری' => [
                'accounting.view' => 'مشاهده سرفصل‌ها، اسناد و تراز',
                'accounting.post' => 'ثبت سند دستی و تعریف حساب',
            ],
            'گزارش‌ها' => ['reports.view' => 'مشاهده و دریافت گزارش‌ها'],
            'حسابرسی' => ['audit.view' => 'مشاهده گزارش حسابرسی'],
            'وب‌سایت' => ['site.manage' => 'ویرایش محتوای صفحه‌ی اصلی عمومی'],
        ];
    }

    public static function all(): array
    {
        $out = [];
        foreach (self::groups() as $perms) {
            foreach (array_keys($perms) as $p) {
                $out[] = $p;
            }
        }
        return $out;
    }

    /** قالب نقش‌های پیش‌فرض: slug => [name, permissions] */
    public static function templates(): array
    {
        $all = self::all();
        return [
            'company_admin' => ['مدیر شرکت', array_values(array_diff($all, ['companies.manage']))],
            'lending_manager' => ['مدیر تسهیلات', [
                'dashboard.view', 'customers.view', 'customers.manage', 'wallet.topup', 'plans.view', 'plans.manage',
                'loans.view', 'loans.create', 'loans.decide', 'installments.view', 'merchants.view', 'products.view',
                'orders.view', 'orders.create', 'reports.view',
            ]],
            'collector' => ['کارشناس وصول', [
                'dashboard.view', 'customers.view', 'loans.view', 'installments.view', 'installments.collect', 'reports.view',
            ]],
            'accountant' => ['حسابدار', [
                'dashboard.view', 'customers.view', 'merchants.view', 'orders.view', 'loans.view', 'installments.view',
                'settlements.manage', 'accounting.view', 'accounting.post', 'reports.view',
            ]],
            'auditor' => ['حسابرس', [
                'dashboard.view', 'companies.view', 'users.view', 'roles.view', 'customers.view', 'plans.view',
                'loans.view', 'installments.view', 'merchants.view', 'products.view', 'orders.view',
                'accounting.view', 'reports.view', 'audit.view',
            ]],
        ];
    }
}
