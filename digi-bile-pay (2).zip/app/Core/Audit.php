<?php
declare(strict_types=1);

namespace App\Core;

final class Audit
{
    public static function log(string $action, string $entity, ?int $entityId = null, array $details = [], ?int $companyId = null): void
    {
        Database::exec(
            'INSERT INTO audit_logs (company_id, user_id, action, entity, entity_id, details, ip, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $companyId ?? (Auth::companyId() ?: null),
                Auth::id() ?: null,
                $action,
                $entity,
                $entityId,
                $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null,
                $_SERVER['REMOTE_ADDR'] ?? null,
                date('Y-m-d H:i:s'),
            ]
        );
    }

    /**
     * تفاوت فیلدهای تغییرکرده بین مقدار قبلی و جدید؛ فقط فیلدهای فهرست‌شده بررسی می‌شوند.
     * @param list<string> $fields  @return array<string,array{0:mixed,1:mixed}>
     */
    public static function diff(array $old, array $new, array $fields): array
    {
        $out = [];
        foreach ($fields as $f) {
            $o = $old[$f] ?? null;
            $n = $new[$f] ?? null;
            $same = is_numeric($o) && is_numeric($n) ? (float) $o === (float) $n : (string) $o === (string) $n;
            if (!$same) {
                $out[$f] = [$o, $n];
            }
        }
        return $out;
    }

    /** رویدادهای یک موجودیت برای پنل تاریخچه */
    public static function events(int $companyId, string $entity, int $entityId, int $limit = 25): array
    {
        return Database::all(
            'SELECT a.action, a.details, a.created_at, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
             WHERE a.company_id = ? AND a.entity = ? AND a.entity_id = ? AND a.action NOT LIKE ? ORDER BY a.id DESC LIMIT ' . (int) $limit,
            [$companyId, $entity, $entityId, 'report.%']
        );
    }
}
