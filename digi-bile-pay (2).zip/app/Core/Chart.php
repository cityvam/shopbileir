<?php
declare(strict_types=1);

namespace App\Core;

/** نمودارهای SVG سمت سرور (بدون جاوااسکریپت و کتابخانه خارجی). رنگ‌ها از کلاس‌های charts.css می‌آیند. */
final class Chart
{
    /** @param list<string> $labels  @param list<int|float> $values  مقادیر ریال؛ محور بر حسب میلیون ریال */
    public static function bars(array $labels, array $values, string $tone = 'primary'): string
    {
        $w = 440;
        $h = 240;
        $left = 46;
        $right = 12;
        $top = 14;
        $bottom = 32;
        $n = count($values);
        $max = max(array_merge([0], $values));
        if ($n === 0 || $max <= 0) {
            return '<p class="chart-empty">برای این بازه هنوز داده‌ای ثبت نشده است.</p>';
        }
        $step = self::niceStep($max / 4);
        $ceil = $step * (int) ceil($max / $step);
        $plotW = $w - $left - $right;
        $plotH = $h - $top - $bottom;
        $slot = $plotW / $n;
        $barW = min(40.0, $slot * 0.5);

        $svg = '<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="نمودار ستونی">';
        for ($g = 0; $g * $step <= $ceil; $g++) {
            $y = $top + $plotH - ($g * $step / $ceil) * $plotH;
            $svg .= '<line class="chart__grid" x1="' . $left . '" x2="' . ($w - $right) . '" y1="' . round($y, 1) . '" y2="' . round($y, 1) . '"/>';
            $svg .= '<text class="chart__axis" x="' . ($left - 8) . '" y="' . round($y + 4, 1) . '" text-anchor="end">' . fa(self::compact($g * $step)) . '</text>';
        }
        foreach ($values as $i => $v) {
            $bh = max(0.0, ($v / $ceil) * $plotH);
            // ترتیب زمان از راست به چپ
            $cx = $w - $right - ($i + 0.5) * $slot;
            $x = $cx - $barW / 2;
            $y = $top + $plotH - $bh;
            $svg .= '<rect class="chart__bar chart__bar--' . e($tone) . '" x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round($barW, 1) . '" height="' . round($bh, 1) . '" rx="4"/>';
            if ($v > 0) {
                $svg .= '<text class="chart__value" x="' . round($cx, 1) . '" y="' . round($y - 5, 1) . '" text-anchor="middle">' . fa(self::compact((float) $v)) . '</text>';
            }
            $svg .= '<text class="chart__label" x="' . round($cx, 1) . '" y="' . ($h - 10) . '" text-anchor="middle">' . e($labels[$i] ?? '') . '</text>';
        }
        return $svg . '</svg><p class="chart-note">مبالغ به میلیون ریال</p>';
    }

    /** @param list<array{0:string,1:int|float,2:string}> $parts برچسب، مقدار، تُن (ok|warn|bad|info|muted|primary) */
    public static function donut(array $parts, string $centerLabel): string
    {
        $total = array_sum(array_column($parts, 1));
        if ($total <= 0) {
            return '<p class="chart-empty">داده‌ای برای نمایش وجود ندارد.</p>';
        }
        $svg = '<svg class="donut" viewBox="0 0 42 42" role="img" aria-label="نمودار حلقه‌ای"><circle class="donut__ring" cx="21" cy="21" r="15.915"/>';
        $offset = 25.0;
        foreach ($parts as [$label, $value, $tone]) {
            if ($value <= 0) {
                continue;
            }
            $pct = $value / $total * 100;
            $svg .= '<circle class="donut__seg donut__seg--' . e($tone) . '" cx="21" cy="21" r="15.915" stroke-dasharray="' . round($pct, 3) . ' ' . round(100 - $pct, 3) . '" stroke-dashoffset="' . round($offset, 3) . '"/>';
            $offset -= $pct;
        }
        $svg .= '<text class="donut__num" x="21" y="21.5" text-anchor="middle">' . fa((string) (int) $total) . '</text>';
        $svg .= '<text class="donut__cap" x="21" y="26.5" text-anchor="middle">' . e($centerLabel) . '</text></svg>';

        $legend = '<ul class="legend">';
        foreach ($parts as [$label, $value, $tone]) {
            $legend .= '<li><span class="legend__dot legend__dot--' . e($tone) . '"></span>' . e($label) . '<strong>' . fa((string) (int) $value) . '</strong></li>';
        }
        return '<div class="donut-wrap">' . $svg . $legend . '</ul></div>';
    }

    private static function niceStep(float $raw): float
    {
        if ($raw <= 0) {
            return 1.0;
        }
        $pow = 10 ** floor(log10($raw));
        foreach ([1, 2, 2.5, 5, 10] as $m) {
            if ($raw <= $m * $pow) {
                return (float) ($m * $pow);
            }
        }
        return (float) (10 * $pow);
    }

    private static function compact(float $rial): string
    {
        $m = $rial / 1_000_000;
        if ($m >= 100) {
            return (string) (int) round($m);
        }
        $s = rtrim(rtrim(number_format($m, 1, '.', ''), '0'), '.');
        return $s === '' ? '0' : $s;
    }
}
