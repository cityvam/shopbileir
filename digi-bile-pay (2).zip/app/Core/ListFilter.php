<?php
declare(strict_types=1);

namespace App\Core;

/**
 * سازنده‌ی مشترک فیلتر، مرتب‌سازی و خروجی برای لیست‌های کارشناسی.
 * همه‌ی مقادیر با پارامتر بایند می‌شوند؛ ستون‌ها و ترتیب فقط از فهرست سفید می‌آیند.
 */
final class ListFilter
{
    /** @var array<string,string> مقادیر فعلی فیلترها (برای نمایش دوباره در فرم) */
    public array $v = [];
    /** @var list<string> */
    public array $errors = [];
    public string $where;
    /** @var list<mixed> */
    public array $params;
    public string $order = '';
    private string $sortKey = '';
    private string $dir = 'desc';

    /** @param array<string,mixed> $input  @param list<mixed> $params */
    public function __construct(private array $input, string $baseWhere, array $params)
    {
        $this->where = $baseWhere;
        $this->params = $params;
    }

    private function get(string $key): string
    {
        $v = $this->input[$key] ?? '';
        $v = is_string($v) ? trim($v) : '';
        $this->v[$key] = $v;
        return $v;
    }

    public static function like(string $q): string
    {
        return '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $q) . '%';
    }

    /** @param list<string> $cols */
    public function text(string $key, array $cols): self
    {
        $q = $this->get($key);
        if ($q !== '') {
            $parts = array_map(static fn ($c) => "$c LIKE ? ESCAPE '!'", $cols);
            $this->where .= ' AND (' . implode(' OR ', $parts) . ')';
            foreach ($cols as $_) {
                $this->params[] = self::like($q);
            }
        }
        return $this;
    }

    /** @param list<string> $allowed */
    public function enum(string $key, string $col, array $allowed): self
    {
        $x = $this->get($key);
        if ($x !== '' && in_array($x, $allowed, true)) {
            $this->where .= " AND $col = ?";
            $this->params[] = $x;
        } else {
            $this->v[$key] = '';
        }
        return $this;
    }

    public function dateRange(string $fromKey, string $toKey, string $col): self
    {
        foreach ([$fromKey => '>=', $toKey => '<='] as $k => $op) {
            $s = $this->get($k);
            if ($s === '') {
                continue;
            }
            $d = Jalali::parse($s);
            if ($d === null) {
                $this->errors[] = 'تاریخ فیلتر باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.';
                continue;
            }
            $this->where .= " AND DATE($col) $op ?";
            $this->params[] = $d;
        }
        return $this;
    }

    public function amount(string $minKey, string $maxKey, string $expr): self
    {
        foreach ([$minKey => '>=', $maxKey => '<='] as $k => $op) {
            $s = $this->get($k);
            if ($s === '') {
                continue;
            }
            $n = Validator::amount($s);
            if ($n === null) {
                $this->errors[] = 'مبلغ فیلتر معتبر نیست.';
                continue;
            }
            $this->where .= " AND $expr $op ?";
            $this->params[] = $n;
        }
        return $this;
    }

    /** شرط خام ثابت (بدون ورودی کاربر) */
    public function raw(string $sql, array $params = []): self
    {
        $this->where .= " AND $sql";
        array_push($this->params, ...$params);
        return $this;
    }

    /** @param array<string,string> $map کلید → ستون  */
    public function sort(array $map, string $default, string $tiebreak): self
    {
        $k = $this->get('sort');
        $this->sortKey = isset($map[$k]) ? $k : $default;
        $this->dir = ($this->get('dir') === 'asc') ? 'asc' : 'desc';
        $this->order = $map[$this->sortKey] . ' ' . $this->dir . ', ' . $tiebreak . ' ' . $this->dir;
        return $this;
    }

    public function isCsv(): bool
    {
        return in_array($this->input['format'] ?? '', ['csv', 'xlsx'], true);
    }

    public function qs(array $over = []): string
    {
        $a = array_filter(array_merge($this->v, $over), static fn ($x) => $x !== '' && $x !== null);
        return http_build_query($a);
    }

    public function sortLink(string $base, string $key, string $label): string
    {
        $dir = $this->sortKey === $key && $this->dir === 'asc' ? 'desc' : 'asc';
        $mark = $this->sortKey === $key ? ($this->dir === 'asc' ? ' ▲' : ' ▼') : '';
        return '<a class="sort-link" href="' . e($base . '?' . $this->qs(['sort' => $key, 'dir' => $dir, 'page' => ''])) . '">' . e($label) . $mark . '</a>';
    }

    /** آیا فیلتر پیشرفته‌ای فعال است؟ (برای باز ماندن بخش جزئیات) */
    public function active(array $keys): bool
    {
        foreach ($keys as $k) {
            if (($this->v[$k] ?? '') !== '') {
                return true;
            }
        }
        return false;
    }
}
