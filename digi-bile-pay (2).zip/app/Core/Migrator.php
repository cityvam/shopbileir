<?php
declare(strict_types=1);

namespace App\Core;

/** اجرای Migrationهای نسخه‌بندی‌شده. روی MySQL مستقیم؛ روی SQLite (فقط برای تست) با ترجمه ساده DDL. */
final class Migrator
{
    public static function run(string $dir): array
    {
        $pdo = Database::pdo();
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS schema_migrations (version VARCHAR(100) NOT NULL PRIMARY KEY, applied_at DATETIME NOT NULL)'
        );
        $done = array_column(Database::all('SELECT version FROM schema_migrations'), 'version');
        $files = array_merge(glob(rtrim($dir, '/') . '/*.sql') ?: [], glob(rtrim($dir, '/') . '/*.php') ?: []);
        usort($files, static fn ($a, $b) => strcmp(basename($a), basename($b)));
        $applied = [];
        foreach ($files as $file) {
            $version = basename($file);
            if (in_array($version, $done, true)) {
                continue;
            }
            if (str_ends_with($file, '.php')) {
                // مهاجرت داده‌ای: فایل PHP یک Closure برمی‌گرداند (برای کارهایی که با SQL خالص قابل حمل بین MySQL و SQLite نیست)
                (require $file)();
            } else {
                foreach (self::statements((string) file_get_contents($file)) as $sql) {
                    $pdo->exec(Database::isSqlite() ? self::toSqlite($sql) : $sql);
                }
            }
            Database::exec('INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)', [$version, date('Y-m-d H:i:s')]);
            $applied[] = $version;
        }
        return $applied;
    }

    private static function statements(string $sql): array
    {
        $sql = preg_replace('/^\s*--.*$/m', '', $sql) ?? $sql;
        $parts = preg_split('/;\s*\n/', trim($sql) . "\n") ?: [];
        return array_values(array_filter(array_map(static fn ($s) => trim($s, " \t\n\r;"), $parts), static fn ($s) => $s !== ''));
    }

    private static function toSqlite(string $sql): string
    {
        $sql = preg_replace('/(\w+) BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,/', '$1 INTEGER PRIMARY KEY AUTOINCREMENT,', $sql);
        $sql = preg_replace('/,\s*PRIMARY KEY \(id\)\s*\n\)/', "\n)", $sql);
        $sql = preg_replace('/\n\s*PRIMARY KEY \(id\),/', '', $sql);
        $sql = preg_replace('/\)\s*ENGINE=[^\n]*/', ')', $sql);
        $sql = preg_replace('/\s+ON UPDATE CURRENT_TIMESTAMP/', '', $sql);
        $sql = preg_replace('/ENUM\([^)]*\)/', 'VARCHAR(20)', $sql);
        return str_replace(' UNSIGNED', '', (string) $sql);
    }
}
