<?php
declare(strict_types=1);

namespace App\Core;

/** خطای قابل‌نمایش به کاربر؛ داخل تراکنش پرتاب می‌شود تا کل عملیات برگردانده (Rollback) شود. */
final class UserError extends \RuntimeException
{
}
