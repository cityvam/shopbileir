<?php
declare(strict_types=1);

namespace App\Core;

final class Auth
{
    private const IDLE_SECONDS = 1800;
    private const MAX_FAILS = 5;
    private const MAX_FAILS_PER_IP = 30;
    private const WINDOW_SECONDS = 900;
    public const MFA_PENDING = '__mfa__';
    private const MFA_TTL = 300;

    private static ?array $user = null;
    private static bool $loaded = false;
    private static array $perms = [];

    public static function user(): ?array
    {
        if (self::$loaded) {
            return self::$user;
        }
        self::$loaded = true;
        $uid = $_SESSION['uid'] ?? null;
        if (!$uid) {
            return null;
        }
        if ((time() - (int) ($_SESSION['last'] ?? 0)) > self::IDLE_SECONDS
            || ($_SESSION['ua'] ?? '') !== self::fingerprint()) {
            self::logout();
            return null;
        }
        $_SESSION['last'] = time();
        $row = Database::one(
            "SELECT u.id, u.company_id, u.role_id, u.username, u.full_name, r.name AS role_name,
                    c.name AS company_name, c.brand_name
             FROM users u
             JOIN roles r ON r.id = u.role_id
             JOIN companies c ON c.id = u.company_id
             WHERE u.id = ? AND u.status = 'active' AND c.status = 'active'",
            [(int) $uid]
        );
        if (!$row) {
            self::logout();
            return null;
        }
        self::$user = $row;
        self::$perms = array_column(
            Database::all('SELECT permission FROM role_permissions WHERE role_id = ?', [(int) $row['role_id']]),
            'permission'
        );
        return self::$user;
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function id(): int
    {
        return (int) (self::user()['id'] ?? 0);
    }

    public static function companyId(): int
    {
        return (int) (self::user()['company_id'] ?? 0);
    }

    public static function can(string $permission): bool
    {
        self::user();
        return in_array($permission, self::$perms, true);
    }

    public static function permissions(): array
    {
        self::user();
        return self::$perms;
    }

    /** @return string|null پیام خطا؛ null یعنی موفق */
    public static function attempt(string $username, string $password): ?string
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $since = date('Y-m-d H:i:s', time() - self::WINDOW_SECONDS);
        $userFails = (int) Database::scalar(
            'SELECT COUNT(*) FROM login_attempts WHERE success = 0 AND attempted_at >= ? AND username = ?',
            [$since, $username]
        );
        // سقف IP بالاتر است تا کاربران پشت یک NAT مشترک قفل یکدیگر نشوند
        $ipFails = (int) Database::scalar(
            'SELECT COUNT(*) FROM login_attempts WHERE success = 0 AND attempted_at >= ? AND ip = ?',
            [$since, $ip]
        );
        if ($userFails >= self::MAX_FAILS || $ipFails >= self::MAX_FAILS_PER_IP) {
            return 'تعداد تلاش‌های ناموفق زیاد است. چند دقیقه بعد دوباره تلاش کنید.';
        }

        $row = Database::one(
            "SELECT u.id, u.password_hash, u.mfa_enabled FROM users u JOIN companies c ON c.id = u.company_id
             WHERE u.username = ? AND u.status = 'active' AND c.status = 'active'",
            [$username]
        );
        // مقایسه با هش ثابت برای یکسان‌سازی زمان پاسخ در صورت نبود کاربر
        $hash = $row['password_hash'] ?? password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT);
        $ok = password_verify($password, $hash) && $row !== null;

        Database::exec(
            'INSERT INTO login_attempts (username, ip, success, attempted_at) VALUES (?, ?, ?, ?)',
            [$username, $ip, $ok ? 1 : 0, date('Y-m-d H:i:s')]
        );
        if (!$ok) {
            return 'نام کاربری یا رمز عبور صحیح نیست.';
        }

        if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
            Database::exec('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), (int) $row['id']]);
        }
        if ((int) $row['mfa_enabled'] === 1) {
            session_regenerate_id(true);
            $_SESSION['mfa_uid'] = (int) $row['id'];
            $_SESSION['mfa_user'] = $username;
            $_SESSION['mfa_at'] = time();
            return self::MFA_PENDING;
        }
        self::completeLogin((int) $row['id']);
        return null;
    }

    /** پس از موفقیت رمز (و در صورت فعال‌بودن، کد دومرحله‌ای) نشست کاربر را می‌سازد */
    public static function completeLogin(int $userId): void
    {
        session_regenerate_id(true);
        unset($_SESSION['mfa_uid'], $_SESSION['mfa_user'], $_SESSION['mfa_at']);
        $_SESSION['uid'] = $userId;
        $_SESSION['last'] = time();
        $_SESSION['ua'] = self::fingerprint();
        unset($_SESSION['_csrf']);
        Database::exec('UPDATE users SET last_login_at = ? WHERE id = ?', [date('Y-m-d H:i:s'), $userId]);
        self::$loaded = false;
        self::user();
        Audit::log('auth.login', 'user', $userId);
    }

    /** شناسه‌ی کاربری که رمزش درست بوده و منتظر کد دومرحله‌ای است (بدون انقضا) */
    public static function pendingMfaUser(): ?array
    {
        $uid = (int) ($_SESSION['mfa_uid'] ?? 0);
        if ($uid === 0 || (time() - (int) ($_SESSION['mfa_at'] ?? 0)) > self::MFA_TTL) {
            unset($_SESSION['mfa_uid'], $_SESSION['mfa_user'], $_SESSION['mfa_at']);
            return null;
        }
        return ['id' => $uid, 'username' => (string) ($_SESSION['mfa_user'] ?? '')];
    }

    public static function logout(): void
    {
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
        self::$user = null;
        self::$loaded = true;
        self::$perms = [];
    }

    private static function fingerprint(): string
    {
        return hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
    }
}
