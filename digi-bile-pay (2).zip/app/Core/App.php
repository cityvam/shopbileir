<?php
declare(strict_types=1);

namespace App\Core;

final class App
{
    public static function run(): void
    {
        header('X-Frame-Options: DENY');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: same-origin');
        header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; frame-ancestors 'none'; form-action 'self'");

        Session::start();
        $_GET = self::normalize($_GET);
        $_POST = self::normalize($_POST);

        $router = new Router();
        (require BASE_PATH . '/routes/web.php')($router);

        try {
            $router->dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $_SERVER['REQUEST_URI'] ?? '/');
        } catch (HttpException $e) {
            self::error($e->status);
        } catch (\Throwable $e) {
            @file_put_contents(
                BASE_PATH . '/storage/logs/app.log',
                sprintf("[%s] %s in %s:%d\n", date('c'), $e->getMessage(), $e->getFile(), $e->getLine()),
                FILE_APPEND
            );
            if (Env::get('APP_DEBUG') === '1') {
                http_response_code(500);
                echo '<pre>' . htmlspecialchars((string) $e) . '</pre>';
                return;
            }
            self::error(500);
        }
    }

    private static function error(int $status): void
    {
        http_response_code($status);
        $known = [403, 404, 419, 500];
        $view = in_array($status, $known, true) ? 'errors/' . $status : 'errors/404';
        $layout = Auth::check() ? 'app' : 'auth';
        View::render($view, ['title' => 'خطا'], 'error', $layout);
    }

    /** فیلدهایی که ارقام فارسی/عربی آن‌ها به لاتین تبدیل می‌شود؛ متن آزاد (نام‌ها، رمز) دست‌نخورده می‌ماند */
    private const NUMERIC_FIELDS = [
        'national_code', 'mobile', 'credit_limit', 'amount', 'months', 'annual_rate_percent', 'fee_percent', 'late_fee_daily_percent',
        'min_amount', 'max_amount', 'page', 'q', 'customer_id', 'plan_id', 'role_id', 'parent_id', 'merchant_id', 'product_id',
        'from', 'to', 'min', 'max', 'credit_min', 'credit_max', 'debt_min', 'debt_max', 'un_min', 'un_max', 'user_id', 'statement_date', 'statement_balance', 'until', 'issue_date', 'due_date', 'no_from', 'no_to', 'requested_amount', 'plan_id', 'plan', 'commission_percent', 'price', 'stock', 'qty', 'debit', 'credit', 'entry_date', 'promise_date', 'account_id', 'code', 'sku',
    ];

    private static function normalize(array $in, bool $force = false): array
    {
        $map = [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ];
        $out = [];
        foreach ($in as $k => $v) {
            $numeric = $force || in_array($k, self::NUMERIC_FIELDS, true);
            if (is_array($v)) {
                $out[$k] = self::normalize($v, $numeric);
            } elseif (is_string($v) && $numeric) {
                $out[$k] = strtr($v, $map);
            } else {
                $out[$k] = $v;
            }
        }
        return $out;
    }
}
