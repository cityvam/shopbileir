<?php
declare(strict_types=1);

namespace App\Core;

final class View
{
    private static array $old = [];

    public static function old(string $key, string $default = ''): string
    {
        $v = self::$old[$key] ?? $default;
        return is_scalar($v) ? (string) $v : $default;
    }

    public static function oldArray(string $key): array
    {
        $v = self::$old[$key] ?? [];
        return is_array($v) ? $v : [];
    }

    /**
     * @param string $view  مسیر نسبی داخل resources/views بدون پسوند
     * @param array  $data  متغیرهای قالب
     * @param string $page  نام صفحه؛ CSS اختصاصی assets/css/pages/{page}.css بارگذاری می‌شود
     */
    public static function render(string $view, array $data, string $page, string $layout = 'app'): void
    {
        self::$old = $_SESSION['_old'] ?? [];
        unset($_SESSION['_old']);

        $file = BASE_PATH . '/resources/views/' . $view . '.php';
        extract($data, EXTR_SKIP);
        ob_start();
        require $file;
        $content = ob_get_clean();

        $flashes = Session::pullFlash();
        $path = rtrim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/') ?: '/';
        $menu = $layout === 'app' ? Menu::forUser($path) : [];
        $title = $data['title'] ?? 'دیجی بایل پی';
        require BASE_PATH . '/resources/layouts/' . $layout . '.php';
    }

    /** نمایش یک partial مثل صفحه‌بندی */
    public static function partial(string $name, array $data = []): void
    {
        extract($data, EXTR_SKIP);
        require BASE_PATH . '/resources/views/components/' . $name . '.php';
    }
}
