<?php
declare(strict_types=1);

namespace App\Core;

/** تبدیل تاریخ میلادی/شمسی. دیتابیس همیشه میلادی است و فقط نمایش شمسی است. */
final class Jalali
{
    public static function toJalali(int $gy, int $gm, int $gd): array
    {
        $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        $gy2 = $gm > 2 ? $gy + 1 : $gy;
        $days = 355666 + (365 * $gy) + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100)
            + intdiv($gy2 + 399, 400) + $gd + $gdm[$gm - 1];
        $jy = -1595 + (33 * intdiv($days, 12053));
        $days %= 12053;
        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;
        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }
        return [$jy, $jm, $jd];
    }

    public static function toGregorian(int $jy, int $jm, int $jd): array
    {
        $jy += 1595;
        $days = -355668 + (365 * $jy) + intdiv($jy, 33) * 8 + intdiv(($jy % 33) + 3, 4) + $jd
            + ($jm < 7 ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);
        $gy = 400 * intdiv($days, 146097);
        $days %= 146097;
        if ($days > 36524) {
            $gy += 100 * intdiv(--$days, 36524);
            $days %= 36524;
            if ($days >= 365) {
                $days++;
            }
        }
        $gy += 4 * intdiv($days, 1461);
        $days %= 1461;
        if ($days > 365) {
            $gy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }
        $gd = $days + 1;
        $leap = (($gy % 4 === 0 && $gy % 100 !== 0) || $gy % 400 === 0);
        $sal = [0, 31, $leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        for ($gm = 0; $gm < 13 && $gd > $sal[$gm]; $gm++) {
            $gd -= $sal[$gm];
        }
        return [$gy, $gm, $gd];
    }

    public static function isLeap(int $jy): bool
    {
        [$gy, $gm, $gd] = self::toGregorian($jy, 12, 30);
        return self::toJalali($gy, $gm, $gd) === [$jy, 12, 30];
    }

    public static function daysInMonth(int $jy, int $jm): int
    {
        if ($jm <= 6) {
            return 31;
        }
        if ($jm <= 11) {
            return 30;
        }
        return self::isLeap($jy) ? 30 : 29;
    }

    /** نمایش شمسی یک تاریخ/زمان میلادی دیتابیس */
    public static function format(string $dbDate, bool $withTime = false): string
    {
        $ts = strtotime($dbDate);
        if ($ts === false) {
            return $dbDate;
        }
        [$jy, $jm, $jd] = self::toJalali((int) date('Y', $ts), (int) date('n', $ts), (int) date('j', $ts));
        $out = sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
        if ($withTime) {
            $out .= ' ' . date('H:i', $ts);
        }
        return $out;
    }

    public const MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

    /** ورودی شمسی yyyy/mm/dd (یا با خط تیره) → تاریخ میلادی Y-m-d؛ نامعتبر = null */
    public static function parse(string $s): ?string
    {
        if (!preg_match('#^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$#', trim($s), $m)) {
            return null;
        }
        [$jy, $jm, $jd] = [(int) $m[1], (int) $m[2], (int) $m[3]];
        if ($jy < 1300 || $jy > 1500 || $jm < 1 || $jm > 12 || $jd < 1 || $jd > self::daysInMonth($jy, $jm)) {
            return null;
        }
        [$gy, $gm, $gd] = self::toGregorian($jy, $jm, $jd);
        return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
    }

    /** [سال، ماه] شمسی یک تاریخ میلادی */
    public static function yearMonth(string $ymd): array
    {
        [$gy, $gm, $gd] = array_map('intval', explode('-', substr($ymd, 0, 10)));
        [$jy, $jm] = self::toJalali($gy, $gm, $gd);
        return [$jy, $jm];
    }

    /** افزودن ماه شمسی به تاریخ میلادی Y-m-d و بازگشت تاریخ میلادی Y-m-d */
    public static function addMonths(string $ymd, int $n): string
    {
        [$gy, $gm, $gd] = array_map('intval', explode('-', substr($ymd, 0, 10)));
        [$jy, $jm, $jd] = self::toJalali($gy, $gm, $gd);
        $t = ($jm - 1) + $n;
        $jy += intdiv($t, 12);
        $jm = ($t % 12) + 1;
        $jd = min($jd, self::daysInMonth($jy, $jm));
        [$ny, $nm, $nd] = self::toGregorian($jy, $jm, $jd);
        return sprintf('%04d-%02d-%02d', $ny, $nm, $nd);
    }
}
