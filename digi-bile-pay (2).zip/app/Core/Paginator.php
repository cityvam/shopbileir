<?php
declare(strict_types=1);

namespace App\Core;

final class Paginator
{
    public static function make(int $total, int $page, int $per = 20): array
    {
        $pages = max(1, (int) ceil($total / $per));
        $page = min(max(1, $page), $pages);
        return ['page' => $page, 'pages' => $pages, 'per' => $per, 'offset' => ($page - 1) * $per, 'total' => $total];
    }
}
