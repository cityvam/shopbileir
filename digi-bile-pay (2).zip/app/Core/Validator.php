<?php
declare(strict_types=1);

namespace App\Core;

final class Validator
{
    public static function nationalCode(string $c): bool
    {
        if (!preg_match('/^\d{10}$/', $c) || preg_match('/^(\d)\1{9}$/', $c)) {
            return false;
        }
        $sum = 0;
        for ($i = 0; $i < 9; $i++) {
            $sum += (int) $c[$i] * (10 - $i);
        }
        $r = $sum % 11;
        $check = (int) $c[9];
        return $r < 2 ? $check === $r : $check === 11 - $r;
    }

    public static function mobile(string $m): bool
    {
        return (bool) preg_match('/^09\d{9}$/', $m);
    }

    /** مبلغ ریالی: فقط ارقام؛ صفر یا مقدار نامعتبر → null */
    public static function amount(string $s): ?int
    {
        $d = preg_replace('/\D/', '', $s) ?? '';
        if ($d === '' || strlen($d) > 13) {
            return null;
        }
        $n = (int) $d;
        return $n > 0 ? $n : null;
    }

    public static function percent(string $s): ?float
    {
        $s = str_replace(['٫', ','], '.', trim($s));
        if (!is_numeric($s)) {
            return null;
        }
        $f = (float) $s;
        return ($f >= 0 && $f <= 100) ? round($f, 2) : null;
    }

    public static function password(string $p): ?string
    {
        if (mb_strlen($p) < 10) {
            return 'رمز عبور باید حداقل ۱۰ نویسه باشد.';
        }
        if (!preg_match('/[A-Za-z]/', $p) || !preg_match('/\d/', $p)) {
            return 'رمز عبور باید شامل حرف و عدد باشد.';
        }
        return null;
    }
}
