<?php
declare(strict_types=1);

namespace App\Core;

/** خروجی CSV با UTF-8 BOM (برای Excel فارسی) و جلوگیری از CSV Injection */
final class Csv
{
    /** درخواست خروجی (csv یا xlsx)؟ */
    public static function wanted(?string $format): bool
    {
        return in_array($format, ['csv', 'xlsx'], true);
    }

    /** @param list<string> $header  @param iterable<list<string|int|float|null>> $rows */
    public static function send(string $filename, array $header, iterable $rows): never
    {
        if (($_GET['format'] ?? '') === 'xlsx') {
            $name = preg_replace('/[^A-Za-z0-9._-]/', '_', preg_replace('/\.csv$/', '', $filename)) . '.xlsx';
            $file = Xlsx::write($header, $rows, 'گزارش');
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $name . '"');
            header('Content-Length: ' . (int) filesize($file));
            header('X-Content-Type-Options: nosniff');
            readfile($file);
            @unlink($file);
            exit;
        }
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) . '"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, $header);
        foreach ($rows as $row) {
            fputcsv($out, array_map([self::class, 'safe'], $row));
        }
        fclose($out);
        exit;
    }

    private static function safe(mixed $v): string
    {
        $v = (string) ($v ?? '');
        return $v !== '' && str_contains('=+-@', $v[0]) && !is_numeric($v) ? "'" . $v : $v;
    }
}
