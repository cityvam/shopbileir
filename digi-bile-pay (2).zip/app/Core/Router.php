<?php
declare(strict_types=1);

namespace App\Core;

final class Router
{
    private array $routes = [];

    public function get(string $path, array $handler, ?string $perm = null, bool $public = false): void
    {
        $this->add('GET', $path, $handler, $perm, $public);
    }

    public function post(string $path, array $handler, ?string $perm = null, bool $public = false): void
    {
        $this->add('POST', $path, $handler, $perm, $public);
    }

    private function add(string $method, string $path, array $handler, ?string $perm, bool $public): void
    {
        $regex = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>[0-9]+)', $path) . '$#';
        $this->routes[] = compact('method', 'regex', 'handler', 'perm', 'public');
    }

    public function dispatch(string $method, string $uri): void
    {
        $path = rtrim((string) parse_url($uri, PHP_URL_PATH), '/') ?: '/';
        $pathMatched = false;
        foreach ($this->routes as $r) {
            if (!preg_match($r['regex'], $path, $m)) {
                continue;
            }
            $pathMatched = true;
            if ($r['method'] !== $method) {
                continue;
            }
            if (!$r['public'] && !Auth::check()) {
                header('Location: /login');
                return;
            }
            if ($r['perm'] !== null && !Auth::can($r['perm'])) {
                throw new HttpException(403);
            }
            if ($method === 'POST' && !Csrf::valid($_POST['_csrf'] ?? null)) {
                throw new HttpException(419);
            }
            $params = array_filter($m, 'is_string', ARRAY_FILTER_USE_KEY);
            [$class, $action] = $r['handler'];
            (new $class())->$action(array_map('intval', $params));
            return;
        }
        throw new HttpException($pathMatched ? 405 : 404);
    }
}
