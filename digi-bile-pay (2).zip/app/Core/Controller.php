<?php
declare(strict_types=1);

namespace App\Core;

abstract class Controller
{
    protected function view(string $view, array $data, string $page, string $layout = 'app'): void
    {
        View::render($view, $data, $page, $layout);
    }

    protected function redirect(string $to): never
    {
        header('Location: ' . $to);
        exit;
    }

    protected function flash(string $type, string $message): void
    {
        Session::flash($type, $message);
    }

    protected function input(string $key, string $default = ''): string
    {
        $v = $_POST[$key] ?? $_GET[$key] ?? $default;
        return is_string($v) ? trim($v) : $default;
    }

    protected function fail(string $to, array $errors): never
    {
        foreach ($errors as $e) {
            Session::flash('error', $e);
        }
        $old = $_POST;
        unset($old['_csrf'], $old['password'], $old['admin_password']);
        $_SESSION['_old'] = $old;
        $this->redirect($to);
    }

    protected function cid(): int
    {
        return Auth::companyId();
    }

    protected function notFound(): never
    {
        throw new HttpException(404);
    }
}
