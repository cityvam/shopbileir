<?php
declare(strict_types=1);

use App\Core\Csrf;
use App\Core\Jalali;
use App\Core\View;

function e(mixed $v): string
{
    return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function fa(string|int|float $s): string
{
    return strtr((string) $s, ['0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹']);
}

function money(int $n): string
{
    return fa(number_format($n)) . ' ریال';
}

/** مبلغ با واحد کم‌رنگ و کوچک‌تر (برای کارت‌های آماری) */
function money_unit(int $n): string
{
    return fa(number_format($n)) . '<span class="unit">ریال</span>';
}

function num(int $n): string
{
    return fa(number_format($n));
}

function jdate(?string $d, bool $time = false): string
{
    return $d ? fa(Jalali::format($d, $time)) : '—';
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(Csrf::token()) . '">';
}

function asset(string $path): string
{
    $file = BASE_PATH . '/public/assets/' . $path;
    return '/assets/' . $path . (is_file($file) ? '?v=' . filemtime($file) : '');
}

function old(string $key, string $default = ''): string
{
    return View::old($key, $default);
}

function badge(string $text, string $tone): string
{
    return '<span class="badge badge--' . e($tone) . '">' . e($text) . '</span>';
}

function status_badge(string $kind, string $value): string
{
    static $map = [
        'loan' => [
            'pending' => ['در انتظار تأیید', 'warn'], 'active' => ['فعال', 'ok'],
            'rejected' => ['ردشده', 'bad'], 'closed' => ['تسویه‌شده', 'muted'],
        ],
        'installment' => [
            'due' => ['پرداخت‌نشده', 'warn'], 'partial' => ['پرداخت جزئی', 'info'], 'paid' => ['پرداخت‌شده', 'ok'],
        ],
        'order' => [
            'pending' => ['در انتظار', 'warn'], 'confirmed' => ['تأییدشده', 'ok'], 'cancelled' => ['لغوشده', 'bad'],
        ],
        'lead' => [
            'new' => ['جدید', 'info'], 'contacted' => ['پیگیری شد', 'warn'], 'qualified' => ['واجد شرایط', 'ok'], 'converted' => ['تبدیل به مشتری', 'ok'], 'rejected' => ['ردشده', 'bad'],
        ],
        'entity' => [
            'active' => ['فعال', 'ok'], 'suspended' => ['تعلیق', 'bad'], 'blocked' => ['مسدود', 'bad'],
            'disabled' => ['غیرفعال', 'muted'],
            'in_hand' => ['نزد صندوق', 'info'], 'deposited' => ['واگذار به بانک', 'warn'], 'cleared' => ['وصول‌شده', 'ok'], 'bounced' => ['برگشتی', 'bad'], 'endorsed' => ['پشت‌نویسی‌شده', 'muted'],
            'issued' => ['صادرشده', 'info'], 'new' => ['جدید', 'info'], 'contacted' => ['پیگیری شد', 'warn'], 'qualified' => ['واجد شرایط', 'ok'], 'converted' => ['تبدیل به مشتری', 'ok'], 'rejected' => ['ردشده', 'bad'], 'passed' => ['پاس‌شده', 'ok'], 'cancelled' => ['ابطال‌شده', 'muted'],
        ],
    ];
    [$label, $tone] = $map[$kind][$value] ?? [$value, 'muted'];
    return badge($label, $tone);
}

function icon(string $name, int $size = 20): string
{
    static $paths = [
        'dashboard' => '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
        'building' => '<path d="M4 21V4a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v17M15 9h4a1 1 0 0 1 1 1v11M3 21h18M8 7h3M8 11h3M8 15h3"/>',
        'users' => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.4 3.2-5.5 6.5-5.5s5.9 2.1 6.5 5.5M16 4.8a3.5 3.5 0 0 1 0 6.4M18 14.8c1.9.6 3.2 2.3 3.5 5.2"/>',
        'shield' => '<path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
        'id-card' => '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.4-1.6 1.6-2.4 3-2.4s2.6.8 3 2.4M14 10h4M14 13h3"/>',
        'tag' => '<path d="M3 12V4a1 1 0 0 1 1-1h8l9 9-9 9-9-9z"/><circle cx="8" cy="8" r="1.2"/>',
        'file-text' => '<path d="M6 3h8l5 5v12a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M14 3v5h5M8 13h8M8 17h6"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
        'clipboard' => '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4h6v3H9zM9 12h6M9 16h4"/>',
        'wallet' => '<path d="M4 7a2 2 0 0 1 2-2h12v4"/><rect x="3" y="7" width="18" height="13" rx="2"/><circle cx="16.5" cy="13.5" r="1.2"/>',
        'logout' => '<path d="M9 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h4M16 8l4 4-4 4M20 12H9"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'check' => '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
        'x' => '<path d="M6 6l12 12M18 6L6 18"/>',
        'eye' => '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'edit' => '<path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/>',
        'search' => '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
        'menu' => '<path d="M4 7h16M4 12h16M4 17h16"/>',
        'trash' => '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
        'alert' => '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18v.5"/>',
        'store' => '<path d="M4 9l1.5-5h13L20 9M4 9v11h16V9M4 9c0 1.7 1.3 3 3 3s3-1.3 3-3c0 1.7 1.3 3 3 3s3-1.3 3-3c0 1.7 1.3 3 3 3"/><path d="M10 20v-5h4v5"/>',
        'box' => '<path d="M3 7l9-4 9 4-9 4-9-4z"/><path d="M3 7v10l9 4 9-4V7M12 11v10"/>',
        'cart' => '<circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/><path d="M3 4h2.5l2.2 10.5h10l2-7.5H6.5"/>',
        'book' => '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3V4z"/><path d="M5 17a3 3 0 0 1 3-3h11M9 8h6"/>',
        'scale' => '<path d="M12 4v16M7 20h10M5 7h14"/><path d="M5 7l-3 7a3.5 3.5 0 0 0 6 0L5 7zM19 7l-3 7a3.5 3.5 0 0 0 6 0l-3-7z"/>',
        'chart' => '<path d="M4 20V4M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
        'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4 4-6 8-6s7.2 2 8 6"/>',
        'key' => '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
        'upload' => '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
        'download' => '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
        'note' => '<path d="M5 4h14v12l-5 5H5V4z"/><path d="M14 21v-5h5M8 9h8M8 13h4"/>',
        'sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M18.4 5.6L17 7M7 17l-1.4 1.4"/>',
        'moon' => '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
        'home' => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
        'arrow-left' => '<path d="M19 12H5M11 6l-6 6 6 6"/>',
        'phone' => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
        'pin' => '<path d="M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
        'lock' => '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        'zap' => '<path d="M13 3L5 14h6l-1 7 8-11h-6l1-7z"/>',
        'refresh' => '<path d="M20 12a8 8 0 1 1-2.5-5.8M20 4v5h-5"/>',
        'bell' => '<path d="M6 9a6 6 0 0 1 12 0c0 6 2.5 7.5 2.5 7.5h-17S6 15 6 9z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'banknote' => '<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 9v.01M18 15v.01"/>',
        'logo' => '<rect x="3" y="3" width="18" height="18" rx="5"/><path d="M8 15V9h3.2a3 3 0 0 1 0 6H8zM15.5 9v6"/>',
    ];
    $p = $paths[$name] ?? '';
    return '<svg class="icon" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}

/** برچسب فارسی فیلدها برای نمایش تاریخچه تغییرات */
function field_label(string $key): string
{
    static $m = [
        'full_name' => 'نام', 'mobile' => 'موبایل', 'credit_limit' => 'سقف اعتبار', 'name' => 'نام', 'contact_name' => 'رابط',
        'commission_percent' => 'کارمزد٪', 'price' => 'قیمت', 'sku' => 'کد کالا', 'stock' => 'موجودی', 'months' => 'تعداد اقساط',
        'annual_rate_percent' => 'نرخ سالانه٪', 'fee_percent' => 'کارمزد صدور٪', 'late_fee_daily_percent' => 'جریمه روزانه٪',
        'min_amount' => 'حداقل مبلغ', 'max_amount' => 'حداکثر مبلغ', 'role_id' => 'نقش', 'status' => 'وضعیت', 'code' => 'کد',
        'parent_id' => 'حساب پدر', 'is_active' => 'فعال', 'description' => 'توضیحات', 'national_code' => 'کد ملی',
    ];
    return $m[$key] ?? $key;
}

/** برچسب فارسی رویدادهای حسابرسی */
function action_label(string $action): string
{
    static $m = [
        'customer.create' => 'ثبت مشتری', 'customer.update' => 'ویرایش مشتری', 'customer.import' => 'درون‌ریزی گروهی مشتریان', 'lead.create' => 'ثبت درخواست اعتبار از سایت', 'lead.status' => 'تغییر وضعیت درخواست اعتبار', 'customer.status' => 'تغییر وضعیت مشتری', 'wallet.topup' => 'شارژ کیف پول', 'payreq.create' => 'ساخت لینک پرداخت', 'payreq.cancel' => 'لغو لینک پرداخت', 'payreq.failed' => 'پرداخت آنلاین ناموفق',
        'merchant.create' => 'ثبت فروشنده', 'merchant.update' => 'ویرایش فروشنده', 'merchant.status' => 'تغییر وضعیت فروشنده', 'merchant.settle' => 'تسویه فروشنده',
        'product.create' => 'ثبت محصول', 'product.update' => 'ویرایش محصول', 'product.status' => 'تغییر وضعیت محصول', 'product.stock' => 'تعدیل موجودی',
        'plan.create' => 'ثبت طرح', 'plan.update' => 'ویرایش طرح', 'plan.status' => 'تغییر وضعیت طرح',
        'user.create' => 'ثبت کاربر', 'user.update' => 'ویرایش کاربر', 'user.status' => 'تغییر وضعیت کاربر',
        'loan.request' => 'درخواست تسهیلات', 'loan.approve' => 'تأیید تسهیلات', 'loan.reject' => 'رد تسهیلات', 'loan.payoff' => 'تسویه زودهنگام',
        'order.create' => 'ثبت سفارش', 'note.add' => 'افزودن یادداشت', 'note.edit' => 'ویرایش یادداشت', 'note.delete' => 'حذف یادداشت', 'note.pin' => 'سنجاق یادداشت',
        'collection.note' => 'یادداشت وصول', 'installment.pay' => 'پرداخت قسط', 'account.update' => 'ویرایش حساب', 'reconcile.create' => 'ثبت تطبیق بانکی', 'reconcile.undo' => 'لغو تطبیق بانکی', 'cheque.create' => 'ثبت چک', 'cheque.update' => 'ویرایش چک', 'cheque.status' => 'تغییر وضعیت چک', 'cheque.endorse' => 'پشت‌نویسی چک', 'site.update' => 'ویرایش محتوای صفحه‌ی اصلی', 'cheque.unendorse' => 'بازگشت پشت‌نویسی چک', 'reconcile.import' => 'ورود صورت‌حساب بانکی', 'notify.run' => 'اجرای یادآوری و ارسال پیامک', 'notify.manual' => 'پیامک دستی به مشتری', 'dimension.create' => 'ثبت تفصیلی/مرکز هزینه', 'dimension.update' => 'ویرایش تفصیلی/مرکز هزینه', 'dimension.status' => 'تغییر وضعیت', 'mfa.enable' => 'فعال‌سازی تأیید دومرحله‌ای', 'mfa.disable' => 'غیرفعال‌سازی تأیید دومرحله‌ای', 'mfa.reset' => 'بازنشانی تأیید دومرحله‌ای', 'mfa.recovery_used' => 'استفاده از کد بازیابی', 'mfa.recovery_regen' => 'تولید مجدد کدهای بازیابی',
    ];
    return $m[$action] ?? $action;
}
