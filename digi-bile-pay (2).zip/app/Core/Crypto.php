<?php
declare(strict_types=1);

namespace App\Core;

/** رمزنگاری متقارن (AES-256-GCM) برای رازهای ذخیره‌شده در دیتابیس؛ کلید از APP_KEY یا فایل storage/app.key */
final class Crypto
{
    public static function encrypt(string $plain): string
    {
        $iv = random_bytes(12);
        $tag = '';
        $ct = openssl_encrypt($plain, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag);
        return base64_encode($iv . $tag . $ct);
    }

    public static function decrypt(string $blob): ?string
    {
        $raw = base64_decode($blob, true);
        if ($raw === false || strlen($raw) < 29) {
            return null;
        }
        $pt = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
        return $pt === false ? null : $pt;
    }

    private static function key(): string
    {
        $k = Env::get('APP_KEY', '');
        if ($k === '' || $k === null) {
            $file = BASE_PATH . '/storage/app.key';
            if (!is_file($file)) {
                file_put_contents($file, bin2hex(random_bytes(32)));
                @chmod($file, 0600);
            }
            $k = trim((string) file_get_contents($file));
        }
        return hash('sha256', (string) $k, true);
    }
}
