<?php
declare(strict_types=1);

namespace App\Core;

/**
 * کپچای عددی ۶ رقمی. تصویر SVG سمت سرور ساخته می‌شود (بدون وابستگی به GD/CDN)،
 * کد فقط در نشست سرور نگه‌داری می‌شود، یک‌بارمصرف است و پس از ۵ دقیقه منقضی می‌شود.
 */
final class Captcha
{
    public const SCOPES = ['login', 'apply', 'portal'];
    private const TTL = 300;

    /** خطوط هر رقم روی شبکه‌ی ۰..۱ */
    private const GLYPHS = [
        '1' => [[[.25, .28], [.55, 0], [.55, 1]]],
        '2' => [[[.1, .25], [.22, .05], [.5, 0], [.8, .1], [.85, .35], [.1, 1], [.9, 1]]],
        '3' => [[[.1, .1], [.5, 0], [.85, .15], [.8, .4], [.4, .5], [.85, .6], [.9, .85], [.5, 1], [.1, .9]]],
        '4' => [[[.7, 1], [.7, 0], [.05, .7], [.95, .7]]],
        '5' => [[[.85, 0], [.15, 0], [.1, .45], [.55, .4], [.9, .6], [.85, .9], [.5, 1], [.1, .9]]],
        '6' => [[[.8, .05], [.4, 0], [.1, .4], [.1, .8], [.45, 1], [.85, .85], [.8, .55], [.45, .5], [.12, .65]]],
        '7' => [[[.1, 0], [.9, 0], [.4, 1]]],
        '8' => [[[.5, .5], [.15, .3], [.3, .05], [.7, .05], [.85, .3], [.5, .5], [.12, .75], [.3, .98], [.7, .98], [.88, .75], [.5, .5]]],
    ];

    public static function valid(string $scope): bool
    {
        return in_array($scope, self::SCOPES, true);
    }

    /** کد جدید می‌سازد و در نشست می‌گذارد. */
    public static function issue(string $scope): string
    {
        $code = '';
        for ($i = 0; $i < 6; $i++) {
            $code .= (string) random_int(0, 9);
        }
        $_SESSION['_captcha'][$scope] = ['code' => $code, 'exp' => time() + self::TTL];
        return $code;
    }

    /** بررسی یک‌بارمصرف: پس از هر بار تلاش (درست یا غلط) کد باطل می‌شود. */
    public static function verify(string $scope, ?string $input): bool
    {
        $rec = $_SESSION['_captcha'][$scope] ?? null;
        unset($_SESSION['_captcha'][$scope]);
        if (!is_array($rec) || ($rec['exp'] ?? 0) < time()) {
            return false;
        }
        $in = strtr((string) $input, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9']);
        $in = preg_replace('/\s+/', '', $in) ?? '';
        return preg_match('/^\d{6}$/', $in) === 1 && hash_equals((string) $rec['code'], $in);
    }

    private static function rnd(float $a, float $b): float
    {
        return $a + (random_int(0, 10000) / 10000) * ($b - $a);
    }

    /** تصویر SVG کد داده‌شده. */
    public static function svg(string $code): string
    {
        $w = 200;
        $h = 68;
        $palette = ['#4338ca', '#6d28d9', '#0f766e', '#be185d', '#1d4ed8', '#b45309'];
        $o = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $w . ' ' . $h . '" width="' . $w . '" height="' . $h . '" role="img" aria-label="کد امنیتی ۶ رقمی">';
        $o .= '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#eef0ff"/><stop offset="1" stop-color="#f6ecff"/></linearGradient></defs>';
        $o .= '<rect width="' . $w . '" height="' . $h . '" rx="' . ($h / 2) . '" fill="url(#g)"/>';
        // نویز پس‌زمینه
        for ($i = 0; $i < 5; $i++) {
            $c = $palette[array_rand($palette)];
            $o .= sprintf('<path d="M%.1f %.1f C%.1f %.1f %.1f %.1f %.1f %.1f" fill="none" stroke="%s" stroke-opacity=".35" stroke-width="%.1f"/>',
                self::rnd(0, 30), self::rnd(8, $h - 8), self::rnd(50, 90), self::rnd(0, $h), self::rnd(110, 150), self::rnd(0, $h), self::rnd(170, $w), self::rnd(8, $h - 8), $c, self::rnd(1, 2.2));
        }
        for ($i = 0; $i < 40; $i++) {
            $o .= sprintf('<circle cx="%.1f" cy="%.1f" r="%.1f" fill="%s" fill-opacity=".4"/>', self::rnd(8, $w - 8), self::rnd(4, $h - 4), self::rnd(.6, 1.6), $palette[array_rand($palette)]);
        }
        // رقم‌ها
        $cell = ($w - 40) / 6;
        $gw = 15.0;
        $gh = 30.0;
        for ($i = 0; $i < 6; $i++) {
            $ch = $code[$i];
            $strokes = $ch === '0' ? [self::ellipse()] : ($ch === '9' ? [array_map(static fn ($p) => [1 - $p[0], 1 - $p[1]], self::GLYPHS['6'][0])] : self::GLYPHS[$ch]);
            $cx = 20 + $cell * $i + $cell / 2 + self::rnd(-2, 2);
            $cy = $h / 2 + self::rnd(-4, 4);
            $rot = self::rnd(-20, 20);
            $skew = self::rnd(-.25, .25);
            $sc = self::rnd(.9, 1.12);
            $col = $palette[array_rand($palette)];
            $d = '';
            foreach ($strokes as $pts) {
                $tp = [];
                foreach ($pts as [$x, $y]) {
                    $tp[] = [(($x - .5) * $gw + ($y - .5) * $gh * $skew) * $sc + self::rnd(-.9, .9), (($y - .5) * $gh) * $sc + self::rnd(-.9, .9)];
                }
                $d .= self::smooth($tp);
            }
            $o .= sprintf('<path transform="translate(%.1f %.1f) rotate(%.1f)" d="%s" fill="none" stroke="%s" stroke-width="%.1f" stroke-linecap="round" stroke-linejoin="round"/>', $cx, $cy, $rot, $d, $col, self::rnd(3, 3.8));
        }
        // خط‌های مزاحم روی رقم‌ها
        for ($i = 0; $i < 3; $i++) {
            $o .= sprintf('<path d="M%.1f %.1f Q%.1f %.1f %.1f %.1f" fill="none" stroke="%s" stroke-opacity=".55" stroke-width="1.4"/>',
                self::rnd(0, 40), self::rnd(10, $h - 10), self::rnd(70, 130), self::rnd(0, $h), self::rnd(160, $w), self::rnd(10, $h - 10), $palette[array_rand($palette)]);
        }
        return $o . '</svg>';
    }

    private static function ellipse(): array
    {
        $p = [];
        for ($i = 0; $i <= 12; $i++) {
            $a = 2 * M_PI * $i / 12;
            $p[] = [.5 + .42 * cos($a), .5 + .5 * sin($a)];
        }
        return $p;
    }

    /** منحنی هموار از میان نقاط (درجه‌ی دو با نقطه‌ی میانی). */
    private static function smooth(array $p): string
    {
        $n = count($p);
        $d = sprintf('M%.1f %.1f', $p[0][0], $p[0][1]);
        for ($i = 1; $i < $n - 1; $i++) {
            $mx = ($p[$i][0] + $p[$i + 1][0]) / 2;
            $my = ($p[$i][1] + $p[$i + 1][1]) / 2;
            $d .= sprintf('Q%.1f %.1f %.1f %.1f', $p[$i][0], $p[$i][1], $mx, $my);
        }
        return $d . sprintf('L%.1f %.1f', $p[$n - 1][0], $p[$n - 1][1]);
    }
}
