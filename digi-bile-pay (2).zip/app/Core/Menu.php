<?php
declare(strict_types=1);

namespace App\Core;

/** منوی سایدبار از دیتابیس خوانده و بر اساس مجوز کاربر فیلتر می‌شود */
final class Menu
{
    public static function forUser(string $currentPath): array
    {
        $items = Database::all('SELECT menu_key, title, icon, url, permission, section FROM menu_items WHERE is_active = 1 ORDER BY sort_order');
        $out = [];
        foreach ($items as $it) {
            if ($it['permission'] && !Auth::can($it['permission'])) {
                continue;
            }
            $it['active'] = $currentPath === $it['url'] || str_starts_with($currentPath, $it['url'] . '/');
            $out[] = $it;
        }
        return $out;
    }
}
