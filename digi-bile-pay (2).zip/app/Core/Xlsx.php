<?php
declare(strict_types=1);

namespace App\Core;

/**
 * خواندن ساده‌ی اولین برگه‌ی فایل Excel (.xlsx) و تبدیل به CSV؛ بدون کتابخانه‌ی بیرونی.
 * محدودیت‌ها: فقط .xlsx (نه .xls)، فرمول‌ها با مقدار ذخیره‌شده خوانده می‌شوند، ترکیب سلول‌ها نادیده گرفته می‌شود.
 * ایمنی: حجم باز‌شده‌ی هر بخش محدود است (ضد زیپ‌بمب)، فقط بخش‌های لازم خوانده می‌شود و XML بدون دسترسی شبکه پردازش می‌شود.
 */
final class Xlsx
{
    private const MAX_PART = 8 * 1024 * 1024;
    public const MAX_ROWS = 5000;

    public static function isXlsx(string $path): bool
    {
        $h = (string) @file_get_contents($path, false, null, 0, 4);
        return $h === "PK\x03\x04";
    }

    /** @throws UserError */
    public static function toCsv(string $path): string
    {
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) {
            throw new UserError('فایل Excel معتبر نیست.');
        }
        try {
            $sheetName = self::firstSheetPath($zip);
            $shared = [];
            if (($x = self::part($zip, 'xl/sharedStrings.xml')) !== null) {
                foreach ($x->si as $si) {
                    $t = '';
                    if (isset($si->t)) {
                        $t = (string) $si->t;
                    } else {
                        foreach ($si->r as $r) {
                            $t .= (string) $r->t;
                        }
                    }
                    $shared[] = $t;
                }
            }
            $sheet = self::part($zip, $sheetName) ?? throw new UserError('برگه‌ی اول فایل Excel پیدا نشد.');
            $rows = [];
            foreach ($sheet->sheetData->row ?? [] as $row) {
                if (count($rows) >= self::MAX_ROWS) {
                    throw new UserError('حداکثر ' . self::MAX_ROWS . ' سطر در هر فایل مجاز است.');
                }
                $cells = [];
                foreach ($row->c as $c) {
                    $col = self::colIndex((string) $c['r']);
                    $type = (string) $c['t'];
                    $v = (string) $c->v;
                    if ($type === 's') {
                        $v = $shared[(int) $v] ?? '';
                    } elseif ($type === 'inlineStr') {
                        $v = (string) $c->is->t;
                    } elseif ($type === 'b') {
                        $v = $v === '1' ? '1' : '0';
                    }
                    $cells[$col] = ['v' => $v, 'num' => $type === '' || $type === 'n'];
                }
                $line = [];
                $max = $cells ? max(array_keys($cells)) : -1;
                for ($i = 0; $i <= $max; $i++) {
                    $line[$i] = $cells[$i] ?? ['v' => '', 'num' => false];
                }
                $rows[] = $line;
            }
        } finally {
            $zip->close();
        }
        if (!$rows) {
            throw new UserError('برگه‌ی اول فایل Excel خالی است.');
        }
        $dateCols = [];
        foreach ($rows[0] as $i => $cell) {
            if (in_array(mb_strtolower(trim($cell['v'])), ['date', 'تاریخ'], true)) {
                $dateCols[$i] = true;
            }
        }
        $fh = fopen('php://memory', 'r+');
        foreach ($rows as $n => $line) {
            $out = [];
            foreach ($line as $i => $cell) {
                $v = $cell['v'];
                if ($n > 0 && isset($dateCols[$i]) && $cell['num'] && is_numeric($v) && (float) $v > 25569 && (float) $v < 80000) {
                    $v = gmdate('Y-m-d', (int) round(((float) $v - 25569) * 86400)); // سریال تاریخ Excel (میلادی)
                } elseif ($cell['num'] && is_numeric($v) && str_contains($v, 'E')) {
                    $v = sprintf('%.0f', (float) $v);
                } elseif ($cell['num'] && is_numeric($v) && str_contains($v, '.') && abs((float) $v - round((float) $v)) < 1e-6) {
                    $v = (string) (int) round((float) $v);
                }
                $out[] = $v;
            }
            fputcsv($fh, $out);
        }
        rewind($fh);
        return (string) stream_get_contents($fh);
    }

    /** ستون‌هایی که عنوانشان شناسه/کد/تلفن است همیشه متن می‌مانند (صفر ابتدایی حفظ شود). */
    private const TEXT_HEADERS = ['کد', 'موبایل', 'تلفن', 'شماره', 'شناسه', 'sku', 'iban', 'شبا', 'پیگیری'];

    /**
     * ساخت فایل .xlsx (راست‌به‌چپ، سطر عنوان پررنگ و ثابت، اعداد واقعی با جداکننده‌ی هزارگان) و برگرداندن مسیر فایل موقت.
     * همه‌ی متن‌ها inlineStr هستند؛ پس هیچ مقداری به‌عنوان فرمول اجرا نمی‌شود.
     * @param list<string> $header @param iterable<list<mixed>> $rows
     */
    public static function write(array $header, iterable $rows, string $sheetName = 'گزارش'): string
    {
        $textCol = [];
        foreach ($header as $i => $h) {
            foreach (self::TEXT_HEADERS as $t) {
                if (mb_stripos($h, $t) !== false) {
                    $textCol[$i] = true;
                }
            }
        }
        $col = static function (int $i): string {
            $s = '';
            for ($i++; $i > 0; $i = intdiv($i - 1, 26)) {
                $s = chr(65 + ($i - 1) % 26) . $s;
            }
            return $s;
        };
        $esc = static fn (string $v): string => htmlspecialchars(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $v) ?? '', ENT_XML1 | ENT_SUBSTITUTE, 'UTF-8');
        $widths = array_map(static fn ($h) => mb_strlen((string) $h) + 4, $header);
        $cell = static function (int $r, int $i, mixed $v, bool $head) use ($col, $esc, $textCol, &$widths): string {
            $ref = $col($i) . $r;
            $str = (string) ($v ?? '');
            $widths[$i] = min(60, max($widths[$i] ?? 8, mb_strlen($str) + 2));
            if ($head) {
                return '<c r="' . $ref . '" s="1" t="inlineStr"><is><t>' . self::escapeStatic($str) . '</t></is></c>';
            }
            if ($str === '') {
                return '';
            }
            $isNum = (is_int($v) || is_float($v) || (is_string($v) && preg_match('/^-?(0|[1-9]\d{0,14})$/', $v))) && !isset($textCol[$i]);
            if ($isNum) {
                return '<c r="' . $ref . '" s="2"><v>' . $str . '</v></c>';
            }
            return '<c r="' . $ref . '" t="inlineStr"><is><t xml:space="preserve">' . self::escapeStatic($str) . '</t></is></c>';
        };
        $body = '<row r="1">';
        foreach ($header as $i => $h) {
            $body .= $cell(1, $i, $h, true);
        }
        $body .= '</row>';
        $r = 1;
        foreach ($rows as $row) {
            if (++$r > self::MAX_ROWS + 1000) {
                break;
            }
            $body .= '<row r="' . $r . '">';
            foreach (array_values($row) as $i => $v) {
                $body .= $cell($r, $i, $v, false);
            }
            $body .= '</row>';
        }
        $cols = '';
        foreach ($widths as $i => $wd) {
            $cols .= '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . $wd . '" customWidth="1"/>';
        }
        $ns = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"';
        $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet ' . $ns . '><sheetViews><sheetView rightToLeft="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>' . $cols . '</cols><sheetData>' . $body . '</sheetData></worksheet>';
        $styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet ' . $ns . '><fonts count="2"><font><sz val="11"/><name val="Tahoma"/></font><font><b/><sz val="11"/><name val="Tahoma"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE8ECFA"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment horizontal="center"/></xf><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
        $safeName = preg_replace('/[\[\]:*?\/\\\\]/u', ' ', $sheetName) ?: 'Sheet1';
        $wb = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook ' . $ns . ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="' . self::escapeStatic(mb_substr($safeName, 0, 31)) . '" sheetId="1" r:id="rId1"/></sheets></workbook>';
        $tmp = tempnam(sys_get_temp_dir(), 'xlsx');
        $zip = new \ZipArchive();
        $zip->open($tmp, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
        $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>');
        $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
        $zip->addFromString('xl/workbook.xml', $wb);
        $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
        $zip->addFromString('xl/styles.xml', $styles);
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheet);
        $zip->close();
        return $tmp;
    }

    private static function escapeStatic(string $v): string
    {
        return htmlspecialchars(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $v) ?? '', ENT_XML1 | ENT_SUBSTITUTE, 'UTF-8');
    }

    private static function part(\ZipArchive $zip, string $name): ?\SimpleXMLElement
    {
        $st = $zip->statName($name);
        if (!$st) {
            return null;
        }
        if ($st['size'] > self::MAX_PART) {
            throw new UserError('فایل Excel بیش از حد بزرگ است.');
        }
        $xml = $zip->getFromName($name, self::MAX_PART + 1);
        if ($xml === false || strlen($xml) > self::MAX_PART) {
            throw new UserError('فایل Excel بیش از حد بزرگ است.');
        }
        $prev = libxml_use_internal_errors(true);
        $x = simplexml_load_string($xml, \SimpleXMLElement::class, LIBXML_NONET | LIBXML_NOCDATA);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);
        return $x ?: null;
    }

    private static function firstSheetPath(\ZipArchive $zip): string
    {
        $wb = self::part($zip, 'xl/workbook.xml');
        $rels = self::part($zip, 'xl/_rels/workbook.xml.rels');
        if ($wb && $rels && isset($wb->sheets->sheet[0])) {
            $rid = (string) $wb->sheets->sheet[0]->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id'];
            foreach ($rels->Relationship as $r) {
                if ((string) $r['Id'] === $rid) {
                    $t = ltrim((string) $r['Target'], '/');
                    return str_starts_with($t, 'xl/') ? $t : 'xl/' . $t;
                }
            }
        }
        return 'xl/worksheets/sheet1.xml';
    }

    private static function colIndex(string $ref): int
    {
        preg_match('/^[A-Z]+/', $ref, $m);
        $n = 0;
        foreach (str_split($m[0] ?? 'A') as $ch) {
            $n = $n * 26 + (ord($ch) - 64);
        }
        return $n - 1;
    }
}
