<?php
declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));

spl_autoload_register(static function (string $class): void {
    if (str_starts_with($class, 'App\\')) {
        $file = BASE_PATH . '/app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
        if (is_file($file)) {
            require $file;
        }
    }
});

require BASE_PATH . '/app/Core/helpers.php';

\App\Core\Env::load(BASE_PATH . '/.env');
date_default_timezone_set(\App\Core\Env::get('APP_TIMEZONE', 'Asia/Tehran'));
mb_internal_encoding('UTF-8');
