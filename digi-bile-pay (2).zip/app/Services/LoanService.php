<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;
use App\Core\UserError;

/** منطق مشترک ایجاد/تأیید/رد تسهیلات؛ باید داخل تراکنش صدا زده شود (به‌جز createPending که ساده است). */
final class LoanService
{
    public static function createPending(int $companyId, int $customerId, array $plan, int $principal, int $userId): int
    {
        $rate = (float) $plan['annual_rate_percent'];
        $schedule = LoanCalculator::schedule($principal, (int) $plan['months'], $rate, date('Y-m-d'));
        $totals = LoanCalculator::totals($schedule);
        return DB::insert(
            "INSERT INTO loans (company_id, customer_id, plan_id, principal, months, annual_rate_percent, fee_amount, total_interest, total_payable, late_fee_daily_percent, status, requested_by, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)",
            [
                $companyId, $customerId, (int) $plan['id'], $principal, (int) $plan['months'], (string) $rate,
                LoanCalculator::fee($principal, (float) $plan['fee_percent']), $totals['interest'], $totals['payable'], (string) ($plan['late_fee_daily_percent'] ?? 0),
                $userId, date('Y-m-d H:i:s'),
            ]
        );
    }

    /** @return bool false اگر درخواست دیگر در وضعیت انتظار نبود */
    public static function activate(array $loan, int $deciderId): bool
    {
        $companyId = (int) $loan['company_id'];
        $n = DB::exec(
            "UPDATE loans SET status = 'active', decided_by = ?, decided_at = ? WHERE id = ? AND company_id = ? AND status = 'pending'",
            [$deciderId, date('Y-m-d H:i:s'), $loan['id'], $companyId]
        );
        if ($n !== 1) {
            return false;
        }
        $schedule = LoanCalculator::schedule((int) $loan['principal'], (int) $loan['months'], (float) $loan['annual_rate_percent'], date('Y-m-d'));
        foreach ($schedule as $r) {
            DB::exec(
                "INSERT INTO installments (company_id, loan_id, seq, due_date, principal_part, interest_part, amount, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'due')",
                [$companyId, $loan['id'], $r['seq'], $r['due_date'], $r['principal_part'], $r['interest_part'], $r['amount']]
            );
        }

        $principal = (int) $loan['principal'];
        $order = DB::one('SELECT id, total, commission_amount FROM orders WHERE loan_id = ? AND company_id = ?', [$loan['id'], $companyId]);
        if ($order) {
            DB::exec("UPDATE orders SET status = 'confirmed' WHERE id = ? AND company_id = ? AND status = 'pending'", [$order['id'], $companyId]);
            $commission = (int) $order['commission_amount'];
            Accounting::post($companyId, 'فعال‌سازی تسهیلات #' . $loan['id'] . ' برای سفارش #' . $order['id'], [
                [Accounting::LOANS, $principal, 0],
                [Accounting::MERCHANT, 0, $principal - $commission],
                [Accounting::COMMISSION, 0, $commission],
            ], 'loan', (int) $loan['id'], $deciderId);
        } else {
            Accounting::post($companyId, 'پرداخت تسهیلات #' . $loan['id'], [
                [Accounting::LOANS, $principal, 0],
                [Accounting::CASH, 0, $principal],
            ], 'loan', (int) $loan['id'], $deciderId);
        }
        $cu = DB::one('SELECT id, full_name, mobile FROM customers WHERE id = ?', [$loan['customer_id']]);
        if ($cu) {
            NotificationService::enqueue($companyId, (int) $cu['id'], (string) $cu['mobile'], 'loan_active', ['name' => $cu['full_name'], 'amount' => fa(number_format($principal))], 'loan:' . $loan['id']);
        }
        return true;
    }

    /** @return bool false اگر درخواست دیگر در وضعیت انتظار نبود */
    public static function reject(array $loan, int $deciderId, string $note): bool
    {
        $companyId = (int) $loan['company_id'];
        $n = DB::exec(
            "UPDATE loans SET status = 'rejected', decided_by = ?, decided_at = ?, decision_note = ? WHERE id = ? AND company_id = ? AND status = 'pending'",
            [$deciderId, date('Y-m-d H:i:s'), $note, $loan['id'], $companyId]
        );
        if ($n !== 1) {
            return false;
        }
        $order = DB::one("SELECT id FROM orders WHERE loan_id = ? AND company_id = ? AND status = 'pending'", [$loan['id'], $companyId]);
        if ($order) {
            DB::exec("UPDATE orders SET status = 'cancelled' WHERE id = ?", [$order['id']]);
            foreach (DB::all('SELECT product_id, qty FROM order_items WHERE order_id = ?', [$order['id']]) as $it) {
                DB::exec('UPDATE products SET stock = stock + ? WHERE id = ? AND company_id = ?', [(int) $it['qty'], $it['product_id'], $companyId]);
                StockService::log($companyId, (int) $it['product_id'], (int) $it['qty'], null, 'return', null, (int) $order['id']);
            }
        }
        return true;
    }

    /**
     * محاسبه مبلغ تسویه زودهنگام: اقساط سررسیدشده/معوق کامل، اقساط آینده فقط اصل (سود آتی بخشوده می‌شود).
     * @return array{total:int, fees:int, waived:int, rows:list<array{id:int,seq:int,remaining:int,new_interest:int,new_amount:int,future:bool}>}
     */
    public static function payoffQuote(int $companyId, int $loanId, ?string $today = null): array
    {
        $today ??= date('Y-m-d');
        $rows = [];
        $total = 0;
        $waived = 0;
        $fees = (int) DB::scalar('SELECT COALESCE(SUM(late_fee_accrued - late_fee_paid), 0) FROM installments WHERE company_id = ? AND loan_id = ?', [$companyId, $loanId]);
        foreach (DB::all("SELECT id, seq, due_date, principal_part, interest_part, amount, paid_amount FROM installments WHERE company_id = ? AND loan_id = ? AND status <> 'paid' ORDER BY seq", [$companyId, $loanId]) as $i) {
            $future = $i['due_date'] > $today;
            $newInterest = $future ? min((int) $i['paid_amount'], (int) $i['interest_part']) : (int) $i['interest_part'];
            $newAmount = $future ? (int) $i['principal_part'] + $newInterest : (int) $i['amount'];
            $remaining = $newAmount - (int) $i['paid_amount'];
            if ($remaining <= 0) {
                continue;
            }
            $waived += (int) $i['amount'] - $newAmount;
            $total += $remaining;
            $rows[] = ['id' => (int) $i['id'], 'seq' => (int) $i['seq'], 'remaining' => $remaining, 'new_interest' => $newInterest, 'new_amount' => $newAmount, 'future' => $future,
                'old_interest' => (int) $i['interest_part'], 'paid' => (int) $i['paid_amount']];
        }
        return ['total' => $total + ($rows ? $fees : 0), 'fees' => $rows ? $fees : 0, 'waived' => $waived, 'rows' => $rows];
    }

    /** تسویه زودهنگام؛ داخل تراکنش اجرا شود. در صورت خطا UserError پرتاب می‌شود. @return int مبلغ پرداختی */
    public static function payoff(int $companyId, int $loanId, string $method, int $userId): int
    {
        $loan = DB::one("SELECT id, customer_id FROM loans WHERE id = ? AND company_id = ? AND status = 'active'", [$loanId, $companyId]);
        if (!$loan) {
            throw new UserError('تسهیلات فعال نیست یا قبلاً تسویه شده است.');
        }
        LateFeeService::accrue($companyId, $loanId);
        $q = self::payoffQuote($companyId, $loanId);
        if ($q['total'] <= 0) {
            throw new UserError('قسط باز برای تسویه وجود ندارد.');
        }
        $now = date('Y-m-d H:i:s');
        if ($method === 'wallet') {
            $n = DB::exec(
                'UPDATE customers SET wallet_balance = wallet_balance - ? WHERE id = ? AND company_id = ? AND wallet_balance >= ?',
                [$q['total'], $loan['customer_id'], $companyId, $q['total']]
            );
            if ($n !== 1) {
                throw new UserError('موجودی کیف پول برای تسویه کافی نیست.');
            }
            $balance = (int) DB::scalar('SELECT wallet_balance FROM customers WHERE id = ?', [$loan['customer_id']]);
            DB::exec(
                "INSERT INTO wallet_transactions (company_id, customer_id, type, amount, balance_after, ref_id, created_by, created_at) VALUES (?, ?, 'installment', ?, ?, ?, ?, ?)",
                [$companyId, $loan['customer_id'], -$q['total'], $balance, $loanId, $userId, $now]
            );
        }
        $interest = 0;
        foreach ($q['rows'] as $r) {
            $n = DB::exec(
                "UPDATE installments SET interest_part = ?, amount = ?, paid_amount = ?, status = 'paid', paid_at = ? WHERE id = ? AND company_id = ? AND status <> 'paid'",
                [$r['new_interest'], $r['new_amount'], $r['new_amount'], $now, $r['id'], $companyId]
            );
            if ($n !== 1) {
                throw new UserError('پرداخت هم‌زمان شناسایی شد؛ دوباره تلاش کنید.');
            }
            DB::insert(
                'INSERT INTO payments (company_id, loan_id, installment_id, amount, method, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$companyId, $loanId, $r['id'], $r['remaining'], $method, $userId, $now]
            );
            $interest += $r['new_interest'] - min($r['paid'], $r['new_interest']);
        }
        if ($q['fees'] > 0) {
            DB::exec('UPDATE installments SET late_fee_paid = late_fee_accrued WHERE company_id = ? AND loan_id = ?', [$companyId, $loanId]);
        }
        Accounting::post($companyId, 'تسویه زودهنگام تسهیلات #' . $loanId, [
            [$method === 'wallet' ? Accounting::WALLET : Accounting::CASH, $q['total'], 0],
            [Accounting::INTEREST, 0, $interest],
            [Accounting::LATE_FEE, 0, $q['fees']],
            [Accounting::LOANS, 0, $q['total'] - $interest - $q['fees']],
        ], 'payoff', $loanId, $userId);
        DB::exec("UPDATE loans SET status = 'closed' WHERE id = ? AND company_id = ?", [$loanId, $companyId]);
        return $q['total'];
    }
}
