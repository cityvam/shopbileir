<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;

final class CreditService
{
    /** اعتبار مصرف‌شده = اصل درخواست‌های در انتظار + اصل اقساط پرداخت‌نشده تسهیلات فعال */
    public static function used(int $companyId, int $customerId, int $excludeLoanId = 0): int
    {
        $pending = (int) DB::scalar(
            "SELECT COALESCE(SUM(principal), 0) FROM loans
             WHERE company_id = ? AND customer_id = ? AND status = 'pending' AND id <> ?",
            [$companyId, $customerId, $excludeLoanId]
        );
        $active = (int) DB::scalar(
            "SELECT COALESCE(SUM(i.principal_part), 0) FROM installments i
             JOIN loans l ON l.id = i.loan_id
             WHERE l.company_id = ? AND l.customer_id = ? AND l.status = 'active' AND i.status <> 'paid' AND l.id <> ?",
            [$companyId, $customerId, $excludeLoanId]
        );
        return $pending + $active;
    }

    public static function available(int $companyId, int $customerId, int $limit, int $excludeLoanId = 0): int
    {
        return max(0, $limit - self::used($companyId, $customerId, $excludeLoanId));
    }
}
