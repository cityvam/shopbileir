<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\UserError;

/** تغییر وضعیت موجودیت‌ها با دلیل اجباری، تاریخچه و قفل خوش‌بینانه (به‌روزرسانی شرطی) */
final class StatusService
{
    /** موجودیت ← [جدول، ستون، نگاشت وضعیت→مقدار ذخیره‌شده] */
    private const CONFIG = [
        'customer' => ['customers', 'status', null],
        'merchant' => ['merchants', 'status', null],
        'product' => ['products', 'status', null],
        'user' => ['users', 'status', null],
        'lead' => ['leads', 'status', null],
        'plan' => ['loan_plans', 'is_active', ['active' => 1, 'disabled' => 0]],
    ];

    public static function change(int $companyId, string $entity, int $id, string $to, string $reason, array $allowed): string
    {
        $reason = trim($reason);
        if (mb_strlen($reason) < 5) {
            throw new UserError('دلیل تغییر وضعیت را (حداقل ۵ نویسه) بنویسید.');
        }
        if (!in_array($to, $allowed, true) || !isset(self::CONFIG[$entity])) {
            throw new UserError('وضعیت مقصد معتبر نیست.');
        }
        if ($entity === 'user' && $id === Auth::id()) {
            throw new UserError('وضعیت حساب کاربری خودتان را نمی‌توانید تغییر دهید.');
        }
        [$table, $col, $map] = self::CONFIG[$entity];
        $toDb = $map ? $map[$to] : $to;
        $fromKey = static fn ($v) => $map ? (array_search((int) $v, $map, true) ?: 'disabled') : (string) $v;
        return DB::tx(function () use ($companyId, $entity, $table, $col, $toDb, $fromKey, $id, $to, $reason) {
            $raw = DB::scalar("SELECT $col FROM $table WHERE id = ? AND company_id = ?", [$id, $companyId]);
            if ($raw === null || $raw === false) {
                throw new UserError('مورد یافت نشد.');
            }
            $from = $fromKey($raw);
            if ($from === $to) {
                throw new UserError('وضعیت فعلی همین است؛ تغییری لازم نیست.');
            }
            $n = DB::exec("UPDATE $table SET $col = ? WHERE id = ? AND company_id = ? AND $col = ?", [$toDb, $id, $companyId, $raw]);
            if ($n !== 1) {
                throw new UserError('وضعیت هم‌زمان توسط کاربر دیگری تغییر کرد؛ صفحه را تازه کنید.');
            }
            DB::insert(
                'INSERT INTO status_history (company_id, entity, entity_id, from_status, to_status, reason, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [$companyId, $entity, $id, $from, $to, mb_substr($reason, 0, 500), Auth::id(), date('Y-m-d H:i:s')]
            );
            Audit::log($entity . '.status', $entity, $id, ['from' => $from, 'to' => $to, 'reason' => $reason]);
            return $from;
        });
    }

    /**
     * تغییر گروهی وضعیت؛ هر مورد جداگانه و در تراکنش خودش اعمال می‌شود.
     * @param list<int> $ids  @return array{ok:int, skipped:list<string>}
     */
    public static function bulk(int $companyId, string $entity, array $ids, string $to, string $reason, array $allowed): array
    {
        $ids = array_slice(array_values(array_unique(array_filter(array_map('intval', $ids)))), 0, 200);
        if (!$ids) {
            throw new UserError('هیچ موردی انتخاب نشده است.');
        }
        $ok = 0;
        $skipped = [];
        foreach ($ids as $id) {
            try {
                self::change($companyId, $entity, $id, $to, $reason, $allowed);
                $ok++;
            } catch (UserError $e) {
                if (mb_strlen(trim($reason)) < 5 || !in_array($to, $allowed, true)) {
                    throw $e; // خطای کلی (دلیل/وضعیت)؛ ادامه معنا ندارد
                }
                $skipped[] = '#' . $id . ': ' . $e->getMessage();
            }
        }
        return ['ok' => $ok, 'skipped' => $skipped];
    }

    /** @return list<array<string,mixed>> */
    public static function history(int $companyId, string $entity, int $id): array
    {
        return DB::all(
            'SELECT h.from_status, h.to_status, h.reason, h.created_at, u.full_name
             FROM status_history h LEFT JOIN users u ON u.id = h.user_id
             WHERE h.company_id = ? AND h.entity = ? AND h.entity_id = ? ORDER BY h.id DESC LIMIT 30',
            [$companyId, $entity, $id]
        );
    }
}
