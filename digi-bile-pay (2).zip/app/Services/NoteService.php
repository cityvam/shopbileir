<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\UserError;

/** یادداشت‌های داخلی (توضیحات کارشناس) روی مشتری، تسهیلات، فروشنده، سفارش و محصول */
final class NoteService
{
    /** موجودیت ← [جدول، مجوز مشاهده، مسیر صفحه] */
    public const ENTITIES = [
        'customer' => ['customers', 'customers.view', '/customers/'],
        'loan' => ['loans', 'loans.view', '/loans/'],
        'merchant' => ['merchants', 'merchants.view', '/merchants/'],
        'order' => ['orders', 'orders.view', '/orders/'],
        'product' => ['products', 'products.view', '/products/{id}/edit'],
        'cheque' => ['cheques', 'accounting.view', '/cheques/'],
        'lead' => ['leads', 'customers.view', '/leads/'],
    ];

    public static function back(string $entity, int $id): string
    {
        $path = self::ENTITIES[$entity][2];
        return str_contains($path, '{id}') ? str_replace('{id}', (string) $id, $path) : $path . $id;
    }

    public static function canView(string $entity): bool
    {
        return isset(self::ENTITIES[$entity]) && Auth::can(self::ENTITIES[$entity][1]);
    }

    public static function add(int $companyId, string $entity, int $entityId, string $body): int
    {
        $body = trim($body);
        if (!isset(self::ENTITIES[$entity]) || !self::canView($entity)) {
            throw new UserError('دسترسی به این بخش ندارید.');
        }
        if (mb_strlen($body) < 3 || mb_strlen($body) > 2000) {
            throw new UserError('متن یادداشت باید بین ۳ تا ۲۰۰۰ نویسه باشد.');
        }
        $table = self::ENTITIES[$entity][0];
        if (!DB::scalar("SELECT id FROM $table WHERE id = ? AND company_id = ?", [$entityId, $companyId])) {
            throw new UserError('مورد یافت نشد.');
        }
        $id = DB::insert(
            'INSERT INTO entity_notes (company_id, entity, entity_id, body, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)',
            [$companyId, $entity, $entityId, $body, Auth::id(), date('Y-m-d H:i:s')]
        );
        Audit::log('note.add', $entity, $entityId, ['note' => $id]);
        return $id;
    }

    public static function find(int $companyId, int $id): array
    {
        $n = DB::one('SELECT * FROM entity_notes WHERE id = ? AND company_id = ?', [$id, $companyId]) ?? throw new UserError('یادداشت یافت نشد.');
        if (!self::canView($n['entity'])) {
            throw new UserError('دسترسی به این بخش ندارید.');
        }
        return $n;
    }

    /** ویرایش و حذف فقط توسط نویسنده */
    public static function edit(int $companyId, int $id, string $body): array
    {
        $n = self::find($companyId, $id);
        self::ownerOnly($n);
        $body = trim($body);
        if (mb_strlen($body) < 3 || mb_strlen($body) > 2000) {
            throw new UserError('متن یادداشت باید بین ۳ تا ۲۰۰۰ نویسه باشد.');
        }
        DB::exec('UPDATE entity_notes SET body = ?, updated_at = ? WHERE id = ? AND company_id = ?', [$body, date('Y-m-d H:i:s'), $id, $companyId]);
        Audit::log('note.edit', $n['entity'], (int) $n['entity_id'], ['note' => $id]);
        return $n;
    }

    public static function delete(int $companyId, int $id): array
    {
        $n = self::find($companyId, $id);
        self::ownerOnly($n);
        DB::exec('DELETE FROM entity_notes WHERE id = ? AND company_id = ?', [$id, $companyId]);
        Audit::log('note.delete', $n['entity'], (int) $n['entity_id'], ['note' => $id]);
        return $n;
    }

    public static function togglePin(int $companyId, int $id): array
    {
        $n = self::find($companyId, $id);
        DB::exec('UPDATE entity_notes SET pinned = ? WHERE id = ? AND company_id = ?', [(int) $n['pinned'] === 1 ? 0 : 1, $id, $companyId]);
        Audit::log('note.pin', $n['entity'], (int) $n['entity_id'], ['note' => $id, 'pinned' => (int) $n['pinned'] === 1 ? 0 : 1]);
        return $n;
    }

    private static function ownerOnly(array $n): void
    {
        if ((int) $n['created_by'] !== Auth::id()) {
            throw new UserError('فقط نویسنده‌ی یادداشت می‌تواند آن را ویرایش یا حذف کند.');
        }
    }

    /** @return list<array<string,mixed>> سنجاق‌شده‌ها اول */
    public static function list(int $companyId, string $entity, int $entityId): array
    {
        return DB::all(
            'SELECT n.id, n.body, n.pinned, n.created_by, n.created_at, n.updated_at, u.full_name
             FROM entity_notes n LEFT JOIN users u ON u.id = n.created_by
             WHERE n.company_id = ? AND n.entity = ? AND n.entity_id = ? ORDER BY n.pinned DESC, n.id DESC LIMIT 50',
            [$companyId, $entity, $entityId]
        );
    }
}
