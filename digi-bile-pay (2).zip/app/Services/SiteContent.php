<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;
use App\Core\Env;

/** متن‌های قابل‌ویرایش صفحه‌ی عمومی؛ مقدار خالی یعنی استفاده از پیش‌فرض (یا مقدار .env برای تماس). */
final class SiteContent
{
    public const FIELDS = [
        'eyebrow' => ['برچسب بالای عنوان', 60],
        'hero_title' => ['عنوان اصلی (با Enter بشکنید)', 120],
        'hero_lead' => ['توضیح زیر عنوان', 400],
        'footer_note' => ['متن معرفی در پاورقی', 300],
        'phone' => ['تلفن تماس', 40],
        'email' => ['ایمیل', 120],
        'address' => ['نشانی', 250],
    ];
    public const DEFAULTS = [
        'eyebrow' => 'خرید اقساطی هوشمند',
        'hero_title' => "امروز بخرید،\nآرام‌آرام بپردازید",
        'hero_lead' => 'اعتبار لحظه‌ای برای خرید از فروشگاه‌های طرف قرارداد، با اقساط شفاف و بدون هزینه‌ی پنهان. نرخ و قسط خود را همین حالا ببینید و درخواست‌تان را ثبت کنید.',
        'footer_note' => 'اعتبار شفاف برای خرید از فروشگاه‌های طرف قرارداد؛ نرخ، کارمزد و جدول اقساط پیش از تصمیم‌گیری در دسترس شماست.',
    ];
    public const DEFAULT_FAQ = [
        ['چه کسانی می‌توانند اعتبار بگیرند؟', 'پس از ثبت درخواست، کارشناسان با شما تماس می‌گیرند و مدارک موردنیاز و سقف اعتبار را اعلام می‌کنند. تصمیم نهایی پس از بررسی اطلاعات است.'],
        ['هزینه‌ی تسهیلات چقدر است؟', 'هر طرح نرخ سالانه و کارمزد مشخصی دارد که در بخش طرح‌ها و ماشین‌حساب قابل مشاهده است. مبلغ هر قسط، مجموع سود و کارمزد پیش از ثبت نهایی نمایش داده می‌شود.'],
        ['اقساط چگونه محاسبه می‌شود؟', 'اقساط مساوی ماهانه با نرخ سالانه‌ی طرح محاسبه می‌شود و سررسید اولین قسط یک ماه پس از تاریخ تسهیلات است.'],
        ['اگر قسطی را دیر بپردازم چه می‌شود؟', 'برای تأخیر در پرداخت، جریمه‌ی دیرکرد طبق شرایط قرارداد محاسبه می‌شود. بهتر است پیش از سررسید با کارشناسان هماهنگ کنید.'],
        ['آیا می‌توانم زودتر تسویه کنم؟', 'بله. در تسویه‌ی زودهنگام باقی‌مانده‌ی اصل و سود تا امروز پرداخت می‌شود و سود اقساط آینده محاسبه نمی‌شود.'],
        ['اطلاعات من چگونه محافظت می‌شود؟', 'دسترسی کارکنان بر اساس نقش و مجوز محدود است، ورود با تأیید دومرحله‌ای قابل‌فعال‌سازی است و تمام تغییرات حساس در گزارش حسابرسی ثبت می‌شود.'],
    ];
    public const MAX_FAQ = 20;

    /** مقادیر ذخیره‌شده‌ی خام (برای فرم ویرایش) */
    public static function stored(int $companyId): array
    {
        $out = [];
        foreach (DB::all('SELECT skey, svalue FROM site_settings WHERE company_id = ?', [$companyId]) as $r) {
            $out[$r['skey']] = $r['svalue'];
        }
        return $out;
    }

    /** مقادیر نهایی برای نمایش (ذخیره‌شده ← پیش‌فرض/.env) */
    public static function get(int $companyId): array
    {
        $s = self::stored($companyId);
        $env = ['phone' => Env::get('SITE_PHONE', ''), 'email' => Env::get('SITE_EMAIL', ''), 'address' => Env::get('SITE_ADDRESS', '')];
        $out = [];
        foreach (array_keys(self::FIELDS) as $k) {
            $v = trim((string) ($s[$k] ?? ''));
            $out[$k] = $v !== '' ? $v : (self::DEFAULTS[$k] ?? $env[$k] ?? '');
        }
        return $out;
    }

    /** @return list<array{0:string,1:string}> */
    public static function faq(int $companyId): array
    {
        $rows = DB::all('SELECT question, answer FROM site_faq WHERE company_id = ? ORDER BY sort_order, id', [$companyId]);
        return $rows ? array_map(static fn ($r) => [$r['question'], $r['answer']], $rows) : self::DEFAULT_FAQ;
    }

    public static function storedFaq(int $companyId): array
    {
        return array_map(static fn ($r) => [$r['question'], $r['answer']], DB::all('SELECT question, answer FROM site_faq WHERE company_id = ? ORDER BY sort_order, id', [$companyId]));
    }

    /** ذخیره‌ی تنظیمات و سوالات؛ مقدار خالی کلید را حذف می‌کند (بازگشت به پیش‌فرض). */
    public static function save(int $companyId, array $values, array $faq): void
    {
        DB::tx(function () use ($companyId, $values, $faq) {
            foreach ($values as $k => $v) {
                DB::exec('DELETE FROM site_settings WHERE company_id = ? AND skey = ?', [$companyId, $k]);
                if ($v !== '') {
                    DB::exec('INSERT INTO site_settings (company_id, skey, svalue, updated_at) VALUES (?, ?, ?, ?)', [$companyId, $k, $v, date('Y-m-d H:i:s')]);
                }
            }
            DB::exec('DELETE FROM site_faq WHERE company_id = ?', [$companyId]);
            foreach (array_values($faq) as $i => [$q, $a]) {
                DB::exec('INSERT INTO site_faq (company_id, question, answer, sort_order) VALUES (?, ?, ?, ?)', [$companyId, $q, $a, $i]);
            }
        });
    }
}
