<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Crypto;
use App\Core\Database as DB;
use App\Core\Totp;
use App\Core\UserError;

/** احراز هویت دومرحله‌ای: فعال‌سازی، تأیید هنگام ورود، کدهای بازیابی (فقط هش ذخیره می‌شود) */
final class MfaService
{
    public const MAX_FAILS = 5;
    private const WINDOW = 900;

    /** @return list<string> کدهای بازیابی (فقط یک‌بار نمایش داده می‌شوند) */
    public static function enable(int $userId, string $secret, string $code): array
    {
        $step = Totp::verify($secret, $code);
        if ($step === null) {
            throw new UserError('کد وارد‌شده صحیح نیست. ساعت دستگاه را بررسی و دوباره تلاش کنید.');
        }
        return DB::tx(function () use ($userId, $secret, $step) {
            DB::exec('UPDATE users SET mfa_secret = ?, mfa_enabled = 1, mfa_last_step = ? WHERE id = ?', [Crypto::encrypt($secret), $step, $userId]);
            $codes = self::newRecoveryCodes($userId);
            Audit::log('mfa.enable', 'user', $userId);
            return $codes;
        });
    }

    /** @return list<string> */
    public static function newRecoveryCodes(int $userId): array
    {
        DB::exec('DELETE FROM mfa_recovery_codes WHERE user_id = ?', [$userId]);
        $codes = [];
        for ($i = 0; $i < 8; $i++) {
            $c = bin2hex(random_bytes(3)) . '-' . bin2hex(random_bytes(3));
            $codes[] = $c;
            DB::exec('INSERT INTO mfa_recovery_codes (user_id, code_hash) VALUES (?, ?)', [$userId, hash('sha256', $c)]);
        }
        return $codes;
    }

    public static function disable(int $userId, string $by = 'self'): void
    {
        DB::tx(function () use ($userId, $by) {
            DB::exec('UPDATE users SET mfa_secret = NULL, mfa_enabled = 0, mfa_last_step = NULL WHERE id = ?', [$userId]);
            DB::exec('DELETE FROM mfa_recovery_codes WHERE user_id = ?', [$userId]);
            Audit::log($by === 'self' ? 'mfa.disable' : 'mfa.reset', 'user', $userId);
        });
    }

    /** کد TOTP یا کد بازیابی را تأیید می‌کند؛ کد TOTP یک‌بار مصرف است */
    public static function verifyLogin(int $userId, string $input): bool
    {
        $u = DB::one('SELECT mfa_secret, mfa_last_step FROM users WHERE id = ? AND mfa_enabled = 1', [$userId]);
        if (!$u) {
            return false;
        }
        $secret = Crypto::decrypt((string) $u['mfa_secret']);
        if ($secret !== null) {
            $step = Totp::verify($secret, $input, $u['mfa_last_step'] !== null ? (int) $u['mfa_last_step'] : null);
            if ($step !== null) {
                $n = DB::exec('UPDATE users SET mfa_last_step = ? WHERE id = ? AND (mfa_last_step IS NULL OR mfa_last_step < ?)', [$step, $userId, $step]);
                return $n === 1;
            }
        }
        $norm = strtolower(trim($input));
        if (preg_match('/^[0-9a-f]{6}-[0-9a-f]{6}$/', $norm)) {
            $n = DB::exec('UPDATE mfa_recovery_codes SET used_at = ? WHERE user_id = ? AND code_hash = ? AND used_at IS NULL', [date('Y-m-d H:i:s'), $userId, hash('sha256', $norm)]);
            if ($n === 1) {
                Audit::log('mfa.recovery_used', 'user', $userId, [], (int) DB::scalar('SELECT company_id FROM users WHERE id = ?', [$userId]));
                return true;
            }
        }
        return false;
    }

    public static function failedRecently(string $username): int
    {
        return (int) DB::scalar('SELECT COUNT(*) FROM login_attempts WHERE success = 0 AND username = ? AND attempted_at >= ?', ['mfa:' . $username, date('Y-m-d H:i:s', time() - self::WINDOW)]);
    }

    public static function recordFail(string $username): void
    {
        DB::exec('INSERT INTO login_attempts (username, ip, success, attempted_at) VALUES (?, ?, 0, ?)', ['mfa:' . $username, $_SERVER['REMOTE_ADDR'] ?? '', date('Y-m-d H:i:s')]);
    }

    public static function remainingCodes(int $userId): int
    {
        return (int) DB::scalar('SELECT COUNT(*) FROM mfa_recovery_codes WHERE user_id = ? AND used_at IS NULL', [$userId]);
    }
}
