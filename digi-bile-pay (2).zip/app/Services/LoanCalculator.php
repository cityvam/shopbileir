<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Jalali;

/** محاسبه جدول اقساط (اقساط مساوی با نرخ سالانه مرکب ماهانه). همه مبالغ ریال و صحیح هستند. */
final class LoanCalculator
{
    /** @return list<array{seq:int,due_date:string,principal_part:int,interest_part:int,amount:int}> */
    public static function schedule(int $principal, int $months, float $annualRatePercent, string $startYmd): array
    {
        if ($principal <= 0 || $months <= 0) {
            throw new \InvalidArgumentException('مبلغ و تعداد اقساط باید مثبت باشد.');
        }
        $r = $annualRatePercent / 1200;
        $pmt = $r > 0 ? $principal * $r / (1 - (1 + $r) ** (-$months)) : $principal / $months;
        $pmt = (int) round($pmt);

        $balance = $principal;
        $rows = [];
        for ($i = 1; $i <= $months; $i++) {
            $interest = (int) round($balance * $r);
            if ($i === $months) {
                $pp = $balance;
            } else {
                $pp = min(max($pmt - $interest, 0), $balance);
            }
            $balance -= $pp;
            $rows[] = [
                'seq' => $i,
                'due_date' => Jalali::addMonths($startYmd, $i),
                'principal_part' => $pp,
                'interest_part' => $interest,
                'amount' => $pp + $interest,
            ];
        }
        return $rows;
    }

    public static function totals(array $schedule): array
    {
        return [
            'interest' => array_sum(array_column($schedule, 'interest_part')),
            'payable' => array_sum(array_column($schedule, 'amount')),
        ];
    }

    public static function fee(int $principal, float $feePercent): int
    {
        return (int) round($principal * $feePercent / 100);
    }
}
