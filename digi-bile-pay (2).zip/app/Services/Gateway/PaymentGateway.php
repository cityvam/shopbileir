<?php
declare(strict_types=1);

namespace App\Services\Gateway;

interface PaymentGateway
{
    public function name(): string;

    /** @return array{authority: string, url: string} آدرس هدایت مشتری به درگاه */
    public function request(array $req, string $callbackUrl, string $description): array;

    /** @return array{ok: bool, ref: string, message: string} تأیید نهایی پس از بازگشت از درگاه (سمت سرور) */
    public function verify(array $req, array $query): array;
}
