<?php
declare(strict_types=1);

namespace App\Services\Gateway;

use App\Core\Env;

/**
 * درگاه زرین‌پال (API نسخه‌ی ۴). مبلغ به ریال ارسال می‌شود (currency=IRR).
 * توجه: این آداپتور در محیط توسعه با سرور واقعی تست نشده است؛ پیش از استقرار با مرچنت آزمایشی (sandbox) بررسی شود.
 */
final class ZarinpalGateway implements PaymentGateway
{
    public function name(): string
    {
        return 'zarinpal';
    }

    private function base(): string
    {
        return Env::get('ZARINPAL_SANDBOX') === '1' ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com';
    }

    private function call(string $path, array $body): array
    {
        $ch = curl_init($this->base() . '/pg/v4/payment/' . $path);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
            CURLOPT_POSTFIELDS => json_encode($body + ['merchant_id' => Env::get('ZARINPAL_MERCHANT_ID', '')], JSON_UNESCAPED_UNICODE),
        ]);
        $res = curl_exec($ch);
        curl_close($ch);
        $j = is_string($res) ? json_decode($res, true) : null;
        return is_array($j) ? $j : [];
    }

    public function request(array $req, string $callbackUrl, string $description): array
    {
        $j = $this->call('request.json', [
            'amount' => (int) $req['amount'], 'currency' => 'IRR', 'callback_url' => $callbackUrl, 'description' => $description,
        ]);
        $authority = $j['data']['authority'] ?? null;
        if (!is_string($authority) || ($j['data']['code'] ?? 0) !== 100) {
            throw new \RuntimeException('ارتباط با درگاه برقرار نشد.');
        }
        return ['authority' => $authority, 'url' => $this->base() . '/pg/StartPay/' . $authority];
    }

    public function verify(array $req, array $query): array
    {
        if (($query['Status'] ?? '') !== 'OK' || ($query['Authority'] ?? '') !== ($req['authority'] ?? null)) {
            return ['ok' => false, 'ref' => '', 'message' => 'پرداخت توسط مشتری لغو یا ناموفق بود.'];
        }
        $j = $this->call('verify.json', ['amount' => (int) $req['amount'], 'authority' => (string) $req['authority']]);
        $code = $j['data']['code'] ?? 0;
        if ($code === 100 || $code === 101) {
            return ['ok' => true, 'ref' => (string) ($j['data']['ref_id'] ?? ''), 'message' => ''];
        }
        return ['ok' => false, 'ref' => '', 'message' => 'تأیید پرداخت از درگاه ناموفق بود.'];
    }
}
