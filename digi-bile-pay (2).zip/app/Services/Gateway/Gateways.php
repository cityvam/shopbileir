<?php
declare(strict_types=1);

namespace App\Services\Gateway;

use App\Core\Env;

final class Gateways
{
    /** درگاه فعال طبق PAYMENT_GATEWAY (none | sandbox | zarinpal)؛ null یعنی پرداخت آنلاین غیرفعال است. */
    public static function active(): ?PaymentGateway
    {
        return match (Env::get('PAYMENT_GATEWAY', 'none')) {
            'sandbox' => Env::get('APP_ENV') === 'production' ? null : new SandboxGateway(),
            'zarinpal' => (Env::get('ZARINPAL_MERCHANT_ID', '') !== '') ? new ZarinpalGateway() : null,
            default => null,
        };
    }
}
