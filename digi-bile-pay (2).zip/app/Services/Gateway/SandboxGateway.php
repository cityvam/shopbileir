<?php
declare(strict_types=1);

namespace App\Services\Gateway;

/** درگاه آزمایشی داخلی (بدون ارتباط با بانک) برای توسعه و آموزش؛ در production غیرفعال است. */
final class SandboxGateway implements PaymentGateway
{
    public function name(): string
    {
        return 'sandbox';
    }

    public function request(array $req, string $callbackUrl, string $description): array
    {
        return ['authority' => 'SBX' . bin2hex(random_bytes(8)), 'url' => '/pay/sandbox?t=' . $req['token']];
    }

    public function verify(array $req, array $query): array
    {
        $ok = ($query['Status'] ?? '') === 'OK' && ($query['Authority'] ?? '') === ($req['authority'] ?? null);
        return ['ok' => $ok, 'ref' => $ok ? 'SBXREF' . $req['id'] : '', 'message' => $ok ? '' : 'پرداخت انجام نشد.'];
    }
}
