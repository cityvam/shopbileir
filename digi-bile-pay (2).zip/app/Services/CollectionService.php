<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Database as DB;

/** منطق مشترک وصول: پرداخت قسط و شارژ کیف پول (توسط پنل و درگاه آنلاین). همیشه داخل تراکنش فراخوانی شود. */
final class CollectionService
{
    /** @return true|string true در موفقیت، وگرنه متن خطا */
    public static function payInstallment(int $companyId, int $installmentId, int $amount, string $method, int $userId, array $extra = []): true|string
    {
        $inst = DB::one(
            "SELECT i.*, l.customer_id FROM installments i JOIN loans l ON l.id = i.loan_id
             WHERE i.id = ? AND i.company_id = ? AND l.status = 'active'",
            [$installmentId, $companyId]
        );
        if (!$inst) {
            return 'قسط یافت نشد یا تسهیلات فعال نیست.';
        }
        $remaining = (int) $inst['amount'] - (int) $inst['paid_amount'];
        if ($remaining <= 0) {
            return 'این قسط قبلاً تسویه شده است.';
        }
        if ($amount > $remaining) {
            return 'مبلغ از باقی‌مانده قسط (' . number_format($remaining) . ' ریال) بیشتر است.';
        }
        $now = date('Y-m-d H:i:s');

        if ($method === 'wallet') {
            // شرط موجودی در خود UPDATE از برداشت منفی و رقابت هم‌زمان جلوگیری می‌کند
            $n = DB::exec(
                'UPDATE customers SET wallet_balance = wallet_balance - ? WHERE id = ? AND company_id = ? AND wallet_balance >= ?',
                [$amount, $inst['customer_id'], $companyId, $amount]
            );
            if ($n !== 1) {
                return 'موجودی کیف پول کافی نیست.';
            }
            $balance = (int) DB::scalar('SELECT wallet_balance FROM customers WHERE id = ?', [$inst['customer_id']]);
            DB::exec(
                "INSERT INTO wallet_transactions (company_id, customer_id, type, amount, balance_after, ref_id, created_by, created_at)
                 VALUES (?, ?, 'installment', ?, ?, ?, ?, ?)",
                [$companyId, $inst['customer_id'], -$amount, $balance, $inst['id'], $userId, $now]
            );
        }

        // شرط paid_amount + ? <= amount از پرداخت بیش‌ازحد در رقابت هم‌زمان جلوگیری می‌کند
        $n = DB::exec(
            'UPDATE installments SET paid_amount = paid_amount + ? WHERE id = ? AND company_id = ? AND paid_amount + ? <= amount',
            [$amount, $inst['id'], $companyId, $amount]
        );
        if ($n !== 1) {
            throw new \RuntimeException('پرداخت هم‌زمان شناسایی شد.');
        }
        $row = DB::one('SELECT amount, paid_amount FROM installments WHERE id = ?', [$inst['id']]);
        $full = (int) $row['paid_amount'] >= (int) $row['amount'];
        DB::exec('UPDATE installments SET status = ?, paid_at = ? WHERE id = ?', [$full ? 'paid' : 'partial', $full ? $now : null, $inst['id']]);
        $payId = DB::insert(
            'INSERT INTO payments (company_id, loan_id, installment_id, amount, method, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$companyId, $inst['loan_id'], $inst['id'], $amount, $method, $userId, $now]
        );

        $interestBefore = min((int) $inst['paid_amount'], (int) $inst['interest_part']);
        $interestNow = min($amount, (int) $inst['interest_part'] - $interestBefore);
        Accounting::post($companyId, 'وصول قسط ' . $inst['seq'] . ' تسهیلات #' . $inst['loan_id'] . ($method === 'online' ? ' (درگاه آنلاین)' : ''), [
            [$method === 'wallet' ? Accounting::WALLET : Accounting::CASH, $amount, 0],
            [Accounting::INTEREST, 0, $interestNow],
            [Accounting::LOANS, 0, $amount - $interestNow],
        ], 'payment', $payId, $userId);

        $closed = false;
        if ((int) DB::scalar("SELECT COUNT(*) FROM installments WHERE loan_id = ? AND status <> 'paid'", [$inst['loan_id']]) === 0) {
            DB::exec("UPDATE loans SET status = 'closed' WHERE id = ? AND company_id = ?", [$inst['loan_id'], $companyId]);
            $closed = true;
        }
        Audit::log('installment.pay', 'installment', (int) $inst['id'], ['amount' => $amount, 'method' => $method, 'payment' => $payId, 'loan_closed' => $closed] + $extra, $companyId);
        return true;
    }

    /** شارژ کیف پول؛ شناسه‌ی تراکنش را برمی‌گرداند. */
    public static function topup(int $companyId, int $customerId, int $amount, int $userId, string $customerName, array $extra = []): int
    {
        DB::exec('UPDATE customers SET wallet_balance = wallet_balance + ? WHERE id = ? AND company_id = ?', [$amount, $customerId, $companyId]);
        $balance = (int) DB::scalar('SELECT wallet_balance FROM customers WHERE id = ? AND company_id = ?', [$customerId, $companyId]);
        $txId = DB::insert(
            "INSERT INTO wallet_transactions (company_id, customer_id, type, amount, balance_after, created_by, created_at) VALUES (?, ?, 'topup', ?, ?, ?, ?)",
            [$companyId, $customerId, $amount, $balance, $userId, date('Y-m-d H:i:s')]
        );
        Accounting::post($companyId, 'شارژ کیف پول ' . $customerName . (isset($extra['payment_request']) ? ' (درگاه آنلاین)' : ''), [
            [Accounting::CASH, $amount, 0],
            [Accounting::WALLET, 0, $amount],
        ], 'wallet', $txId, $userId);
        Audit::log('wallet.topup', 'customer', $customerId, ['amount' => $amount, 'tx' => $txId] + $extra, $companyId);
        return $txId;
    }
}
