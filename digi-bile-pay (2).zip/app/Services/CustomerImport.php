<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Database as DB;
use App\Core\Validator;

/** درون‌ریزی گروهی مشتریان از CSV: اعتبارسنجی کامل همه‌ی سطرها؛ ثبت فقط وقتی همه سالم باشند (همه‌یا‌هیچ) */
final class CustomerImport
{
    public const MAX_ROWS = 1000;
    private const ALIASES = [
        'national_code' => ['national_code', 'کدملی', 'کد ملی'],
        'full_name' => ['full_name', 'نام', 'نام و نام خانوادگی', 'نام کامل'],
        'mobile' => ['mobile', 'موبایل', 'شماره موبایل', 'تلفن همراه'],
        'credit_limit' => ['credit_limit', 'سقف اعتبار', 'اعتبار'],
    ];

    /**
     * @return array{rows:list<array{line:int,data:array<string,mixed>,errors:list<string>}>,fatal:?string}
     */
    public static function parse(string $csv, int $companyId): array
    {
        $csv = ltrim(self::digits($csv), "\xEF\xBB\xBF");
        $first = strtok($csv, "\n") ?: '';
        $delim = substr_count($first, ';') > substr_count($first, ',') ? ';' : ',';
        $fh = fopen('php://memory', 'r+');
        fwrite($fh, $csv);
        rewind($fh);
        $header = fgetcsv($fh, 0, $delim);
        if (!$header) {
            return ['rows' => [], 'fatal' => 'فایل خالی است.'];
        }
        $idx = [];
        foreach ($header as $i => $h) {
            $h = mb_strtolower(trim((string) $h));
            foreach (self::ALIASES as $key => $names) {
                if (in_array($h, array_map('mb_strtolower', $names), true)) {
                    $idx[$key] = $i;
                }
            }
        }
        foreach (['national_code', 'full_name', 'mobile'] as $req) {
            if (!isset($idx[$req])) {
                return ['rows' => [], 'fatal' => 'ستون «' . self::ALIASES[$req][1] . '» در سطر عنوان پیدا نشد. از فایل نمونه استفاده کنید.'];
            }
        }
        $rows = [];
        $seen = [];
        $line = 1;
        while (($r = fgetcsv($fh, 0, $delim)) !== false) {
            $line++;
            if (count(array_filter($r, static fn ($v) => trim((string) $v) !== '')) === 0) {
                continue;
            }
            if (count($rows) >= self::MAX_ROWS) {
                return ['rows' => $rows, 'fatal' => 'حداکثر ' . self::MAX_ROWS . ' سطر در هر فایل مجاز است.'];
            }
            $get = static fn (string $k): string => isset($idx[$k]) ? trim((string) ($r[$idx[$k]] ?? '')) : '';
            $nc = preg_replace('/\D/', '', $get('national_code')) ?? '';
            if (strlen($nc) >= 8 && strlen($nc) < 10) {
                $nc = str_pad($nc, 10, '0', STR_PAD_LEFT);
            }
            $mobile = preg_replace('/\D/', '', $get('mobile')) ?? '';
            if (strlen($mobile) === 10 && $mobile[0] === '9') {
                $mobile = '0' . $mobile;
            }
            $limRaw = $get('credit_limit');
            $lim = preg_replace('/\D/', '', $limRaw) === '' || preg_replace('/\D/', '', $limRaw) === '0' ? 0 : Validator::amount($limRaw);
            $errors = [];
            if (!Validator::nationalCode($nc)) {
                $errors[] = 'کد ملی نامعتبر';
            } elseif (isset($seen[$nc])) {
                $errors[] = 'کد ملی تکراری در همین فایل (سطر ' . $seen[$nc] . ')';
            } elseif (DB::scalar('SELECT id FROM customers WHERE company_id = ? AND national_code = ?', [$companyId, $nc])) {
                $errors[] = 'قبلاً ثبت شده است';
            }
            $seen[$nc] ??= $line;
            $name = trim((string) preg_replace('/\s+/u', ' ', $get('full_name')));
            if (mb_strlen($name) < 2) {
                $errors[] = 'نام نامعتبر';
            }
            if (!Validator::mobile($mobile)) {
                $errors[] = 'موبایل نامعتبر';
            }
            if ($lim === null) {
                $errors[] = 'سقف اعتبار نامعتبر';
            }
            $rows[] = ['line' => $line, 'data' => ['national_code' => $nc, 'full_name' => $name, 'mobile' => $mobile, 'credit_limit' => (int) $lim], 'errors' => $errors];
        }
        return ['rows' => $rows, 'fatal' => $rows ? null : 'فایل هیچ سطر داده‌ای ندارد.'];
    }

    /** @param list<array{line:int,data:array<string,mixed>,errors:list<string>}> $rows */
    public static function commit(int $companyId, array $rows): int
    {
        return DB::tx(function () use ($companyId, $rows) {
            foreach ($rows as $r) {
                $d = $r['data'];
                $id = DB::insert('INSERT INTO customers (company_id, national_code, full_name, mobile, credit_limit) VALUES (?, ?, ?, ?, ?)', [$companyId, $d['national_code'], $d['full_name'], $d['mobile'], $d['credit_limit']]);
                Audit::log('customer.create', 'customer', $id, ['credit_limit' => $d['credit_limit'], 'import' => 1]);
            }
            Audit::log('customer.import', 'customer', null, ['count' => count($rows)]);
            return count($rows);
        });
    }

    private static function digits(string $s): string
    {
        return strtr($s, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9', '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9']);
    }
}
