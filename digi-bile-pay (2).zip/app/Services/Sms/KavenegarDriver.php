<?php
declare(strict_types=1);

namespace App\Services\Sms;

use App\Core\Env;

/**
 * ارسال ساده از طریق وب‌سرویس کاوه‌نگار (sms/send). توجه: با سرویس واقعی در محیط توسعه تست نشده است.
 * KAVENEGAR_API_KEY و در صورت نیاز SMS_SENDER را در .env بگذارید.
 */
final class KavenegarDriver implements SmsDriver
{
    public function send(string $mobile, string $body): array
    {
        $key = Env::get('KAVENEGAR_API_KEY', '');
        if ($key === '') {
            return ['ok' => false, 'ref' => '', 'error' => 'KAVENEGAR_API_KEY تنظیم نشده است.'];
        }
        $params = ['receptor' => $mobile, 'message' => $body];
        if (Env::get('SMS_SENDER', '') !== '') {
            $params['sender'] = Env::get('SMS_SENDER');
        }
        $ch = curl_init('https://api.kavenegar.com/v1/' . rawurlencode($key) . '/sms/send.json');
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query($params), CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 8]);
        $res = curl_exec($ch);
        curl_close($ch);
        $j = is_string($res) ? json_decode($res, true) : null;
        if (is_array($j) && ($j['return']['status'] ?? 0) === 200) {
            return ['ok' => true, 'ref' => (string) ($j['entries'][0]['messageid'] ?? ''), 'error' => ''];
        }
        return ['ok' => false, 'ref' => '', 'error' => mb_substr((string) ($j['return']['message'] ?? 'ارتباط با سرویس پیامک برقرار نشد.'), 0, 240)];
    }
}
