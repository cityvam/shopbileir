<?php
declare(strict_types=1);

namespace App\Services\Sms;

/** پیامک را فقط در storage/logs/sms.log می‌نویسد (توسعه و آزمایش)؛ هیچ پیامکی ارسال نمی‌شود. */
final class LogSmsDriver implements SmsDriver
{
    public function send(string $mobile, string $body): array
    {
        $dir = BASE_PATH . '/storage/logs';
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        $ok = @file_put_contents($dir . '/sms.log', date('c') . "\t" . $mobile . "\t" . str_replace(["\r", "\n"], ' ', $body) . "\n", FILE_APPEND | LOCK_EX) !== false;
        return ['ok' => $ok, 'ref' => 'log', 'error' => $ok ? '' : 'نوشتن لاگ ممکن نشد.'];
    }
}
