<?php
declare(strict_types=1);

namespace App\Services\Sms;

interface SmsDriver
{
    /** @return array{ok: bool, ref: string, error: string} */
    public function send(string $mobile, string $body): array;
}
