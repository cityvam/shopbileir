<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\UserError;

/**
 * چرخه‌ی عمر چک با سند حسابداری خودکار:
 *  دریافتی: ثبت (بد: اسناد دریافتنی / بس: حساب مقابل) ← واگذاری به بانک ← وصول (بد: بانک / بس: اسناد دریافتنی) یا برگشت (سند ثبت معکوس می‌شود)
 *  صادره:   ثبت (بد: حساب مقابل / بس: اسناد پرداختنی) ← پاس (بد: اسناد پرداختنی / بس: بانک) یا ابطال (سند ثبت معکوس می‌شود)
 */
final class ChequeService
{
    public const STATUS_LABELS = [
        'in_hand' => 'نزد صندوق', 'deposited' => 'واگذار به بانک', 'cleared' => 'وصول‌شده', 'bounced' => 'برگشتی',
        'issued' => 'صادرشده', 'passed' => 'پاس‌شده', 'cancelled' => 'ابطال‌شده', 'endorsed' => 'پشت‌نویسی‌شده',
    ];

    /** جهت ← وضعیت جاری ← وضعیت‌های مجاز بعدی */
    public const FLOW = [
        'received' => ['in_hand' => ['deposited', 'cleared', 'bounced'], 'deposited' => ['in_hand', 'cleared', 'bounced']],
        'issued' => ['issued' => ['passed', 'cancelled']],
    ];

    public static function initialStatus(string $direction): string
    {
        return $direction === 'received' ? 'in_hand' : 'issued';
    }

    public static function register(int $companyId, array $d, int $userId): int
    {
        if (!in_array($d['direction'], ['received', 'issued'], true)) {
            throw new UserError('جهت چک نامعتبر است.');
        }
        return DB::tx(function () use ($companyId, $d, $userId) {
            $counter = DB::one("SELECT id, name FROM accounts WHERE id = ? AND company_id = ? AND is_active = 1", [$d['counter_account_id'], $companyId]);
            if (!$counter) {
                throw new UserError('حساب مقابل نامعتبر است.');
            }
            if ($d['bank_account_id'] && !DB::scalar('SELECT id FROM accounts WHERE id = ? AND company_id = ? AND type = ?', [$d['bank_account_id'], $companyId, 'asset'])) {
                throw new UserError('حساب بانک/صندوق نامعتبر است.');
            }
            if ($d['detail_id'] && !DB::scalar("SELECT id FROM dimensions WHERE id = ? AND company_id = ? AND kind = 'detail' AND is_active = 1", [$d['detail_id'], $companyId])) {
                throw new UserError('حساب تفصیلی نامعتبر یا غیرفعال است.');
            }
            if (DB::scalar('SELECT id FROM cheques WHERE company_id = ? AND direction = ? AND bank_name = ? AND cheque_no = ?', [$companyId, $d['direction'], $d['bank_name'], $d['cheque_no']])) {
                throw new UserError('چکی با همین شماره و بانک قبلاً ثبت شده است.');
            }
            $now = date('Y-m-d H:i:s');
            $id = DB::insert(
                'INSERT INTO cheques (company_id, direction, cheque_no, bank_name, amount, issue_date, due_date, party, detail_id, counter_account_id, bank_account_id, status, description, created_by, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [$companyId, $d['direction'], $d['cheque_no'], $d['bank_name'], $d['amount'], $d['issue_date'], $d['due_date'], $d['party'], $d['detail_id'], $d['counter_account_id'],
                 $d['bank_account_id'], self::initialStatus($d['direction']), $d['description'], $userId, $now]
            );
            $notes = self::notesAccountId($companyId, $d['direction']);
            $label = ($d['direction'] === 'received' ? 'ثبت چک دریافتی ' : 'ثبت چک صادره ') . $d['cheque_no'] . ' — ' . $d['party'];
            $lines = $d['direction'] === 'received'
                ? [[$notes, $d['amount'], 0, null, $d['detail_id'], null], [(int) $counter['id'], 0, $d['amount'], null, $d['detail_id'], null]]
                : [[(int) $counter['id'], $d['amount'], 0, null, $d['detail_id'], null], [$notes, 0, $d['amount'], null, $d['detail_id'], null]];
            $entry = Accounting::postById($companyId, $label, $lines, 'cheque', $id, $userId, $d['issue_date'], 'چک ' . $d['cheque_no']);
            DB::exec('UPDATE cheques SET reg_entry_id = ? WHERE id = ?', [$entry, $id]);
            Audit::log('cheque.create', 'cheque', $id, ['direction' => $d['direction'], 'amount' => $d['amount'], 'no' => $d['cheque_no']]);
            return $id;
        });
    }

    /** @return array<string,string> وضعیت‌های بعدی مجاز (کلید→برچسب) */
    public static function nextOptions(array $c): array
    {
        $out = [];
        foreach (self::FLOW[$c['direction']][$c['status']] ?? [] as $to) {
            $out[$to] = self::STATUS_LABELS[$to === 'cleared' && $c['direction'] === 'issued' ? 'passed' : $to] ?? $to;
        }
        return $out;
    }

    public static function transition(int $companyId, int $id, string $to, string $date, ?int $bankAccountId, string $reason, int $userId): void
    {
        $reason = trim($reason);
        DB::tx(function () use ($companyId, $id, $to, $date, $bankAccountId, $reason, $userId) {
            $c = DB::one('SELECT * FROM cheques WHERE id = ? AND company_id = ?', [$id, $companyId]) ?? throw new UserError('چک یافت نشد.');
            if ($c['direction'] === 'issued' && $to === 'cleared') {
                $to = 'passed';
            }
            $allowed = self::FLOW[$c['direction']][$c['status']] ?? [];
            $allowed = array_map(static fn ($x) => $c['direction'] === 'issued' && $x === 'cleared' ? 'passed' : $x, $allowed);
            if (!in_array($to, $allowed, true)) {
                throw new UserError('این تغییر وضعیت برای چک مجاز نیست.');
            }
            if (in_array($to, ['bounced', 'cancelled'], true) && mb_strlen($reason) < 5) {
                throw new UserError('دلیل برگشت یا ابطال را (حداقل ۵ نویسه) بنویسید.');
            }
            $bank = $bankAccountId ?: ($c['bank_account_id'] ? (int) $c['bank_account_id'] : null);
            if (in_array($to, ['deposited', 'cleared', 'passed'], true)) {
                if (!$bank || !DB::scalar('SELECT id FROM accounts WHERE id = ? AND company_id = ? AND type = ? AND is_active = 1', [$bank, $companyId, 'asset'])) {
                    throw new UserError('حساب بانک/صندوق را انتخاب کنید.');
                }
            }
            $n = DB::exec('UPDATE cheques SET status = ?, bank_account_id = ?, updated_at = ? WHERE id = ? AND company_id = ? AND status = ?', [$to, $bank, date('Y-m-d H:i:s'), $id, $companyId, $c['status']]);
            if ($n !== 1) {
                throw new UserError('وضعیت چک هم‌زمان تغییر کرد؛ صفحه را تازه کنید.');
            }
            $notes = self::notesAccountId($companyId, $c['direction']);
            $amount = (int) $c['amount'];
            $detail = $c['detail_id'] ? (int) $c['detail_id'] : null;
            $entry = null;
            if ($to === 'cleared') {
                $entry = Accounting::postById($companyId, 'وصول چک دریافتی ' . $c['cheque_no'] . ' — ' . $c['party'], [[$bank, $amount, 0, null, null, null], [$notes, 0, $amount, null, $detail, null]], 'cheque', $id, $userId, $date, 'چک ' . $c['cheque_no']);
            } elseif ($to === 'passed') {
                $entry = Accounting::postById($companyId, 'پاس‌شدن چک صادره ' . $c['cheque_no'] . ' — ' . $c['party'], [[$notes, $amount, 0, null, $detail, null], [$bank, 0, $amount, null, null, null]], 'cheque', $id, $userId, $date, 'چک ' . $c['cheque_no']);
            } elseif (in_array($to, ['bounced', 'cancelled'], true)) {
                $lines = [];
                foreach (DB::all('SELECT account_id, debit, credit, detail_id, cost_center_id FROM journal_lines WHERE entry_id = ? ORDER BY id', [$c['reg_entry_id']]) as $l) {
                    $lines[] = [(int) $l['account_id'], (int) $l['credit'], (int) $l['debit'], null, $l['detail_id'], $l['cost_center_id']];
                }
                $entry = Accounting::postById($companyId, ($to === 'bounced' ? 'برگشت چک ' : 'ابطال چک ') . $c['cheque_no'] . ' — ' . $c['party'], $lines, 'cheque', $id, $userId, $date, 'چک ' . $c['cheque_no']);
            }
            if ($entry) {
                DB::exec('UPDATE cheques SET final_entry_id = ? WHERE id = ?', [$entry, $id]);
            }
            DB::insert(
                'INSERT INTO status_history (company_id, entity, entity_id, from_status, to_status, reason, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [$companyId, 'cheque', $id, $c['status'], $to, $reason !== '' ? mb_substr($reason, 0, 500) : 'تغییر وضعیت چک', $userId, date('Y-m-d H:i:s')]
            );
            Audit::log('cheque.status', 'cheque', $id, ['from' => $c['status'], 'to' => $to, 'reason' => $reason, 'entry' => $entry]);
        });
    }

    /**
     * پشت‌نویسی چک دریافتیِ «نزد صندوق» به شخص ثالث برای تسویه‌ی بدهی:
     * سند: بدهکار حساب مقابل (بدهی/حساب طرف پشت‌نویس) ← بستانکار اسناد دریافتنی.
     */
    public static function endorse(int $companyId, int $id, int $counterAccountId, ?int $detailId, string $endorsee, string $date, int $userId): void
    {
        $endorsee = trim($endorsee);
        if (mb_strlen($endorsee) < 2) {
            throw new UserError('نام شخص دریافت‌کننده‌ی پشت‌نویسی را بنویسید.');
        }
        DB::tx(function () use ($companyId, $id, $counterAccountId, $detailId, $endorsee, $date, $userId) {
            $c = DB::one('SELECT * FROM cheques WHERE id = ? AND company_id = ?', [$id, $companyId]) ?? throw new UserError('چک یافت نشد.');
            if ($c['direction'] !== 'received' || $c['status'] !== 'in_hand') {
                throw new UserError('فقط چک دریافتیِ «نزد صندوق» قابل پشت‌نویسی است.');
            }
            $notes = self::notesAccountId($companyId, 'received');
            if ($counterAccountId === $notes || !DB::scalar('SELECT id FROM accounts WHERE id = ? AND company_id = ? AND is_active = 1', [$counterAccountId, $companyId])) {
                throw new UserError('حساب طرف پشت‌نویسی نامعتبر است.');
            }
            if ($detailId && !DB::scalar("SELECT id FROM dimensions WHERE id = ? AND company_id = ? AND kind = 'detail' AND is_active = 1", [$detailId, $companyId])) {
                throw new UserError('حساب تفصیلی نامعتبر یا غیرفعال است.');
            }
            $n = DB::exec("UPDATE cheques SET status = 'endorsed', endorsed_to = ?, updated_at = ? WHERE id = ? AND company_id = ? AND status = 'in_hand'", [mb_substr($endorsee, 0, 120), date('Y-m-d H:i:s'), $id, $companyId]);
            if ($n !== 1) {
                throw new UserError('وضعیت چک هم‌زمان تغییر کرد؛ صفحه را تازه کنید.');
            }
            $amount = (int) $c['amount'];
            $own = $c['detail_id'] ? (int) $c['detail_id'] : null;
            $entry = Accounting::postById($companyId, 'پشت‌نویسی چک دریافتی ' . $c['cheque_no'] . ' به ' . $endorsee, [
                [$counterAccountId, $amount, 0, null, $detailId, null], [$notes, 0, $amount, null, $own, null],
            ], 'cheque', $id, $userId, $date, 'چک ' . $c['cheque_no']);
            DB::exec('UPDATE cheques SET endorse_entry_id = ?, final_entry_id = ? WHERE id = ?', [$entry, $entry, $id]);
            DB::insert(
                'INSERT INTO status_history (company_id, entity, entity_id, from_status, to_status, reason, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [$companyId, 'cheque', $id, 'in_hand', 'endorsed', 'پشت‌نویسی به ' . mb_substr($endorsee, 0, 100), $userId, date('Y-m-d H:i:s')]
            );
            Audit::log('cheque.endorse', 'cheque', $id, ['to' => $endorsee, 'account' => $counterAccountId, 'entry' => $entry]);
        });
    }

    /** بازگشت چک پشت‌نویسی‌شده به صندوق (مثلاً شخص ثالث آن را برگرداند)؛ سند پشت‌نویسی معکوس می‌شود. */
    public static function unendorse(int $companyId, int $id, string $date, string $reason, int $userId): void
    {
        $reason = trim($reason);
        if (mb_strlen($reason) < 5) {
            throw new UserError('دلیل بازگشت پشت‌نویسی را (حداقل ۵ نویسه) بنویسید.');
        }
        DB::tx(function () use ($companyId, $id, $date, $reason, $userId) {
            $c = DB::one('SELECT * FROM cheques WHERE id = ? AND company_id = ?', [$id, $companyId]) ?? throw new UserError('چک یافت نشد.');
            if ($c['status'] !== 'endorsed' || !$c['endorse_entry_id']) {
                throw new UserError('این چک پشت‌نویسی نشده است.');
            }
            $n = DB::exec("UPDATE cheques SET status = 'in_hand', endorsed_to = NULL, final_entry_id = NULL, updated_at = ? WHERE id = ? AND company_id = ? AND status = 'endorsed'", [date('Y-m-d H:i:s'), $id, $companyId]);
            if ($n !== 1) {
                throw new UserError('وضعیت چک هم‌زمان تغییر کرد؛ صفحه را تازه کنید.');
            }
            $lines = [];
            foreach (DB::all('SELECT account_id, debit, credit, detail_id, cost_center_id FROM journal_lines WHERE entry_id = ? ORDER BY id', [$c['endorse_entry_id']]) as $l) {
                $lines[] = [(int) $l['account_id'], (int) $l['credit'], (int) $l['debit'], null, $l['detail_id'], $l['cost_center_id']];
            }
            $entry = Accounting::postById($companyId, 'بازگشت پشت‌نویسی چک ' . $c['cheque_no'] . ' — ' . $c['party'], $lines, 'cheque', $id, $userId, $date, 'چک ' . $c['cheque_no']);
            DB::insert(
                'INSERT INTO status_history (company_id, entity, entity_id, from_status, to_status, reason, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [$companyId, 'cheque', $id, 'endorsed', 'in_hand', mb_substr($reason, 0, 500), $userId, date('Y-m-d H:i:s')]
            );
            Audit::log('cheque.unendorse', 'cheque', $id, ['reason' => $reason, 'entry' => $entry]);
        });
    }

    private static function notesAccountId(int $companyId, string $direction): int
    {
        $code = $direction === 'received' ? Accounting::NOTES_REC : Accounting::NOTES_PAY;
        return (int) (DB::scalar('SELECT id FROM accounts WHERE company_id = ? AND code = ?', [$companyId, $code]) ?: throw new UserError('حساب اسناد در این شرکت تعریف نشده است.'));
    }
}
