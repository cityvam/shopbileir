<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\UserError;

/**
 * حسابداری دوطرفه: سال مالی، حساب‌های درختی (گروه ← حساب)، اسناد موقت/قطعی و ابطال سند.
 * همه گزارش‌ها فقط اسناد «قطعی» را می‌شمارند. اسناد خودکار (منشأ غیر manual) فقط قطعی و غیرقابل ویرایش‌اند.
 */
final class Accounting
{
    public const CASH = '1101';
    public const LOANS = '1201';
    public const WALLET = '2101';
    public const MERCHANT = '2201';
    public const INTEREST = '4101';
    public const COMMISSION = '4102';
    public const LATE_FEE = '4103';
    public const RETAINED = '3102';
    public const NOTES_REC = '1103';
    public const NOTES_PAY = '2103';

    /** گروه اصلی هر نوع حساب */
    public const GROUPS = [
        'asset' => ['1000', 'دارایی‌ها'],
        'liability' => ['2000', 'بدهی‌ها'],
        'equity' => ['3000', 'حقوق صاحبان سرمایه'],
        'revenue' => ['4000', 'درآمدها'],
        'expense' => ['5000', 'هزینه‌ها'],
    ];

    /** @return list<array{0:string,1:string,2:string}> کد، نام، نوع */
    public static function defaultChart(): array
    {
        return [
            [self::CASH, 'صندوق و بانک', 'asset'],
            [self::NOTES_REC, 'اسناد دریافتنی (چک‌های دریافتی)', 'asset'],
            [self::LOANS, 'مطالبات تسهیلات (اصل)', 'asset'],
            [self::NOTES_PAY, 'اسناد پرداختنی (چک‌های صادره)', 'liability'],
            [self::WALLET, 'کیف پول مشتریان', 'liability'],
            [self::MERCHANT, 'بدهی به فروشندگان', 'liability'],
            ['3101', 'سرمایه', 'equity'],
            [self::INTEREST, 'درآمد سود تسهیلات', 'revenue'],
            [self::COMMISSION, 'درآمد کارمزد فروشندگان', 'revenue'],
            [self::LATE_FEE, 'درآمد جریمه تأخیر', 'revenue'],
            ['5101', 'هزینه‌های عملیاتی', 'expense'],
        ];
    }

    public static function provision(int $companyId): void
    {
        self::ensureGroups($companyId);
        $groups = self::groupIds($companyId);
        foreach (self::defaultChart() as [$code, $name, $type]) {
            DB::exec('INSERT INTO accounts (company_id, code, name, type, is_system, parent_id) VALUES (?, ?, ?, ?, 1, ?)', [$companyId, $code, $name, $type, $groups[$type]]);
        }
        self::fiscalYearFor($companyId, date('Y-m-d'), false);
    }

    /** برای شرکت‌های موجود: گروه‌ها، اتصال حساب‌های بی‌پدر، سال مالی و انتساب اسناد قدیمی به سال مالی (ایدمپوتنت) */
    public static function upgradeCompany(int $companyId): void
    {
        self::ensureGroups($companyId);
        $groups = self::groupIds($companyId);
        foreach (self::defaultChart() as [$code, $name, $type]) {
            if (!DB::scalar('SELECT id FROM accounts WHERE company_id = ? AND code = ?', [$companyId, $code])) {
                DB::exec('INSERT INTO accounts (company_id, code, name, type, is_system, parent_id) VALUES (?, ?, ?, ?, 1, ?)', [$companyId, $code, $name, $type, $groups[$type]]);
            }
        }
        foreach (self::groupIds($companyId) as $type => $gid) {
            DB::exec('UPDATE accounts SET parent_id = ? WHERE company_id = ? AND type = ? AND parent_id IS NULL AND id <> ?', [$gid, $companyId, $type, $gid]);
        }
        foreach (DB::all('SELECT DISTINCT entry_date FROM journal_entries WHERE company_id = ? AND fiscal_year_id IS NULL', [$companyId]) as $r) {
            $fy = self::fiscalYearFor($companyId, $r['entry_date'], false);
            DB::exec('UPDATE journal_entries SET fiscal_year_id = ? WHERE company_id = ? AND entry_date = ? AND fiscal_year_id IS NULL', [$fy['id'], $companyId, $r['entry_date']]);
        }
        self::fiscalYearFor($companyId, date('Y-m-d'), false);
    }

    public static function ensureGroups(int $companyId): void
    {
        foreach (self::GROUPS as $type => [$code, $name]) {
            if (!DB::scalar('SELECT id FROM accounts WHERE company_id = ? AND code = ?', [$companyId, $code])) {
                DB::exec('INSERT INTO accounts (company_id, code, name, type, is_system) VALUES (?, ?, ?, ?, 1)', [$companyId, $code, $name, $type]);
            }
        }
    }

    /** @return array<string,int> نوع حساب ← شناسه گروه */
    private static function groupIds(int $companyId): array
    {
        $out = [];
        foreach (self::GROUPS as $type => [$code]) {
            $out[$type] = (int) DB::scalar('SELECT id FROM accounts WHERE company_id = ? AND code = ?', [$companyId, $code]);
        }
        return $out;
    }

    // ---------------------------------------------------------------- سال مالی

    /** سال مالی شمسی شامل تاریخ؛ در صورت نبود ساخته می‌شود. با $mustBeOpen بسته‌بودن خطا می‌دهد. */
    public static function fiscalYearFor(int $companyId, string $date, bool $mustBeOpen = true): array
    {
        $fy = DB::one('SELECT * FROM fiscal_years WHERE company_id = ? AND start_date <= ? AND end_date >= ?', [$companyId, $date, $date]);
        if (!$fy) {
            [$gy, $gm, $gd] = array_map('intval', explode('-', substr($date, 0, 10)));
            [$jy] = Jalali::toJalali($gy, $gm, $gd);
            $start = vsprintf('%04d-%02d-%02d', Jalali::toGregorian($jy, 1, 1));
            $end = vsprintf('%04d-%02d-%02d', Jalali::toGregorian($jy, 12, Jalali::daysInMonth($jy, 12)));
            DB::exec('INSERT INTO fiscal_years (company_id, title, start_date, end_date, status) VALUES (?, ?, ?, ?, ?)', [$companyId, 'سال مالی ' . $jy, $start, $end, 'open']);
            $fy = DB::one('SELECT * FROM fiscal_years WHERE company_id = ? AND start_date = ?', [$companyId, $start]);
        }
        if ($mustBeOpen && $fy['status'] !== 'open') {
            throw new UserError('«' . $fy['title'] . '» بسته است و ثبت یا تغییر سند در آن مجاز نیست.');
        }
        return $fy;
    }

    // ------------------------------------------------------------ ثبت خودکار

    /**
     * ثبت سند قطعی خودکار توسط رویدادهای کسب‌وکار.
     * @param list<array{0:string,1:int,2:int}> $lines  [کد حساب، بدهکار، بستانکار]
     */
    public static function post(int $companyId, string $description, array $lines, string $sourceType, ?int $sourceId, ?int $userId, ?string $date = null): int
    {
        $lines = array_values(array_filter($lines, static fn ($l) => $l[1] > 0 || $l[2] > 0));
        $codes = array_values(array_unique(array_column($lines, 0)));
        if (!$codes) {
            throw new \InvalidArgumentException('سند حسابداری متوازن نیست.');
        }
        $in = implode(',', array_fill(0, count($codes), '?'));
        $map = [];
        foreach (DB::all("SELECT id, code FROM accounts WHERE company_id = ? AND code IN ($in)", [$companyId, ...$codes]) as $a) {
            $map[$a['code']] = (int) $a['id'];
        }
        $byId = [];
        foreach ($lines as [$code, $d, $c]) {
            if (!isset($map[$code])) {
                throw new \RuntimeException("حساب $code در این شرکت تعریف نشده است.");
            }
            $byId[] = [$map[$code], $d, $c, null];
        }
        self::checkLines($companyId, $byId, true);
        return self::insertEntry($companyId, $description, $byId, $sourceType, $sourceId, $userId, $date ?? date('Y-m-d'), 'final', null);
    }

    /**
     * سند قطعی خودکار با شناسه‌ی حساب (برای حساب‌های انتخابی کاربر مثل بانک).
     * @param list<array{0:int,1:int,2:int,3:?string,4?:?int,5?:?int}> $lines
     */
    public static function postById(int $companyId, string $description, array $lines, string $sourceType, ?int $sourceId, ?int $userId, string $date, ?string $reference = null): int
    {
        $lines = array_values(array_filter($lines, static fn ($l) => $l[1] > 0 || $l[2] > 0));
        self::checkLines($companyId, $lines, true);
        return self::insertEntry($companyId, $description, $lines, $sourceType, $sourceId, $userId, $date, 'final', $reference);
    }

    // ---------------------------------------------------------- اسناد دستی

    /**
     * ایجاد یا ویرایش سند دستی. سند موقت می‌تواند نامتوازن باشد؛ سند قطعی باید متوازن باشد.
     * @param list<array{0:int,1:int,2:int,3:?string}> $lines [شناسه حساب، بدهکار، بستانکار، شرح]
     */
    public static function saveManual(int $companyId, ?int $entryId, string $date, string $description, ?string $reference, array $lines, string $status, int $userId): int
    {
        if (!in_array($status, ['draft', 'final'], true)) {
            throw new UserError('وضعیت سند معتبر نیست.');
        }
        if (mb_strlen($description) < 3) {
            throw new UserError('شرح سند را بنویسید.');
        }
        if ($status === 'draft') {
            // پیش‌نویس ناقص مجاز است: ردیف‌های بدون مبلغ نادیده گرفته می‌شوند
            $lines = array_values(array_filter($lines, static fn ($l) => $l[1] > 0 || $l[2] > 0));
        }
        self::checkLines($companyId, $lines, $status === 'final');
        $fy = self::fiscalYearFor($companyId, $date);

        if ($entryId === null) {
            return self::insertEntry($companyId, $description, $lines, 'manual', null, $userId, $date, $status, $reference);
        }
        $e = self::editable($companyId, $entryId);
        self::fiscalYearFor($companyId, $e['entry_date']);
        DB::exec(
            'UPDATE journal_entries SET entry_date = ?, description = ?, reference = ?, status = ?, fiscal_year_id = ? WHERE id = ? AND company_id = ? AND status = ?',
            [$date, mb_substr($description, 0, 250), $reference, $status, $fy['id'], $entryId, $companyId, 'draft']
        );
        DB::exec('DELETE FROM journal_lines WHERE entry_id = ?', [$entryId]);
        self::insertLines($entryId, $lines);
        return $entryId;
    }

    public static function finalize(int $companyId, int $entryId): void
    {
        $e = self::editable($companyId, $entryId);
        $lines = array_map(
            static fn ($l) => [(int) $l['account_id'], (int) $l['debit'], (int) $l['credit'], $l['description']],
            DB::all('SELECT account_id, debit, credit, description FROM journal_lines WHERE entry_id = ?', [$entryId])
        );
        self::checkLines($companyId, $lines, true);
        self::fiscalYearFor($companyId, $e['entry_date']);
        DB::exec("UPDATE journal_entries SET status = 'final' WHERE id = ? AND company_id = ? AND status = 'draft'", [$entryId, $companyId]);
    }

    public static function deleteDraft(int $companyId, int $entryId): void
    {
        self::editable($companyId, $entryId);
        DB::exec('DELETE FROM journal_lines WHERE entry_id = ?', [$entryId]);
        DB::exec("DELETE FROM journal_entries WHERE id = ? AND company_id = ? AND status = 'draft'", [$entryId, $companyId]);
    }

    /** ابطال سند دستی قطعی با صدور سند معکوس (سند اصلی هرگز حذف یا تغییر نمی‌کند) */
    public static function reverse(int $companyId, int $entryId, string $date, int $userId): int
    {
        $e = DB::one('SELECT * FROM journal_entries WHERE id = ? AND company_id = ?', [$entryId, $companyId]) ?? throw new UserError('سند یافت نشد.');
        if ($e['status'] !== 'final') {
            throw new UserError('فقط سند قطعی قابل ابطال است.');
        }
        if ($e['source_type'] !== 'manual') {
            throw new UserError('اسناد خودکار از روی عملیات کسب‌وکار صادر شده‌اند و با ابطال دستی تغییر نمی‌کنند.');
        }
        if ($e['reversed_by'] !== null || $e['reversal_of'] !== null) {
            throw new UserError('این سند قبلاً ابطال شده یا خودش سند ابطال است.');
        }
        $lines = [];
        foreach (DB::all('SELECT account_id, debit, credit, detail_id, cost_center_id FROM journal_lines WHERE entry_id = ? ORDER BY id', [$entryId]) as $l) {
            $lines[] = [(int) $l['account_id'], (int) $l['credit'], (int) $l['debit'], 'ابطال سند شماره ' . $e['entry_no'], $l['detail_id'], $l['cost_center_id']];
        }
        self::checkLines($companyId, $lines, true, true);
        $newId = self::insertEntry($companyId, 'ابطال سند شماره ' . $e['entry_no'] . ' — ' . $e['description'], $lines, 'manual', null, $userId, $date, 'final', null);
        $n = DB::exec('UPDATE journal_entries SET reversed_by = ? WHERE id = ? AND company_id = ? AND reversed_by IS NULL', [$newId, $entryId, $companyId]);
        if ($n !== 1) {
            throw new UserError('ابطال هم‌زمان شناسایی شد؛ دوباره تلاش کنید.');
        }
        DB::exec('UPDATE journal_entries SET reversal_of = ? WHERE id = ?', [$entryId, $newId]);
        return $newId;
    }

    private static function editable(int $companyId, int $entryId): array
    {
        $e = DB::one('SELECT * FROM journal_entries WHERE id = ? AND company_id = ?', [$entryId, $companyId]) ?? throw new UserError('سند یافت نشد.');
        if ($e['status'] !== 'draft' || $e['source_type'] !== 'manual') {
            throw new UserError('فقط سند دستیِ موقت قابل ویرایش، قطعی‌سازی یا حذف است. سند قطعی را باید ابطال کرد.');
        }
        return $e;
    }

    // ------------------------------------------------------------- داخلی

    /**
     * اعتبارسنجی ردیف‌ها: حساب موجود، فعال و غیرگروه؛ هر ردیف فقط یک سمت؛ در حالت قطعی توازن.
     * @param list<array{0:int,1:int,2:int,3:?string}> $lines
     */
    private static function checkLines(int $companyId, array $lines, bool $requireBalanced, bool $allowInactive = false): void
    {
        if (!$lines) {
            throw new UserError('سند حداقل یک ردیف لازم دارد.');
        }
        $ids = array_values(array_unique(array_map(static fn ($l) => (int) $l[0], $lines)));
        $in = implode(',', array_fill(0, count($ids), '?'));
        $rows = [];
        foreach (DB::all(
            "SELECT a.id, a.code, a.name, a.is_active, (SELECT COUNT(*) FROM accounts c WHERE c.parent_id = a.id) AS kids FROM accounts a WHERE a.company_id = ? AND a.id IN ($in)",
            [$companyId, ...$ids]
        ) as $r) {
            $rows[(int) $r['id']] = $r;
        }
        if (!$allowInactive) {
            self::checkDimensions($companyId, $lines);
        }
        $debit = 0;
        $credit = 0;
        foreach ($lines as [$accId, $d, $c]) {
            $a = $rows[(int) $accId] ?? null;
            if (!$a) {
                throw new UserError('حساب یکی از ردیف‌ها نامعتبر است.');
            }
            if ((int) $a['kids'] > 0) {
                throw new UserError('روی حساب گروه «' . $a['name'] . '» سند ثبت نمی‌شود؛ حساب زیرمجموعه را انتخاب کنید.');
            }
            if (!$allowInactive && (int) $a['is_active'] !== 1) {
                throw new UserError('حساب «' . $a['name'] . '» غیرفعال است.');
            }
            if ($d < 0 || $c < 0 || ($d > 0 && $c > 0) || ($d === 0 && $c === 0)) {
                throw new UserError('هر ردیف باید دقیقاً یکی از مبلغ بدهکار یا بستانکار را (بزرگ‌تر از صفر) داشته باشد.');
            }
            $debit += $d;
            $credit += $c;
        }
        if ($requireBalanced) {
            if (count($lines) < 2) {
                throw new UserError('سند قطعی حداقل دو ردیف لازم دارد.');
            }
            if ($debit !== $credit) {
                throw new UserError('جمع بدهکار (' . number_format($debit) . ') و بستانکار (' . number_format($credit) . ') برابر نیست.');
            }
        }
    }

    /** تفصیلی و مرکز هزینه‌ی هر ردیف باید متعلق به همین شرکت، از نوع درست و فعال باشد */
    private static function checkDimensions(int $companyId, array $lines): void
    {
        foreach ([4 => 'detail', 5 => 'cost_center'] as $idx => $kind) {
            $ids = array_values(array_unique(array_filter(array_map(static fn ($l) => (int) ($l[$idx] ?? 0), $lines))));
            if (!$ids) {
                continue;
            }
            $in = implode(',', array_fill(0, count($ids), '?'));
            $ok = (int) DB::scalar("SELECT COUNT(*) FROM dimensions WHERE company_id = ? AND kind = ? AND is_active = 1 AND id IN ($in)", [$companyId, $kind, ...$ids]);
            if ($ok !== count($ids)) {
                throw new UserError($kind === 'detail' ? 'حساب تفصیلی یکی از ردیف‌ها نامعتبر یا غیرفعال است.' : 'مرکز هزینه‌ی یکی از ردیف‌ها نامعتبر یا غیرفعال است.');
            }
        }
    }

    private static function insertEntry(int $companyId, string $description, array $lines, string $sourceType, ?int $sourceId, ?int $userId, string $date, string $status, ?string $reference): int
    {
        $fy = self::fiscalYearFor($companyId, $date);
        $no = (int) DB::scalar('SELECT COALESCE(MAX(entry_no), 0) + 1 FROM journal_entries WHERE company_id = ?', [$companyId]);
        $entryId = DB::insert(
            'INSERT INTO journal_entries (company_id, entry_no, entry_date, description, source_type, source_id, created_by, created_at, status, reference, fiscal_year_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$companyId, $no, $date, mb_substr($description, 0, 250), $sourceType, $sourceId, $userId, date('Y-m-d H:i:s'), $status, $reference, $fy['id']]
        );
        self::insertLines($entryId, $lines);
        return $entryId;
    }

    private static function insertLines(int $entryId, array $lines): void
    {
        foreach ($lines as $l) {
            [$accId, $d, $c, $desc] = $l;
            DB::exec(
                'INSERT INTO journal_lines (entry_id, account_id, debit, credit, description, detail_id, cost_center_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$entryId, $accId, $d, $c, $desc !== null && $desc !== '' ? mb_substr($desc, 0, 250) : null, ($l[4] ?? null) ?: null, ($l[5] ?? null) ?: null]
            );
        }
    }

    // ------------------------------------------------------------ سند اختتامیه

    /** سند اختتامیه‌ی فعال (ابطال‌نشده) سال مالی یا null */
    public static function closingEntry(int $companyId, int $fiscalYearId): ?array
    {
        return DB::one("SELECT * FROM journal_entries WHERE company_id = ? AND source_type = 'closing' AND source_id = ? AND reversed_by IS NULL", [$companyId, $fiscalYearId]);
    }

    /**
     * سند اختتامیه: مانده‌ی همه‌ی حساب‌های درآمد و هزینه‌ی سال مالی را صفر و سود/زیان را به «سود (زیان) انباشته» منتقل می‌کند.
     * سند قطعی و خودکار است؛ با undoClosing باطل می‌شود. @return int شناسه سند
     */
    public static function closeYear(int $companyId, int $fiscalYearId, int $userId): int
    {
        $fy = DB::one('SELECT * FROM fiscal_years WHERE id = ? AND company_id = ?', [$fiscalYearId, $companyId]) ?? throw new UserError('سال مالی یافت نشد.');
        if ($fy['status'] !== 'open') {
            throw new UserError('سال مالی بسته است؛ ابتدا آن را بازگشایی کنید.');
        }
        if (self::closingEntry($companyId, $fiscalYearId)) {
            throw new UserError('برای این سال مالی قبلاً سند اختتامیه صادر شده است.');
        }
        if ((int) DB::scalar("SELECT COUNT(*) FROM journal_entries WHERE fiscal_year_id = ? AND status = 'draft'", [$fiscalYearId]) > 0) {
            throw new UserError('ابتدا اسناد موقت این سال مالی را قطعی یا حذف کنید.');
        }
        $retained = DB::scalar('SELECT id FROM accounts WHERE company_id = ? AND code = ?', [$companyId, self::RETAINED]);
        if (!$retained) {
            $eq = (int) DB::scalar('SELECT id FROM accounts WHERE company_id = ? AND code = ?', [$companyId, self::GROUPS['equity'][0]]);
            $retained = DB::insert('INSERT INTO accounts (company_id, code, name, type, is_system, parent_id) VALUES (?, ?, ?, ?, 1, ?)', [$companyId, self::RETAINED, 'سود (زیان) انباشته', 'equity', $eq ?: null]);
        }
        $lines = [];
        $net = 0; // بدهکار - بستانکار کل درآمد/هزینه
        foreach (DB::all(
            "SELECT a.id, a.type, COALESCE(SUM(l.debit), 0) AS d, COALESCE(SUM(l.credit), 0) AS c
             FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id JOIN accounts a ON a.id = l.account_id
             WHERE e.company_id = ? AND e.status = 'final' AND e.entry_date >= ? AND e.entry_date <= ? AND a.type IN ('revenue', 'expense')
               AND e.source_type NOT IN ('closing', 'closing_rev')
             GROUP BY a.id, a.type ORDER BY a.id",
            [$companyId, $fy['start_date'], $fy['end_date']]
        ) as $r) {
            $bal = (int) $r['d'] - (int) $r['c'];
            if ($bal === 0) {
                continue;
            }
            $net += $bal;
            $lines[] = [(int) $r['id'], $bal < 0 ? -$bal : 0, $bal > 0 ? $bal : 0, 'اختتام حساب'];
        }
        if (!$lines) {
            throw new UserError('در این سال مالی گردش درآمد یا هزینه‌ای برای اختتام وجود ندارد.');
        }
        if ($net < 0) { // سود: بستانکار انباشته
            $lines[] = [(int) $retained, 0, -$net, 'انتقال سود سال'];
        } elseif ($net > 0) {
            $lines[] = [(int) $retained, $net, 0, 'انتقال زیان سال'];
        }
        self::checkLines($companyId, $lines, true, true);
        return self::insertEntry($companyId, 'سند اختتامیه ' . $fy['title'], $lines, 'closing', $fiscalYearId, $userId, $fy['end_date'], 'final', null);
    }

    /** ابطال سند اختتامیه با سند معکوس (برای اصلاح و صدور دوباره) */
    public static function undoClosing(int $companyId, int $fiscalYearId, int $userId): int
    {
        $e = self::closingEntry($companyId, $fiscalYearId) ?? throw new UserError('سند اختتامیه‌ی فعالی برای این سال مالی وجود ندارد.');
        $fy = DB::one('SELECT * FROM fiscal_years WHERE id = ? AND company_id = ?', [$fiscalYearId, $companyId]);
        if ($fy['status'] !== 'open') {
            throw new UserError('سال مالی بسته است؛ ابتدا آن را بازگشایی کنید.');
        }
        $lines = [];
        foreach (DB::all('SELECT account_id, debit, credit FROM journal_lines WHERE entry_id = ? ORDER BY id', [$e['id']]) as $l) {
            $lines[] = [(int) $l['account_id'], (int) $l['credit'], (int) $l['debit'], 'ابطال سند اختتامیه'];
        }
        $newId = self::insertEntry($companyId, 'ابطال سند اختتامیه (شماره ' . $e['entry_no'] . ')', $lines, 'closing_rev', $fiscalYearId, $userId, $e['entry_date'], 'final', null);
        if (DB::exec('UPDATE journal_entries SET reversed_by = ? WHERE id = ? AND reversed_by IS NULL', [$newId, $e['id']]) !== 1) {
            throw new UserError('ابطال هم‌زمان شناسایی شد؛ دوباره تلاش کنید.');
        }
        DB::exec('UPDATE journal_entries SET reversal_of = ? WHERE id = ?', [$e['id'], $newId]);
        return $newId;
    }

    // ------------------------------------------------------------ گزارش

    /**
     * درخت حساب‌ها با گردش بازه و مانده اول دوره (فقط اسناد قطعی؛ مجموع گروه‌ها از زیرمجموعه‌ها).
     * @return list<array{id:int,parent_id:?int,code:string,name:string,type:string,is_active:int,is_system:int,depth:int,kids:int,open:int,debit:int,credit:int,close:int,balance:int}>
     * open/close: مانده خالص بدهکار-بستانکار؛ balance: مانده با ماهیت حساب.
     */
    public static function tree(int $companyId, string $from, string $to, bool $excludeClosing = false): array
    {
        $accounts = DB::all('SELECT id, parent_id, code, name, type, is_active, is_system FROM accounts WHERE company_id = ? ORDER BY code', [$companyId]);
        $sums = [];
        $sql = "SELECT l.account_id, COALESCE(SUM(l.debit), 0) AS d, COALESCE(SUM(l.credit), 0) AS c
                FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
                WHERE e.company_id = ? AND e.status = 'final' AND e.entry_date %s" . ($excludeClosing ? " AND e.source_type NOT IN ('closing', 'closing_rev')" : '') . ' GROUP BY l.account_id';
        foreach (DB::all(sprintf($sql, '< ?'), [$companyId, $from]) as $r) {
            $sums[(int) $r['account_id']]['open'] = (int) $r['d'] - (int) $r['c'];
        }
        foreach (DB::all(sprintf($sql, '>= ? AND e.entry_date <= ?'), [$companyId, $from, $to]) as $r) {
            $sums[(int) $r['account_id']]['d'] = (int) $r['d'];
            $sums[(int) $r['account_id']]['c'] = (int) $r['c'];
        }
        $nodes = [];
        $children = [];
        foreach ($accounts as $a) {
            $id = (int) $a['id'];
            $nodes[$id] = [
                'id' => $id, 'parent_id' => $a['parent_id'] !== null ? (int) $a['parent_id'] : null, 'code' => $a['code'], 'name' => $a['name'],
                'type' => $a['type'], 'is_active' => (int) $a['is_active'], 'is_system' => (int) $a['is_system'], 'depth' => 0, 'kids' => 0,
                'open' => $sums[$id]['open'] ?? 0, 'debit' => $sums[$id]['d'] ?? 0, 'credit' => $sums[$id]['c'] ?? 0,
            ];
            $children[$nodes[$id]['parent_id'] ?? 0][] = $id;
        }
        $ordered = [];
        $walk = function (int $parent, int $depth) use (&$walk, &$nodes, &$children, &$ordered): array {
            $acc = ['open' => 0, 'debit' => 0, 'credit' => 0];
            foreach ($children[$parent] ?? [] as $id) {
                $nodes[$id]['depth'] = $depth;
                $nodes[$id]['kids'] = count($children[$id] ?? []);
                $ordered[] = $id;
                if ($nodes[$id]['kids'] > 0) {
                    $sub = $walk($id, $depth + 1);
                    foreach ($sub as $k => $v) {
                        $nodes[$id][$k] += $v;
                    }
                }
                foreach (['open', 'debit', 'credit'] as $k) {
                    $acc[$k] += $nodes[$id][$k];
                }
            }
            return $acc;
        };
        $walk(0, 0);
        $out = [];
        foreach ($ordered as $id) {
            $n = $nodes[$id];
            $n['close'] = $n['open'] + $n['debit'] - $n['credit'];
            $n['balance'] = in_array($n['type'], ['asset', 'expense'], true) ? $n['close'] : -$n['close'];
            $out[] = $n;
        }
        return $out;
    }

    /** شناسه حساب و همه زیرمجموعه‌های آن */
    public static function descendantIds(int $companyId, int $accountId): array
    {
        $parents = [];
        foreach (DB::all('SELECT id, parent_id FROM accounts WHERE company_id = ?', [$companyId]) as $a) {
            $parents[(int) $a['id']] = $a['parent_id'] !== null ? (int) $a['parent_id'] : null;
        }
        $ids = [$accountId];
        $changed = true;
        while ($changed) {
            $changed = false;
            foreach ($parents as $id => $p) {
                if ($p !== null && in_array($p, $ids, true) && !in_array($id, $ids, true)) {
                    $ids[] = $id;
                    $changed = true;
                }
            }
        }
        return $ids;
    }

    /** مانده با ماهیت حساب: دارایی و هزینه بدهکار، بقیه بستانکار */
    public static function balance(string $type, int $debit, int $credit): int
    {
        return in_array($type, ['asset', 'expense'], true) ? $debit - $credit : $credit - $debit;
    }

    public static function typeLabel(string $type): string
    {
        return ['asset' => 'دارایی', 'liability' => 'بدهی', 'equity' => 'سرمایه', 'revenue' => 'درآمد', 'expense' => 'هزینه'][$type] ?? $type;
    }
}
