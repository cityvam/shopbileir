<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Database as DB;
use App\Core\Env;
use App\Core\UserError;
use App\Services\Gateway\Gateways;

/** لینک‌های پرداخت آنلاین: ساخت توسط کارمند، پرداخت عمومی با توکن، تأیید سمت سرور و ثبت حسابداری. */
final class PaymentLinkService
{
    public const STATUS_LABELS = ['pending' => 'در انتظار پرداخت', 'paid' => 'پرداخت‌شده', 'failed' => 'ناموفق', 'cancelled' => 'لغوشده', 'expired' => 'منقضی'];
    public const TTL_HOURS = 72;

    public static function url(string $token): string
    {
        $base = rtrim((string) Env::get('APP_URL', ''), '/');
        if ($base === '') {
            $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
            $base = ($https ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost');
        }
        return $base . '/pay?t=' . $token;
    }

    /** @return array{id: int, token: string} */
    public static function create(int $companyId, string $kind, int $customerId, ?int $installmentId, int $amount, int $userId, string $note = ''): array
    {
        if (!in_array($kind, ['installment', 'topup'], true) || $amount <= 0) {
            throw new UserError('مبلغ یا نوع پرداخت معتبر نیست.');
        }
        if (!DB::one('SELECT id FROM customers WHERE id = ? AND company_id = ?', [$customerId, $companyId])) {
            throw new UserError('مشتری یافت نشد.');
        }
        if ($kind === 'installment') {
            $inst = DB::one(
                "SELECT i.amount, i.paid_amount FROM installments i JOIN loans l ON l.id = i.loan_id
                 WHERE i.id = ? AND i.company_id = ? AND l.customer_id = ? AND l.status = 'active'",
                [$installmentId, $companyId, $customerId]
            ) ?? throw new UserError('قسط یافت نشد یا تسهیلات فعال نیست.');
            $remaining = (int) $inst['amount'] - (int) $inst['paid_amount'];
            if ($remaining <= 0) {
                throw new UserError('این قسط قبلاً تسویه شده است.');
            }
            if ($amount > $remaining) {
                throw new UserError('مبلغ از باقی‌مانده قسط (' . number_format($remaining) . ' ریال) بیشتر است.');
            }
        }
        // لینک معلق قبلی برای همین قسط باطل می‌شود تا هم‌زمان دو لینک فعال نباشد
        if ($kind === 'installment') {
            DB::exec("UPDATE payment_requests SET status = 'cancelled' WHERE installment_id = ? AND status = 'pending'", [$installmentId]);
        }
        $token = bin2hex(random_bytes(20));
        $id = DB::insert(
            'INSERT INTO payment_requests (company_id, token, kind, customer_id, installment_id, amount, status, note, expires_at, created_by, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$companyId, $token, $kind, $customerId, $installmentId, $amount, 'pending', $note !== '' ? $note : null,
                date('Y-m-d H:i:s', time() + self::TTL_HOURS * 3600), $userId, date('Y-m-d H:i:s')]
        );
        Audit::log('payreq.create', 'payment_request', $id, ['kind' => $kind, 'amount' => $amount, 'installment' => $installmentId], $companyId);
        return ['id' => $id, 'token' => $token];
    }

    /** درخواست را با توکن می‌خواند؛ منقضی‌ها را در همین لحظه منقضی می‌کند. */
    public static function byToken(string $token): ?array
    {
        if (!preg_match('/^[a-f0-9]{40}$/', $token)) {
            return null;
        }
        $r = DB::one(
            'SELECT pr.*, c.full_name, co.name AS company_name FROM payment_requests pr
             JOIN customers c ON c.id = pr.customer_id JOIN companies co ON co.id = pr.company_id WHERE pr.token = ?',
            [$token]
        );
        if ($r && $r['status'] === 'pending' && $r['expires_at'] < date('Y-m-d H:i:s')) {
            DB::exec("UPDATE payment_requests SET status = 'expired' WHERE id = ? AND status = 'pending'", [$r['id']]);
            $r['status'] = 'expired';
        }
        return $r;
    }

    /** شروع پرداخت: آدرس هدایت به درگاه را برمی‌گرداند. */
    public static function start(array $req): string
    {
        $gw = Gateways::active() ?? throw new UserError('پرداخت آنلاین فعلاً فعال نیست.');
        if ($req['status'] !== 'pending') {
            throw new UserError('این لینک دیگر قابل پرداخت نیست.');
        }
        // مبلغ قسط ممکن است بین ساخت لینک و پرداخت تغییر کرده باشد
        if ($req['kind'] === 'installment') {
            $inst = DB::one('SELECT amount, paid_amount FROM installments WHERE id = ?', [$req['installment_id']]);
            if (!$inst || (int) $inst['amount'] - (int) $inst['paid_amount'] < (int) $req['amount']) {
                DB::exec("UPDATE payment_requests SET status = 'cancelled' WHERE id = ? AND status = 'pending'", [$req['id']]);
                throw new UserError('وضعیت قسط تغییر کرده است؛ لینک جدید بگیرید.');
            }
        }
        $callback = preg_replace('#/pay\?t=.*$#', '/pay/return?t=' . $req['token'], self::url($req['token'])) ?? '';
        try {
            $r = $gw->request($req, $callback, 'پرداخت ' . ($req['kind'] === 'installment' ? 'قسط' : 'شارژ کیف پول') . ' - ' . $req['full_name']);
        } catch (\RuntimeException $e) {
            throw new UserError($e->getMessage());
        }
        DB::exec('UPDATE payment_requests SET gateway = ?, authority = ? WHERE id = ?', [$gw->name(), $r['authority'], $req['id']]);
        return $r['url'];
    }

    /**
     * بازگشت از درگاه: تأیید سمت سرور و ثبت پرداخت؛ ایدمپوتنت (بازگشت تکراری هیچ ثبت دوباره‌ای نمی‌کند).
     * @return array{status: string, message: string}
     */
    public static function complete(array $req, array $query): array
    {
        if ($req['status'] === 'paid') {
            return ['status' => 'paid', 'message' => 'این پرداخت قبلاً ثبت شده است.'];
        }
        if ($req['status'] !== 'pending' || !$req['authority']) {
            return ['status' => $req['status'], 'message' => 'این لینک دیگر قابل پرداخت نیست.'];
        }
        $gw = Gateways::active();
        if (!$gw || $gw->name() !== $req['gateway']) {
            return ['status' => 'failed', 'message' => 'درگاه پرداخت در دسترس نیست.'];
        }
        $v = $gw->verify($req, $query);
        if (!$v['ok']) {
            DB::exec("UPDATE payment_requests SET status = 'failed', note = ? WHERE id = ? AND status = 'pending'", [mb_substr($v['message'], 0, 240), $req['id']]);
            Audit::log('payreq.failed', 'payment_request', (int) $req['id'], ['gateway' => $req['gateway']], (int) $req['company_id']);
            return ['status' => 'failed', 'message' => $v['message'] ?: 'پرداخت ناموفق بود.'];
        }
        $msg = DB::tx(function () use ($req, $v) {
            // فقط یک درخواست هم‌زمان می‌تواند pending را paid کند
            $n = DB::exec("UPDATE payment_requests SET status = 'paid', ref_id = ?, paid_at = ? WHERE id = ? AND status = 'pending'", [$v['ref'], date('Y-m-d H:i:s'), $req['id']]);
            if ($n !== 1) {
                return 'این پرداخت قبلاً ثبت شده است.';
            }
            $cid = (int) $req['company_id'];
            $extra = ['payment_request' => (int) $req['id'], 'ref' => $v['ref']];
            if ($req['kind'] === 'installment') {
                $res = CollectionService::payInstallment($cid, (int) $req['installment_id'], (int) $req['amount'], 'online', (int) $req['created_by'], $extra);
                if ($res === true) {
                    return '';
                }
                // وجه دریافت شده اما قسط قابل ثبت نبود (مثلاً هم‌زمان نقدی تسویه شد): به کیف پول مشتری می‌رود
                CollectionService::topup($cid, (int) $req['customer_id'], (int) $req['amount'], (int) $req['created_by'], $req['full_name'], $extra);
                DB::exec('UPDATE payment_requests SET note = ? WHERE id = ?', ['قسط قابل ثبت نبود؛ مبلغ به کیف پول افزوده شد: ' . $res, $req['id']]);
                return 'مبلغ به کیف پول شما افزوده شد.';
            }
            CollectionService::topup($cid, (int) $req['customer_id'], (int) $req['amount'], (int) $req['created_by'], $req['full_name'], $extra);
            return '';
        });
        NotificationService::enqueue((int) $req['company_id'], (int) $req['customer_id'], (string) (DB::scalar('SELECT mobile FROM customers WHERE id = ?', [$req['customer_id']]) ?? ''), 'payment_ok',
            ['name' => $req['full_name'], 'amount' => fa(number_format((int) $req['amount'])), 'ref' => $v['ref']], 'pay:' . $req['id']);
        return ['status' => 'paid', 'message' => $msg];
    }

    public static function cancel(int $companyId, int $id): bool
    {
        $n = DB::exec("UPDATE payment_requests SET status = 'cancelled' WHERE id = ? AND company_id = ? AND status = 'pending'", [$id, $companyId]);
        if ($n === 1) {
            Audit::log('payreq.cancel', 'payment_request', $id, [], $companyId);
        }
        return $n === 1;
    }
}
