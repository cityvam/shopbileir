<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;
use App\Core\Jalali;

/**
 * ورود صورت‌حساب بانکی (CSV) و مغایرت‌گیری خودکار با ردیف‌های قطعیِ تطبیق‌نشده‌ی حساب بانک.
 * واریز بانک ↔ بدهکار دفتر، برداشت بانک ↔ بستانکار دفتر؛ جفت‌سازی یک‌به‌یک با مبلغ برابر و نزدیک‌ترین تاریخ (حداکثر ۵ روز).
 */
final class BankStatementImport
{
    public const MAX_ROWS = 2000;
    public const DAY_TOLERANCE = 5;
    private const ALIASES = [
        'date' => ['date', 'تاریخ'],
        'desc' => ['description', 'desc', 'شرح', 'توضیحات', 'شرح تراکنش'],
        'deposit' => ['deposit', 'واریز', 'بستانکار', 'credit', 'ورودی'],
        'withdraw' => ['withdrawal', 'withdraw', 'برداشت', 'بدهکار', 'debit', 'خروجی'],
        'amount' => ['amount', 'مبلغ'],
        'balance' => ['balance', 'مانده', 'مانده پس از تراکنش'],
    ];

    private static function digits(string $s): string
    {
        return strtr($s, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9', '٬' => ',', '٫' => '.']);
    }

    private static function money(string $v): ?int
    {
        $v = trim(str_replace([',', ' '], '', $v));
        if ($v === '' || $v === '-') {
            return 0;
        }
        $neg = str_starts_with($v, '-') || (str_starts_with($v, '(') && str_ends_with($v, ')'));
        $v = ltrim(trim($v, '()-'), '+');
        if (!ctype_digit($v) || strlen($v) > 15) {
            return null;
        }
        return $neg ? -(int) $v : (int) $v;
    }

    /**
     * @return array{fatal:?string, rows:list<array{line:int,date:string,desc:string,deposit:int,withdraw:int,balance:?int}>, errors:list<string>}
     */
    public static function parse(string $csv): array
    {
        $csv = ltrim(self::digits($csv), "\xEF\xBB\xBF");
        $first = strtok($csv, "\n") ?: '';
        $delim = substr_count($first, ';') > substr_count($first, ',') ? ';' : (substr_count($first, "\t") > substr_count($first, ',') ? "\t" : ',');
        $fh = fopen('php://memory', 'r+');
        fwrite($fh, $csv);
        rewind($fh);
        $header = fgetcsv($fh, 0, $delim);
        if (!$header) {
            return ['fatal' => 'فایل خالی است.', 'rows' => [], 'errors' => []];
        }
        $idx = [];
        foreach ($header as $i => $h) {
            $h = mb_strtolower(trim((string) $h));
            foreach (self::ALIASES as $key => $names) {
                if (in_array($h, array_map('mb_strtolower', $names), true) && !isset($idx[$key])) {
                    $idx[$key] = $i;
                }
            }
        }
        if (!isset($idx['date']) || (!isset($idx['amount']) && !isset($idx['deposit']) && !isset($idx['withdraw']))) {
            return ['fatal' => 'ستون‌های «تاریخ» و «واریز/برداشت» (یا «مبلغ») در سطر عنوان پیدا نشد.', 'rows' => [], 'errors' => []];
        }
        $rows = [];
        $errors = [];
        $line = 1;
        while (($r = fgetcsv($fh, 0, $delim)) !== false) {
            $line++;
            if (count(array_filter($r, static fn ($v) => trim((string) $v) !== '')) === 0) {
                continue;
            }
            if (count($rows) >= self::MAX_ROWS) {
                return ['fatal' => 'حداکثر ' . self::MAX_ROWS . ' سطر در هر فایل مجاز است.', 'rows' => $rows, 'errors' => $errors];
            }
            $rawDate = trim((string) ($r[$idx['date']] ?? ''));
            $date = Jalali::parse($rawDate) ?? (preg_match('/^(20\d\d)-(\d\d)-(\d\d)$/', $rawDate) ? $rawDate : null);
            $dep = 0;
            $wd = 0;
            $bad = false;
            if (isset($idx['amount'])) {
                $a = self::money((string) ($r[$idx['amount']] ?? ''));
                $bad = $a === null;
                $dep = max((int) $a, 0);
                $wd = max(-(int) $a, 0);
            } else {
                $d = isset($idx['deposit']) ? self::money((string) ($r[$idx['deposit']] ?? '')) : 0;
                $w = isset($idx['withdraw']) ? self::money((string) ($r[$idx['withdraw']] ?? '')) : 0;
                $bad = $d === null || $w === null;
                $dep = abs((int) $d);
                $wd = abs((int) $w);
            }
            if ($date === null || $bad || ($dep === 0 && $wd === 0) || ($dep > 0 && $wd > 0)) {
                $errors[] = "سطر $line: تاریخ شمسی یا مبلغ معتبر نیست.";
                continue;
            }
            $bal = isset($idx['balance']) ? self::money((string) ($r[$idx['balance']] ?? '')) : null;
            $rows[] = ['line' => $line, 'date' => $date, 'desc' => mb_substr(trim((string) ($r[$idx['desc'] ?? -1] ?? '')), 0, 200), 'deposit' => $dep, 'withdraw' => $wd, 'balance' => $bal];
        }
        return ['fatal' => $rows || $errors ? null : 'هیچ سطر قابل خواندنی پیدا نشد.', 'rows' => $rows, 'errors' => $errors];
    }

    /**
     * @param list<array{line:int,date:string,desc:string,deposit:int,withdraw:int,balance:?int}> $rows
     * @return array{matched: array<int,int>, unmatched_bank: list<array>, unmatched_book: int, closing: ?int, last_date: ?string}
     */
    public static function match(int $companyId, int $accountId, array $rows): array
    {
        $book = DB::all(
            "SELECT l.id, e.entry_date, l.debit, l.credit FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
             WHERE e.company_id = ? AND e.status = 'final' AND l.account_id = ? AND l.reconciliation_id IS NULL ORDER BY e.entry_date, l.id",
            [$companyId, $accountId]
        );
        $used = [];
        $matched = [];
        $unmatched = [];
        foreach ($rows as $i => $r) {
            $amount = $r['deposit'] > 0 ? $r['deposit'] : $r['withdraw'];
            $field = $r['deposit'] > 0 ? 'debit' : 'credit';
            $best = null;
            $bestGap = PHP_INT_MAX;
            foreach ($book as $b) {
                if (isset($used[$b['id']]) || (int) $b[$field] !== $amount) {
                    continue;
                }
                $gap = abs((int) round((strtotime($b['entry_date']) - strtotime($r['date'])) / 86400));
                if ($gap <= self::DAY_TOLERANCE && $gap < $bestGap) {
                    $best = (int) $b['id'];
                    $bestGap = $gap;
                }
            }
            if ($best !== null) {
                $used[$best] = true;
                $matched[$best] = $i;
            } else {
                $unmatched[] = $r;
            }
        }
        $last = $rows ? end($rows) : null;
        return [
            'matched' => $matched, 'unmatched_bank' => $unmatched, 'unmatched_book' => count($book) - count($matched),
            'closing' => $last['balance'] ?? null, 'last_date' => $last['date'] ?? null,
        ];
    }
}
