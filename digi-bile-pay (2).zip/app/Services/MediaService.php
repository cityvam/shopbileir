<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\UserError;

/**
 * آپلود امن تصویر: نوع واقعی با finfo، بازسازی کامل با GD (حذف هر محتوای پنهان و EXIF)،
 * تغییر اندازه، نام تصادفی و ذخیره در storage/uploads خارج از وب‌روت. هر مرجع (لوگو/کالا) یک تصویر دارد.
 */
final class MediaService
{
    public const MAX_BYTES = 2 * 1024 * 1024;
    public const MAX_DIM = 6000;
    /** kind => [حداکثر ضلع بزرگ، کیفیت] */
    private const KINDS = ['logo' => 480, 'product' => 960];
    private const TYPES = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];

    public static function dir(int $companyId): string
    {
        return BASE_PATH . '/storage/uploads/' . $companyId;
    }

    /** @param array<string,mixed> $file ورودی $_FILES */
    public static function store(int $companyId, string $kind, int $refId, array $file, bool $square = false): int
    {
        if (!isset(self::KINDS[$kind])) {
            throw new UserError('نوع تصویر نامعتبر است.');
        }
        $err = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
            throw new UserError('حجم تصویر بیش از حد مجاز است (حداکثر ۲ مگابایت).');
        }
        $tmp = (string) ($file['tmp_name'] ?? '');
        if ($err !== UPLOAD_ERR_OK || !is_uploaded_file($tmp)) {
            throw new UserError('بارگذاری تصویر ناموفق بود.');
        }
        if ((int) filesize($tmp) > self::MAX_BYTES) {
            throw new UserError('حجم تصویر بیش از ۲ مگابایت است.');
        }
        if (!extension_loaded('gd')) {
            throw new UserError('افزونه‌ی GD روی سرور فعال نیست؛ آپلود تصویر ممکن نیست.');
        }
        $mime = (string) (new \finfo(FILEINFO_MIME_TYPE))->file($tmp);
        if (!isset(self::TYPES[$mime])) {
            throw new UserError('فقط تصویر PNG، JPG یا WebP مجاز است.');
        }
        $info = @getimagesize($tmp);
        if (!$info || $info[0] < 16 || $info[1] < 16 || $info[0] > self::MAX_DIM || $info[1] > self::MAX_DIM) {
            throw new UserError('ابعاد تصویر معتبر نیست (حداقل ۱۶ و حداکثر ' . self::MAX_DIM . ' پیکسل).');
        }
        $src = match ($mime) {
            'image/png' => @imagecreatefrompng($tmp),
            'image/jpeg' => @imagecreatefromjpeg($tmp),
            default => @imagecreatefromwebp($tmp),
        };
        if (!$src) {
            throw new UserError('فایل تصویر خراب است.');
        }
        [$w, $h] = [imagesx($src), imagesy($src)];
        $sx = 0;
        $sy = 0;
        if ($square && $w !== $h) { // برش مربعی از وسط تصویر
            $side = min($w, $h);
            $sx = intdiv($w - $side, 2);
            $sy = intdiv($h - $side, 2);
            [$w, $h] = [$side, $side];
        }
        $scale = min(1.0, self::KINDS[$kind] / max($w, $h));
        [$nw, $nh] = [max(1, (int) round($w * $scale)), max(1, (int) round($h * $scale))];
        $dst = imagecreatetruecolor($nw, $nh);
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
        imagecopyresampled($dst, $src, 0, 0, $sx, $sy, $nw, $nh, $w, $h);

        $dir = self::dir($companyId);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new UserError('پوشه‌ی ذخیره‌ی تصاویر قابل نوشتن نیست (storage/uploads).');
        }
        $name = bin2hex(random_bytes(16)) . '.png';
        if (!imagepng($dst, $dir . '/' . $name, 6)) {
            throw new UserError('ذخیره‌ی تصویر ناموفق بود.');
        }
        @chmod($dir . '/' . $name, 0640);
        $size = (int) filesize($dir . '/' . $name);

        self::remove($companyId, $kind, $refId, false);
        $id = DB::insert(
            'INSERT INTO media (company_id, kind, ref_id, filename, mime, size, width, height, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$companyId, $kind, $refId, $name, 'image/png', $size, $nw, $nh, Auth::id() ?: null, date('Y-m-d H:i:s')]
        );
        Audit::log('media.upload', 'media', $id, ['kind' => $kind, 'ref' => $refId, 'bytes' => $size], $companyId);
        return $id;
    }

    public static function remove(int $companyId, string $kind, int $refId, bool $audit = true): bool
    {
        $m = DB::one('SELECT id, filename FROM media WHERE company_id = ? AND kind = ? AND ref_id = ?', [$companyId, $kind, $refId]);
        if (!$m) {
            return false;
        }
        DB::exec('DELETE FROM media WHERE id = ?', [$m['id']]);
        @unlink(self::dir($companyId) . '/' . $m['filename']);
        if ($audit) {
            Audit::log('media.remove', 'media', (int) $m['id'], ['kind' => $kind, 'ref' => $refId], $companyId);
        }
        return true;
    }

    /** آدرس تصویر (با پارامتر نسخه برای کش) یا null */
    public static function url(int $companyId, string $kind, int $refId = 0): ?string
    {
        $id = DB::scalar('SELECT id FROM media WHERE company_id = ? AND kind = ? AND ref_id = ?', [$companyId, $kind, $refId]);
        return $id ? '/media?id=' . (int) $id : null;
    }

    /** @param list<int> $refIds @return array<int,string> ref_id => url */
    public static function urls(int $companyId, string $kind, array $refIds): array
    {
        if (!$refIds) {
            return [];
        }
        $in = implode(',', array_fill(0, count($refIds), '?'));
        $out = [];
        foreach (DB::all("SELECT id, ref_id FROM media WHERE company_id = ? AND kind = ? AND ref_id IN ($in)", array_merge([$companyId, $kind], array_map('intval', $refIds))) as $r) {
            $out[(int) $r['ref_id']] = '/media?id=' . (int) $r['id'];
        }
        return $out;
    }
}
