<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Database as DB;
use App\Core\Env;
use App\Core\Jalali;
use App\Services\Sms\KavenegarDriver;
use App\Services\Sms\LogSmsDriver;
use App\Services\Sms\SmsDriver;

/** صف پیامک: ثبت پیام، تولید یادآوری اقساط (بدون تکرار) و ارسال با درایور قابل تعویض. */
final class NotificationService
{
    public const MAX_ATTEMPTS = 3;
    public const STATUS_LABELS = ['queued' => 'در صف', 'sent' => 'ارسال‌شده', 'failed' => 'ناموفق'];
    public const TEMPLATES = [
        'inst_due' => '{name} عزیز؛ قسط {seq} شما به مبلغ {amount} ریال در تاریخ {due} سررسید می‌شود. {company}',
        'inst_overdue' => '{name} عزیز؛ قسط {seq} شما به مبلغ {amount} ریال از تاریخ {due} معوق است. لطفاً هرچه زودتر پرداخت کنید. {company}',
        'payment_ok' => '{name} عزیز؛ پرداخت {amount} ریال شما ثبت شد. کد پیگیری: {ref}. {company}',
        'loan_active' => '{name} عزیز؛ تسهیلات شما به مبلغ {amount} ریال فعال شد. {company}',
        'manual' => '{body}',
    ];

    public static function driver(): ?SmsDriver
    {
        return match (Env::get('SMS_DRIVER', 'off')) {
            'log' => new LogSmsDriver(),
            'kavenegar' => new KavenegarDriver(),
            default => null,
        };
    }

    public static function render(string $template, array $vars): string
    {
        $out = self::TEMPLATES[$template] ?? '{body}';
        foreach ($vars as $k => $v) {
            $out = str_replace('{' . $k . '}', (string) $v, $out);
        }
        return trim(mb_substr(preg_replace('/\s+/u', ' ', $out) ?? $out, 0, 480));
    }

    /** پیام را در صف می‌گذارد. null یعنی شماره نامعتبر یا پیام تکراری بوده است. */
    public static function enqueue(int $companyId, ?int $customerId, string $mobile, string $template, array $vars, ?string $dedupe = null, ?int $userId = null): ?int
    {
        $mobile = preg_replace('/\D/', '', $mobile) ?? '';
        if (!preg_match('/^09\d{9}$/', $mobile)) {
            return null;
        }
        if ($dedupe !== null && DB::scalar('SELECT id FROM notifications WHERE company_id = ? AND dedupe_key = ?', [$companyId, $dedupe])) {
            return null;
        }
        $vars += ['company' => (string) DB::scalar('SELECT name FROM companies WHERE id = ?', [$companyId])];
        return DB::insert(
            "INSERT INTO notifications (company_id, customer_id, channel, recipient, template, body, status, dedupe_key, created_by, created_at) VALUES (?, ?, 'sms', ?, ?, ?, 'queued', ?, ?, ?)",
            [$companyId, $customerId, $mobile, $template, self::render($template, $vars), $dedupe, $userId, date('Y-m-d H:i:s')]
        );
    }

    /** @return array{sent: int, failed: int, pending: int} پیام‌های صف را با درایور می‌فرستد. */
    public static function dispatch(int $companyId, int $limit = 50): array
    {
        $res = ['sent' => 0, 'failed' => 0, 'pending' => 0];
        $driver = self::driver();
        if ($driver === null) {
            $res['pending'] = (int) DB::scalar("SELECT COUNT(*) FROM notifications WHERE company_id = ? AND status = 'queued'", [$companyId]);
            return $res;
        }
        $rows = DB::all("SELECT id, recipient, body, attempts FROM notifications WHERE company_id = ? AND status = 'queued' AND attempts < ? ORDER BY id LIMIT " . (int) $limit, [$companyId, self::MAX_ATTEMPTS]);
        foreach ($rows as $r) {
            try {
                $o = $driver->send($r['recipient'], $r['body']);
            } catch (\Throwable $e) {
                $o = ['ok' => false, 'ref' => '', 'error' => 'خطای ارسال'];
            }
            $attempts = (int) $r['attempts'] + 1;
            if ($o['ok']) {
                DB::exec("UPDATE notifications SET status = 'sent', attempts = ?, provider_ref = ?, sent_at = ?, last_error = NULL WHERE id = ?", [$attempts, $o['ref'], date('Y-m-d H:i:s'), $r['id']]);
                $res['sent']++;
            } else {
                DB::exec('UPDATE notifications SET status = ?, attempts = ?, last_error = ? WHERE id = ?', [$attempts >= self::MAX_ATTEMPTS ? 'failed' : 'queued', $attempts, $o['error'], $r['id']]);
                $res['failed']++;
            }
        }
        return $res;
    }

    /** یادآوری قسط‌های نزدیک (۳ روز آینده) و معوق (هر ۳ روز یک‌بار). @return int تعداد پیام‌های جدید صف‌شده */
    public static function generateReminders(int $companyId, ?string $today = null): int
    {
        $today ??= date('Y-m-d');
        $ahead = (int) Env::get('REMINDER_DAYS', '3');
        $n = 0;
        $rows = DB::all(
            "SELECT i.id, i.seq, i.due_date, i.amount - i.paid_amount AS remaining, c.id AS cid, c.full_name, c.mobile
             FROM installments i JOIN loans l ON l.id = i.loan_id JOIN customers c ON c.id = l.customer_id
             WHERE i.company_id = ? AND l.status = 'active' AND i.status <> 'paid' AND i.due_date <= ? AND c.status = 'active'",
            [$companyId, date('Y-m-d', strtotime($today . " +$ahead days"))]
        );
        foreach ($rows as $r) {
            $daysOver = (int) floor((strtotime($today) - strtotime($r['due_date'])) / 86400);
            $vars = ['name' => $r['full_name'], 'seq' => fa((string) $r['seq']), 'amount' => fa(number_format((int) $r['remaining'])), 'due' => fa(Jalali::format($r['due_date']))];
            if ($daysOver > 0) {
                $id = self::enqueue($companyId, (int) $r['cid'], (string) $r['mobile'], 'inst_overdue', $vars, 'over:' . $r['id'] . ':' . intdiv($daysOver - 1, 3));
            } else {
                $id = self::enqueue($companyId, (int) $r['cid'], (string) $r['mobile'], 'inst_due', $vars, 'due:' . $r['id']);
            }
            $n += $id ? 1 : 0;
        }
        return $n;
    }

    public static function retry(int $companyId, int $id): bool
    {
        return DB::exec("UPDATE notifications SET status = 'queued', attempts = 0, last_error = NULL WHERE id = ? AND company_id = ? AND status = 'failed'", [$id, $companyId]) === 1;
    }
}
