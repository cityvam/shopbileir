<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;
use App\Core\Permissions;

final class TenantProvisioner
{
    /** نقش‌های پیش‌فرض یک شرکت را می‌سازد و شناسه‌ها را به‌صورت slug => id برمی‌گرداند. باید داخل تراکنش صدا زده شود. */
    public static function createDefaultRoles(int $companyId, bool $withSuperAdmin = false): array
    {
        $templates = Permissions::templates();
        if ($withSuperAdmin) {
            $templates = ['super_admin' => ['مدیرکل', Permissions::all()]] + $templates;
        }
        $ids = [];
        foreach ($templates as $slug => [$name, $perms]) {
            $id = DB::insert('INSERT INTO roles (company_id, slug, name, is_system) VALUES (?, ?, ?, 1)', [$companyId, $slug, $name]);
            foreach ($perms as $p) {
                DB::exec('INSERT INTO role_permissions (role_id, permission) VALUES (?, ?)', [$id, $p]);
            }
            $ids[$slug] = $id;
        }
        return $ids;
    }

    public static function createDefaultAccounts(int $companyId): void
    {
        Accounting::provision($companyId);
    }

    public static function createUser(int $companyId, int $roleId, string $username, string $fullName, string $password, ?string $mobile = null): int
    {
        return DB::insert(
            'INSERT INTO users (company_id, role_id, username, full_name, mobile, password_hash) VALUES (?, ?, ?, ?, ?, ?)',
            [$companyId, $roleId, $username, $fullName, $mobile, password_hash($password, PASSWORD_DEFAULT)]
        );
    }
}
