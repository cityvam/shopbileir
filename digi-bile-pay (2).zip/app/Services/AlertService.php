<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Database as DB;

/** هشدارهای عملیاتی که زنده از داده‌ها محاسبه می‌شوند (جدول جداگانه ندارد) و بر اساس مجوز کاربر فیلتر می‌شوند */
final class AlertService
{
    public const LOW_STOCK = 5;

    /** @return list<array{key:string,read:bool,level:string,title:string,count:int,hint:string,url:string,icon:string}> */
    public static function items(int $companyId): array
    {
        $today = date('Y-m-d');
        $soon = date('Y-m-d', strtotime('+7 days'));
        $out = [];
        $seen = [];
        foreach (DB::all('SELECT alert_key, seen_count FROM alert_reads WHERE user_id = ?', [Auth::id()]) as $r) {
            $seen[$r['alert_key']] = (int) $r['seen_count'];
        }
        $add = static function (string $perm, string $level, string $title, int $count, string $hint, string $url, string $icon) use (&$out, $seen): void {
            if ($count > 0 && Auth::can($perm)) {
                $key = substr(md5($title), 0, 16);
                // «خوانده‌شده» تا وقتی تعداد بیشتر نشده باقی می‌ماند؛ با افزایش تعداد دوباره تازه می‌شود
                $read = isset($seen[$key]) && $seen[$key] >= $count;
                $out[] = compact('key', 'read', 'level', 'title', 'count', 'hint', 'url', 'icon');
            }
        };
        $n = static fn (string $sql, array $p): int => (int) DB::scalar($sql, $p);

        $add('installments.view', 'danger', 'اقساط معوق', $n("SELECT COUNT(*) FROM installments i JOIN loans l ON l.id = i.loan_id WHERE i.company_id = ? AND l.status = 'active' AND i.status <> 'paid' AND i.due_date < ?", [$companyId, $today]), 'اقساطی که سررسیدشان گذشته و پرداخت کامل نشده است', '/installments?filter=overdue', 'clock');
        $add('installments.view', 'warning', 'اقساط سررسید هفته‌ی آینده', $n("SELECT COUNT(*) FROM installments i JOIN loans l ON l.id = i.loan_id WHERE i.company_id = ? AND l.status = 'active' AND i.status <> 'paid' AND i.due_date BETWEEN ? AND ?", [$companyId, $today, $soon]), 'برای یادآوری به مشتری', '/installments', 'clock');
        $add('customers.view', 'warning', 'درخواست‌های اعتبار جدید از سایت', $n("SELECT COUNT(*) FROM leads WHERE company_id = ? AND status = 'new'", [$companyId]), 'منتظر تماس و بررسی', '/leads?status=new', 'clipboard');
        $add('loans.decide', 'warning', 'درخواست‌های تسهیلات در انتظار تصمیم', $n("SELECT COUNT(*) FROM loans WHERE company_id = ? AND status = 'pending'", [$companyId]), 'منتظر تأیید یا رد', '/loans?status=pending', 'check');
        $add('accounting.view', 'danger', 'چک‌های سررسیدگذشته', $n("SELECT COUNT(*) FROM cheques WHERE company_id = ? AND status IN ('in_hand','deposited','issued') AND due_date < ?", [$companyId, $today]), 'وضعیت نهایی (وصول/برگشت) ثبت نشده', '/cheques', 'banknote');
        $add('accounting.view', 'warning', 'چک‌های سررسید هفته‌ی آینده', $n("SELECT COUNT(*) FROM cheques WHERE company_id = ? AND status IN ('in_hand','deposited','issued') AND due_date BETWEEN ? AND ?", [$companyId, $today, $soon]), 'برای پیگیری وصول یا تأمین وجه', '/cheques', 'banknote');
        $add('products.view', 'info', 'محصولات کم‌موجودی', $n('SELECT COUNT(*) FROM products WHERE company_id = ? AND status = \'active\' AND stock <= ?', [$companyId, self::LOW_STOCK]), 'موجودی ' . fa((string) self::LOW_STOCK) . ' یا کمتر', '/products', 'box');
        if (Auth::can('users.manage')) {
            $add('users.manage', 'info', 'کاربران فعال بدون تأیید دومرحله‌ای', $n("SELECT COUNT(*) FROM users WHERE company_id = ? AND status = 'active' AND mfa_enabled = 0", [$companyId]), 'برای امنیت بیشتر فعال‌سازی توصیه می‌شود', '/users', 'key');
        }
        return $out;
    }

    public static function count(int $companyId): int
    {
        return array_sum(array_column(array_filter(self::items($companyId), static fn ($a) => $a['level'] !== 'info' && !$a['read']), 'count'));
    }

    /** علامت خوانده‌شدن برای کاربر فعلی؛ key خالی یعنی همه‌ی هشدارهای فعلی. */
    public static function markRead(int $companyId, string $key): void
    {
        foreach (self::items($companyId) as $a) {
            if ($key !== '' && $a['key'] !== $key) {
                continue;
            }
            $n = DB::exec('UPDATE alert_reads SET seen_count = ?, seen_at = ? WHERE user_id = ? AND alert_key = ?', [$a['count'], date('Y-m-d H:i:s'), Auth::id(), $a['key']]);
            if ($n === 0) {
                DB::exec('INSERT INTO alert_reads (user_id, alert_key, seen_count, seen_at) VALUES (?, ?, ?, ?)', [Auth::id(), $a['key'], $a['count'], date('Y-m-d H:i:s')]);
            }
        }
    }
}
