<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Database as DB;
use App\Core\Env;
use App\Core\UserError;

/** پرتال مشتری: ورود با کد یک‌بارمصرف پیامکی و داده‌های فقط‌خواندنی خود مشتری. */
final class PortalService
{
    public const OTP_TTL = 300;
    public const RESEND_SECONDS = 60;
    public const MAX_PER_HOUR = 5;
    public const MAX_ATTEMPTS = 5;

    public static function enabled(): bool
    {
        return NotificationService::driver() !== null && SiteService::company() !== null;
    }

    private static function hash(int $customerId, string $code): string
    {
        return hash_hmac('sha256', $customerId . ':' . $code, (string) (Env::get('APP_KEY') ?: 'dbp-portal'));
    }

    /** برای جلوگیری از شناسایی شماره‌های ثبت‌شده، پاسخ عمومی همیشه یکسان است؛ خطای ارسال فقط برای محدودیت زمانی نشان داده می‌شود. */
    public static function requestCode(string $mobile, string $ip): void
    {
        $mobile = strtr(preg_replace('/\D/', '', strtr($mobile, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9'])) ?? '', []);
        if (!preg_match('/^09\d{9}$/', $mobile)) {
            throw new UserError('شماره‌ی موبایل معتبر نیست (مثال: 09121234567).');
        }
        $company = SiteService::company() ?? throw new UserError('پرتال فعلاً در دسترس نیست.');
        $driver = NotificationService::driver() ?? throw new UserError('ارسال پیامک فعال نیست؛ با پشتیبانی تماس بگیرید.');
        $c = DB::one("SELECT id, full_name FROM customers WHERE company_id = ? AND mobile = ? AND status = 'active' ORDER BY id LIMIT 1", [$company['id'], $mobile]);
        if (!$c) {
            return; // پاسخ یکسان؛ هیچ پیامکی ارسال نمی‌شود
        }
        $now = time();
        $last = DB::scalar('SELECT MAX(created_at) FROM customer_otps WHERE customer_id = ?', [$c['id']]);
        if ($last && $now - strtotime((string) $last) < self::RESEND_SECONDS) {
            throw new UserError('کد اخیراً ارسال شده است؛ ' . self::RESEND_SECONDS . ' ثانیه بعد دوباره تلاش کنید.');
        }
        $hour = (int) DB::scalar('SELECT COUNT(*) FROM customer_otps WHERE customer_id = ? AND created_at >= ?', [$c['id'], date('Y-m-d H:i:s', $now - 3600)]);
        if ($hour >= self::MAX_PER_HOUR) {
            throw new UserError('تعداد درخواست کد زیاد است؛ یک ساعت بعد دوباره تلاش کنید.');
        }
        $code = (string) random_int(100000, 999999);
        DB::exec('INSERT INTO customer_otps (customer_id, code_hash, expires_at, ip, created_at) VALUES (?, ?, ?, ?, ?)',
            [$c['id'], self::hash((int) $c['id'], $code), date('Y-m-d H:i:s', $now + self::OTP_TTL), $ip, date('Y-m-d H:i:s', $now)]);
        // کد پیامکی در صف/دیتابیس ذخیره نمی‌شود؛ مستقیم با درایور ارسال می‌شود
        $driver->send($mobile, 'کد ورود شما: ' . $code . ' (۵ دقیقه معتبر است) ' . $company['name']);
        Audit::log('portal.otp_sent', 'customer', (int) $c['id'], [], (int) $company['id']);
    }

    /** @return ?array{id:int,company_id:int} مشتری در صورت درست‌بودن کد */
    public static function verify(string $mobile, string $code): ?array
    {
        $mobile = preg_replace('/\D/', '', strtr($mobile, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9'])) ?? '';
        $code = preg_replace('/\D/', '', strtr($code, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9'])) ?? '';
        $company = SiteService::company();
        if (!$company || strlen($code) !== 6) {
            return null;
        }
        $c = DB::one("SELECT id, company_id FROM customers WHERE company_id = ? AND mobile = ? AND status = 'active' ORDER BY id LIMIT 1", [$company['id'], $mobile]);
        if (!$c) {
            return null;
        }
        $otp = DB::one('SELECT * FROM customer_otps WHERE customer_id = ? AND used = 0 ORDER BY id DESC LIMIT 1', [$c['id']]);
        if (!$otp || $otp['expires_at'] < date('Y-m-d H:i:s') || (int) $otp['attempts'] >= self::MAX_ATTEMPTS) {
            return null;
        }
        DB::exec('UPDATE customer_otps SET attempts = attempts + 1 WHERE id = ?', [$otp['id']]);
        if (!hash_equals((string) $otp['code_hash'], self::hash((int) $c['id'], $code))) {
            return null;
        }
        // یک‌بارمصرف: فقط یک درخواست هم‌زمان می‌تواند کد را مصرف کند
        if (DB::exec('UPDATE customer_otps SET used = 1 WHERE id = ? AND used = 0', [$otp['id']]) !== 1) {
            return null;
        }
        Audit::log('portal.login', 'customer', (int) $c['id'], [], (int) $c['company_id']);
        return ['id' => (int) $c['id'], 'company_id' => (int) $c['company_id']];
    }

    public static function overview(int $companyId, int $customerId): array
    {
        $c = DB::one('SELECT id, full_name, mobile, credit_limit, wallet_balance FROM customers WHERE id = ? AND company_id = ?', [$customerId, $companyId]) ?? throw new UserError('حساب یافت نشد.');
        $used = CreditService::used($companyId, $customerId);
        $inst = DB::all(
            "SELECT i.id, i.seq, i.due_date, i.amount, i.paid_amount, i.late_fee_accrued - i.late_fee_paid AS late_fee, l.id AS loan_id, l.months,
                    (SELECT COUNT(*) FROM payment_requests pr WHERE pr.installment_id = i.id AND pr.status = 'pending') AS pending_links
             FROM installments i JOIN loans l ON l.id = i.loan_id
             WHERE i.company_id = ? AND l.customer_id = ? AND l.status = 'active' AND i.status <> 'paid' ORDER BY i.due_date, i.id LIMIT 24",
            [$companyId, $customerId]
        );
        return [
            'c' => $c, 'used' => $used, 'available' => max(0, (int) $c['credit_limit'] - $used), 'installments' => $inst,
            'loans' => DB::all('SELECT l.id, l.principal, l.months, l.status, l.created_at, p.name AS plan_name FROM loans l JOIN loan_plans p ON p.id = l.plan_id WHERE l.company_id = ? AND l.customer_id = ? ORDER BY l.id DESC LIMIT 10', [$companyId, $customerId]),
            'wallet' => DB::all('SELECT type, amount, balance_after, created_at FROM wallet_transactions WHERE company_id = ? AND customer_id = ? ORDER BY id DESC LIMIT 10', [$companyId, $customerId]),
            'payments' => DB::all("SELECT pr.id, pr.kind, pr.amount, pr.status, pr.ref_id, pr.paid_at, pr.created_at FROM payment_requests pr WHERE pr.company_id = ? AND pr.customer_id = ? ORDER BY pr.id DESC LIMIT 8", [$companyId, $customerId]),
        ];
    }

    /** کاربری که پرداخت‌های آنلاین مشتری در حسابداری به او نسبت داده می‌شود (اولین کاربر فعال شرکت). */
    public static function systemUserId(int $companyId): int
    {
        return (int) (DB::scalar("SELECT id FROM users WHERE company_id = ? AND status = 'active' ORDER BY id LIMIT 1", [$companyId]) ?: throw new UserError('کاربر فعالی در شرکت وجود ندارد.'));
    }
}
