<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;
use App\Core\Env;
use App\Core\Jalali;
use App\Core\UserError;
use App\Core\Validator;

/** داده‌ی صفحه‌ی عمومی: شرکت نمایش‌داده‌شده، طرح‌ها، فروشندگان، محاسبه‌ی قسط و ثبت درخواست اعتبار */
final class SiteService
{
    private const RATE_LIMIT_PER_HOUR = 5;

    /** @return array{id:int,name:string}|null */
    public static function company(): ?array
    {
        $code = Env::get('PUBLIC_COMPANY_CODE', '');
        if ($code) {
            $c = DB::one("SELECT id, COALESCE(NULLIF(brand_name, ''), name) AS name FROM companies WHERE code = ? AND status = 'active'", [$code]);
            if ($c) {
                return ['id' => (int) $c['id'], 'name' => $c['name']];
            }
        }
        $c = DB::one("SELECT c.id, COALESCE(NULLIF(c.brand_name, ''), c.name) AS name FROM companies c WHERE c.status = 'active'
                      AND EXISTS (SELECT 1 FROM loan_plans p WHERE p.company_id = c.id AND p.is_active = 1) ORDER BY c.id LIMIT 1");
        return $c ? ['id' => (int) $c['id'], 'name' => $c['name']] : null;
    }

    /** @return list<array<string,mixed>> */
    public static function plans(int $cid): array
    {
        $plans = DB::all('SELECT id, name, months, annual_rate_percent, fee_percent, min_amount, max_amount FROM loan_plans WHERE company_id = ? AND is_active = 1 ORDER BY months, id', [$cid]);
        foreach ($plans as &$p) {
            $p['sample'] = self::monthly((int) $p['min_amount'], (int) $p['months'], (float) $p['annual_rate_percent']);
        }
        return $plans;
    }

    /** @return list<array<string,mixed>> */
    public static function merchants(int $cid, int $limit = 8): array
    {
        return DB::all(
            "SELECT m.id, m.name, (SELECT COUNT(*) FROM products p WHERE p.merchant_id = m.id AND p.status = 'active' AND p.stock > 0) AS products
             FROM merchants m WHERE m.company_id = ? AND m.status = 'active' ORDER BY products DESC, m.id LIMIT " . (int) $limit,
            [$cid]
        );
    }

    /** @param list<array<string,mixed>> $plans @return list<array<string,mixed>> */
    public static function products(int $cid, array $plans, int $limit = 8): array
    {
        $rows = DB::all(
            "SELECT p.id, p.name, p.price, m.name AS merchant FROM products p JOIN merchants m ON m.id = p.merchant_id
             WHERE p.company_id = ? AND p.status = 'active' AND p.stock > 0 AND m.status = 'active' ORDER BY p.id DESC LIMIT " . (int) $limit,
            [$cid]
        );
        $imgs = MediaService::urls($cid, 'product', array_map('intval', array_column($rows, 'id')));
        foreach ($rows as &$r) {
            $r['image'] = $imgs[(int) $r['id']] ?? null;
            $r['plan'] = null;
            foreach (array_reverse($plans) as $pl) { // طولانی‌ترین طرح مناسب
                if ((int) $r['price'] >= (int) $pl['min_amount'] && (int) $r['price'] <= (int) $pl['max_amount']) {
                    $r['plan'] = $pl;
                    $r['monthly'] = self::monthly((int) $r['price'], (int) $pl['months'], (float) $pl['annual_rate_percent']);
                    break;
                }
            }
        }
        return $rows;
    }

    public static function monthly(int $principal, int $months, float $rate): int
    {
        $s = LoanCalculator::schedule($principal, $months, $rate, date('Y-m-d'));
        return (int) $s[0]['amount'];
    }

    /** @return array<string,mixed> نتیجه‌ی محاسبه یا ['error' => پیام] */
    public static function quote(int $cid, int $planId, int $amount): array
    {
        $p = DB::one('SELECT id, name, months, annual_rate_percent, fee_percent, min_amount, max_amount FROM loan_plans WHERE id = ? AND company_id = ? AND is_active = 1', [$planId, $cid]);
        if (!$p) {
            return ['error' => 'طرح انتخاب‌شده معتبر نیست.'];
        }
        if ($amount < (int) $p['min_amount'] || $amount > (int) $p['max_amount']) {
            return ['error' => 'مبلغ برای این طرح باید بین ' . money((int) $p['min_amount']) . ' و ' . money((int) $p['max_amount']) . ' باشد.'];
        }
        $today = date('Y-m-d');
        $sch = LoanCalculator::schedule($amount, (int) $p['months'], (float) $p['annual_rate_percent'], $today);
        $t = LoanCalculator::totals($sch);
        $fee = LoanCalculator::fee($amount, (float) $p['fee_percent']);
        return [
            'monthly' => money((int) $sch[0]['amount']),
            'interest' => money((int) $t['interest']),
            'fee' => money($fee),
            'total' => money((int) $t['payable'] + $fee),
            'months' => fa((string) $p['months']),
            'first_due' => Jalali::format($sch[0]['due_date']),
            'rows' => array_map(static fn ($r) => ['seq' => fa((string) $r['seq']), 'due' => Jalali::format($r['due_date']), 'amount' => money((int) $r['amount'])], $sch),
        ];
    }

    /** @param array<string,string> $in */
    public static function createLead(int $cid, array $in, string $ip): int
    {
        $name = trim((string) preg_replace('/\s+/u', ' ', $in['full_name'] ?? ''));
        $mobile = $in['mobile'] ?? '';
        $nc = $in['national_code'] ?? '';
        $amountRaw = $in['requested_amount'] ?? '';
        $planId = (int) ($in['plan_id'] ?? 0);
        $msg = trim($in['message'] ?? '');
        if (mb_strlen($name) < 3) {
            throw new UserError('نام و نام خانوادگی را وارد کنید.');
        }
        if (!Validator::mobile($mobile)) {
            throw new UserError('شماره موبایل باید با ۰۹ شروع شود و ۱۱ رقم باشد.');
        }
        if ($nc !== '' && !Validator::nationalCode($nc)) {
            throw new UserError('کد ملی معتبر نیست.');
        }
        $amount = null;
        if (preg_replace('/\D/', '', $amountRaw) !== '') {
            $amount = Validator::amount($amountRaw) ?? throw new UserError('مبلغ درخواستی معتبر نیست.');
        }
        if ($planId && !DB::scalar('SELECT id FROM loan_plans WHERE id = ? AND company_id = ? AND is_active = 1', [$planId, $cid])) {
            $planId = 0;
        }
        $since = date('Y-m-d H:i:s', time() - 3600);
        if ((int) DB::scalar('SELECT COUNT(*) FROM leads WHERE ip = ? AND created_at >= ?', [$ip, $since]) >= self::RATE_LIMIT_PER_HOUR) {
            throw new UserError('تعداد درخواست‌ها از این شبکه زیاد است؛ کمی بعد دوباره تلاش کنید.');
        }
        if (DB::scalar("SELECT id FROM leads WHERE company_id = ? AND mobile = ? AND status = 'new' AND created_at >= ?", [$cid, $mobile, date('Y-m-d H:i:s', time() - 86400)])) {
            throw new UserError('درخواست شما قبلاً ثبت شده و در انتظار بررسی است.');
        }
        return DB::insert(
            'INSERT INTO leads (company_id, full_name, mobile, national_code, requested_amount, plan_id, message, status, ip, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$cid, $name, $mobile, $nc !== '' ? $nc : null, $amount, $planId ?: null, $msg !== '' ? mb_substr($msg, 0, 500) : null, 'new', $ip, date('Y-m-d H:i:s')]
        );
    }
}
