<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;
use App\Core\Jalali;

final class ReportService
{
    /** @return array{labels: list<string>, values: list<int>} از جدیدترین ماه شمسی به قدیمی‌ترین */
    public static function monthlyCollections(int $companyId, int $months = 6): array
    {
        [$jy, $jm] = Jalali::yearMonth(date('Y-m-d'));
        $slots = [];
        for ($i = 0; $i < $months; $i++) {
            $slots[] = [$jy, $jm];
            if (--$jm < 1) {
                $jm = 12;
                $jy--;
            }
        }
        [$oy, $om] = end($slots);
        [$gy, $gm, $gd] = Jalali::toGregorian($oy, $om, 1);
        $since = sprintf('%04d-%02d-%02d 00:00:00', $gy, $gm, $gd);

        $sum = [];
        foreach (DB::all('SELECT amount, created_at FROM payments WHERE company_id = ? AND created_at >= ?', [$companyId, $since]) as $r) {
            $k = implode('-', Jalali::yearMonth($r['created_at']));
            $sum[$k] = ($sum[$k] ?? 0) + (int) $r['amount'];
        }
        $labels = [];
        $values = [];
        foreach ($slots as [$y, $m]) {
            $labels[] = Jalali::MONTHS[$m - 1];
            $values[] = $sum["$y-$m"] ?? 0;
        }
        return ['labels' => $labels, 'values' => $values];
    }

    /** سن مطالبات: مبلغ باقی‌مانده اقساط تسهیلات فعال به تفکیک تأخیر */
    public static function aging(int $companyId): array
    {
        $buckets = [
            ['label' => 'سررسید نشده', 'amount' => 0, 'count' => 0, 'tone' => 'ok'],
            ['label' => '۱ تا ۳۰ روز', 'amount' => 0, 'count' => 0, 'tone' => 'info'],
            ['label' => '۳۱ تا ۶۰ روز', 'amount' => 0, 'count' => 0, 'tone' => 'warn'],
            ['label' => '۶۱ تا ۹۰ روز', 'amount' => 0, 'count' => 0, 'tone' => 'bad'],
            ['label' => 'بیش از ۹۰ روز', 'amount' => 0, 'count' => 0, 'tone' => 'bad'],
        ];
        $today = strtotime(date('Y-m-d'));
        $rows = DB::all(
            "SELECT i.due_date, (i.amount - i.paid_amount) AS rem FROM installments i JOIN loans l ON l.id = i.loan_id
             WHERE i.company_id = ? AND i.status <> 'paid' AND l.status = 'active'",
            [$companyId]
        );
        foreach ($rows as $r) {
            $days = (int) floor(($today - strtotime($r['due_date'])) / 86400);
            $b = $days <= 0 ? 0 : ($days <= 30 ? 1 : ($days <= 60 ? 2 : ($days <= 90 ? 3 : 4)));
            $buckets[$b]['amount'] += (int) $r['rem'];
            $buckets[$b]['count']++;
        }
        return $buckets;
    }

    /** @return list<array{status:string,count:int,principal:int}> */
    public static function portfolio(int $companyId): array
    {
        $out = [];
        foreach (DB::all('SELECT status, COUNT(*) AS c, COALESCE(SUM(principal), 0) AS p FROM loans WHERE company_id = ? GROUP BY status', [$companyId]) as $r) {
            $out[$r['status']] = ['status' => $r['status'], 'count' => (int) $r['c'], 'principal' => (int) $r['p']];
        }
        return $out;
    }

    public static function topDebtors(int $companyId, int $limit = 5): array
    {
        return DB::all(
            "SELECT cu.id, cu.full_name, COUNT(*) AS cnt, SUM(i.amount - i.paid_amount) AS rem
             FROM installments i JOIN loans l ON l.id = i.loan_id JOIN customers cu ON cu.id = l.customer_id
             WHERE i.company_id = ? AND i.status <> 'paid' AND l.status = 'active' AND i.due_date < ?
             GROUP BY cu.id, cu.full_name ORDER BY rem DESC LIMIT ?",
            [$companyId, date('Y-m-d'), $limit]
        );
    }
}
