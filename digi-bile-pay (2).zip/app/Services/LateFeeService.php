<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database as DB;

/**
 * جریمه تأخیر روزشمار روی باقی‌مانده قسط معوق (نرخ از قرارداد/تسهیلات). ایدمپوتنت: هر روز فقط یک‌بار برای هر قسط.
 * درآمد جریمه هنگام دریافت در حسابداری ثبت می‌شود (مبنای نقدی، مانند سود).
 */
final class LateFeeService
{
    /** @return array{installments:int, total:int} */
    public static function accrue(int $companyId, ?int $loanId = null, ?string $today = null): array
    {
        $today ??= date('Y-m-d');
        $sql = "SELECT i.id, i.amount, i.paid_amount, i.due_date, i.late_fee_until, l.late_fee_daily_percent AS rate
                FROM installments i JOIN loans l ON l.id = i.loan_id
                WHERE i.company_id = ? AND l.status = 'active' AND i.status <> 'paid' AND i.due_date < ? AND l.late_fee_daily_percent > 0";
        $params = [$companyId, $today];
        if ($loanId !== null) {
            $sql .= ' AND l.id = ?';
            $params[] = $loanId;
        }
        $count = 0;
        $total = 0;
        foreach (DB::all($sql, $params) as $r) {
            $from = $r['late_fee_until'] !== null && $r['late_fee_until'] > $r['due_date'] ? $r['late_fee_until'] : $r['due_date'];
            $days = (int) floor((strtotime($today) - strtotime($from)) / 86400);
            $remaining = (int) $r['amount'] - (int) $r['paid_amount'];
            if ($days <= 0 || $remaining <= 0) {
                continue;
            }
            $fee = (int) round($remaining * (float) $r['rate'] / 100 * $days);
            $n = DB::exec(
                'UPDATE installments SET late_fee_accrued = late_fee_accrued + ?, late_fee_until = ? WHERE id = ? AND company_id = ? AND (late_fee_until IS NULL OR late_fee_until < ?)',
                [$fee, $today, $r['id'], $companyId, $today]
            );
            if ($n === 1) {
                $count++;
                $total += $fee;
            }
        }
        return ['installments' => $count, 'total' => $total];
    }
}
