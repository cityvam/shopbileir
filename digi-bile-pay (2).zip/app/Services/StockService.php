<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database as DB;
use App\Core\UserError;

/** تعدیل موجودی کالا با دلیل و دفتر حرکت (هیچ‌وقت منفی نمی‌شود) */
final class StockService
{
    public const KINDS = ['add' => 'افزایش', 'remove' => 'کاهش', 'set' => 'شمارش و تنظیم'];

    /** @return int موجودی جدید */
    public static function adjust(int $companyId, int $productId, string $mode, int $qty, string $reason): int
    {
        $reason = trim($reason);
        if (!isset(self::KINDS[$mode])) {
            throw new UserError('نوع تعدیل نامعتبر است.');
        }
        if ($qty < 0 || $qty > 1000000 || ($mode !== 'set' && $qty === 0)) {
            throw new UserError('تعداد باید عدد صحیح معتبر باشد.');
        }
        if (mb_strlen($reason) < 3) {
            throw new UserError('دلیل تعدیل موجودی را بنویسید.');
        }
        return DB::tx(function () use ($companyId, $productId, $mode, $qty, $reason) {
            $cur = DB::scalar('SELECT stock FROM products WHERE id = ? AND company_id = ?', [$productId, $companyId]);
            if ($cur === null || $cur === false) {
                throw new UserError('محصول یافت نشد.');
            }
            $cur = (int) $cur;
            $new = match ($mode) { 'add' => $cur + $qty, 'remove' => $cur - $qty, default => $qty };
            if ($new < 0) {
                throw new UserError('موجودی نمی‌تواند منفی شود (موجودی فعلی: ' . $cur . ').');
            }
            if ($new === $cur) {
                throw new UserError('موجودی تغییری نمی‌کند.');
            }
            if (DB::exec('UPDATE products SET stock = ? WHERE id = ? AND company_id = ? AND stock = ?', [$new, $productId, $companyId, $cur]) !== 1) {
                throw new UserError('موجودی هم‌زمان تغییر کرد؛ صفحه را تازه کنید.');
            }
            self::log($companyId, $productId, $new - $cur, $new, $mode, $reason, null);
            Audit::log('product.stock', 'product', $productId, ['from' => $cur, 'to' => $new, 'reason' => $reason]);
            return $new;
        });
    }

    /** ثبت حرکت (فراخوانی از سفارش/رد تسهیلات، پس از تغییر موجودی) */
    public static function log(int $companyId, int $productId, int $delta, ?int $balance, string $kind, ?string $reason, ?int $refId): void
    {
        $balance ??= (int) DB::scalar('SELECT stock FROM products WHERE id = ? AND company_id = ?', [$productId, $companyId]);
        DB::exec(
            'INSERT INTO stock_movements (company_id, product_id, delta, balance_after, kind, reason, ref_id, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$companyId, $productId, $delta, $balance, $kind, $reason !== null ? mb_substr($reason, 0, 300) : null, $refId, Auth::id() ?: null, date('Y-m-d H:i:s')]
        );
    }

    /** @return list<array<string,mixed>> */
    public static function movements(int $companyId, int $productId): array
    {
        return DB::all(
            'SELECT m.delta, m.balance_after, m.kind, m.reason, m.ref_id, m.created_at, u.full_name
             FROM stock_movements m LEFT JOIN users u ON u.id = m.user_id
             WHERE m.company_id = ? AND m.product_id = ? ORDER BY m.id DESC LIMIT 30',
            [$companyId, $productId]
        );
    }
}
