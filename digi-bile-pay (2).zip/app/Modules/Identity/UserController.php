<?php
declare(strict_types=1);

namespace App\Modules\Identity;

use App\Core\Audit;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\Paginator;
use App\Core\Validator;
use App\Services\TenantProvisioner;

final class UserController extends Controller
{
    public function index(): void
    {
        $total = (int) DB::scalar('SELECT COUNT(*) FROM users WHERE company_id = ?', [$this->cid()]);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all(
            'SELECT u.id, u.username, u.full_name, u.mobile, u.status, u.last_login_at, r.name AS role_name
             FROM users u JOIN roles r ON r.id = u.role_id WHERE u.company_id = ? ORDER BY u.id LIMIT ? OFFSET ?',
            [$this->cid(), $pg['per'], $pg['offset']]
        );
        $this->view('users/index', ['title' => 'کاربران', 'rows' => $rows, 'pg' => $pg], 'users');
    }

    public function create(): void
    {
        $this->view('users/form', ['title' => 'کاربر جدید', 'user' => null, 'roles' => $this->roles()], 'users');
    }

    public function store(): void
    {
        $username = mb_strtolower($this->input('username'));
        $name = $this->input('full_name');
        $mobile = $this->input('mobile');
        $roleId = (int) $this->input('role_id', '0');
        $pass = (string) ($_POST['password'] ?? '');

        $errors = [];
        if (!preg_match('/^[a-z0-9_.]{3,40}$/', $username)) {
            $errors[] = 'نام کاربری باید ۳ تا ۴۰ نویسه لاتین کوچک، عدد، نقطه یا خط‌زیر باشد.';
        }
        if (mb_strlen($name) < 2) {
            $errors[] = 'نام و نام خانوادگی را وارد کنید.';
        }
        if ($mobile !== '' && !Validator::mobile($mobile)) {
            $errors[] = 'شماره موبایل معتبر نیست.';
        }
        if (!$this->roleBelongs($roleId)) {
            $errors[] = 'نقش انتخاب‌شده نامعتبر است.';
        }
        if ($e = Validator::password($pass)) {
            $errors[] = $e;
        }
        if (DB::scalar('SELECT id FROM users WHERE username = ?', [$username])) {
            $errors[] = 'این نام کاربری قبلاً استفاده شده است.';
        }
        if ($errors) {
            $this->fail('/users/create', $errors);
        }
        $id = TenantProvisioner::createUser($this->cid(), $roleId, $username, $name, $pass, $mobile !== '' ? $mobile : null);
        Audit::log('user.create', 'user', $id, ['username' => $username, 'role_id' => $roleId]);
        $this->flash('success', 'کاربر ثبت شد.');
        $this->redirect('/users');
    }

    public function edit(array $p): void
    {
        $user = $this->find($p['id']);
        $this->view('users/form', [
            'title' => 'ویرایش کاربر', 'user' => $user, 'roles' => $this->roles(),
            'history' => \App\Services\StatusService::history($this->cid(), 'user', (int) $user['id']), 'events' => Audit::events($this->cid(), 'user', (int) $user['id']),
        ], 'users');
    }

    /** بازنشانی تأیید دومرحله‌ای کاربر توسط مدیر (مثلاً گم‌شدن گوشی و کدهای بازیابی) */
    public function mfaReset(array $p): void
    {
        $user = $this->find($p['id']);
        if ((int) $user['id'] === \App\Core\Auth::id()) {
            $this->flash('error', 'برای حساب خودتان از صفحه «حساب کاربری» استفاده کنید.');
        } else {
            \App\Services\MfaService::disable((int) $user['id'], 'admin');
            $this->flash('success', 'تأیید دومرحله‌ای کاربر بازنشانی شد.');
        }
        $this->redirect('/users/' . $user['id'] . '/edit');
    }

    public function status(array $p): void
    {
        $user = $this->find($p['id']);
        try {
            \App\Services\StatusService::change($this->cid(), 'user', (int) $user['id'], $this->input('to_status'), $this->input('reason'), ['active', 'disabled']);
            $this->flash('success', 'وضعیت کاربر تغییر کرد.');
        } catch (\App\Core\UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/users/' . $user['id'] . '/edit');
    }

    public function update(array $p): void
    {
        $user = $this->find($p['id']);
        $name = $this->input('full_name');
        $mobile = $this->input('mobile');
        $roleId = (int) $this->input('role_id', '0');
        $pass = (string) ($_POST['password'] ?? '');
        $back = '/users/' . $user['id'] . '/edit';

        $errors = [];
        if (mb_strlen($name) < 2) {
            $errors[] = 'نام و نام خانوادگی را وارد کنید.';
        }
        if ($mobile !== '' && !Validator::mobile($mobile)) {
            $errors[] = 'شماره موبایل معتبر نیست.';
        }
        if (!$this->roleBelongs($roleId)) {
            $errors[] = 'نقش انتخاب‌شده نامعتبر است.';
        }
        if ($pass !== '' && ($e = Validator::password($pass))) {
            $errors[] = $e;
        }
        if ((int) $user['id'] === \App\Core\Auth::id() && $roleId !== (int) $user['role_id']) {
            $errors[] = 'امکان تغییر نقش حساب کاربری خودتان وجود ندارد.';
        }
        if ($errors) {
            $this->fail($back, $errors);
        }
        DB::exec(
            'UPDATE users SET full_name = ?, mobile = ?, role_id = ? WHERE id = ? AND company_id = ?',
            [$name, $mobile !== '' ? $mobile : null, $roleId, $user['id'], $this->cid()]
        );
        if ($pass !== '') {
            DB::exec('UPDATE users SET password_hash = ? WHERE id = ? AND company_id = ?', [password_hash($pass, PASSWORD_DEFAULT), $user['id'], $this->cid()]);
        }
        Audit::log('user.update', 'user', (int) $user['id'], ['changes' => Audit::diff($user, ['full_name' => $name, 'mobile' => $mobile !== '' ? $mobile : null, 'role_id' => $roleId], ['full_name', 'mobile', 'role_id']), 'password_changed' => $pass !== '']);
        $this->flash('success', 'اطلاعات کاربر ذخیره شد.');
        $this->redirect('/users');
    }

    private function find(int $id): array
    {
        $u = DB::one('SELECT id, username, full_name, mobile, role_id, status, mfa_enabled FROM users WHERE id = ? AND company_id = ?', [$id, $this->cid()]);
        return $u ?? $this->notFound();
    }

    private function roles(): array
    {
        return DB::all('SELECT id, name FROM roles WHERE company_id = ? ORDER BY id', [$this->cid()]);
    }

    private function roleBelongs(int $roleId): bool
    {
        return $roleId > 0 && (bool) DB::scalar('SELECT id FROM roles WHERE id = ? AND company_id = ?', [$roleId, $this->cid()]);
    }
}
