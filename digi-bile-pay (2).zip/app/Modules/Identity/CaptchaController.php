<?php
declare(strict_types=1);

namespace App\Modules\Identity;

use App\Core\Captcha;
use App\Core\Controller;
use App\Core\Env;

final class CaptchaController extends Controller
{
    public function image(): void
    {
        $scope = $this->input('scope', 'login');
        if (!Captcha::valid($scope)) {
            http_response_code(404);
            exit;
        }
        $code = Captcha::issue($scope);
        header('Content-Type: image/svg+xml; charset=utf-8');
        header('Cache-Control: no-store, max-age=0');
        if (Env::get('APP_ENV') === 'local') { // فقط برای تست خودکار در محیط توسعه
            header('X-Captcha-Code: ' . $code);
        }
        echo Captcha::svg($code);
        exit;
    }
}
