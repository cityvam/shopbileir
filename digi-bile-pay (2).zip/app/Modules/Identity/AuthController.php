<?php
declare(strict_types=1);

namespace App\Modules\Identity;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Captcha;
use App\Core\Controller;
use App\Services\MfaService;

final class AuthController extends Controller
{
    public function showLogin(): void
    {
        if (Auth::check()) {
            $this->redirect('/dashboard');
        }
        $this->view('auth/login', ['title' => 'ورود به سامانه'], 'login', 'auth');
    }

    public function login(): void
    {
        $username = mb_strtolower($this->input('username'));
        $password = (string) ($_POST['password'] ?? '');
        if ($username === '' || $password === '') {
            $this->fail('/login', ['نام کاربری و رمز عبور را وارد کنید.']);
        }
        if (!Captcha::verify('login', $this->input('captcha'))) {
            $_SESSION['_old'] = ['username' => $username];
            $this->flash('error', 'کد امنیتی اشتباه یا منقضی است؛ کد جدید را وارد کنید.');
            $this->redirect('/login');
        }
        $error = Auth::attempt($username, $password);
        if ($error === Auth::MFA_PENDING) {
            $this->redirect('/login/mfa');
        }
        if ($error !== null) {
            $_SESSION['_old'] = ['username' => $username];
            $this->flash('error', $error);
            $this->redirect('/login');
        }
        $this->redirect('/dashboard');
    }

    public function showMfa(): void
    {
        if (Auth::check()) {
            $this->redirect('/dashboard');
        }
        if (Auth::pendingMfaUser() === null) {
            $this->redirect('/login');
        }
        $this->view('auth/mfa', ['title' => 'تأیید دومرحله‌ای'], 'login', 'auth');
    }

    public function verifyMfa(): void
    {
        $p = Auth::pendingMfaUser();
        if ($p === null) {
            $this->flash('error', 'زمان تأیید به پایان رسید؛ دوباره وارد شوید.');
            $this->redirect('/login');
        }
        if (MfaService::failedRecently($p['username']) >= MfaService::MAX_FAILS) {
            unset($_SESSION['mfa_uid'], $_SESSION['mfa_user'], $_SESSION['mfa_at']);
            $this->flash('error', 'تعداد تلاش‌های ناموفق زیاد است. چند دقیقه بعد دوباره تلاش کنید.');
            $this->redirect('/login');
        }
        if (!MfaService::verifyLogin($p['id'], $this->input('code'))) {
            MfaService::recordFail($p['username']);
            $this->flash('error', 'کد تأیید یا کد بازیابی صحیح نیست.');
            $this->redirect('/login/mfa');
        }
        Auth::completeLogin($p['id']);
        $this->redirect('/dashboard');
    }

    public function logout(): void
    {
        Audit::log('auth.logout', 'user', Auth::id());
        Auth::logout();
        $this->redirect('/login');
    }
}
