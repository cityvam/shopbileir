<?php
declare(strict_types=1);

namespace App\Modules\Identity;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\Permissions;

final class RoleController extends Controller
{
    public function index(): void
    {
        $rows = DB::all(
            'SELECT r.id, r.name, r.slug, r.is_system,
                    (SELECT COUNT(*) FROM role_permissions rp WHERE rp.role_id = r.id) AS perm_count,
                    (SELECT COUNT(*) FROM users u WHERE u.role_id = r.id) AS user_count
             FROM roles r WHERE r.company_id = ? ORDER BY r.id',
            [$this->cid()]
        );
        $this->view('roles/index', ['title' => 'نقش‌ها و مجوزها', 'rows' => $rows], 'roles');
    }

    public function create(): void
    {
        $this->view('roles/form', ['title' => 'نقش جدید', 'role' => null, 'granted' => [], 'held' => Auth::permissions()], 'roles');
    }

    public function store(): void
    {
        $name = $this->input('name');
        if (mb_strlen($name) < 2) {
            $this->fail('/roles/create', ['نام نقش را وارد کنید.']);
        }
        $perms = $this->submittedPermissions([]);
        $id = DB::tx(function () use ($name, $perms) {
            $id = DB::insert('INSERT INTO roles (company_id, slug, name, is_system) VALUES (?, ?, ?, 0)', [$this->cid(), 'role_' . bin2hex(random_bytes(4)), $name]);
            foreach ($perms as $p) {
                DB::exec('INSERT INTO role_permissions (role_id, permission) VALUES (?, ?)', [$id, $p]);
            }
            Audit::log('role.create', 'role', $id, ['permissions' => $perms]);
            return $id;
        });
        $this->flash('success', 'نقش ثبت شد.');
        $this->redirect('/roles');
    }

    public function edit(array $p): void
    {
        $role = $this->editable($p['id']);
        $granted = array_column(DB::all('SELECT permission FROM role_permissions WHERE role_id = ?', [$role['id']]), 'permission');
        $this->view('roles/form', ['title' => 'ویرایش نقش', 'role' => $role, 'granted' => $granted, 'held' => Auth::permissions()], 'roles');
    }

    public function update(array $p): void
    {
        $role = $this->editable($p['id']);
        $name = $this->input('name');
        if (mb_strlen($name) < 2) {
            $this->fail('/roles/' . $role['id'] . '/edit', ['نام نقش را وارد کنید.']);
        }
        $current = array_column(DB::all('SELECT permission FROM role_permissions WHERE role_id = ?', [$role['id']]), 'permission');
        $perms = $this->submittedPermissions($current);
        DB::tx(function () use ($role, $name, $perms) {
            DB::exec('UPDATE roles SET name = ? WHERE id = ? AND company_id = ?', [$name, $role['id'], $this->cid()]);
            DB::exec('DELETE FROM role_permissions WHERE role_id = ?', [$role['id']]);
            foreach ($perms as $perm) {
                DB::exec('INSERT INTO role_permissions (role_id, permission) VALUES (?, ?)', [$role['id'], $perm]);
            }
            Audit::log('role.update', 'role', (int) $role['id'], ['permissions' => $perms]);
        });
        $this->flash('success', 'نقش ذخیره شد.');
        $this->redirect('/roles');
    }

    public function delete(array $p): void
    {
        $role = $this->editable($p['id']);
        if ((int) DB::scalar('SELECT COUNT(*) FROM users WHERE role_id = ?', [$role['id']]) > 0) {
            $this->flash('error', 'این نقش به کاربر اختصاص دارد و قابل حذف نیست.');
            $this->redirect('/roles');
        }
        DB::tx(function () use ($role) {
            DB::exec('DELETE FROM roles WHERE id = ? AND company_id = ?', [$role['id'], $this->cid()]);
            Audit::log('role.delete', 'role', (int) $role['id'], ['name' => $role['name']]);
        });
        $this->flash('success', 'نقش حذف شد.');
        $this->redirect('/roles');
    }

    /** نقش‌های سیستمی و نقش شرکت‌های دیگر قابل ویرایش نیستند */
    private function editable(int $id): array
    {
        $r = DB::one('SELECT id, name, slug, is_system FROM roles WHERE id = ? AND company_id = ?', [$id, $this->cid()]);
        if (!$r) {
            $this->notFound();
        }
        if ((int) $r['is_system'] === 1) {
            $this->flash('error', 'نقش‌های سیستمی قابل ویرایش یا حذف نیستند. برای سفارشی‌سازی یک نقش جدید بسازید.');
            $this->redirect('/roles');
        }
        return $r;
    }

    /** فقط مجوزهایی که خود کاربر دارد قابل اعطا هستند؛ مجوزهای فعلی که کاربر ندارد حفظ می‌شوند (جلوگیری از ارتقای سطح دسترسی) */
    private function submittedPermissions(array $current): array
    {
        $valid = Permissions::all();
        $held = Auth::permissions();
        $posted = array_filter((array) ($_POST['perms'] ?? []), 'is_string');
        $granted = array_values(array_intersect($valid, $held, $posted));
        $kept = array_values(array_diff($current, $held));
        return array_values(array_unique(array_merge($granted, $kept)));
    }
}
