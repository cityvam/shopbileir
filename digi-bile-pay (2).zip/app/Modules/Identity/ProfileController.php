<?php
declare(strict_types=1);

namespace App\Modules\Identity;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\Totp;
use App\Core\UserError;
use App\Core\Validator;
use App\Services\MfaService;

final class ProfileController extends Controller
{
    public function show(): void
    {
        $u = DB::one('SELECT username, full_name, mobile, last_login_at, mfa_enabled FROM users WHERE id = ?', [Auth::id()]);
        $this->view('account/index', ['title' => 'حساب کاربری', 'u' => $u, 'perms' => Auth::permissions(), 'codesLeft' => MfaService::remainingCodes(Auth::id())], 'account');
    }

    public function password(): void
    {
        $current = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');
        $hash = (string) DB::scalar('SELECT password_hash FROM users WHERE id = ?', [Auth::id()]);

        $errors = [];
        if (!password_verify($current, $hash)) {
            $errors[] = 'رمز عبور فعلی صحیح نیست.';
        }
        if ($e = Validator::password($new)) {
            $errors[] = $e;
        }
        if ($new !== $confirm) {
            $errors[] = 'تکرار رمز عبور جدید یکسان نیست.';
        }
        if ($current !== '' && $current === $new) {
            $errors[] = 'رمز جدید باید با رمز فعلی متفاوت باشد.';
        }
        if ($errors) {
            $this->fail('/account', $errors);
        }
        DB::exec('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), Auth::id()]);
        session_regenerate_id(true);
        Audit::log('auth.password_change', 'user', Auth::id());
        $this->flash('success', 'رمز عبور تغییر کرد.');
        $this->redirect('/account');
    }

    public function mfa(): void
    {
        $u = DB::one('SELECT username, mfa_enabled FROM users WHERE id = ?', [Auth::id()]);
        if ((int) $u['mfa_enabled'] === 1) {
            $this->redirect('/account');
        }
        if (empty($_SESSION['mfa_setup'])) {
            $_SESSION['mfa_setup'] = Totp::newSecret();
        }
        $secret = (string) $_SESSION['mfa_setup'];
        $this->view('account/mfa', [
            'title' => 'فعال‌سازی تأیید دومرحله‌ای', 'secret' => $secret, 'chunks' => trim(chunk_split($secret, 4, ' ')),
            'uri' => Totp::uri($secret, $u['username'], 'DigiBilePay'), 'codes' => null,
        ], 'account');
    }

    public function mfaEnable(): void
    {
        $secret = (string) ($_SESSION['mfa_setup'] ?? '');
        if ($secret === '') {
            $this->redirect('/account/mfa');
        }
        try {
            $codes = MfaService::enable(Auth::id(), $secret, $this->input('code'));
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
            $this->redirect('/account/mfa');
        }
        unset($_SESSION['mfa_setup']);
        $this->view('account/mfa', ['title' => 'کدهای بازیابی', 'secret' => '', 'chunks' => '', 'uri' => '', 'codes' => $codes], 'account');
    }

    public function mfaRegenerate(): void
    {
        if (!$this->passwordOk()) {
            $this->flash('error', 'رمز عبور فعلی صحیح نیست.');
            $this->redirect('/account');
        }
        $codes = MfaService::newRecoveryCodes(Auth::id());
        Audit::log('mfa.recovery_regen', 'user', Auth::id());
        $this->view('account/mfa', ['title' => 'کدهای بازیابی', 'secret' => '', 'chunks' => '', 'uri' => '', 'codes' => $codes], 'account');
    }

    public function mfaDisable(): void
    {
        if (!$this->passwordOk()) {
            $this->flash('error', 'رمز عبور فعلی صحیح نیست.');
            $this->redirect('/account');
        }
        MfaService::disable(Auth::id());
        $this->flash('success', 'تأیید دومرحله‌ای غیرفعال شد.');
        $this->redirect('/account');
    }

    private function passwordOk(): bool
    {
        return password_verify((string) ($_POST['current_password'] ?? ''), (string) DB::scalar('SELECT password_hash FROM users WHERE id = ?', [Auth::id()]));
    }
}
