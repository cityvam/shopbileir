<?php
declare(strict_types=1);

namespace App\Modules\Finance;

use App\Core\Audit;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Services\Accounting;

final class AccountController extends Controller
{
    private const FAR = '9999-12-31';
    private const EPOCH = '0001-01-01';

    public function index(): void
    {
        $tree = Accounting::tree($this->cid(), self::EPOCH, self::FAR);
        $this->view('accounts/index', ['title' => 'سرفصل حساب‌ها', 'tree' => $tree, 'parents' => $this->parentChoices($tree)], 'accounting');
    }

    public function store(): void
    {
        $parent = DB::one('SELECT id, type FROM accounts WHERE id = ? AND company_id = ?', [(int) $this->input('parent_id', '0'), $this->cid()]);
        $code = $this->input('code');
        $name = $this->input('name');
        $errors = $this->validateAccount($code, $name, $parent, null);
        if ($errors) {
            $this->fail('/accounts', $errors);
        }
        $id = DB::insert('INSERT INTO accounts (company_id, code, name, type, parent_id) VALUES (?, ?, ?, ?, ?)', [$this->cid(), $code, $name, $parent['type'], $parent['id']]);
        Audit::log('account.create', 'account', $id, ['code' => $code, 'parent' => (int) $parent['id']]);
        $this->flash('success', 'حساب ثبت شد.');
        $this->redirect('/accounts');
    }

    public function edit(array $p): void
    {
        $acc = $this->find($p['id']);
        $tree = Accounting::tree($this->cid(), self::EPOCH, self::FAR);
        $this->view('accounts/form', [
            'title' => 'ویرایش حساب', 'acc' => $acc, 'parents' => $this->parentChoices($tree, (int) $acc['id']),
            'hasLines' => $this->hasLines((int) $acc['id']), 'kids' => (int) DB::scalar('SELECT COUNT(*) FROM accounts WHERE parent_id = ?', [$acc['id']]),
        ], 'accounting');
    }

    public function update(array $p): void
    {
        $acc = $this->find($p['id']);
        $hasLines = $this->hasLines((int) $acc['id']);
        $kids = (int) DB::scalar('SELECT COUNT(*) FROM accounts WHERE parent_id = ?', [$acc['id']]);
        $system = (int) $acc['is_system'] === 1;
        $name = $this->input('name');
        $active = $this->input('is_active') === '1' ? 1 : 0;
        $code = ($hasLines || $system) ? $acc['code'] : $this->input('code');
        $parentId = $system ? (int) $acc['parent_id'] : (int) $this->input('parent_id', '0');
        $parent = DB::one('SELECT id, type FROM accounts WHERE id = ? AND company_id = ?', [$parentId, $this->cid()]);
        $errors = $this->validateAccount($code, $name, $parent, (int) $acc['id']);
        if (!$system && $parent && in_array((int) $parent['id'], Accounting::descendantIds($this->cid(), (int) $acc['id']), true)) {
            $errors[] = 'حساب نمی‌تواند زیرمجموعه خودش یا فرزندانش باشد.';
        }
        if (!$system && $parent && $parent['type'] !== $acc['type']) {
            $errors[] = 'نوع حساب والد باید با نوع این حساب یکی باشد.';
        }
        if ($active === 0 && $acc['is_active'] && ($system || $kids > 0 && $this->activeKids((int) $acc['id']) > 0)) {
            $errors[] = 'حساب سیستمی یا حسابی که زیرمجموعه فعال دارد غیرفعال نمی‌شود.';
        }
        if ($active === 0 && $acc['is_active']) {
            $bal = array_values(array_filter(Accounting::tree($this->cid(), self::EPOCH, self::FAR), static fn ($n) => $n['id'] === (int) $acc['id']))[0] ?? null;
            if ($bal && $bal['close'] !== 0) {
                $errors[] = 'حساب دارای مانده است و غیرفعال نمی‌شود.';
            }
        }
        if ($errors) {
            $this->fail('/accounts/' . $acc['id'] . '/edit', $errors);
        }
        DB::exec('UPDATE accounts SET code = ?, name = ?, is_active = ?, parent_id = ? WHERE id = ? AND company_id = ?', [$code, $name, $active, $parentId ?: null, $acc['id'], $this->cid()]);
        Audit::log('account.update', 'account', (int) $acc['id'], ['code' => $code, 'name' => $name, 'active' => $active, 'parent' => $parentId]);
        $this->flash('success', 'حساب ذخیره شد.');
        $this->redirect('/accounts');
    }

    /** دفتر معین/کل با بازه، مانده اول دوره و خروجی CSV؛ حساب گروه شامل زیرمجموعه‌هاست */
    public function ledger(array $p): void
    {
        $acc = $this->find($p['id']);
        [$from, $to, $errors] = $this->period();
        $ids = Accounting::descendantIds($this->cid(), (int) $acc['id']);
        $in = implode(',', array_fill(0, count($ids), '?'));
        $open = DB::one(
            "SELECT COALESCE(SUM(l.debit), 0) AS d, COALESCE(SUM(l.credit), 0) AS c FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
             WHERE e.company_id = ? AND e.status = 'final' AND e.entry_date < ? AND l.account_id IN ($in)",
            [$this->cid(), $from, ...$ids]
        );
        $lines = DB::all(
            "SELECT e.id AS entry_id, e.entry_no, e.entry_date, e.description, l.description AS line_desc, a.code, a.name, l.debit, l.credit
             FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id JOIN accounts a ON a.id = l.account_id
             WHERE e.company_id = ? AND e.status = 'final' AND e.entry_date >= ? AND e.entry_date <= ? AND l.account_id IN ($in)
             ORDER BY e.entry_date, e.entry_no, l.id",
            [$this->cid(), $from, $to, ...$ids]
        );
        $net = (int) $open['d'] - (int) $open['c'];
        $openBalance = Accounting::balance($acc['type'], (int) $open['d'], (int) $open['c']);
        $debit = 0;
        $credit = 0;
        foreach ($lines as &$l) {
            $debit += (int) $l['debit'];
            $credit += (int) $l['credit'];
            $net += (int) $l['debit'] - (int) $l['credit'];
            $l['running'] = in_array($acc['type'], ['asset', 'expense'], true) ? $net : -$net;
        }
        unset($l);

        if (\App\Core\Csv::wanted($this->input('format'))) {
            Audit::log('report.export', 'report', null, ['name' => 'ledger', 'account' => (int) $acc['id']]);
            Csv::send('ledger-' . $acc['code'] . '.csv', ['شماره سند', 'تاریخ', 'حساب', 'شرح', 'بدهکار', 'بستانکار', 'مانده'],
                array_map(static fn ($l) => [$l['entry_no'], Jalali::format($l['entry_date']), $l['code'] . ' ' . $l['name'], trim($l['description'] . ' ' . $l['line_desc']), $l['debit'], $l['credit'], $l['running']], $lines));
        }
        $this->view('accounts/ledger', [
            'title' => 'دفتر ' . $acc['name'], 'acc' => $acc, 'lines' => $lines, 'debit' => $debit, 'credit' => $credit,
            'openBalance' => $openBalance, 'balance' => $lines ? end($lines)['running'] : $openBalance,
            'from' => Jalali::format($from), 'to' => Jalali::format($to), 'errors' => $errors, 'multi' => count($ids) > 1,
        ], 'accounting');
    }

    /** تراز آزمایشی شش‌ستونی (مانده اول دوره، گردش، مانده پایان) با جمع گروه‌ها */
    public function trial(): void
    {
        [$from, $to, $errors] = $this->period();
        $tree = Accounting::tree($this->cid(), $from, $to);
        $leaves = array_filter($tree, static fn ($n) => $n['kids'] === 0);
        $tot = ['open' => 0, 'debit' => 0, 'credit' => 0, 'close' => 0];
        foreach ($leaves as $n) {
            foreach ($tot as $k => $_) {
                $tot[$k] += $n[$k];
            }
        }
        if (\App\Core\Csv::wanted($this->input('format'))) {
            Audit::log('report.export', 'report', null, ['name' => 'trial']);
            Csv::send('trial-balance.csv', ['کد', 'حساب', 'مانده اول دوره (بدهکار+/بستانکار-)', 'گردش بدهکار', 'گردش بستانکار', 'مانده پایان (بدهکار+/بستانکار-)'],
                array_map(static fn ($n) => [$n['code'], str_repeat('  ', $n['depth']) . $n['name'], $n['open'], $n['debit'], $n['credit'], $n['close']], $tree));
        }
        $this->view('accounts/trial', [
            'title' => 'تراز آزمایشی', 'tree' => $tree, 'tot' => $tot, 'from' => Jalali::format($from), 'to' => Jalali::format($to), 'errors' => $errors,
        ], 'accounting');
    }

    /** ترازنامه تا تاریخ «to» و صورت سود و زیان بازه from..to (فقط اسناد قطعی) */
    public function statements(): void
    {
        [$from, $to, $errors] = $this->period();
        $cum = Accounting::tree($this->cid(), self::EPOCH, $to);
        $per = Accounting::tree($this->cid(), $from, $to, true);
        $group = static function (array $tree, array $types): array {
            $out = [];
            foreach ($tree as $n) {
                if ($n['kids'] === 0 && in_array($n['type'], $types, true) && $n['balance'] !== 0) {
                    $out[] = ['code' => $n['code'], 'name' => $n['name'], 'balance' => $n['balance']];
                }
            }
            return $out;
        };
        $periodGroup = static function (array $tree, array $types): array {
            $out = [];
            foreach ($tree as $n) {
                $b = in_array($n['type'], ['asset', 'expense'], true) ? $n['debit'] - $n['credit'] : $n['credit'] - $n['debit'];
                if ($n['kids'] === 0 && in_array($n['type'], $types, true) && $b !== 0) {
                    $out[] = ['code' => $n['code'], 'name' => $n['name'], 'balance' => $b];
                }
            }
            return $out;
        };
        $sum = static fn (array $rows): int => (int) array_sum(array_column($rows, 'balance'));
        $assets = $group($cum, ['asset']);
        $liabilities = $group($cum, ['liability']);
        $equity = $group($cum, ['equity']);
        $profitToDate = $sum($group($cum, ['revenue'])) - $sum($group($cum, ['expense']));
        $revenue = $periodGroup($per, ['revenue']);
        $expense = $periodGroup($per, ['expense']);

        $this->view('accounts/statements', [
            'title' => 'صورت‌های مالی', 'from' => Jalali::format($from), 'to' => Jalali::format($to), 'errors' => $errors,
            'assets' => $assets, 'liabilities' => $liabilities, 'equity' => $equity, 'profitToDate' => $profitToDate,
            'revenue' => $revenue, 'expense' => $expense, 'periodProfit' => $sum($revenue) - $sum($expense),
            'sumAssets' => $sum($assets), 'sumLiabilities' => $sum($liabilities), 'sumEquity' => $sum($equity),
        ], 'accounting');
    }

    // ------------------------------------------------------------------

    /** @return array{0:string,1:string,2:list<string>} بازه میلادی؛ پیش‌فرض: ابتدای سال مالی جاری تا امروز */
    private function period(): array
    {
        $fy = Accounting::fiscalYearFor($this->cid(), date('Y-m-d'), false);
        $from = Jalali::parse($this->input('from')) ?? $fy['start_date'];
        $to = Jalali::parse($this->input('to')) ?? date('Y-m-d');
        $errors = [];
        if (($this->input('from') !== '' && Jalali::parse($this->input('from')) === null) || ($this->input('to') !== '' && Jalali::parse($this->input('to')) === null)) {
            $errors[] = 'تاریخ باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.';
        }
        if ($from > $to) {
            $errors[] = 'تاریخ شروع نباید بعد از تاریخ پایان باشد.';
            $from = $fy['start_date'];
            $to = date('Y-m-d');
        }
        return [$from, $to, $errors];
    }

    private function find(int $id): array
    {
        return DB::one('SELECT * FROM accounts WHERE id = ? AND company_id = ?', [$id, $this->cid()]) ?? $this->notFound();
    }

    private function hasLines(int $accountId): bool
    {
        return (int) DB::scalar('SELECT COUNT(*) FROM journal_lines WHERE account_id = ?', [$accountId]) > 0;
    }

    private function activeKids(int $accountId): int
    {
        return (int) DB::scalar('SELECT COUNT(*) FROM accounts WHERE parent_id = ? AND is_active = 1', [$accountId]);
    }

    /** گزینه‌های والد: حساب‌های بدون گردش (خودِ حساب و فرزندانش حذف می‌شوند) */
    private function parentChoices(array $tree, ?int $exclude = null): array
    {
        $skip = $exclude ? Accounting::descendantIds($this->cid(), $exclude) : [];
        $withLines = array_map('intval', array_column(DB::all('SELECT DISTINCT l.account_id FROM journal_lines l JOIN accounts a ON a.id = l.account_id WHERE a.company_id = ?', [$this->cid()]), 'account_id'));
        return array_values(array_filter($tree, static fn ($n) => !in_array($n['id'], $skip, true) && !in_array($n['id'], $withLines, true)));
    }

    /** @return list<string> */
    private function validateAccount(string $code, string $name, ?array $parent, ?int $selfId): array
    {
        $errors = [];
        if (!preg_match('/^\d{3,10}$/', $code)) {
            $errors[] = 'کد حساب باید ۳ تا ۱۰ رقم باشد.';
        }
        if (mb_strlen($name) < 2) {
            $errors[] = 'نام حساب را وارد کنید.';
        }
        if (!$parent) {
            $errors[] = 'حساب والد (گروه) را انتخاب کنید.';
        }
        $dup = DB::scalar('SELECT id FROM accounts WHERE company_id = ? AND code = ?', [$this->cid(), $code]);
        if ($dup && (int) $dup !== $selfId) {
            $errors[] = 'این کد حساب قبلاً تعریف شده است.';
        }
        return $errors;
    }
}
