<?php
declare(strict_types=1);

namespace App\Modules\Finance;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\UserError;
use App\Services\BankStatementImport;

/** تطبیق بانکی: ردیف‌های قطعی حساب بانک/صندوق با صورت‌حساب بانک تطبیق داده و علامت‌گذاری می‌شوند */
final class ReconciliationController extends Controller
{
    public function index(): void
    {
        $accounts = DB::all(
            "SELECT a.id, a.code, a.name,
                    (SELECT COALESCE(SUM(l.debit - l.credit), 0) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final' AND l.account_id = a.id) AS book,
                    (SELECT COUNT(*) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final' AND l.account_id = a.id AND l.reconciliation_id IS NULL) AS open_lines,
                    (SELECT MAX(r.statement_date) FROM bank_reconciliations r WHERE r.account_id = a.id AND r.status = 'active') AS last_date
             FROM accounts a
             WHERE a.company_id = ? AND a.type = 'asset' AND a.is_active = 1 AND NOT EXISTS (SELECT 1 FROM accounts c WHERE c.parent_id = a.id)
               AND EXISTS (SELECT 1 FROM journal_lines l WHERE l.account_id = a.id)
             ORDER BY a.code",
            [$this->cid()]
        );
        $this->view('reconcile/index', ['title' => 'تطبیق بانکی', 'accounts' => $accounts], 'accounting');
    }

    public function show(array $p): void
    {
        $acc = $this->account($p['id']);
        $auto = $_SESSION['_recon'][(int) $acc['id']] ?? null;
        $until = Jalali::parse($this->input('until')) ?? ($auto['last_date'] ?? date('Y-m-d'));
        $lines = DB::all(
            "SELECT l.id, e.id AS entry_id, e.entry_no, e.entry_date, e.description, l.description AS line_desc, l.debit, l.credit
             FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
             WHERE e.company_id = ? AND e.status = 'final' AND l.account_id = ? AND l.reconciliation_id IS NULL AND e.entry_date <= ?
             ORDER BY e.entry_date, e.id, l.id",
            [$this->cid(), $acc['id'], $until]
        );
        $reconciledNet = (int) DB::scalar(
            "SELECT COALESCE(SUM(l.debit - l.credit), 0) FROM journal_lines l JOIN bank_reconciliations r ON r.id = l.reconciliation_id WHERE r.company_id = ? AND l.account_id = ? AND r.status = 'active'",
            [$this->cid(), $acc['id']]
        );
        $book = (int) DB::scalar("SELECT COALESCE(SUM(l.debit - l.credit), 0) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.company_id = ? AND e.status = 'final' AND l.account_id = ?", [$this->cid(), $acc['id']]);
        $history = DB::all(
            'SELECT r.id, r.statement_date, r.statement_balance, r.lines_count, r.status, r.created_at, u.full_name FROM bank_reconciliations r LEFT JOIN users u ON u.id = r.created_by WHERE r.company_id = ? AND r.account_id = ? ORDER BY r.id DESC LIMIT 15',
            [$this->cid(), $acc['id']]
        );
        $lastActive = DB::scalar("SELECT MAX(id) FROM bank_reconciliations WHERE company_id = ? AND account_id = ? AND status = 'active'", [$this->cid(), $acc['id']]);
        $this->view('reconcile/show', [
            'title' => 'تطبیق بانکی ' . $acc['name'], 'acc' => $acc, 'lines' => $lines, 'reconciledNet' => $reconciledNet, 'book' => $book,
            'until' => Jalali::format($until), 'history' => $history, 'auto' => $_SESSION['_recon'][(int) $acc['id']] ?? null, 'lastActive' => (int) $lastActive, 'canPost' => Auth::can('accounting.post'),
        ], 'accounting');
    }

    public function store(array $p): void
    {
        $acc = $this->account($p['id']);
        $back = '/reconciliation/' . $acc['id'];
        $date = Jalali::parse($this->input('statement_date'));
        $balRaw = trim($this->input('statement_balance'));
        $neg = str_starts_with($balRaw, '-');
        $digits = str_replace([',', '٬', ' '], '', ltrim($balRaw, '-'));
        $bal = ctype_digit($digits) && strlen($digits) <= 15 ? (int) $digits : null;
        $ids = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['ids'] ?? [])))));
        if ($date === null || $bal === null) {
            $this->flash('error', 'تاریخ شمسی و مانده‌ی صورت‌حساب را درست وارد کنید.');
            $this->redirect($back);
        }
        $bal = $neg ? -$bal : $bal;
        try {
            $rid = DB::tx(function () use ($acc, $date, $bal, $ids) {
                if (!$ids) {
                    throw new UserError('هیچ ردیفی انتخاب نشده است.');
                }
                $in = implode(',', array_fill(0, count($ids), '?'));
                $rows = DB::all(
                    "SELECT l.id, l.debit, l.credit FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
                     WHERE e.company_id = ? AND e.status = 'final' AND l.account_id = ? AND l.reconciliation_id IS NULL AND l.id IN ($in)",
                    [$this->cid(), $acc['id'], ...$ids]
                );
                if (count($rows) !== count($ids)) {
                    throw new UserError('برخی ردیف‌ها نامعتبر یا قبلاً تطبیق شده‌اند؛ صفحه را تازه کنید.');
                }
                $prev = (int) DB::scalar(
                    "SELECT COALESCE(SUM(l.debit - l.credit), 0) FROM journal_lines l JOIN bank_reconciliations r ON r.id = l.reconciliation_id WHERE r.company_id = ? AND l.account_id = ? AND r.status = 'active'",
                    [$this->cid(), $acc['id']]
                );
                $net = 0;
                foreach ($rows as $r) {
                    $net += (int) $r['debit'] - (int) $r['credit'];
                }
                $diff = $bal - ($prev + $net);
                if ($diff !== 0) {
                    throw new UserError('اختلاف ' . number_format(abs($diff)) . ' ریال است؛ مانده‌ی تطبیق‌شده (' . number_format($prev + $net) . ') باید با مانده‌ی صورت‌حساب برابر باشد.');
                }
                $rid = DB::insert(
                    'INSERT INTO bank_reconciliations (company_id, account_id, statement_date, statement_balance, lines_count, status, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [$this->cid(), $acc['id'], $date, $bal, count($ids), 'active', Auth::id(), date('Y-m-d H:i:s')]
                );
                $n = DB::exec("UPDATE journal_lines SET reconciliation_id = ? WHERE reconciliation_id IS NULL AND id IN ($in)", [$rid, ...$ids]);
                if ($n !== count($ids)) {
                    throw new UserError('تطبیق هم‌زمان شناسایی شد؛ دوباره تلاش کنید.');
                }
                Audit::log('reconcile.create', 'account', (int) $acc['id'], ['reconciliation' => $rid, 'lines' => count($ids), 'balance' => $bal]);
                return $rid;
            });
            unset($_SESSION['_recon'][(int) $acc['id']]);
            $this->flash('success', 'تطبیق بانکی ثبت شد (' . count($ids) . ' ردیف).');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect($back);
    }

    /** ورود CSV صورت‌حساب بانکی و مغایرت‌گیری خودکار؛ نتیجه برای تأیید نهایی کاربر در همان صفحه‌ی تطبیق پیش‌انتخاب می‌شود. */
    public function import(array $p): void
    {
        $acc = $this->account($p['id']);
        $back = '/reconciliation/' . $acc['id'];
        $f = $_FILES['file'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) $f['tmp_name'])) {
            $this->fail($back, ['فایل CSV یا Excel صورت‌حساب را انتخاب کنید.']);
        }
        if ((int) $f['size'] > 1048576) {
            $this->fail($back, ['حجم فایل بیش از ۱ مگابایت است.']);
        }
        try {
            $raw = \App\Core\Xlsx::isXlsx((string) $f['tmp_name']) ? \App\Core\Xlsx::toCsv((string) $f['tmp_name']) : (string) file_get_contents((string) $f['tmp_name']);
        } catch (\App\Core\UserError $e) {
            $this->fail($back, [$e->getMessage()]);
        }
        $parsed = BankStatementImport::parse($raw);
        if ($parsed['fatal'] !== null) {
            $this->fail($back, [$parsed['fatal']]);
        }
        $m = BankStatementImport::match($this->cid(), (int) $acc['id'], $parsed['rows']);
        $_SESSION['_recon'][(int) $acc['id']] = [
            'matched' => array_keys($m['matched']), 'unmatched_bank' => array_slice($m['unmatched_bank'], 0, 200), 'unmatched_book' => $m['unmatched_book'],
            'closing' => $m['closing'], 'last_date' => $m['last_date'], 'rows' => count($parsed['rows']), 'errors' => array_slice($parsed['errors'], 0, 20),
        ];
        Audit::log('reconcile.import', 'account', (int) $acc['id'], ['rows' => count($parsed['rows']), 'matched' => count($m['matched']), 'unmatched_bank' => count($m['unmatched_bank'])]);
        $this->flash('success', count($m['matched']) . ' ردیف خودکار مغایرت‌گیری شد؛ نتیجه را بررسی و تأیید کنید.');
        $this->redirect($back);
    }

    public function clearImport(array $p): void
    {
        unset($_SESSION['_recon'][(int) $p['id']]);
        $this->redirect('/reconciliation/' . (int) $p['id']);
    }

    /** فقط آخرین تطبیق فعال حساب قابل لغو است */
    public function undo(array $p): void
    {
        $r = DB::one('SELECT * FROM bank_reconciliations WHERE id = ? AND company_id = ?', [$p['id'], $this->cid()]) ?? $this->notFound();
        $last = (int) DB::scalar("SELECT MAX(id) FROM bank_reconciliations WHERE company_id = ? AND account_id = ? AND status = 'active'", [$this->cid(), $r['account_id']]);
        if ($r['status'] !== 'active' || $last !== (int) $r['id']) {
            $this->flash('error', 'فقط آخرین تطبیق فعال هر حساب قابل لغو است.');
        } else {
            DB::tx(function () use ($r) {
                DB::exec('UPDATE journal_lines SET reconciliation_id = NULL WHERE reconciliation_id = ?', [$r['id']]);
                DB::exec("UPDATE bank_reconciliations SET status = 'undone' WHERE id = ? AND company_id = ?", [$r['id'], $this->cid()]);
                Audit::log('reconcile.undo', 'account', (int) $r['account_id'], ['reconciliation' => (int) $r['id']]);
            });
            $this->flash('success', 'تطبیق لغو شد و ردیف‌ها دوباره باز شدند.');
        }
        $this->redirect('/reconciliation/' . $r['account_id']);
    }

    private function account(int $id): array
    {
        return DB::one("SELECT id, code, name FROM accounts WHERE id = ? AND company_id = ? AND type = 'asset'", [$id, $this->cid()]) ?? $this->notFound();
    }
}
