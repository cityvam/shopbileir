<?php
declare(strict_types=1);

namespace App\Modules\Finance;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\UserError;
use App\Services\Accounting;

final class FiscalYearController extends Controller
{
    public function index(): void
    {
        Accounting::fiscalYearFor($this->cid(), date('Y-m-d'), false);
        $rows = DB::all(
            "SELECT f.*, (SELECT COUNT(*) FROM journal_entries e WHERE e.fiscal_year_id = f.id AND e.status = 'final') AS finals,
                    (SELECT COUNT(*) FROM journal_entries e WHERE e.fiscal_year_id = f.id AND e.status = 'draft') AS drafts,
                    (SELECT full_name FROM users u WHERE u.id = f.closed_by) AS closer,
                    (SELECT e.id FROM journal_entries e WHERE e.company_id = f.company_id AND e.source_type = 'closing' AND e.source_id = f.id AND e.reversed_by IS NULL) AS closing_id
             FROM fiscal_years f WHERE f.company_id = ? ORDER BY f.start_date DESC",
            [$this->cid()]
        );
        $this->view('fiscal/index', ['title' => 'سال‌های مالی', 'rows' => $rows], 'accounting');
    }

    /** ایجاد سال مالی بعد از آخرین سال */
    public function store(): void
    {
        $last = (string) DB::scalar('SELECT MAX(end_date) FROM fiscal_years WHERE company_id = ?', [$this->cid()]);
        $fy = Accounting::fiscalYearFor($this->cid(), date('Y-m-d', strtotime($last . ' +1 day')), false);
        Audit::log('fiscal.create', 'fiscal_year', (int) $fy['id'], ['title' => $fy['title']]);
        $this->flash('success', '«' . $fy['title'] . '» ایجاد شد.');
        $this->redirect('/fiscal-years');
    }

    public function close(array $p): void
    {
        $fy = $this->find($p['id']);
        $drafts = (int) DB::scalar("SELECT COUNT(*) FROM journal_entries WHERE fiscal_year_id = ? AND status = 'draft'", [$fy['id']]);
        if ($fy['status'] !== 'open') {
            $this->flash('error', 'این سال مالی قبلاً بسته شده است.');
        } elseif ($drafts > 0) {
            $this->flash('error', 'تا زمانی که ' . number_format($drafts) . ' سند موقت در این سال مالی وجود دارد بستن آن ممکن نیست؛ آن‌ها را قطعی یا حذف کنید.');
        } else {
            DB::exec("UPDATE fiscal_years SET status = 'closed', closed_by = ?, closed_at = ? WHERE id = ? AND company_id = ? AND status = 'open'", [Auth::id(), date('Y-m-d H:i:s'), $fy['id'], $this->cid()]);
            Audit::log('fiscal.close', 'fiscal_year', (int) $fy['id'], ['title' => $fy['title']]);
            $this->flash('success', '«' . $fy['title'] . '» بسته شد.');
        }
        $this->redirect('/fiscal-years');
    }

    public function closing(array $p): void
    {
        $fy = $this->find($p['id']);
        try {
            $id = DB::tx(function () use ($fy) {
                $id = Accounting::closeYear($this->cid(), (int) $fy['id'], Auth::id());
                Audit::log('fiscal.closing', 'fiscal_year', (int) $fy['id'], ['entry' => $id]);
                return $id;
            });
            $this->flash('success', 'سند اختتامیه صادر شد.');
            $this->redirect('/journal/' . $id);
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/fiscal-years');
    }

    public function undoClosing(array $p): void
    {
        $fy = $this->find($p['id']);
        try {
            DB::tx(function () use ($fy) {
                $id = Accounting::undoClosing($this->cid(), (int) $fy['id'], Auth::id());
                Audit::log('fiscal.closing_undo', 'fiscal_year', (int) $fy['id'], ['entry' => $id]);
            });
            $this->flash('success', 'سند اختتامیه ابطال شد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/fiscal-years');
    }

    public function reopen(array $p): void
    {
        $fy = $this->find($p['id']);
        if ($fy['status'] === 'closed') {
            DB::exec("UPDATE fiscal_years SET status = 'open', closed_by = NULL, closed_at = NULL WHERE id = ? AND company_id = ?", [$fy['id'], $this->cid()]);
            Audit::log('fiscal.reopen', 'fiscal_year', (int) $fy['id'], ['title' => $fy['title']]);
            $this->flash('success', '«' . $fy['title'] . '» بازگشایی شد.');
        }
        $this->redirect('/fiscal-years');
    }

    private function find(int $id): array
    {
        return DB::one('SELECT * FROM fiscal_years WHERE id = ? AND company_id = ?', [$id, $this->cid()]) ?? $this->notFound();
    }
}
