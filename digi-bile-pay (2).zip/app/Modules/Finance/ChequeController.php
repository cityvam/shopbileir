<?php
declare(strict_types=1);

namespace App\Modules\Finance;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\ListFilter;
use App\Core\Paginator;
use App\Core\UserError;
use App\Core\Validator;
use App\Services\ChequeService;
use App\Services\NoteService;
use App\Services\StatusService;

final class ChequeController extends Controller
{
    private const SORTS = ['due' => 'c.due_date', 'amount' => 'c.amount', 'party' => 'c.party', 'created' => 'c.id'];

    public function index(): void
    {
        $today = date('Y-m-d');
        $lf = (new ListFilter($_GET, 'c.company_id = ?', [$this->cid()]))
            ->text('q', ['c.cheque_no', 'c.party', 'c.bank_name', 'c.description'])
            ->enum('direction', 'c.direction', ['received', 'issued'])
            ->enum('status', 'c.status', array_keys(ChequeService::STATUS_LABELS))
            ->amount('min', 'max', 'c.amount')
            ->dateRange('from', 'to', 'c.due_date')
            ->sort(self::SORTS, 'due', 'c.id');
        $due = $this->input('due');
        if ($due === 'overdue') {
            $lf->v['due'] = 'overdue';
            $lf->raw("c.status IN ('in_hand', 'deposited', 'issued') AND c.due_date < ?", [$today]);
        } elseif ($due === 'week') {
            $lf->v['due'] = 'week';
            $lf->raw("c.status IN ('in_hand', 'deposited', 'issued') AND c.due_date >= ? AND c.due_date <= ?", [$today, date('Y-m-d', strtotime('+7 days'))]);
        }
        $sel = "SELECT c.*, d.name AS detail_name FROM cheques c LEFT JOIN dimensions d ON d.id = c.detail_id WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'cheques']);
            Csv::send('cheques.csv', ['جهت', 'شماره', 'بانک', 'طرف حساب', 'مبلغ', 'تاریخ صدور', 'سررسید', 'وضعیت'],
                array_map(static fn ($r) => [$r['direction'] === 'received' ? 'دریافتی' : 'صادره', $r['cheque_no'], $r['bank_name'], $r['party'], $r['amount'], Jalali::format($r['issue_date']), Jalali::format($r['due_date']), ChequeService::STATUS_LABELS[$r['status']] ?? $r['status']], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) FROM cheques c WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $sum = DB::one(
            "SELECT COALESCE(SUM(CASE WHEN direction = 'received' AND status IN ('in_hand','deposited') THEN amount ELSE 0 END), 0) AS rec,
                    COALESCE(SUM(CASE WHEN direction = 'issued' AND status = 'issued' THEN amount ELSE 0 END), 0) AS iss,
                    COALESCE(SUM(CASE WHEN status IN ('in_hand','deposited','issued') AND due_date < ? THEN 1 ELSE 0 END), 0) AS overdue,
                    COALESCE(SUM(CASE WHEN status IN ('in_hand','deposited','issued') AND due_date >= ? AND due_date <= ? THEN 1 ELSE 0 END), 0) AS week
             FROM cheques WHERE company_id = ?",
            [$today, $today, date('Y-m-d', strtotime('+7 days')), $this->cid()]
        );
        $this->view('cheques/index', ['title' => 'چک‌ها', 'rows' => $rows, 'pg' => $pg, 'lf' => $lf, 'sum' => $sum, 'today' => $today], 'accounting');
    }

    public function create(): void
    {
        $this->view('cheques/form', ['title' => 'ثبت چک', 'c' => null] + $this->choices(), 'accounting');
    }

    public function store(): void
    {
        $issue = Jalali::parse($this->input('issue_date'));
        $due = Jalali::parse($this->input('due_date'));
        $amount = Validator::amount($this->input('amount'));
        $errors = [];
        if (!in_array($this->input('direction'), ['received', 'issued'], true)) {
            $errors[] = 'جهت چک را انتخاب کنید.';
        }
        if (!preg_match('/^[0-9A-Za-z\-\/]{3,30}$/', $this->input('cheque_no'))) {
            $errors[] = 'شماره چک معتبر نیست.';
        }
        if (mb_strlen($this->input('bank_name')) < 2) {
            $errors[] = 'نام بانک را وارد کنید.';
        }
        if (mb_strlen($this->input('party')) < 2) {
            $errors[] = 'نام طرف حساب را وارد کنید.';
        }
        if ($amount === null) {
            $errors[] = 'مبلغ چک معتبر نیست.';
        }
        if ($issue === null || $due === null) {
            $errors[] = 'تاریخ صدور و سررسید باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.';
        } elseif ($due < $issue) {
            $errors[] = 'سررسید نباید قبل از تاریخ صدور باشد.';
        }
        if ($errors) {
            $this->fail('/cheques/create', $errors);
        }
        try {
            $id = ChequeService::register($this->cid(), [
                'direction' => $this->input('direction'), 'cheque_no' => $this->input('cheque_no'), 'bank_name' => $this->input('bank_name'),
                'amount' => (int) $amount, 'issue_date' => $issue, 'due_date' => $due, 'party' => $this->input('party'),
                'detail_id' => (int) $this->input('detail_id', '0') ?: null, 'counter_account_id' => (int) $this->input('counter_account_id', '0'),
                'bank_account_id' => (int) $this->input('bank_account_id', '0') ?: null,
                'description' => $this->input('description') !== '' ? mb_substr($this->input('description'), 0, 250) : null,
            ], Auth::id());
        } catch (UserError $e) {
            $this->fail('/cheques/create', [$e->getMessage()]);
        }
        $this->flash('success', 'چک ثبت و سند حسابداری آن صادر شد.');
        $this->redirect('/cheques/' . $id);
    }

    public function show(array $p): void
    {
        $c = $this->find($p['id']);
        $accName = static fn ($id) => $id ? DB::one('SELECT id, code, name FROM accounts WHERE id = ?', [$id]) : null;
        $this->view('cheques/show', [
            'title' => 'چک ' . $c['cheque_no'], 'c' => $c, 'next' => ChequeService::nextOptions($c),
            'detail' => $c['detail_id'] ? DB::one('SELECT id, name FROM dimensions WHERE id = ?', [$c['detail_id']]) : null,
            'counter' => $accName($c['counter_account_id']), 'bank' => $accName($c['bank_account_id']),
            'regEntry' => $c['reg_entry_id'] ? DB::one('SELECT id, entry_no FROM journal_entries WHERE id = ?', [$c['reg_entry_id']]) : null,
            'finalEntry' => $c['final_entry_id'] ? DB::one('SELECT id, entry_no FROM journal_entries WHERE id = ?', [$c['final_entry_id']]) : null,
            'banks' => $this->choices()['banks'], 'choices' => $this->choices(), 'history' => StatusService::history($this->cid(), 'cheque', (int) $c['id']),
            'events' => Audit::events($this->cid(), 'cheque', (int) $c['id']), 'internalNotes' => NoteService::list($this->cid(), 'cheque', (int) $c['id']),
            'canPost' => Auth::can('accounting.post'),
        ], 'accounting');
    }

    /** ویرایش فیلدهای غیرمالی (مبلغ و طرف حساب حسابداری‌شده‌اند: برای تغییر، چک را ابطال و دوباره ثبت کنید) */
    public function update(array $p): void
    {
        $c = $this->find($p['id']);
        $due = Jalali::parse($this->input('due_date'));
        if ($due === null || $due < $c['issue_date']) {
            $this->fail('/cheques/' . $c['id'], ['سررسید باید تاریخ شمسی معتبر و بعد از تاریخ صدور باشد.']);
        }
        if (mb_strlen($this->input('party')) < 2) {
            $this->fail('/cheques/' . $c['id'], ['نام طرف حساب را وارد کنید.']);
        }
        $new = ['due_date' => $due, 'party' => $this->input('party'), 'description' => mb_substr($this->input('description'), 0, 250)];
        DB::exec('UPDATE cheques SET due_date = ?, party = ?, description = ?, updated_at = ? WHERE id = ? AND company_id = ?', [$due, $new['party'], $new['description'] !== '' ? $new['description'] : null, date('Y-m-d H:i:s'), $c['id'], $this->cid()]);
        Audit::log('cheque.update', 'cheque', (int) $c['id'], ['changes' => Audit::diff($c, $new, ['due_date', 'party', 'description'])]);
        $this->flash('success', 'ذخیره شد.');
        $this->redirect('/cheques/' . $c['id']);
    }

    public function transition(array $p): void
    {
        $c = $this->find($p['id']);
        $date = $this->input('date') === '' ? date('Y-m-d') : Jalali::parse($this->input('date'));
        try {
            if ($date === null) {
                throw new UserError('تاریخ باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.');
            }
            ChequeService::transition($this->cid(), (int) $c['id'], $this->input('to_status'), $date, (int) $this->input('bank_account_id', '0') ?: null, $this->input('reason'), Auth::id());
            $this->flash('success', 'وضعیت چک تغییر کرد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/cheques/' . $c['id']);
    }

    public function endorse(array $p): void
    {
        $c = $this->find($p['id']);
        $date = $this->input('date') === '' ? date('Y-m-d') : Jalali::parse($this->input('date'));
        try {
            if ($date === null) {
                throw new UserError('تاریخ باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.');
            }
            ChequeService::endorse($this->cid(), (int) $c['id'], (int) $this->input('counter_account_id', '0'), (int) $this->input('detail_id', '0') ?: null, $this->input('endorsee'), $date, Auth::id());
            $this->flash('success', 'چک پشت‌نویسی شد و سند حسابداری صادر گردید.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/cheques/' . $c['id']);
    }

    public function unendorse(array $p): void
    {
        $c = $this->find($p['id']);
        $date = $this->input('date') === '' ? date('Y-m-d') : Jalali::parse($this->input('date'));
        try {
            if ($date === null) {
                throw new UserError('تاریخ باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.');
            }
            ChequeService::unendorse($this->cid(), (int) $c['id'], $date, $this->input('reason'), Auth::id());
            $this->flash('success', 'چک به صندوق بازگشت و سند پشت‌نویسی معکوس شد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/cheques/' . $c['id']);
    }

    /** @return array{details:list<array>,accounts:list<array>,banks:list<array>} */
    private function choices(): array
    {
        $leaf = 'a.company_id = ? AND a.is_active = 1 AND NOT EXISTS (SELECT 1 FROM accounts c WHERE c.parent_id = a.id)';
        return [
            'details' => DB::all("SELECT id, code, name FROM dimensions WHERE company_id = ? AND kind = 'detail' AND is_active = 1 ORDER BY code", [$this->cid()]),
            'accounts' => DB::all("SELECT a.id, a.code, a.name FROM accounts a WHERE $leaf ORDER BY a.code", [$this->cid()]),
            'banks' => DB::all("SELECT a.id, a.code, a.name FROM accounts a WHERE $leaf AND a.type = 'asset' ORDER BY a.code", [$this->cid()]),
        ];
    }

    private function find(int $id): array
    {
        return DB::one('SELECT * FROM cheques WHERE id = ? AND company_id = ?', [$id, $this->cid()]) ?? $this->notFound();
    }
}
