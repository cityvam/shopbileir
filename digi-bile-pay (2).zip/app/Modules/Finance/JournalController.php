<?php
declare(strict_types=1);

namespace App\Modules\Finance;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\Paginator;
use App\Core\UserError;
use App\Core\Validator;
use App\Core\View;
use App\Services\Accounting;

final class JournalController extends Controller
{
    private const SORTS = ['no' => 'e.entry_no', 'date' => 'e.entry_date', 'amount' => 'amount'];

    /** فهرست اسناد با جست‌وجو، فیلتر پیشرفته، مرتب‌سازی و خروجی CSV */
    public function index(): void
    {
        $f = [
            'from' => $this->input('from'), 'to' => $this->input('to'), 'q' => $this->input('q'), 'status' => $this->input('status'),
            'source' => $this->input('source'), 'min' => $this->input('min'), 'max' => $this->input('max'),
            'no_from' => $this->input('no_from'), 'no_to' => $this->input('no_to'),
            'sort' => isset(self::SORTS[$this->input('sort')]) ? $this->input('sort') : 'no', 'dir' => $this->input('dir') === 'asc' ? 'asc' : 'desc',
        ];
        $where = 'e.company_id = ?';
        $params = [$this->cid()];
        $errors = [];
        foreach (['from' => '>=', 'to' => '<='] as $k => $op) {
            if ($f[$k] !== '') {
                $d = Jalali::parse($f[$k]);
                if ($d === null) {
                    $errors[] = 'تاریخ فیلتر باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.';
                } else {
                    $where .= " AND e.entry_date $op ?";
                    $params[] = $d;
                }
            }
        }
        if ($f['q'] !== '') {
            $like = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $f['q']) . '%';
            $where .= " AND (e.description LIKE ? ESCAPE '!' OR e.reference LIKE ? ESCAPE '!' OR EXISTS (SELECT 1 FROM journal_lines x WHERE x.entry_id = e.id AND x.description LIKE ? ESCAPE '!'))";
            array_push($params, $like, $like, $like);
        }
        if (in_array($f['status'], ['draft', 'final'], true)) {
            $where .= ' AND e.status = ?';
            $params[] = $f['status'];
        }
        if ($f['source'] === 'manual') {
            $where .= " AND e.source_type = 'manual'";
        } elseif ($f['source'] === 'auto') {
            $where .= " AND e.source_type <> 'manual'";
        }
        foreach (['no_from' => '>=', 'no_to' => '<='] as $k => $op) {
            if ($f[$k] !== '' && ctype_digit($f[$k])) {
                $where .= " AND e.entry_no $op ?";
                $params[] = (int) $f[$k];
            }
        }
        $amountSql = '(SELECT COALESCE(SUM(l.debit), 0) FROM journal_lines l WHERE l.entry_id = e.id)';
        foreach (['min' => '>=', 'max' => '<='] as $k => $op) {
            if ($f[$k] !== '') {
                $v = Validator::amount($f[$k]);
                if ($v === null) {
                    $errors[] = 'مبلغ فیلتر معتبر نیست.';
                } else {
                    $where .= " AND $amountSql $op ?";
                    $params[] = $v;
                }
            }
        }
        $order = self::SORTS[$f['sort']] . ' ' . $f['dir'] . ', e.id ' . $f['dir'];
        $sel = "SELECT e.id, e.entry_no, e.entry_date, e.description, e.reference, e.source_type, e.status, e.reversed_by, e.reversal_of, $amountSql AS amount FROM journal_entries e WHERE $where ORDER BY $order";

        if (\App\Core\Csv::wanted($this->input('format'))) {
            Audit::log('report.export', 'report', null, ['name' => 'journal']);
            Csv::send('journal.csv', ['شماره', 'تاریخ', 'شرح', 'مرجع', 'منشأ', 'وضعیت', 'مبلغ'],
                array_map(static fn ($r) => [$r['entry_no'], Jalali::format($r['entry_date']), $r['description'], $r['reference'], $r['source_type'] === 'manual' ? 'دستی' : 'خودکار', $r['status'] === 'draft' ? 'موقت' : 'قطعی', $r['amount']], DB::all($sel, $params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) FROM journal_entries e WHERE $where", $params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$params, $pg['per'], $pg['offset']]);
        $sum = DB::one("SELECT COUNT(*) AS c, COALESCE(SUM($amountSql), 0) AS s FROM journal_entries e WHERE $where", $params);
        $this->view('journal/index', ['title' => 'اسناد حسابداری', 'rows' => $rows, 'pg' => $pg, 'f' => $f, 'errors' => $errors, 'sum' => $sum], 'accounting');
    }

    public function show(array $p): void
    {
        $e = $this->find($p['id']);
        $lines = DB::all(
            'SELECT a.id AS account_id, a.code, a.name, l.debit, l.credit, l.description, l.detail_id, l.cost_center_id, dd.name AS detail_name, dc.name AS cc_name FROM journal_lines l JOIN accounts a ON a.id = l.account_id LEFT JOIN dimensions dd ON dd.id = l.detail_id LEFT JOIN dimensions dc ON dc.id = l.cost_center_id WHERE l.entry_id = ? ORDER BY l.id',
            [$e['id']]
        );
        $fy = $e['fiscal_year_id'] ? DB::one('SELECT title, status FROM fiscal_years WHERE id = ?', [$e['fiscal_year_id']]) : null;
        $link = static fn ($id) => $id ? DB::one('SELECT id, entry_no FROM journal_entries WHERE id = ?', [$id]) : null;
        $creator = $e['created_by'] ? DB::scalar('SELECT full_name FROM users WHERE id = ?', [$e['created_by']]) : null;
        $this->view('journal/show', [
            'title' => 'سند شماره ' . fa($e['entry_no']), 'e' => $e, 'lines' => $lines, 'fy' => $fy,
            'reversedBy' => $link($e['reversed_by']), 'reversalOf' => $link($e['reversal_of']), 'creator' => $creator,
        ], 'accounting');
    }

    public function create(): void
    {
        $this->form(null);
    }

    public function edit(array $p): void
    {
        $e = $this->find($p['id']);
        if ($e['status'] !== 'draft' || $e['source_type'] !== 'manual') {
            $this->flash('error', 'فقط سند دستیِ موقت قابل ویرایش است. سند قطعی را باید ابطال کرد.');
            $this->redirect('/journal/' . $e['id']);
        }
        $this->form($e);
    }

    public function store(): void
    {
        $this->save(null);
    }

    public function update(array $p): void
    {
        $this->save($this->find($p['id']));
    }

    public function finalize(array $p): void
    {
        $e = $this->find($p['id']);
        try {
            DB::tx(function () use ($e) {
                Accounting::finalize($this->cid(), (int) $e['id']);
                Audit::log('journal.finalize', 'journal_entry', (int) $e['id']);
            });
            $this->flash('success', 'سند قطعی شد.');
        } catch (UserError $x) {
            $this->flash('error', $x->getMessage());
        }
        $this->redirect('/journal/' . $e['id']);
    }

    public function delete(array $p): void
    {
        $e = $this->find($p['id']);
        try {
            DB::tx(function () use ($e) {
                Accounting::deleteDraft($this->cid(), (int) $e['id']);
                Audit::log('journal.delete_draft', 'journal_entry', (int) $e['id'], ['entry_no' => (int) $e['entry_no'], 'description' => $e['description']]);
            });
            $this->flash('success', 'سند موقت حذف شد.');
            $this->redirect('/journal?status=draft');
        } catch (UserError $x) {
            $this->flash('error', $x->getMessage());
            $this->redirect('/journal/' . $e['id']);
        }
    }

    public function reverse(array $p): void
    {
        $e = $this->find($p['id']);
        $date = $this->input('date') === '' ? date('Y-m-d') : Jalali::parse($this->input('date'));
        if ($date === null) {
            $this->flash('error', 'تاریخ ابطال باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.');
            $this->redirect('/journal/' . $e['id']);
        }
        try {
            $newId = DB::tx(function () use ($e, $date) {
                $newId = Accounting::reverse($this->cid(), (int) $e['id'], $date, Auth::id());
                Audit::log('journal.reverse', 'journal_entry', (int) $e['id'], ['reversal' => $newId]);
                return $newId;
            });
            $this->flash('success', 'سند معکوس صادر شد.');
            $this->redirect('/journal/' . $newId);
        } catch (UserError $x) {
            $this->flash('error', $x->getMessage());
            $this->redirect('/journal/' . $e['id']);
        }
    }

    // ------------------------------------------------------------------

    private function form(?array $e): void
    {
        $accounts = DB::all(
            'SELECT a.id, a.code, a.name FROM accounts a WHERE a.company_id = ? AND a.is_active = 1 AND NOT EXISTS (SELECT 1 FROM accounts c WHERE c.parent_id = a.id) ORDER BY a.code',
            [$this->cid()]
        );
        $old = View::oldArray('account_id');
        $rows = [];
        if ($old) {
            $deb = View::oldArray('debit');
            $cre = View::oldArray('credit');
            $des = View::oldArray('line_desc');
            $det = View::oldArray('detail_id');
            $cc = View::oldArray('cost_center_id');
            foreach ($old as $i => $acc) {
                $rows[] = ['account_id' => (string) $acc, 'debit' => (string) ($deb[$i] ?? ''), 'credit' => (string) ($cre[$i] ?? ''), 'description' => (string) ($des[$i] ?? ''), 'detail_id' => (string) ($det[$i] ?? ''), 'cost_center_id' => (string) ($cc[$i] ?? '')];
            }
        } elseif ($e) {
            foreach (DB::all('SELECT account_id, debit, credit, description, detail_id, cost_center_id FROM journal_lines WHERE entry_id = ? ORDER BY id', [$e['id']]) as $l) {
                $rows[] = ['account_id' => (string) $l['account_id'], 'debit' => $l['debit'] ? (string) $l['debit'] : '', 'credit' => $l['credit'] ? (string) $l['credit'] : '', 'description' => (string) $l['description'], 'detail_id' => (string) $l['detail_id'], 'cost_center_id' => (string) $l['cost_center_id']];
            }
        }
        while (count($rows) < 2) {
            $rows[] = ['account_id' => '', 'debit' => '', 'credit' => '', 'description' => '', 'detail_id' => '', 'cost_center_id' => ''];
        }
        $this->view('journal/form', [
            'title' => $e ? 'ویرایش سند موقت شماره ' . fa($e['entry_no']) : 'سند جدید', 'e' => $e, 'accounts' => $accounts, 'rows' => $rows,
            'details' => DB::all("SELECT id, code, name FROM dimensions WHERE company_id = ? AND kind = 'detail' AND is_active = 1 ORDER BY code", [$this->cid()]),
            'centers' => DB::all("SELECT id, code, name FROM dimensions WHERE company_id = ? AND kind = 'cost_center' AND is_active = 1 ORDER BY code", [$this->cid()]),
            'date' => View::old('entry_date', $e ? Jalali::format($e['entry_date']) : Jalali::format(date('Y-m-d'))),
        ], 'accounting');
    }

    private function save(?array $e): void
    {
        $back = $e ? '/journal/' . $e['id'] . '/edit' : '/journal/create';
        $date = Jalali::parse($this->input('entry_date'));
        if ($date === null) {
            $this->fail($back, ['تاریخ سند باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.']);
        }
        $status = $this->input('status') === 'final' ? 'final' : 'draft';
        $lines = [];
        $accIds = (array) ($_POST['account_id'] ?? []);
        $debits = (array) ($_POST['debit'] ?? []);
        $credits = (array) ($_POST['credit'] ?? []);
        $descs = (array) ($_POST['line_desc'] ?? []);
        $details = (array) ($_POST['detail_id'] ?? []);
        $centers = (array) ($_POST['cost_center_id'] ?? []);
        foreach ($accIds as $i => $accId) {
            $dRaw = trim((string) ($debits[$i] ?? ''));
            $cRaw = trim((string) ($credits[$i] ?? ''));
            if ((string) $accId === '' && $dRaw === '' && $cRaw === '') {
                continue;
            }
            $d = $dRaw === '' ? 0 : Validator::amount($dRaw);
            $c = $cRaw === '' ? 0 : Validator::amount($cRaw);
            if ($d === null || $c === null) {
                $this->fail($back, ['مبلغ یکی از ردیف‌ها معتبر نیست.']);
            }
            $lines[] = [(int) $accId, $d, $c, trim((string) ($descs[$i] ?? '')), (int) ($details[$i] ?? 0) ?: null, (int) ($centers[$i] ?? 0) ?: null];
        }
        $ref = $this->input('reference');
        try {
            $id = DB::tx(function () use ($e, $date, $lines, $status, $ref) {
                $id = Accounting::saveManual($this->cid(), $e ? (int) $e['id'] : null, $date, $this->input('description'), $ref !== '' ? mb_substr($ref, 0, 60) : null, $lines, $status, Auth::id());
                Audit::log($e ? 'journal.update' : 'journal.manual', 'journal_entry', $id, ['status' => $status, 'lines' => count($lines)]);
                return $id;
            });
        } catch (UserError $x) {
            $this->fail($back, [$x->getMessage()]);
        }
        $this->flash('success', $status === 'final' ? 'سند قطعی ثبت شد.' : 'سند موقت ذخیره شد.');
        $this->redirect('/journal/' . $id);
    }

    private function find(int $id): array
    {
        return DB::one('SELECT * FROM journal_entries WHERE id = ? AND company_id = ?', [$id, $this->cid()]) ?? $this->notFound();
    }
}
