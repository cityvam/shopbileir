<?php
declare(strict_types=1);

namespace App\Modules\Finance;

use App\Core\Audit;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\ListFilter;
use App\Services\Accounting;

/** حساب تفصیلی (طرف‌حساب) و مرکز هزینه: تعریف، فعال/غیرفعال و گزارش گردش */
final class DimensionController extends Controller
{
    public const KINDS = ['detail' => 'تفصیلی', 'cost_center' => 'مرکز هزینه'];

    public function index(): void
    {
        $lf = (new ListFilter($_GET, 'd.company_id = ?', [$this->cid()]))
            ->text('q', ['d.name', 'd.code'])
            ->enum('kind', 'd.kind', array_keys(self::KINDS))
            ->enum('status', 'd.is_active', ['1', '0'])
            ->sort(['code' => 'd.code', 'name' => 'd.name', 'turnover' => 'turnover'], 'code', 'd.id');
        $col = "CASE d.kind WHEN 'detail' THEN l.detail_id ELSE l.cost_center_id END";
        $sel = "SELECT d.id, d.kind, d.code, d.name, d.is_active,
                       (SELECT COUNT(*) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final' AND $col = d.id) AS uses,
                       (SELECT COALESCE(SUM(l.debit), 0) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final' AND $col = d.id) AS turnover
                FROM dimensions d WHERE {$lf->where} ORDER BY {$lf->order}";
        $rows = DB::all($sel, $lf->params);
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'dimensions']);
            Csv::send('dimensions.csv', ['نوع', 'کد', 'نام', 'تعداد ردیف', 'گردش بدهکار', 'وضعیت'],
                array_map(static fn ($r) => [self::KINDS[$r['kind']], $r['code'], $r['name'], $r['uses'], $r['turnover'], (int) $r['is_active'] ? 'فعال' : 'غیرفعال'], $rows));
        }
        $this->view('dimensions/index', ['title' => 'تفصیلی و مرکز هزینه', 'rows' => $rows, 'lf' => $lf, 'kinds' => self::KINDS], 'accounting');
    }

    public function store(): void
    {
        $kind = $this->input('kind');
        $code = $this->input('code');
        $name = $this->input('name');
        $errors = [];
        if (!isset(self::KINDS[$kind])) {
            $errors[] = 'نوع نامعتبر است.';
        }
        if (!preg_match('/^[0-9A-Za-z\-]{1,20}$/', $code)) {
            $errors[] = 'کد فقط شامل حروف لاتین، عدد و خط تیره (حداکثر ۲۰ نویسه) باشد.';
        }
        if (mb_strlen($name) < 2 || mb_strlen($name) > 120) {
            $errors[] = 'نام را وارد کنید.';
        }
        if (!$errors && DB::scalar('SELECT id FROM dimensions WHERE company_id = ? AND kind = ? AND code = ?', [$this->cid(), $kind, $code])) {
            $errors[] = 'این کد قبلاً برای همین نوع تعریف شده است.';
        }
        if ($errors) {
            $this->fail('/dimensions', $errors);
        }
        $id = DB::insert('INSERT INTO dimensions (company_id, kind, code, name, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)', [$this->cid(), $kind, $code, $name, date('Y-m-d H:i:s')]);
        Audit::log('dimension.create', 'dimension', $id, ['kind' => $kind, 'code' => $code]);
        $this->flash('success', self::KINDS[$kind] . ' ثبت شد.');
        $this->redirect('/dimensions');
    }

    public function edit(array $p): void
    {
        $d = $this->find($p['id']);
        $this->view('dimensions/form', ['title' => 'ویرایش ' . self::KINDS[$d['kind']], 'd' => $d, 'kinds' => self::KINDS, 'events' => Audit::events($this->cid(), 'dimension', (int) $d['id'])], 'accounting');
    }

    public function update(array $p): void
    {
        $d = $this->find($p['id']);
        $code = $this->input('code');
        $name = $this->input('name');
        $errors = [];
        if (!preg_match('/^[0-9A-Za-z\-]{1,20}$/', $code)) {
            $errors[] = 'کد فقط شامل حروف لاتین، عدد و خط تیره (حداکثر ۲۰ نویسه) باشد.';
        }
        if (mb_strlen($name) < 2 || mb_strlen($name) > 120) {
            $errors[] = 'نام را وارد کنید.';
        }
        if (!$errors && $code !== $d['code'] && DB::scalar('SELECT id FROM dimensions WHERE company_id = ? AND kind = ? AND code = ? AND id <> ?', [$this->cid(), $d['kind'], $code, $d['id']])) {
            $errors[] = 'این کد قبلاً برای همین نوع تعریف شده است.';
        }
        if ($errors) {
            $this->fail('/dimensions/' . $d['id'] . '/edit', $errors);
        }
        DB::exec('UPDATE dimensions SET code = ?, name = ? WHERE id = ? AND company_id = ?', [$code, $name, $d['id'], $this->cid()]);
        Audit::log('dimension.update', 'dimension', (int) $d['id'], ['changes' => Audit::diff($d, ['code' => $code, 'name' => $name], ['code', 'name'])]);
        $this->flash('success', 'ذخیره شد.');
        $this->redirect('/dimensions');
    }

    public function toggle(array $p): void
    {
        $d = $this->find($p['id']);
        $to = (int) $d['is_active'] === 1 ? 0 : 1;
        DB::exec('UPDATE dimensions SET is_active = ? WHERE id = ? AND company_id = ?', [$to, $d['id'], $this->cid()]);
        Audit::log('dimension.status', 'dimension', (int) $d['id'], ['to' => $to ? 'active' : 'disabled']);
        $this->flash('success', $to ? 'فعال شد.' : 'غیرفعال شد؛ در اسناد جدید قابل انتخاب نیست ولی سوابق قبلی حفظ می‌شود.');
        $this->redirect('/dimensions');
    }

    /** گزارش گردش یک تفصیلی/مرکز هزینه در بازه، به تفکیک حساب */
    public function report(array $p): void
    {
        $d = $this->find($p['id']);
        $fy = Accounting::fiscalYearFor($this->cid(), date('Y-m-d'), false);
        $errors = [];
        $from = Jalali::parse($this->input('from')) ?? $fy['start_date'];
        $to = Jalali::parse($this->input('to')) ?? date('Y-m-d');
        if (($this->input('from') !== '' && Jalali::parse($this->input('from')) === null) || ($this->input('to') !== '' && Jalali::parse($this->input('to')) === null)) {
            $errors[] = 'تاریخ باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۰ باشد.';
        }
        if ($from > $to) {
            $errors[] = 'تاریخ شروع نباید بعد از تاریخ پایان باشد.';
            $from = $fy['start_date'];
            $to = date('Y-m-d');
        }
        $col = $d['kind'] === 'detail' ? 'l.detail_id' : 'l.cost_center_id';
        $base = "FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id JOIN accounts a ON a.id = l.account_id
                 WHERE e.company_id = ? AND e.status = 'final' AND $col = ? AND e.entry_date >= ? AND e.entry_date <= ?";
        $bind = [$this->cid(), $d['id'], $from, $to];
        $byAccount = DB::all("SELECT a.id, a.code, a.name, a.type, SUM(l.debit) AS d, SUM(l.credit) AS c $base GROUP BY a.id, a.code, a.name, a.type ORDER BY a.code", $bind);
        $lines = DB::all("SELECT e.id AS entry_id, e.entry_no, e.entry_date, e.description, l.description AS line_desc, a.code, a.name, l.debit, l.credit $base ORDER BY e.entry_date, e.id, l.id LIMIT 1000", $bind);
        if (\App\Core\Csv::wanted($this->input('format'))) {
            Audit::log('report.export', 'report', null, ['name' => 'dimension']);
            Csv::send('dimension-' . $d['code'] . '.csv', ['شماره سند', 'تاریخ', 'شرح', 'کد حساب', 'حساب', 'بدهکار', 'بستانکار'],
                array_map(static fn ($r) => [$r['entry_no'], Jalali::format($r['entry_date']), trim($r['description'] . ' ' . ($r['line_desc'] ?? '')), $r['code'], $r['name'], $r['debit'], $r['credit']], $lines));
        }
        $this->view('dimensions/report', [
            'title' => self::KINDS[$d['kind']] . ' ' . $d['name'], 'd' => $d, 'byAccount' => $byAccount, 'lines' => $lines,
            'from' => Jalali::format($from), 'to' => Jalali::format($to), 'errors' => $errors, 'action' => '/dimensions/' . (int) $d['id'],
        ], 'accounting');
    }

    private function find(int $id): array
    {
        return DB::one('SELECT * FROM dimensions WHERE id = ? AND company_id = ?', [$id, $this->cid()]) ?? $this->notFound();
    }
}
