<?php
declare(strict_types=1);

namespace App\Modules\Reports;

use App\Core\Chart;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Services\ReportService;

final class DashboardController extends Controller
{
    public function index(): void
    {
        $c = $this->cid();
        $today = date('Y-m-d');
        $monthStart = date('Y-m-01 00:00:00');

        $stats = [
            'customers' => (int) DB::scalar("SELECT COUNT(*) FROM customers WHERE company_id = ? AND status = 'active'", [$c]),
            'pending' => (int) DB::scalar("SELECT COUNT(*) FROM loans WHERE company_id = ? AND status = 'pending'", [$c]),
            'active_loans' => (int) DB::scalar("SELECT COUNT(*) FROM loans WHERE company_id = ? AND status = 'active'", [$c]),
            'outstanding' => (int) DB::scalar(
                "SELECT COALESCE(SUM(i.amount - i.paid_amount), 0) FROM installments i JOIN loans l ON l.id = i.loan_id
                 WHERE i.company_id = ? AND l.status = 'active' AND i.status <> 'paid'",
                [$c]
            ),
            'overdue_count' => (int) DB::scalar("SELECT COUNT(*) FROM installments WHERE company_id = ? AND status <> 'paid' AND due_date < ?", [$c, $today]),
            'overdue_sum' => (int) DB::scalar("SELECT COALESCE(SUM(amount - paid_amount), 0) FROM installments WHERE company_id = ? AND status <> 'paid' AND due_date < ?", [$c, $today]),
            'collected_month' => (int) DB::scalar('SELECT COALESCE(SUM(amount), 0) FROM payments WHERE company_id = ? AND created_at >= ?', [$c, $monthStart]),
            'merchants' => (int) DB::scalar("SELECT COUNT(*) FROM merchants WHERE company_id = ? AND status = 'active'", [$c]),
            'orders_month' => (int) DB::scalar("SELECT COUNT(*) FROM orders WHERE company_id = ? AND status <> 'cancelled' AND created_at >= ?", [$c, $monthStart]),
            'sales_month' => (int) DB::scalar("SELECT COALESCE(SUM(total), 0) FROM orders WHERE company_id = ? AND status <> 'cancelled' AND created_at >= ?", [$c, $monthStart]),
        ];

        $monthly = ReportService::monthlyCollections($c, 6);
        $aging = ReportService::aging($c);
        $portfolio = ReportService::portfolio($c);
        $labels = ['pending' => ['در انتظار', 'warn'], 'active' => ['فعال', 'ok'], 'closed' => ['تسویه‌شده', 'muted'], 'rejected' => ['ردشده', 'bad']];
        $parts = [];
        foreach ($labels as $k => [$label, $tone]) {
            $parts[] = [$label, $portfolio[$k]['count'] ?? 0, $tone];
        }

        $upcoming = DB::all(
            "SELECT i.id, i.seq, i.due_date, (i.amount - i.paid_amount) AS remaining, cu.full_name, l.id AS loan_id
             FROM installments i JOIN loans l ON l.id = i.loan_id JOIN customers cu ON cu.id = l.customer_id
             WHERE i.company_id = ? AND i.status <> 'paid' AND l.status = 'active'
             ORDER BY i.due_date ASC, i.id ASC LIMIT 6",
            [$c]
        );
        $activity = DB::all(
            'SELECT a.action, a.entity, a.entity_id, a.created_at, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
             WHERE a.company_id = ? ORDER BY a.id DESC LIMIT 7',
            [$c]
        );

        $this->view('dashboard/index', [
            'title' => 'داشبورد', 'stats' => $stats, 'upcoming' => $upcoming, 'today' => $today, 'activity' => $activity,
            'barsChart' => Chart::bars($monthly['labels'], $monthly['values'], 'primary'),
            'agingChart' => Chart::bars(array_column($aging, 'label'), array_column($aging, 'amount'), 'warn'),
            'donut' => Chart::donut($parts, 'تسهیلات'),
        ], 'dashboard');
    }
}
