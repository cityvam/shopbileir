<?php
declare(strict_types=1);

namespace App\Modules\Reports;

use App\Core\Audit;
use App\Core\Chart;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Services\ReportService;

final class ReportController extends Controller
{
    public function index(): void
    {
        $c = $this->cid();
        $aging = ReportService::aging($c);
        $monthly = ReportService::monthlyCollections($c, 6);
        $portfolio = ReportService::portfolio($c);
        $merchants = DB::all(
            "SELECT m.id, m.name, COUNT(o.id) AS orders_count, COALESCE(SUM(o.total), 0) AS sales, COALESCE(SUM(o.commission_amount), 0) AS commission
             FROM merchants m LEFT JOIN orders o ON o.merchant_id = m.id AND o.status = 'confirmed'
             WHERE m.company_id = ? GROUP BY m.id, m.name ORDER BY sales DESC",
            [$c]
        );
        $this->view('reports/index', [
            'title' => 'گزارش‌ها', 'aging' => $aging, 'portfolio' => $portfolio, 'merchants' => $merchants,
            'debtors' => ReportService::topDebtors($c, 8),
            'monthlyChart' => Chart::bars($monthly['labels'], $monthly['values'], 'primary'),
            'agingChart' => Chart::bars(array_column($aging, 'label'), array_column($aging, 'amount'), 'warn'),
            'monthlyTotal' => array_sum($monthly['values']),
        ], 'reports');
    }

    /** خروجی CSV معوقات (UTF-8 با BOM برای Excel) */
    public function overdueCsv(): void
    {
        $rows = DB::all(
            "SELECT cu.full_name, cu.national_code, cu.mobile, l.id AS loan_id, i.seq, i.due_date, (i.amount - i.paid_amount) AS rem
             FROM installments i JOIN loans l ON l.id = i.loan_id JOIN customers cu ON cu.id = l.customer_id
             WHERE i.company_id = ? AND i.status <> 'paid' AND l.status = 'active' AND i.due_date < ?
             ORDER BY i.due_date ASC, i.id ASC",
            [$this->cid(), date('Y-m-d')]
        );
        Audit::log('report.export', 'report', null, ['name' => 'overdue', 'rows' => count($rows)]);

        $today = strtotime(date('Y-m-d'));
        Csv::send('overdue-' . date('Ymd') . '.csv', ['مشتری', 'کد ملی', 'موبایل', 'تسهیلات', 'قسط', 'سررسید (شمسی)', 'روز تأخیر', 'باقی‌مانده (ریال)'],
            array_map(static fn ($r) => [
                $r['full_name'], $r['national_code'], $r['mobile'], $r['loan_id'], $r['seq'],
                Jalali::format($r['due_date']), (int) floor(($today - strtotime($r['due_date'])) / 86400), $r['rem'],
            ], $rows));
    }
}
