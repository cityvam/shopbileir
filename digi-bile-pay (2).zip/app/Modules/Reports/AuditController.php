<?php
declare(strict_types=1);

namespace App\Modules\Reports;

use App\Core\Audit;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\ListFilter;
use App\Core\Paginator;

final class AuditController extends Controller
{
    public function index(): void
    {
        $users = DB::all('SELECT id, full_name FROM users WHERE company_id = ? ORDER BY full_name', [$this->cid()]);
        $entities = array_column(DB::all('SELECT DISTINCT entity FROM audit_logs WHERE company_id = ? ORDER BY entity', [$this->cid()]), 'entity');
        $lf = (new ListFilter($_GET, 'a.company_id = ?', [$this->cid()]))
            ->text('q', ['a.action', 'a.entity', 'a.details'])
            ->enum('user_id', 'a.user_id', array_map('strval', array_column($users, 'id')))
            ->enum('entity', 'a.entity', $entities)
            ->dateRange('from', 'to', 'a.created_at')
            ->sort(['time' => 'a.id', 'action' => 'a.action', 'user' => 'u.full_name'], 'time', 'a.id');
        $sel = "SELECT a.id, a.action, a.entity, a.entity_id, a.details, a.ip, a.created_at, u.full_name
                FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'audit']);
            Csv::send('audit.csv', ['زمان', 'کاربر', 'رویداد', 'موجودیت', 'شناسه', 'جزئیات', 'IP'],
                array_map(static fn ($r) => [Jalali::format(substr($r['created_at'], 0, 10)) . ' ' . substr($r['created_at'], 11, 5), $r['full_name'], $r['action'], $r['entity'], $r['entity_id'], $r['details'], $r['ip']], DB::all($sel . ' LIMIT 5000', $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $this->view('audit/index', ['title' => 'گزارش حسابرسی', 'rows' => $rows, 'pg' => $pg, 'lf' => $lf, 'users' => $users, 'entities' => $entities], 'audit');
    }
}
