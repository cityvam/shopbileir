<?php
declare(strict_types=1);

namespace App\Modules\Reports;

use App\Core\Controller;
use App\Services\AlertService;

final class AlertController extends Controller
{
    public function index(): void
    {
        $this->view('alerts/index', ['title' => 'هشدارها', 'items' => AlertService::items($this->cid())], 'alerts');
    }

    public function read(): void
    {
        AlertService::markRead($this->cid(), $this->input('key'));
        $this->redirect('/alerts');
    }
}
