<?php
declare(strict_types=1);

namespace App\Modules\Site;

use App\Core\Controller;
use App\Core\UserError;
use App\Services\Gateway\Gateways;
use App\Services\PaymentLinkService;

/** صفحه‌ی عمومی پرداخت برای مشتری (بدون ورود؛ فقط با توکن تصادفی ۴۰ نویسه‌ای). */
final class PayController extends Controller
{
    private function load(): array
    {
        header('Cache-Control: no-store');
        header('Referrer-Policy: no-referrer');
        return PaymentLinkService::byToken($this->input('t')) ?? $this->notFound();
    }

    public function show(): void
    {
        $r = $this->load();
        $this->view('pay/show', ['title' => 'پرداخت آنلاین', 'r' => $r, 'gatewayOn' => Gateways::active() !== null, 'result' => null], 'pay', 'auth');
    }

    public function start(): void
    {
        $r = $this->load();
        try {
            $url = PaymentLinkService::start($r);
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
            $this->redirect('/pay?t=' . $r['token']);
        }
        $this->redirect($url);
    }

    public function back(): void
    {
        $r = $this->load();
        $result = PaymentLinkService::complete($r, $_GET);
        $r = PaymentLinkService::byToken($r['token']) ?? $r;
        $this->view('pay/show', ['title' => 'نتیجه‌ی پرداخت', 'r' => $r, 'gatewayOn' => Gateways::active() !== null, 'result' => $result], 'pay', 'auth');
    }

    /** صفحه‌ی درگاه آزمایشی داخلی (فقط وقتی PAYMENT_GATEWAY=sandbox و محیط غیر production). */
    public function sandbox(): void
    {
        $r = $this->load();
        $gw = Gateways::active();
        if (!$gw || $gw->name() !== 'sandbox' || $r['status'] !== 'pending' || !$r['authority']) {
            $this->notFound();
        }
        $this->view('pay/sandbox', ['title' => 'درگاه آزمایشی', 'r' => $r], 'pay', 'auth');
    }
}
