<?php
declare(strict_types=1);

namespace App\Modules\Site;

use App\Core\Audit;
use App\Core\Captcha;
use App\Core\Controller;
use App\Core\Env;
use App\Core\UserError;
use App\Core\Validator;
use App\Core\View;
use App\Services\SiteContent;
use App\Services\SiteService;

final class SiteController extends Controller
{
    public function index(): void
    {
        $company = SiteService::company();
        $plans = $company ? SiteService::plans($company['id']) : [];
        $planId = (int) $this->input('plan', '0');
        $amount = (int) (preg_replace('/\D/', '', $this->input('amount')) ?: 0);
        $quote = null;
        if ($company && $planId && $amount) {
            $quote = SiteService::quote($company['id'], $planId, $amount);
        }
        View::render('site/index', [
            'title' => 'تسهیلات و خرید اقساطی',
            'brand' => $company['name'] ?? 'دیجی بایل پی',
            'plans' => $plans,
            'merchants' => $company ? SiteService::merchants($company['id']) : [],
            'products' => $company ? SiteService::products($company['id'], $plans) : [],
            'quote' => $quote, 'planId' => $planId, 'amount' => $amount,
            'contact' => $c = ($company ? SiteContent::get($company['id']) : SiteContent::get(0)),
            'copy' => $c, 'faq' => $company ? SiteContent::faq($company['id']) : SiteContent::DEFAULT_FAQ,
            'loggedIn' => \App\Core\Auth::check(),
            'logo' => $company ? \App\Services\MediaService::url($company['id'], 'logo') : null,
        ], 'site', 'site');
    }

    public function calc(): void
    {
        $company = SiteService::company();
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $q = $company ? SiteService::quote($company['id'], (int) $this->input('plan', '0'), (int) (preg_replace('/\D/', '', $this->input('amount')) ?: 0)) : ['error' => 'سرویس در دسترس نیست.'];
        echo json_encode($q, JSON_UNESCAPED_UNICODE);
        exit;
    }

    public function apply(): void
    {
        $company = SiteService::company();
        if (!$company) {
            $this->flash('error', 'ثبت درخواست فعلاً ممکن نیست.');
            $this->redirect('/');
        }
        if ($this->input('website') !== '') { // تله‌ی ربات: فیلد پنهان باید خالی بماند
            $this->flash('success', 'درخواست شما ثبت شد.');
            $this->redirect('/#apply');
        }
        if (!Captcha::verify('apply', $this->input('captcha'))) {
            $_SESSION['_old'] = array_intersect_key($_POST, array_flip(['full_name', 'mobile', 'national_code', 'requested_amount', 'plan_id', 'message']));
            $this->flash('error', 'کد امنیتی اشتباه یا منقضی است؛ کد جدید را وارد کنید.');
            $this->redirect('/#apply');
        }
        try {
            $id = SiteService::createLead($company['id'], [
                'full_name' => $this->input('full_name'), 'mobile' => $this->input('mobile'), 'national_code' => $this->input('national_code'),
                'requested_amount' => $this->input('requested_amount'), 'plan_id' => $this->input('plan_id'), 'message' => $this->input('message'),
            ], $_SERVER['REMOTE_ADDR'] ?? '');
            Audit::log('lead.create', 'lead', $id, [], $company['id']);
            $this->flash('success', 'درخواست شما ثبت شد؛ کارشناسان ما به‌زودی با شما تماس می‌گیرند.');
        } catch (UserError $e) {
            $_SESSION['_old'] = array_intersect_key($_POST, array_flip(['full_name', 'mobile', 'national_code', 'requested_amount', 'plan_id', 'message']));
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/#apply');
    }
}
