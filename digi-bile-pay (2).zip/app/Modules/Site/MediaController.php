<?php
declare(strict_types=1);

namespace App\Modules\Site;

use App\Core\Controller;
use App\Core\Database as DB;
use App\Services\MediaService;

/** سرو تصاویر ذخیره‌شده (لوگو و عکس کالا)؛ عمومی چون در صفحه‌ی اصلی نمایش داده می‌شوند. */
final class MediaController extends Controller
{
    public function show(): void
    {
        $m = DB::one('SELECT company_id, filename, mime, size FROM media WHERE id = ?', [(int) $this->input('id', '0')]);
        $file = $m ? MediaService::dir((int) $m['company_id']) . '/' . basename((string) $m['filename']) : '';
        if (!$m || !is_file($file)) {
            $this->notFound();
        }
        header('Content-Type: ' . $m['mime']);
        header('Content-Length: ' . (int) filesize($file));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: public, max-age=86400');
        readfile($file);
        exit;
    }
}
