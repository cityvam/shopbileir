<?php
declare(strict_types=1);

namespace App\Modules\Site;

use App\Core\Audit;
use App\Core\Controller;
use App\Core\UserError;
use App\Services\MediaService;
use App\Services\SiteContent;
use App\Services\SiteService;

/** ویرایش محتوای صفحه‌ی اصلی عمومی (CMS سبک) برای مجاز به site.manage */
final class SiteSettingsController extends Controller
{
    public function form(): void
    {
        $pub = SiteService::company();
        $this->view('site-settings/form', [
            'title' => 'محتوای صفحه‌ی اصلی', 'fields' => SiteContent::FIELDS, 'stored' => SiteContent::stored($this->cid()),
            'defaults' => SiteContent::DEFAULTS, 'faq' => SiteContent::storedFaq($this->cid()) ?: SiteContent::DEFAULT_FAQ,
            'isPublic' => $pub !== null && (int) $pub['id'] === $this->cid(), 'maxFaq' => SiteContent::MAX_FAQ, 'logo' => MediaService::url($this->cid(), 'logo'),
        ], 'site-settings');
    }

    public function save(): void
    {
        $errors = [];
        $values = [];
        foreach (SiteContent::FIELDS as $k => [$label, $max]) {
            $v = trim(str_replace("\r", '', (string) ($_POST[$k] ?? '')));
            if ($k !== 'hero_title') {
                $v = preg_replace('/\s+/u', ' ', $v) ?? $v;
            }
            if (mb_strlen($v) > $max) {
                $errors[] = "«$label» حداکثر $max نویسه است.";
            }
            $values[$k] = $v;
        }
        if ($values['email'] !== '' && !filter_var($values['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'ایمیل معتبر نیست.';
        }
        if ($values['phone'] !== '' && !preg_match('/^[0-9۰-۹+\-\s()]{5,40}$/u', $values['phone'])) {
            $errors[] = 'تلفن فقط می‌تواند عدد، فاصله و + - ( ) باشد.';
        }
        $faq = [];
        $qs = (array) ($_POST['faq_q'] ?? []);
        $as = (array) ($_POST['faq_a'] ?? []);
        foreach ($qs as $i => $q) {
            $q = trim((string) $q);
            $a = trim((string) ($as[$i] ?? ''));
            if ($q === '' && $a === '') {
                continue;
            }
            if ($q === '' || $a === '') {
                $errors[] = 'هر سوال باید هم پرسش و هم پاسخ داشته باشد.';
                break;
            }
            if (mb_strlen($q) > 200 || mb_strlen($a) > 800) {
                $errors[] = 'پرسش حداکثر ۲۰۰ و پاسخ حداکثر ۸۰۰ نویسه است.';
                break;
            }
            $faq[] = [$q, $a];
        }
        if (count($faq) > SiteContent::MAX_FAQ) {
            $errors[] = 'حداکثر ' . SiteContent::MAX_FAQ . ' سوال مجاز است.';
        }
        if ($errors) {
            $this->fail('/site-settings', $errors);
        }
        $logo = $_FILES['logo'] ?? null;
        $hasLogo = $logo && (int) ($logo['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
        $old = SiteContent::stored($this->cid());
        SiteContent::save($this->cid(), $values, $faq);
        $note = '';
        try {
            if ($hasLogo) {
                MediaService::store($this->cid(), 'logo', 0, $logo, $this->input('crop_square') === '1');
            } elseif ($this->input('remove_logo') === '1') {
                MediaService::remove($this->cid(), 'logo', 0);
            }
        } catch (UserError $e) {
            $note = ' ولی لوگو ذخیره نشد: ' . $e->getMessage();
        }
        Audit::log('site.update', 'company', $this->cid(), ['fields' => array_keys(Audit::diff($old, $values, array_keys($values))), 'faq_count' => count($faq)]);
        $this->flash($note === '' ? 'success' : 'error', 'محتوای صفحه‌ی اصلی ذخیره شد.' . $note);
        $this->redirect('/site-settings');
    }
}
