<?php
declare(strict_types=1);

namespace App\Modules\Site;

use App\Core\Audit;
use App\Core\Captcha;
use App\Core\Controller;
use App\Core\UserError;
use App\Core\Validator;
use App\Services\PaymentLinkService;
use App\Services\PortalService;

/** پرتال مشتری (جدا از ورود کارکنان): نشست جدا با کلید portal_cid و ورود با پیامک. */
final class PortalController extends Controller
{
    private function me(): ?array
    {
        $cid = (int) ($_SESSION['portal_cid'] ?? 0);
        $co = (int) ($_SESSION['portal_co'] ?? 0);
        if ($cid <= 0 || ($_SESSION['portal_at'] ?? 0) < time() - 3600 * 4) {
            unset($_SESSION['portal_cid'], $_SESSION['portal_co'], $_SESSION['portal_at']);
            return null;
        }
        return ['id' => $cid, 'company_id' => $co];
    }

    private function guard(): array
    {
        header('Cache-Control: no-store');
        return $this->me() ?? $this->redirect('/portal/login');
    }

    public function loginForm(): void
    {
        header('Cache-Control: no-store');
        if ($this->me()) {
            $this->redirect('/portal');
        }
        $this->view('portal/login', ['title' => 'ورود مشتریان', 'step' => 'mobile', 'mobile' => '', 'enabled' => PortalService::enabled()], 'portal-login', 'auth');
    }

    public function sendCode(): void
    {
        $mobile = $this->input('mobile');
        if (!Captcha::verify('portal', $this->input('captcha'))) {
            $this->fail('/portal/login', ['کد امنیتی اشتباه یا منقضی است؛ کد جدید را وارد کنید.']);
        }
        try {
            PortalService::requestCode($mobile, $_SERVER['REMOTE_ADDR'] ?? '');
        } catch (UserError $e) {
            $this->fail('/portal/login', [$e->getMessage()]);
        }
        $_SESSION['portal_mobile'] = preg_replace('/\D/', '', strtr($mobile, ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9']));
        $this->flash('success', 'اگر این شماره در سامانه ثبت باشد، کد ورود پیامک شد.');
        $this->redirect('/portal/code');
    }

    public function codeForm(): void
    {
        header('Cache-Control: no-store');
        $mobile = (string) ($_SESSION['portal_mobile'] ?? '');
        if ($mobile === '') {
            $this->redirect('/portal/login');
        }
        $this->view('portal/login', ['title' => 'کد ورود', 'step' => 'code', 'mobile' => $mobile, 'enabled' => true], 'portal-login', 'auth');
    }

    public function verify(): void
    {
        $mobile = (string) ($_SESSION['portal_mobile'] ?? '');
        $c = $mobile !== '' ? PortalService::verify($mobile, $this->input('code')) : null;
        if (!$c) {
            $this->fail('/portal/code', ['کد اشتباه یا منقضی است.']);
        }
        session_regenerate_id(true);
        unset($_SESSION['portal_mobile']);
        $_SESSION['portal_cid'] = $c['id'];
        $_SESSION['portal_co'] = $c['company_id'];
        $_SESSION['portal_at'] = time();
        $this->redirect('/portal');
    }

    public function home(): void
    {
        $me = $this->guard();
        $d = PortalService::overview($me['company_id'], $me['id']);
        $this->view('portal/home', ['title' => 'حساب من', 'logo' => \App\Services\MediaService::url($me['company_id'], 'logo')] + $d, 'portal', 'portal');
    }

    /** ساخت لینک پرداخت برای قسط یا شارژ توسط خود مشتری و هدایت به صفحه‌ی پرداخت */
    public function pay(): void
    {
        $me = $this->guard();
        $kind = $this->input('kind') === 'topup' ? 'topup' : 'installment';
        $amount = Validator::amount($this->input('amount')) ?? 0;
        try {
            $sys = PortalService::systemUserId($me['company_id']);
            $instId = $kind === 'installment' ? (int) $this->input('installment_id') : null;
            if ($kind === 'topup' && ($amount < 100000 || $amount > 500000000)) {
                throw new UserError('مبلغ شارژ باید بین ۱۰۰٬۰۰۰ و ۵۰۰٬۰۰۰٬۰۰۰ ریال باشد.');
            }
            $r = PaymentLinkService::create($me['company_id'], $kind, $me['id'], $instId, $amount, $sys, 'ایجادشده توسط مشتری از پرتال');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
            $this->redirect('/portal');
        }
        $this->redirect('/pay?t=' . $r['token']);
    }

    public function logout(): void
    {
        unset($_SESSION['portal_cid'], $_SESSION['portal_co'], $_SESSION['portal_at'], $_SESSION['portal_mobile']);
        session_regenerate_id(true);
        $this->redirect('/portal/login');
    }
}
