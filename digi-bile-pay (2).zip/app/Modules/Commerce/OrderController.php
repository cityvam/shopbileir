<?php
declare(strict_types=1);

namespace App\Modules\Commerce;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\ListFilter;
use App\Core\Jalali;
use App\Core\Csv;
use App\Core\Paginator;
use App\Core\UserError;
use App\Services\Accounting;
use App\Services\CreditService;
use App\Services\LoanService;

final class OrderController extends Controller
{
    private const SORTS = ['id' => 'o.id', 'total' => 'o.total', 'customer' => 'cu.full_name', 'merchant' => 'm.name'];

    public function index(): void
    {
        $lf = (new ListFilter($_GET, 'o.company_id = ?', [$this->cid()]))
            ->text('q', ['cu.full_name', 'cu.national_code', 'm.name'])
            ->enum('status', 'o.status', ['pending', 'confirmed', 'cancelled'])
            ->enum('payment_type', 'o.payment_type', ['cash', 'installment'])
            ->enum('merchant_id', 'o.merchant_id', array_map('strval', array_column(DB::all('SELECT id FROM merchants WHERE company_id = ?', [$this->cid()]), 'id')))
            ->amount('min', 'max', 'o.total')
            ->dateRange('from', 'to', 'o.created_at')
            ->sort(self::SORTS, 'id', 'o.id');
        $from = 'FROM orders o JOIN merchants m ON m.id = o.merchant_id JOIN customers cu ON cu.id = o.customer_id';
        $sel = "SELECT o.id, o.total, o.payment_type, o.status, o.created_at, m.name AS merchant_name, cu.full_name $from WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'orders']);
            Csv::send('orders.csv', ['شماره', 'مشتری', 'فروشنده', 'مبلغ', 'روش', 'وضعیت', 'تاریخ'],
                array_map(static fn ($r) => [$r['id'], $r['full_name'], $r['merchant_name'], $r['total'], $r['payment_type'] === 'cash' ? 'نقدی' : 'اقساطی', $r['status'], Jalali::format(substr($r['created_at'], 0, 10))], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) $from WHERE {$lf->where}", $lf->params);
        $sum = (int) DB::scalar("SELECT COALESCE(SUM(o.total), 0) $from WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $merchants = DB::all('SELECT id, name FROM merchants WHERE company_id = ? ORDER BY name', [$this->cid()]);
        $this->view('orders/index', ['title' => 'سفارش‌ها', 'rows' => $rows, 'pg' => $pg, 'lf' => $lf, 'sum' => $sum, 'merchants' => $merchants], 'orders');
    }

    /** مرحله ۱: انتخاب فروشنده. مرحله ۲: انتخاب کالا، مشتری و روش پرداخت */
    public function create(): void
    {
        $merchantId = (int) $this->input('merchant_id', '0');
        $merchants = DB::all("SELECT id, name, commission_percent FROM merchants WHERE company_id = ? AND status = 'active' ORDER BY name", [$this->cid()]);
        $merchant = null;
        $products = $customers = $plans = [];
        foreach ($merchants as $m) {
            if ((int) $m['id'] === $merchantId) {
                $merchant = $m;
            }
        }
        if ($merchant) {
            $products = DB::all("SELECT id, name, price, stock FROM products WHERE company_id = ? AND merchant_id = ? AND status = 'active' AND stock > 0 ORDER BY name", [$this->cid(), $merchantId]);
            $customers = DB::all("SELECT id, full_name, national_code FROM customers WHERE company_id = ? AND status = 'active' ORDER BY full_name LIMIT 500", [$this->cid()]);
            $plans = DB::all('SELECT id, name, months, annual_rate_percent, min_amount, max_amount FROM loan_plans WHERE company_id = ? AND is_active = 1 ORDER BY name', [$this->cid()]);
        }
        $this->view('orders/form', [
            'title' => 'سفارش جدید', 'merchants' => $merchants, 'merchant' => $merchant,
            'products' => $products, 'customers' => $customers, 'plans' => $plans,
        ], 'orders');
    }

    public function store(): void
    {
        $merchantId = (int) $this->input('merchant_id', '0');
        $customerId = (int) $this->input('customer_id', '0');
        $type = $this->input('payment_type') === 'installment' ? 'installment' : 'cash';
        $planId = (int) $this->input('plan_id', '0');
        $back = '/orders/create?merchant_id=' . $merchantId;

        $merchant = DB::one("SELECT * FROM merchants WHERE id = ? AND company_id = ? AND status = 'active'", [$merchantId, $this->cid()]);
        $customer = DB::one("SELECT * FROM customers WHERE id = ? AND company_id = ? AND status = 'active'", [$customerId, $this->cid()]);
        if (!$merchant) {
            $this->fail('/orders/create', ['فروشنده فعال انتخاب نشده است.']);
        }

        $errors = [];
        if (!$customer) {
            $errors[] = 'مشتری فعال انتخاب نشده است.';
        }
        $qty = [];
        foreach ((array) ($_POST['qty'] ?? []) as $pid => $q) {
            if (is_string($q) && ctype_digit($q) && (int) $q > 0 && (int) $q <= 1000) {
                $qty[(int) $pid] = (int) $q;
            }
        }
        if (!$qty) {
            $errors[] = 'حداقل یک کالا با تعداد معتبر انتخاب کنید.';
        }
        $products = [];
        if ($qty) {
            $in = implode(',', array_fill(0, count($qty), '?'));
            foreach (DB::all("SELECT id, name, price, stock FROM products WHERE company_id = ? AND merchant_id = ? AND status = 'active' AND id IN ($in)", [$this->cid(), $merchantId, ...array_keys($qty)]) as $p) {
                $products[(int) $p['id']] = $p;
            }
            foreach ($qty as $pid => $q) {
                if (!isset($products[$pid])) {
                    $errors[] = 'یکی از کالاهای انتخاب‌شده معتبر نیست.';
                    break;
                }
                if ($q > (int) $products[$pid]['stock']) {
                    $errors[] = 'موجودی «' . $products[$pid]['name'] . '» کافی نیست.';
                }
            }
        }
        $total = 0;
        foreach ($qty as $pid => $q) {
            $total += (int) ($products[$pid]['price'] ?? 0) * $q;
        }

        $plan = null;
        if ($type === 'installment') {
            $plan = DB::one('SELECT * FROM loan_plans WHERE id = ? AND company_id = ? AND is_active = 1', [$planId, $this->cid()]);
            if (!$plan) {
                $errors[] = 'برای خرید اقساطی یک طرح فعال انتخاب کنید.';
            } elseif ($total < (int) $plan['min_amount'] || $total > (int) $plan['max_amount']) {
                $errors[] = 'مبلغ سفارش خارج از بازه مجاز طرح است.';
            }
            if ($customer && $total > CreditService::available($this->cid(), $customerId, (int) $customer['credit_limit'])) {
                $errors[] = 'مبلغ سفارش از اعتبار آزاد مشتری بیشتر است.';
            }
        } elseif ($customer && $total > (int) $customer['wallet_balance']) {
            $errors[] = 'موجودی کیف پول مشتری برای پرداخت نقدی کافی نیست.';
        }
        if ($errors) {
            $this->fail($back, $errors);
        }

        $commission = (int) round($total * (float) $merchant['commission_percent'] / 100);
        try {
            $orderId = DB::tx(function () use ($merchant, $customer, $type, $plan, $qty, $products, $total, $commission) {
                foreach ($qty as $pid => $q) {
                    $n = DB::exec(
                        "UPDATE products SET stock = stock - ? WHERE id = ? AND company_id = ? AND status = 'active' AND stock >= ?",
                        [$q, $pid, $this->cid(), $q]
                    );
                    if ($n !== 1) {
                        throw new UserError('موجودی «' . $products[$pid]['name'] . '» هم‌زمان تمام شد.');
                    }
                }
                $now = date('Y-m-d H:i:s');
                $loanId = null;
                if ($type === 'installment') {
                    $loanId = LoanService::createPending($this->cid(), (int) $customer['id'], $plan, $total, Auth::id());
                }
                $orderId = DB::insert(
                    'INSERT INTO orders (company_id, merchant_id, customer_id, payment_type, total, commission_amount, loan_id, status, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [$this->cid(), $merchant['id'], $customer['id'], $type, $total, $commission, $loanId, $type === 'cash' ? 'confirmed' : 'pending', Auth::id(), $now]
                );
                foreach ($qty as $pid => $q) {
                    DB::exec(
                        'INSERT INTO order_items (order_id, product_id, name, unit_price, qty) VALUES (?, ?, ?, ?, ?)',
                        [$orderId, $pid, $products[$pid]['name'], $products[$pid]['price'], $q]
                    );
                    \App\Services\StockService::log($this->cid(), (int) $pid, -$q, null, 'order', null, $orderId);
                }
                if ($type === 'cash') {
                    $n = DB::exec(
                        'UPDATE customers SET wallet_balance = wallet_balance - ? WHERE id = ? AND company_id = ? AND wallet_balance >= ?',
                        [$total, $customer['id'], $this->cid(), $total]
                    );
                    if ($n !== 1) {
                        throw new UserError('موجودی کیف پول مشتری کافی نیست.');
                    }
                    $balance = (int) DB::scalar('SELECT wallet_balance FROM customers WHERE id = ?', [$customer['id']]);
                    DB::exec(
                        "INSERT INTO wallet_transactions (company_id, customer_id, type, amount, balance_after, ref_id, created_by, created_at)
                         VALUES (?, ?, 'order', ?, ?, ?, ?, ?)",
                        [$this->cid(), $customer['id'], -$total, $balance, $orderId, Auth::id(), $now]
                    );
                    Accounting::post($this->cid(), 'فروش نقدی سفارش #' . $orderId, [
                        [Accounting::WALLET, $total, 0],
                        [Accounting::MERCHANT, 0, $total - $commission],
                        [Accounting::COMMISSION, 0, $commission],
                    ], 'order', $orderId, Auth::id());
                }
                Audit::log('order.create', 'order', $orderId, ['total' => $total, 'type' => $type, 'loan_id' => $loanId]);
                return $orderId;
            });
        } catch (UserError $e) {
            $this->fail($back, [$e->getMessage()]);
        }
        $this->flash('success', $type === 'cash' ? 'سفارش ثبت و از کیف پول پرداخت شد.' : 'سفارش ثبت شد و درخواست تسهیلات آن در انتظار تأیید است.');
        $this->redirect('/orders/' . $orderId);
    }

    public function show(array $p): void
    {
        $o = DB::one(
            'SELECT o.*, m.name AS merchant_name, cu.full_name, cu.id AS customer_id, u.full_name AS creator_name
             FROM orders o JOIN merchants m ON m.id = o.merchant_id JOIN customers cu ON cu.id = o.customer_id JOIN users u ON u.id = o.created_by
             WHERE o.id = ? AND o.company_id = ?',
            [$p['id'], $this->cid()]
        ) ?? $this->notFound();
        $items = DB::all('SELECT name, unit_price, qty FROM order_items WHERE order_id = ?', [$o['id']]);
        $this->view('orders/show', ['title' => 'سفارش شماره ' . fa($o['id']), 'o' => $o, 'items' => $items,
            'events' => Audit::events($this->cid(), 'order', (int) $o['id']), 'internalNotes' => \App\Services\NoteService::list($this->cid(), 'order', (int) $o['id']),
        ], 'orders');
    }
}
