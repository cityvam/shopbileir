<?php
declare(strict_types=1);

namespace App\Modules\Commerce;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\ListFilter;
use App\Core\Paginator;
use App\Core\UserError;
use App\Core\Validator;
use App\Services\Accounting;
use App\Services\NoteService;
use App\Services\StatusService;

final class MerchantController extends Controller
{
    private const SORTS = ['name' => 'm.name', 'orders' => 'orders_count', 'unsettled' => 'unsettled', 'created' => 'm.id'];

    public function index(): void
    {
        $unsettledSql = "(SELECT COALESCE(SUM(o.total - o.commission_amount), 0) FROM orders o WHERE o.merchant_id = m.id AND o.status = 'confirmed' AND o.settlement_id IS NULL)";
        $lf = (new ListFilter($_GET, 'm.company_id = ?', [$this->cid()]))
            ->text('q', ['m.name', 'm.contact_name', 'm.mobile'])
            ->enum('status', 'm.status', ['active', 'disabled'])
            ->amount('un_min', 'un_max', $unsettledSql)
            ->sort(self::SORTS, 'created', 'm.id');
        $sel = "SELECT m.*, (SELECT COUNT(*) FROM orders o WHERE o.merchant_id = m.id AND o.status <> 'cancelled') AS orders_count, $unsettledSql AS unsettled
                FROM merchants m WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'merchants']);
            Csv::send('merchants.csv', ['نام', 'رابط', 'موبایل', 'کارمزد٪', 'سفارش‌ها', 'تسویه‌نشده', 'وضعیت'],
                array_map(static fn ($r) => [$r['name'], $r['contact_name'], $r['mobile'], $r['commission_percent'], $r['orders_count'], $r['unsettled'], $r['status'] === 'active' ? 'فعال' : 'غیرفعال'], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) FROM merchants m WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $this->view('merchants/index', ['title' => 'فروشندگان', 'rows' => $rows, 'pg' => $pg, 'lf' => $lf], 'merchants');
    }

    public function create(): void
    {
        $this->view('merchants/form', ['title' => 'فروشنده جدید', 'merchant' => null], 'merchants');
    }

    public function store(): void
    {
        [$errors, $d] = $this->validated();
        if ($errors) {
            $this->fail('/merchants/create', $errors);
        }
        $id = DB::insert(
            'INSERT INTO merchants (company_id, name, contact_name, mobile, commission_percent) VALUES (?, ?, ?, ?, ?)',
            [$this->cid(), $d['name'], $d['contact'], $d['mobile'], (string) $d['commission']]
        );
        Audit::log('merchant.create', 'merchant', $id, $d);
        $this->flash('success', 'فروشنده ثبت شد.');
        $this->redirect('/merchants/' . $id);
    }

    public function show(array $p): void
    {
        $m = $this->find($p['id']);
        $unsettled = DB::one(
            "SELECT COUNT(*) AS c, COALESCE(SUM(total), 0) AS gross, COALESCE(SUM(commission_amount), 0) AS comm FROM orders
             WHERE company_id = ? AND merchant_id = ? AND status = 'confirmed' AND settlement_id IS NULL",
            [$this->cid(), $m['id']]
        );
        $orders = DB::all(
            'SELECT o.id, o.total, o.payment_type, o.status, o.created_at, o.settlement_id, cu.full_name
             FROM orders o JOIN customers cu ON cu.id = o.customer_id
             WHERE o.company_id = ? AND o.merchant_id = ? ORDER BY o.id DESC LIMIT 15',
            [$this->cid(), $m['id']]
        );
        $settlements = DB::all(
            'SELECT s.id, s.gross_amount, s.commission_amount, s.net_amount, s.orders_count, s.created_at, u.full_name
             FROM settlements s JOIN users u ON u.id = s.created_by
             WHERE s.company_id = ? AND s.merchant_id = ? ORDER BY s.id DESC LIMIT 10',
            [$this->cid(), $m['id']]
        );
        $products = DB::all('SELECT id, name, price, stock, status FROM products WHERE company_id = ? AND merchant_id = ? ORDER BY id DESC LIMIT 20', [$this->cid(), $m['id']]);
        $this->view('merchants/show', [
            'title' => $m['name'], 'm' => $m, 'unsettled' => $unsettled, 'orders' => $orders, 'settlements' => $settlements, 'products' => $products,
            'history' => StatusService::history($this->cid(), 'merchant', (int) $m['id']),
            'events' => Audit::events($this->cid(), 'merchant', (int) $m['id']), 'internalNotes' => NoteService::list($this->cid(), 'merchant', (int) $m['id']),
        ], 'merchants');
    }

    public function status(array $p): void
    {
        $m = $this->find($p['id']);
        try {
            StatusService::change($this->cid(), 'merchant', (int) $m['id'], $this->input('to_status'), $this->input('reason'), ['active', 'disabled']);
            $this->flash('success', 'وضعیت فروشنده تغییر کرد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/merchants/' . $m['id']);
    }

    public function bulkStatus(): void
    {
        try {
            $r = StatusService::bulk($this->cid(), 'merchant', (array) ($_POST['ids'] ?? []), $this->input('to_status'), $this->input('reason'), ['active', 'disabled']);
            $this->flash($r['skipped'] ? 'error' : 'success', $r['ok'] . ' مورد تغییر کرد.' . ($r['skipped'] ? ' ردشده: ' . implode(' | ', array_slice($r['skipped'], 0, 5)) : ''));
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/merchants');
    }

    public function edit(array $p): void
    {
        $this->view('merchants/form', ['title' => 'ویرایش فروشنده', 'merchant' => $this->find($p['id'])], 'merchants');
    }

    public function update(array $p): void
    {
        $m = $this->find($p['id']);
        [$errors, $d] = $this->validated();
        if ($errors) {
            $this->fail('/merchants/' . $m['id'] . '/edit', $errors);
        }
        DB::exec(
            'UPDATE merchants SET name = ?, contact_name = ?, mobile = ?, commission_percent = ? WHERE id = ? AND company_id = ?',
            [$d['name'], $d['contact'], $d['mobile'], (string) $d['commission'], $m['id'], $this->cid()]
        );
        Audit::log('merchant.update', 'merchant', (int) $m['id'], ['changes' => Audit::diff($m, ['name' => $d['name'], 'contact_name' => $d['contact'], 'mobile' => $d['mobile'], 'commission_percent' => $d['commission']], ['name', 'contact_name', 'mobile', 'commission_percent'])]);
        $this->flash('success', 'اطلاعات فروشنده ذخیره شد. کارمزد جدید فقط روی سفارش‌های بعدی اثر دارد.');
        $this->redirect('/merchants/' . $m['id']);
    }

    /** تسویه همه سفارش‌های تأییدشده و تسویه‌نشده فروشنده */
    public function settle(array $p): void
    {
        $m = $this->find($p['id']);
        try {
            $result = DB::tx(function () use ($m) {
                $orders = DB::all(
                    "SELECT id, total, commission_amount FROM orders
                     WHERE company_id = ? AND merchant_id = ? AND status = 'confirmed' AND settlement_id IS NULL",
                    [$this->cid(), $m['id']]
                );
                if (!$orders) {
                    throw new UserError('سفارش تسویه‌نشده‌ای برای این فروشنده وجود ندارد.');
                }
                $gross = (int) array_sum(array_column($orders, 'total'));
                $comm = (int) array_sum(array_column($orders, 'commission_amount'));
                $net = $gross - $comm;
                if ($net <= 0) {
                    throw new UserError('مبلغ خالص تسویه صفر است.');
                }
                $sid = DB::insert(
                    'INSERT INTO settlements (company_id, merchant_id, gross_amount, commission_amount, net_amount, orders_count, created_by, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [$this->cid(), $m['id'], $gross, $comm, $net, count($orders), Auth::id(), date('Y-m-d H:i:s')]
                );
                $ids = array_map('intval', array_column($orders, 'id'));
                $in = implode(',', array_fill(0, count($ids), '?'));
                $n = DB::exec("UPDATE orders SET settlement_id = ? WHERE id IN ($in) AND settlement_id IS NULL AND status = 'confirmed'", [$sid, ...$ids]);
                if ($n !== count($ids)) {
                    throw new UserError('تسویه هم‌زمان شناسایی شد؛ دوباره تلاش کنید.');
                }
                Accounting::post($this->cid(), 'تسویه فروشنده ' . $m['name'], [
                    [Accounting::MERCHANT, $net, 0],
                    [Accounting::CASH, 0, $net],
                ], 'settlement', $sid, Auth::id());
                Audit::log('merchant.settle', 'merchant', (int) $m['id'], ['settlement' => $sid, 'net' => $net, 'orders' => count($ids)]);
                return $net;
            });
            $this->flash('success', 'تسویه ثبت شد: ' . number_format((int) $result) . ' ریال.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/merchants/' . $m['id']);
    }

    private function find(int $id): array
    {
        return DB::one('SELECT * FROM merchants WHERE id = ? AND company_id = ?', [$id, $this->cid()]) ?? $this->notFound();
    }

    /** @return array{0: list<string>, 1: array} */
    private function validated(): array
    {
        $name = $this->input('name');
        $contact = $this->input('contact_name');
        $mobile = $this->input('mobile');
        $commission = Validator::percent($this->input('commission_percent', '0'));
        $errors = [];
        if (mb_strlen($name) < 2) {
            $errors[] = 'نام فروشنده را وارد کنید.';
        }
        if ($mobile !== '' && !Validator::mobile($mobile)) {
            $errors[] = 'شماره موبایل معتبر نیست.';
        }
        if ($commission === null || $commission >= 100) {
            $errors[] = 'کارمزد باید کمتر از ۱۰۰ درصد باشد.';
        }
        return [$errors, [
            'name' => $name, 'contact' => $contact !== '' ? $contact : null, 'mobile' => $mobile !== '' ? $mobile : null,
            'commission' => $commission ?? 0.0,
        ]];
    }
}
