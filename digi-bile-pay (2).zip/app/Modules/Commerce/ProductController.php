<?php
declare(strict_types=1);

namespace App\Modules\Commerce;

use App\Core\Audit;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\ListFilter;
use App\Core\UserError;
use App\Services\MediaService;
use App\Core\Paginator;
use App\Core\Validator;
use App\Services\NoteService;
use App\Services\StatusService;
use App\Services\StockService;

final class ProductController extends Controller
{
    private const SORTS = ['name' => 'p.name', 'price' => 'p.price', 'stock' => 'p.stock', 'created' => 'p.id'];

    public function index(): void
    {
        $merchants = DB::all('SELECT id, name FROM merchants WHERE company_id = ? ORDER BY name', [$this->cid()]);
        $lf = (new ListFilter($_GET, 'p.company_id = ?', [$this->cid()]))
            ->text('q', ['p.name', 'p.sku', 'm.name'])
            ->enum('merchant_id', 'p.merchant_id', array_map('strval', array_column($merchants, 'id')))
            ->enum('status', 'p.status', ['active', 'disabled'])
            ->amount('min', 'max', 'p.price')
            ->sort(self::SORTS, 'created', 'p.id');
        if (($_GET['stock'] ?? '') === 'out') {
            $lf->v['stock'] = 'out';
            $lf->raw('p.stock = 0');
        } elseif (($_GET['stock'] ?? '') === 'low') {
            $lf->v['stock'] = 'low';
            $lf->raw('p.stock > 0 AND p.stock <= 5');
        }
        $from = 'FROM products p JOIN merchants m ON m.id = p.merchant_id';
        $sel = "SELECT p.id, p.name, p.sku, p.price, p.stock, p.status, m.name AS merchant_name $from WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'products']);
            Csv::send('products.csv', ['نام', 'کد کالا', 'فروشنده', 'قیمت', 'موجودی', 'وضعیت'],
                array_map(static fn ($r) => [$r['name'], $r['sku'], $r['merchant_name'], $r['price'], $r['stock'], $r['status'] === 'active' ? 'فعال' : 'غیرفعال'], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) $from WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $this->view('products/index', ['title' => 'محصولات', 'rows' => $rows, 'pg' => $pg, 'merchants' => $merchants, 'lf' => $lf], 'products');
    }

    public function create(): void
    {
        $this->view('products/form', ['title' => 'محصول جدید', 'product' => null, 'merchants' => $this->activeMerchants(), 'selMerchant' => (int) $this->input('merchant_id', '0')], 'products');
    }

    public function store(): void
    {
        [$errors, $d] = $this->validated(true);
        if ($errors) {
            $this->fail('/products/create', $errors);
        }
        $id = DB::insert(
            'INSERT INTO products (company_id, merchant_id, name, sku, price, stock) VALUES (?, ?, ?, ?, ?, ?)',
            [$this->cid(), $d['merchant_id'], $d['name'], $d['sku'], $d['price'], $d['stock']]
        );
        if ($d['stock'] > 0) {
            StockService::log($this->cid(), $id, $d['stock'], $d['stock'], 'add', 'موجودی اولیه', null);
        }
        Audit::log('product.create', 'product', $id, $d);
        $this->flash('success', 'محصول ثبت شد.' . $this->saveImage($id));
        $this->redirect('/products');
    }

    public function edit(array $p): void
    {
        $pr = $this->find($p['id']);
        $cid = $this->cid();
        $this->view('products/form', [
            'title' => 'ویرایش محصول', 'product' => $pr, 'merchants' => $this->activeMerchants(), 'selMerchant' => 0,
            'movements' => StockService::movements($cid, (int) $pr['id']), 'history' => StatusService::history($cid, 'product', (int) $pr['id']),
            'image' => MediaService::url($cid, 'product', (int) $pr['id']), 'events' => Audit::events($cid, 'product', (int) $pr['id']), 'internalNotes' => NoteService::list($cid, 'product', (int) $pr['id']),
        ], 'products');
    }

    public function update(array $p): void
    {
        $pr = $this->find($p['id']);
        [$errors, $d] = $this->validated(false);
        if ($errors) {
            $this->fail('/products/' . $pr['id'] . '/edit', $errors);
        }
        DB::exec('UPDATE products SET name = ?, sku = ?, price = ? WHERE id = ? AND company_id = ?', [$d['name'], $d['sku'], $d['price'], $pr['id'], $this->cid()]);
        Audit::log('product.update', 'product', (int) $pr['id'], ['changes' => Audit::diff($pr, $d, ['name', 'sku', 'price'])]);
        $this->flash('success', 'محصول ذخیره شد.' . $this->saveImage((int) $pr['id']));
        $this->redirect('/products/' . $pr['id'] . '/edit');
    }

    public function status(array $p): void
    {
        $pr = $this->find($p['id']);
        try {
            StatusService::change($this->cid(), 'product', (int) $pr['id'], $this->input('to_status'), $this->input('reason'), ['active', 'disabled']);
            $this->flash('success', 'وضعیت محصول تغییر کرد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/products/' . $pr['id'] . '/edit');
    }

    public function stock(array $p): void
    {
        $pr = $this->find($p['id']);
        $qty = ctype_digit($this->input('qty')) ? (int) $this->input('qty') : -1;
        try {
            $new = StockService::adjust($this->cid(), (int) $pr['id'], $this->input('mode'), $qty, $this->input('reason'));
            $this->flash('success', 'موجودی تعدیل شد؛ موجودی جدید: ' . number_format($new));
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/products/' . $pr['id'] . '/edit');
    }

    public function bulkStatus(): void
    {
        try {
            $r = StatusService::bulk($this->cid(), 'product', (array) ($_POST['ids'] ?? []), $this->input('to_status'), $this->input('reason'), ['active', 'disabled']);
            $this->flash($r['skipped'] ? 'error' : 'success', $r['ok'] . ' مورد تغییر کرد.' . ($r['skipped'] ? ' ردشده: ' . implode(' | ', array_slice($r['skipped'], 0, 5)) : ''));
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/products');
    }

    /** تصویر کالا اختیاری است؛ خطای تصویر مانع ذخیره‌ی خود محصول نمی‌شود و پیام جداگانه برمی‌گردد. */
    private function saveImage(int $productId): string
    {
        $f = $_FILES['image'] ?? null;
        try {
            if ($f && (int) ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                MediaService::store($this->cid(), 'product', $productId, $f, $this->input('crop_square') === '1');
            } elseif ($this->input('remove_image') === '1') {
                MediaService::remove($this->cid(), 'product', $productId);
            }
        } catch (UserError $e) {
            return ' ولی تصویر ذخیره نشد: ' . $e->getMessage();
        }
        return '';
    }

    private function find(int $id): array
    {
        return DB::one('SELECT * FROM products WHERE id = ? AND company_id = ?', [$id, $this->cid()]) ?? $this->notFound();
    }

    private function activeMerchants(): array
    {
        return DB::all("SELECT id, name FROM merchants WHERE company_id = ? AND status = 'active' ORDER BY name", [$this->cid()]);
    }

    /** @return array{0: list<string>, 1: array} */
    private function validated(bool $creating): array
    {
        $name = $this->input('name');
        $sku = $this->input('sku');
        $price = Validator::amount($this->input('price'));
        $stockRaw = $this->input('stock', '0');
        $stock = ctype_digit($stockRaw) ? (int) $stockRaw : -1;
        $merchantId = (int) $this->input('merchant_id', '0');

        $errors = [];
        if (mb_strlen($name) < 2) {
            $errors[] = 'نام محصول را وارد کنید.';
        }
        if ($price === null) {
            $errors[] = 'قیمت معتبر نیست.';
        }
        if ($creating && ($stock < 0 || $stock > 1000000)) {
            $errors[] = 'موجودی باید عدد صحیح و غیرمنفی باشد.';
        }
        if ($creating && !DB::scalar("SELECT id FROM merchants WHERE id = ? AND company_id = ? AND status = 'active'", [$merchantId, $this->cid()])) {
            $errors[] = 'فروشنده فعال انتخاب نشده است.';
        }
        return [$errors, [
            'merchant_id' => $merchantId, 'name' => $name, 'sku' => $sku !== '' ? $sku : null,
            'price' => (int) $price, 'stock' => max(0, $stock),
        ]];
    }
}
