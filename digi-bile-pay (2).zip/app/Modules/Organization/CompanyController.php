<?php
declare(strict_types=1);

namespace App\Modules\Organization;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\Validator;
use App\Services\TenantProvisioner;

final class CompanyController extends Controller
{
    public function index(): void
    {
        $all = Auth::can('companies.manage');
        $rows = $all
            ? DB::all('SELECT c.*, p.name AS parent_name FROM companies c LEFT JOIN companies p ON p.id = c.parent_id ORDER BY c.id')
            : DB::all('SELECT c.*, p.name AS parent_name FROM companies c LEFT JOIN companies p ON p.id = c.parent_id WHERE c.id = ?', [$this->cid()]);
        $this->view('companies/index', ['title' => 'شرکت‌ها', 'rows' => $rows], 'companies');
    }

    public function create(): void
    {
        $parents = DB::all('SELECT id, name FROM companies ORDER BY id');
        $this->view('companies/form', ['title' => 'ثبت شرکت جدید', 'parents' => $parents], 'companies');
    }

    public function store(): void
    {
        $code = strtoupper($this->input('code'));
        $name = $this->input('name');
        $brand = $this->input('brand_name');
        $parentId = (int) $this->input('parent_id', '0');
        $adminUser = mb_strtolower($this->input('admin_username'));
        $adminName = $this->input('admin_name');
        $adminPass = (string) ($_POST['admin_password'] ?? '');

        $errors = [];
        if (!preg_match('/^[A-Z0-9_]{2,40}$/', $code)) {
            $errors[] = 'کد شرکت باید ۲ تا ۴۰ نویسه لاتین بزرگ، عدد یا خط‌زیر باشد.';
        }
        if (mb_strlen($name) < 2) {
            $errors[] = 'نام شرکت را وارد کنید.';
        }
        if ($parentId && !DB::scalar('SELECT id FROM companies WHERE id = ?', [$parentId])) {
            $errors[] = 'شرکت مادر نامعتبر است.';
        }
        if (!preg_match('/^[a-z0-9_.]{3,40}$/', $adminUser)) {
            $errors[] = 'نام کاربری مدیر باید ۳ تا ۴۰ نویسه لاتین کوچک، عدد، نقطه یا خط‌زیر باشد.';
        }
        if (mb_strlen($adminName) < 2) {
            $errors[] = 'نام مدیر شرکت را وارد کنید.';
        }
        if ($e = Validator::password($adminPass)) {
            $errors[] = $e;
        }
        if (DB::scalar('SELECT id FROM companies WHERE code = ?', [$code])) {
            $errors[] = 'این کد شرکت قبلاً ثبت شده است.';
        }
        if (DB::scalar('SELECT id FROM users WHERE username = ?', [$adminUser])) {
            $errors[] = 'این نام کاربری قبلاً استفاده شده است.';
        }
        if ($errors) {
            $this->fail('/companies/create', $errors);
        }

        $id = DB::tx(function () use ($code, $name, $brand, $parentId, $adminUser, $adminName, $adminPass) {
            $id = DB::insert(
                'INSERT INTO companies (parent_id, code, name, brand_name) VALUES (?, ?, ?, ?)',
                [$parentId ?: null, $code, $name, $brand !== '' ? $brand : null]
            );
            $roles = TenantProvisioner::createDefaultRoles($id);
            TenantProvisioner::createDefaultAccounts($id);
            TenantProvisioner::createUser($id, $roles['company_admin'], $adminUser, $adminName, $adminPass);
            Audit::log('company.create', 'company', $id, ['code' => $code, 'admin' => $adminUser]);
            return $id;
        });
        $this->flash('success', 'شرکت با نقش‌های پیش‌فرض و کاربر مدیر ثبت شد.');
        $this->redirect('/companies');
    }

    public function toggle(array $p): void
    {
        $row = DB::one('SELECT id, status FROM companies WHERE id = ?', [$p['id']]);
        if (!$row) {
            $this->notFound();
        }
        if ((int) $row['id'] === $this->cid()) {
            $this->flash('error', 'امکان تعلیق شرکت خودتان وجود ندارد.');
            $this->redirect('/companies');
        }
        $new = $row['status'] === 'active' ? 'suspended' : 'active';
        DB::exec('UPDATE companies SET status = ? WHERE id = ?', [$new, $p['id']]);
        Audit::log('company.status', 'company', $p['id'], ['status' => $new]);
        $this->flash('success', 'وضعیت شرکت تغییر کرد.');
        $this->redirect('/companies');
    }
}
