<?php
declare(strict_types=1);

namespace App\Modules\Collaboration;

use App\Core\Controller;
use App\Core\UserError;
use App\Services\NoteService;

final class NoteController extends Controller
{
    public function store(): void
    {
        $entity = $this->input('entity');
        $id = (int) $this->input('entity_id', '0');
        try {
            NoteService::add($this->cid(), $entity, $id, $this->input('body'));
            $this->flash('success', 'یادداشت ثبت شد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect(isset(NoteService::ENTITIES[$entity]) ? NoteService::back($entity, $id) : '/dashboard');
    }

    public function update(array $p): void
    {
        $this->run(fn () => NoteService::edit($this->cid(), (int) $p['id'], $this->input('body')), 'یادداشت ویرایش شد.', (int) $p['id']);
    }

    public function delete(array $p): void
    {
        $this->run(fn () => NoteService::delete($this->cid(), (int) $p['id']), 'یادداشت حذف شد.', (int) $p['id']);
    }

    public function pin(array $p): void
    {
        $this->run(fn () => NoteService::togglePin($this->cid(), (int) $p['id']), 'وضعیت سنجاق یادداشت تغییر کرد.', (int) $p['id']);
    }

    private function run(callable $fn, string $ok, int $noteId): never
    {
        $back = '/dashboard';
        try {
            $n = $fn();
            $back = NoteService::back($n['entity'], (int) $n['entity_id']);
            $this->flash('success', $ok);
        } catch (UserError $e) {
            $row = \App\Core\Database::one('SELECT entity, entity_id FROM entity_notes WHERE id = ? AND company_id = ?', [$noteId, $this->cid()]);
            if ($row && isset(NoteService::ENTITIES[$row['entity']])) {
                $back = NoteService::back($row['entity'], (int) $row['entity_id']);
            }
            $this->flash('error', $e->getMessage());
        }
        $this->redirect($back);
    }
}
