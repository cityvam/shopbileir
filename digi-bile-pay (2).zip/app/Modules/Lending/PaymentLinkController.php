<?php
declare(strict_types=1);

namespace App\Modules\Lending;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\ListFilter;
use App\Core\Paginator;
use App\Core\UserError;
use App\Core\Validator;
use App\Services\Gateway\Gateways;
use App\Services\PaymentLinkService;

/** لینک‌های پرداخت آنلاین (سمت کارمند): ساخت، فهرست، مشاهده و لغو. */
final class PaymentLinkController extends Controller
{
    public function index(): void
    {
        $lf = (new ListFilter($_GET, 'pr.company_id = ?', [$this->cid()]))
            ->text('q', ['c.full_name', 'c.national_code', 'c.mobile', 'pr.ref_id'])
            ->enum('status', 'pr.status', array_keys(PaymentLinkService::STATUS_LABELS))
            ->enum('kind', 'pr.kind', ['installment', 'topup'])
            ->amount('min', 'max', 'pr.amount')
            ->dateRange('from', 'to', 'pr.created_at')
            ->sort(['created' => 'pr.id', 'amount' => 'pr.amount', 'customer' => 'c.full_name'], 'created', 'pr.id');
        $sel = "SELECT pr.id, pr.kind, pr.amount, pr.status, pr.gateway, pr.ref_id, pr.installment_id, pr.created_at, pr.paid_at, c.full_name, c.id AS customer_id
                FROM payment_requests pr JOIN customers c ON c.id = pr.customer_id WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'payment_links']);
            Csv::send('payment-links.csv', ['مشتری', 'نوع', 'مبلغ', 'وضعیت', 'درگاه', 'کد پیگیری', 'تاریخ ساخت', 'تاریخ پرداخت'],
                array_map(static fn ($r) => [$r['full_name'], $r['kind'] === 'installment' ? 'قسط' : 'شارژ کیف پول', $r['amount'], PaymentLinkService::STATUS_LABELS[$r['status']] ?? $r['status'], $r['gateway'], $r['ref_id'], Jalali::format(substr($r['created_at'], 0, 10)), $r['paid_at'] ? Jalali::format(substr($r['paid_at'], 0, 10)) : ''], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) FROM payment_requests pr JOIN customers c ON c.id = pr.customer_id WHERE {$lf->where}", $lf->params);
        $paidSum = (int) DB::scalar("SELECT COALESCE(SUM(pr.amount), 0) FROM payment_requests pr JOIN customers c ON c.id = pr.customer_id WHERE {$lf->where} AND pr.status = 'paid'", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $this->view('payment-links/index', ['title' => 'لینک‌های پرداخت', 'rows' => $rows, 'pg' => $pg, 'lf' => $lf, 'paidSum' => $paidSum, 'gatewayOn' => Gateways::active() !== null], 'payment-links');
    }

    public function show(array $p): void
    {
        $r = DB::one(
            'SELECT pr.*, c.full_name, c.mobile FROM payment_requests pr JOIN customers c ON c.id = pr.customer_id WHERE pr.id = ? AND pr.company_id = ?',
            [$p['id'], $this->cid()]
        ) ?? $this->notFound();
        $events = DB::all("SELECT * FROM audit_logs WHERE company_id = ? AND entity = 'payment_request' AND entity_id = ? ORDER BY id DESC", [$this->cid(), $r['id']]);
        $this->view('payment-links/show', [
            'title' => 'لینک پرداخت #' . $r['id'], 'r' => $r, 'url' => PaymentLinkService::url($r['token']),
            'events' => $events, 'gatewayOn' => Gateways::active() !== null,
        ], 'payment-links');
    }

    /** ساخت لینک پرداخت قسط */
    public function forInstallment(array $p): void
    {
        $inst = DB::one(
            'SELECT i.id, i.amount, i.paid_amount, l.customer_id FROM installments i JOIN loans l ON l.id = i.loan_id WHERE i.id = ? AND i.company_id = ?',
            [$p['id'], $this->cid()]
        ) ?? $this->notFound();
        $amount = $this->input('amount') === '' ? (int) $inst['amount'] - (int) $inst['paid_amount'] : (Validator::amount($this->input('amount')) ?? 0);
        $this->make('installment', (int) $inst['customer_id'], (int) $inst['id'], $amount, '/installments');
    }

    /** ساخت لینک شارژ کیف پول */
    public function forTopup(array $p): void
    {
        $c = DB::one('SELECT id FROM customers WHERE id = ? AND company_id = ?', [$p['id'], $this->cid()]) ?? $this->notFound();
        $this->make('topup', (int) $c['id'], null, Validator::amount($this->input('amount')) ?? 0, '/customers/' . (int) $c['id']);
    }

    private function make(string $kind, int $customerId, ?int $installmentId, int $amount, string $back): never
    {
        try {
            $r = PaymentLinkService::create($this->cid(), $kind, $customerId, $installmentId, $amount, Auth::id(), $this->input('note'));
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
            $this->redirect($back);
        }
        $this->flash('success', 'لینک پرداخت ساخته شد؛ آن را برای مشتری بفرستید.');
        $this->redirect('/payment-links/' . $r['id']);
    }

    public function cancel(array $p): void
    {
        $ok = PaymentLinkService::cancel($this->cid(), (int) $p['id']);
        $this->flash($ok ? 'success' : 'error', $ok ? 'لینک لغو شد.' : 'فقط لینک در انتظار پرداخت قابل لغو است.');
        $this->redirect('/payment-links/' . (int) $p['id']);
    }
}
