<?php
declare(strict_types=1);

namespace App\Modules\Lending;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\ListFilter;
use App\Core\UserError;
use App\Core\Paginator;
use App\Core\Validator;
use App\Services\Accounting;
use App\Services\CollectionService;
use App\Services\CreditService;
use App\Services\NoteService;
use App\Services\StatusService;

final class CustomerController extends Controller
{
    private const SORTS = [
        'name' => 'c.full_name', 'credit' => 'c.credit_limit', 'wallet' => 'c.wallet_balance', 'created' => 'c.id', 'debt' => 'debt',
    ];

    public function index(): void
    {
        $debtSql = "(SELECT COALESCE(SUM(i.amount - i.paid_amount), 0) FROM installments i JOIN loans l ON l.id = i.loan_id WHERE l.customer_id = c.id AND l.status = 'active' AND i.status <> 'paid')";
        $lf = (new ListFilter($_GET, 'c.company_id = ?', [$this->cid()]))
            ->text('q', ['c.full_name', 'c.national_code', 'c.mobile'])
            ->enum('status', 'c.status', ['active', 'blocked'])
            ->amount('credit_min', 'credit_max', 'c.credit_limit')
            ->amount('debt_min', 'debt_max', $debtSql)
            ->dateRange('from', 'to', 'c.created_at')
            ->sort(self::SORTS, 'created', 'c.id');
        if (($_GET['overdue'] ?? '') === '1') {
            $lf->v['overdue'] = '1';
            $lf->raw("EXISTS (SELECT 1 FROM installments i JOIN loans l ON l.id = i.loan_id WHERE l.customer_id = c.id AND i.status <> 'paid' AND i.due_date < ?)", [date('Y-m-d')]);
        }
        $sel = "SELECT c.id, c.national_code, c.full_name, c.mobile, c.credit_limit, c.wallet_balance, c.status, c.created_at, $debtSql AS debt
                FROM customers c WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'customers']);
            Csv::send('customers.csv', ['نام', 'کد ملی', 'موبایل', 'سقف اعتبار', 'کیف پول', 'بدهی جاری', 'وضعیت', 'تاریخ ثبت'],
                array_map(static fn ($r) => [$r['full_name'], $r['national_code'], $r['mobile'], $r['credit_limit'], $r['wallet_balance'], $r['debt'], $r['status'] === 'active' ? 'فعال' : 'مسدود', Jalali::format(substr($r['created_at'], 0, 10))], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) FROM customers c WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $this->view('customers/index', ['title' => 'مشتریان', 'rows' => $rows, 'pg' => $pg, 'lf' => $lf], 'customers');
    }

    public function create(): void
    {
        $this->view('customers/form', ['title' => 'مشتری جدید', 'customer' => null], 'customers');
    }

    public function store(): void
    {
        [$errors, $data] = $this->validated(null);
        if ($errors) {
            $this->fail('/customers/create', $errors);
        }
        $id = DB::insert(
            'INSERT INTO customers (company_id, national_code, full_name, mobile, credit_limit) VALUES (?, ?, ?, ?, ?)',
            [$this->cid(), $data['national_code'], $data['full_name'], $data['mobile'], $data['credit_limit']]
        );
        Audit::log('customer.create', 'customer', $id, ['credit_limit' => $data['credit_limit']]);
        $this->flash('success', 'مشتری ثبت شد.');
        $this->redirect('/customers/' . $id);
    }

    public function show(array $p): void
    {
        $c = $this->find($p['id']);
        $used = CreditService::used($this->cid(), (int) $c['id']);
        $loans = DB::all(
            'SELECT l.id, l.principal, l.months, l.status, l.created_at, p.name AS plan_name
             FROM loans l JOIN loan_plans p ON p.id = l.plan_id
             WHERE l.company_id = ? AND l.customer_id = ? ORDER BY l.id DESC LIMIT 20',
            [$this->cid(), $c['id']]
        );
        $wallet = DB::all(
            'SELECT type, amount, balance_after, created_at FROM wallet_transactions
             WHERE company_id = ? AND customer_id = ? ORDER BY id DESC LIMIT 20',
            [$this->cid(), $c['id']]
        );
        $orders = DB::all(
            'SELECT o.id, o.total, o.payment_type, o.status, o.created_at, m.name AS merchant_name
             FROM orders o JOIN merchants m ON m.id = o.merchant_id WHERE o.company_id = ? AND o.customer_id = ? ORDER BY o.id DESC LIMIT 10',
            [$this->cid(), $c['id']]
        );
        $notes = DB::all(
            'SELECT n.note, n.promise_date, n.created_at, u.full_name, l.id AS loan_id, i.seq
             FROM collection_notes n JOIN installments i ON i.id = n.installment_id JOIN loans l ON l.id = i.loan_id
             LEFT JOIN users u ON u.id = n.user_id
             WHERE n.company_id = ? AND l.customer_id = ? ORDER BY n.id DESC LIMIT 15',
            [$this->cid(), $c['id']]
        );
        $debt = DB::one(
            "SELECT COALESCE(SUM(i.amount - i.paid_amount), 0) AS remaining,
                    COALESCE(SUM(CASE WHEN i.due_date < ? THEN i.amount - i.paid_amount ELSE 0 END), 0) AS overdue,
                    COALESCE(SUM(CASE WHEN i.due_date < ? THEN 1 ELSE 0 END), 0) AS overdue_count
             FROM installments i JOIN loans l ON l.id = i.loan_id
             WHERE i.company_id = ? AND l.customer_id = ? AND l.status = 'active' AND i.status <> 'paid'",
            [date('Y-m-d'), date('Y-m-d'), $this->cid(), $c['id']]
        );
        $this->view('customers/show', [
            'title' => $c['full_name'], 'c' => $c, 'used' => $used,
            'available' => max(0, (int) $c['credit_limit'] - $used), 'loans' => $loans, 'wallet' => $wallet,
            'orders' => $orders, 'notes' => $notes, 'events' => Audit::events($this->cid(), 'customer', (int) $c['id']), 'internalNotes' => NoteService::list($this->cid(), 'customer', (int) $c['id']), 'debt' => $debt, 'history' => StatusService::history($this->cid(), 'customer', (int) $c['id']),
        ], 'customers');
    }

    public function status(array $p): void
    {
        $c = $this->find($p['id']);
        try {
            StatusService::change($this->cid(), 'customer', (int) $c['id'], $this->input('to_status'), $this->input('reason'), ['active', 'blocked']);
            $this->flash('success', 'وضعیت مشتری تغییر کرد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/customers/' . $c['id']);
    }

    public function edit(array $p): void
    {
        $this->view('customers/form', ['title' => 'ویرایش مشتری', 'customer' => $this->find($p['id'])], 'customers');
    }

    public function update(array $p): void
    {
        $c = $this->find($p['id']);
        [$errors, $data] = $this->validated($c);
        if ($errors) {
            $this->fail('/customers/' . $c['id'] . '/edit', $errors);
        }
        DB::exec(
            'UPDATE customers SET full_name = ?, mobile = ?, credit_limit = ? WHERE id = ? AND company_id = ?',
            [$data['full_name'], $data['mobile'], $data['credit_limit'], $c['id'], $this->cid()]
        );
        Audit::log('customer.update', 'customer', (int) $c['id'], ['changes' => Audit::diff($c, $data, ['full_name', 'mobile', 'credit_limit'])]);
        $this->flash('success', 'اطلاعات مشتری ذخیره شد.');
        $this->redirect('/customers/' . $c['id']);
    }

    public function bulkStatus(): void
    {
        try {
            $r = StatusService::bulk($this->cid(), 'customer', (array) ($_POST['ids'] ?? []), $this->input('to_status'), $this->input('reason'), ['active', 'blocked']);
            $this->flash($r['skipped'] ? 'error' : 'success', $r['ok'] . ' مورد تغییر کرد.' . ($r['skipped'] ? ' ردشده: ' . implode(' | ', array_slice($r['skipped'], 0, 5)) : ''));
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/customers');
    }

    public function topup(array $p): void
    {
        $c = $this->find($p['id']);
        $amount = Validator::amount($this->input('amount'));
        if ($amount === null) {
            $this->flash('error', 'مبلغ شارژ معتبر نیست.');
            $this->redirect('/customers/' . $c['id']);
        }
        DB::tx(fn () => CollectionService::topup($this->cid(), (int) $c['id'], $amount, Auth::id(), $c['full_name']));
        $this->flash('success', 'کیف پول شارژ شد.');
        $this->redirect('/customers/' . $c['id']);
    }

    private function find(int $id): array
    {
        $c = DB::one('SELECT * FROM customers WHERE id = ? AND company_id = ?', [$id, $this->cid()]);
        return $c ?? $this->notFound();
    }

    /** @return array{0: list<string>, 1: array} */
    private function validated(?array $existing): array
    {
        $nc = $this->input('national_code');
        $name = $this->input('full_name');
        $mobile = $this->input('mobile');
        $limitRaw = $this->input('credit_limit', '0');
        $limit = preg_replace('/\D/', '', $limitRaw) === '0' || $limitRaw === '' ? 0 : Validator::amount($limitRaw);

        $errors = [];
        if ($existing === null) {
            if (!Validator::nationalCode($nc)) {
                $errors[] = 'کد ملی معتبر نیست.';
            } elseif (DB::scalar('SELECT id FROM customers WHERE company_id = ? AND national_code = ?', [$this->cid(), $nc])) {
                $errors[] = 'مشتری با این کد ملی قبلاً ثبت شده است.';
            }
        } else {
            $nc = $existing['national_code'];
        }
        if (mb_strlen($name) < 2) {
            $errors[] = 'نام و نام خانوادگی را وارد کنید.';
        }
        if (!Validator::mobile($mobile)) {
            $errors[] = 'شماره موبایل باید با ۰۹ شروع شود و ۱۱ رقم باشد.';
        }
        if ($limit === null) {
            $errors[] = 'سقف اعتبار معتبر نیست.';
        }
        return [$errors, [
            'national_code' => $nc, 'full_name' => $name, 'mobile' => $mobile,
            'credit_limit' => (int) $limit,
        ]];
    }
}
