<?php
declare(strict_types=1);

namespace App\Modules\Lending;

use App\Core\Controller;
use App\Core\Csv;
use App\Services\CustomerImport;

final class CustomerImportController extends Controller
{
    private const MAX_BYTES = 1048576;

    public function form(): void
    {
        $this->view('customers/import', ['title' => 'درون‌ریزی مشتریان', 'result' => null, 'committed' => 0], 'customers');
    }

    public function template(): never
    {
        Csv::send('customers-template.csv', ['national_code', 'full_name', 'mobile', 'credit_limit'], [['0012345678', 'نمونه مشتری', '09121234567', '20000000']]);
    }

    public function run(): void
    {
        $f = $_FILES['file'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) $f['tmp_name'])) {
            $this->fail('/customers/import', ['فایل CSV را انتخاب کنید.']);
        }
        if ((int) $f['size'] > self::MAX_BYTES) {
            $this->fail('/customers/import', ['حجم فایل بیش از ۱ مگابایت است.']);
        }
        $result = CustomerImport::parse((string) file_get_contents((string) $f['tmp_name']), $this->cid());
        $bad = count(array_filter($result['rows'], static fn ($r) => $r['errors']));
        $committed = 0;
        if ($result['fatal'] === null && $bad === 0 && $this->input('mode') === 'import') {
            $committed = CustomerImport::commit($this->cid(), $result['rows']);
        }
        $this->view('customers/import', ['title' => 'درون‌ریزی مشتریان', 'result' => $result + ['bad' => $bad], 'committed' => $committed], 'customers');
    }
}
