<?php
declare(strict_types=1);

namespace App\Modules\Lending;

use App\Core\Audit;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\Validator;

final class PlanController extends Controller
{
    public function index(): void
    {
        $rows = DB::all('SELECT * FROM loan_plans WHERE company_id = ? ORDER BY is_active DESC, id DESC', [$this->cid()]);
        $this->view('plans/index', ['title' => 'طرح‌های تسهیلاتی', 'rows' => $rows], 'plans');
    }

    public function create(): void
    {
        $this->view('plans/form', ['title' => 'طرح جدید', 'plan' => null], 'plans');
    }

    public function store(): void
    {
        [$errors, $d] = $this->validated();
        if ($errors) {
            $this->fail('/plans/create', $errors);
        }
        $id = DB::insert(
            'INSERT INTO loan_plans (company_id, name, months, annual_rate_percent, fee_percent, late_fee_daily_percent, min_amount, max_amount, is_active)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$this->cid(), $d['name'], $d['months'], (string) $d['rate'], (string) $d['fee'], (string) $d['late'], $d['min'], $d['max'], $d['active']]
        );
        Audit::log('plan.create', 'loan_plan', $id, $d);
        $this->flash('success', 'طرح ثبت شد.');
        $this->redirect('/plans');
    }

    public function status(array $p): void
    {
        $plan = $this->find($p['id']);
        try {
            \App\Services\StatusService::change($this->cid(), 'plan', (int) $plan['id'], $this->input('to_status'), $this->input('reason'), ['active', 'disabled']);
            $this->flash('success', 'وضعیت طرح تغییر کرد.');
        } catch (\App\Core\UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/plans/' . $plan['id'] . '/edit');
    }

    public function edit(array $p): void
    {
        $plan = $this->find($p['id']);
        $this->view('plans/form', [
            'title' => 'ویرایش طرح', 'plan' => $plan, 'history' => \App\Services\StatusService::history($this->cid(), 'plan', (int) $plan['id']),
            'events' => Audit::events($this->cid(), 'loan_plan', (int) $plan['id']),
        ], 'plans');
    }

    /** طرح‌هایی که تسهیلات روی آن‌ها ثبت شده، با تغییر شرایط تأثیری روی تسهیلات قبلی نمی‌گذارند (شرایط در تسهیلات snapshot می‌شود) */
    public function update(array $p): void
    {
        $plan = $this->find($p['id']);
        [$errors, $d] = $this->validated();
        if ($errors) {
            $this->fail('/plans/' . $plan['id'] . '/edit', $errors);
        }
        DB::exec(
            'UPDATE loan_plans SET name = ?, months = ?, annual_rate_percent = ?, fee_percent = ?, late_fee_daily_percent = ?, min_amount = ?, max_amount = ?
             WHERE id = ? AND company_id = ?',
            [$d['name'], $d['months'], (string) $d['rate'], (string) $d['fee'], (string) $d['late'], $d['min'], $d['max'], $plan['id'], $this->cid()]
        );
        Audit::log('plan.update', 'loan_plan', (int) $plan['id'], ['changes' => Audit::diff($plan, ['name' => $d['name'], 'months' => $d['months'], 'annual_rate_percent' => $d['rate'], 'fee_percent' => $d['fee'], 'late_fee_daily_percent' => $d['late'], 'min_amount' => $d['min'], 'max_amount' => $d['max']], ['name', 'months', 'annual_rate_percent', 'fee_percent', 'late_fee_daily_percent', 'min_amount', 'max_amount'])]);
        $this->flash('success', 'طرح ذخیره شد.');
        $this->redirect('/plans');
    }

    private function find(int $id): array
    {
        return DB::one('SELECT * FROM loan_plans WHERE id = ? AND company_id = ?', [$id, $this->cid()]) ?? $this->notFound();
    }

    /** @return array{0: list<string>, 1: array} */
    private function validated(): array
    {
        $name = $this->input('name');
        $months = (int) $this->input('months', '0');
        $rate = Validator::percent($this->input('annual_rate_percent', ''));
        $fee = Validator::percent($this->input('fee_percent', '0'));
        $late = Validator::percent($this->input('late_fee_daily_percent', '0'));
        $min = Validator::amount($this->input('min_amount'));
        $max = Validator::amount($this->input('max_amount'));

        $errors = [];
        if (mb_strlen($name) < 2) {
            $errors[] = 'نام طرح را وارد کنید.';
        }
        if ($months < 1 || $months > 60) {
            $errors[] = 'تعداد اقساط باید بین ۱ تا ۶۰ باشد.';
        }
        if ($rate === null) {
            $errors[] = 'نرخ سود سالانه باید بین ۰ تا ۱۰۰ درصد باشد.';
        }
        if ($fee === null) {
            $errors[] = 'کارمزد باید بین ۰ تا ۱۰۰ درصد باشد.';
        }
        if ($late === null || $late > 5) {
            $errors[] = 'جریمه تأخیر روزانه باید بین ۰ تا ۵ درصد باشد.';
        }
        if ($min === null || $max === null || $min > $max) {
            $errors[] = 'حداقل و حداکثر مبلغ معتبر نیست.';
        }
        return [$errors, [
            'name' => $name, 'months' => $months, 'rate' => $rate ?? 0.0, 'fee' => $fee ?? 0.0, 'late' => $late ?? 0.0,
            'min' => $min ?? 0, 'max' => $max ?? 0, 'active' => $this->input('is_active') === '1' ? 1 : 0,
        ]];
    }
}
