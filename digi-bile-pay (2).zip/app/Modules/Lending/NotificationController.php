<?php
declare(strict_types=1);

namespace App\Modules\Lending;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\ListFilter;
use App\Core\Paginator;
use App\Services\NotificationService;

/** صف پیامک: فهرست و فیلتر، اجرای یادآوری و ارسال، تلاش مجدد، و پیامک دستی به مشتری. */
final class NotificationController extends Controller
{
    private const TEMPLATE_LABELS = ['inst_due' => 'یادآوری سررسید', 'inst_overdue' => 'اخطار معوقه', 'payment_ok' => 'تأیید پرداخت', 'loan_active' => 'فعال‌سازی تسهیلات', 'manual' => 'دستی'];

    public function index(): void
    {
        $lf = (new ListFilter($_GET, 'n.company_id = ?', [$this->cid()]))
            ->text('q', ['n.recipient', 'n.body', 'c.full_name'])
            ->enum('status', 'n.status', array_keys(NotificationService::STATUS_LABELS))
            ->enum('template', 'n.template', array_keys(self::TEMPLATE_LABELS))
            ->dateRange('from', 'to', 'n.created_at')
            ->sort(['created' => 'n.id', 'customer' => 'c.full_name'], 'created', 'n.id');
        $join = 'FROM notifications n LEFT JOIN customers c ON c.id = n.customer_id';
        $sel = "SELECT n.id, n.recipient, n.template, n.body, n.status, n.attempts, n.last_error, n.created_at, n.sent_at, c.id AS customer_id, c.full_name $join WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'notifications']);
            Csv::send('notifications.csv', ['مشتری', 'شماره', 'نوع', 'متن', 'وضعیت', 'تاریخ'],
                array_map(static fn ($r) => [$r['full_name'], $r['recipient'], self::TEMPLATE_LABELS[$r['template']] ?? $r['template'], $r['body'], NotificationService::STATUS_LABELS[$r['status']] ?? $r['status'], Jalali::format(substr($r['created_at'], 0, 10))], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) $join WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $queued = (int) DB::scalar("SELECT COUNT(*) FROM notifications WHERE company_id = ? AND status = 'queued'", [$this->cid()]);
        $this->view('notifications/index', ['title' => 'پیامک‌ها', 'rows' => $rows, 'pg' => $pg, 'lf' => $lf, 'templates' => self::TEMPLATE_LABELS, 'queued' => $queued, 'driverOn' => NotificationService::driver() !== null], 'notifications');
    }

    /** تولید یادآوری‌ها و ارسال صف همین حالا */
    public function run(): void
    {
        $made = NotificationService::generateReminders($this->cid());
        $r = NotificationService::dispatch($this->cid());
        Audit::log('notify.run', 'company', $this->cid(), ['queued' => $made] + $r);
        if (NotificationService::driver() === null) {
            $this->flash('warning', $made . ' پیام در صف قرار گرفت؛ درایور پیامک (SMS_DRIVER) فعال نیست و ارسالی انجام نشد.');
        } else {
            $this->flash('success', $made . ' یادآوری جدید ساخته شد؛ ' . $r['sent'] . ' ارسال، ' . $r['failed'] . ' ناموفق.');
        }
        $this->redirect('/notifications');
    }

    public function retry(array $p): void
    {
        $ok = NotificationService::retry($this->cid(), (int) $p['id']);
        $this->flash($ok ? 'success' : 'error', $ok ? 'پیام دوباره در صف قرار گرفت.' : 'فقط پیام ناموفق قابل تلاش مجدد است.');
        $this->redirect('/notifications');
    }

    /** پیامک دستی به یک مشتری */
    public function manual(array $p): void
    {
        $c = DB::one('SELECT id, full_name, mobile FROM customers WHERE id = ? AND company_id = ?', [$p['id'], $this->cid()]) ?? $this->notFound();
        $body = mb_substr($this->input('body'), 0, 300);
        if ($body === '') {
            $this->flash('error', 'متن پیامک را وارد کنید.');
            $this->redirect('/customers/' . (int) $c['id']);
        }
        $id = NotificationService::enqueue($this->cid(), (int) $c['id'], (string) $c['mobile'], 'manual', ['body' => $body], null, Auth::id());
        if ($id === null) {
            $this->flash('error', 'شماره‌ی موبایل مشتری معتبر نیست.');
            $this->redirect('/customers/' . (int) $c['id']);
        }
        NotificationService::dispatch($this->cid(), 20);
        Audit::log('notify.manual', 'customer', (int) $c['id'], ['notification' => $id]);
        $this->flash('success', NotificationService::driver() === null ? 'پیامک در صف قرار گرفت (درایور پیامک فعال نیست).' : 'پیامک ارسال شد.');
        $this->redirect('/customers/' . (int) $c['id']);
    }
}
