<?php
declare(strict_types=1);

namespace App\Modules\Lending;

use App\Core\Audit;
use App\Core\Controller;
use App\Core\Csv;
use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\ListFilter;
use App\Core\Paginator;
use App\Core\UserError;
use App\Services\NoteService;
use App\Services\StatusService;

final class LeadController extends Controller
{
    public const STATUSES = ['new' => 'جدید', 'contacted' => 'پیگیری شد', 'qualified' => 'واجد شرایط', 'converted' => 'تبدیل به مشتری', 'rejected' => 'ردشده'];

    public function index(): void
    {
        $lf = (new ListFilter($_GET, 'l.company_id = ?', [$this->cid()]))
            ->text('q', ['l.full_name', 'l.mobile', 'l.national_code'])
            ->enum('status', 'l.status', array_keys(self::STATUSES))
            ->dateRange('from', 'to', 'l.created_at')
            ->sort(['created' => 'l.id', 'name' => 'l.full_name', 'amount' => 'l.requested_amount'], 'created', 'l.id');
        $sel = "SELECT l.id, l.full_name, l.mobile, l.national_code, l.requested_amount, l.status, l.created_at, p.name AS plan_name
                FROM leads l LEFT JOIN loan_plans p ON p.id = l.plan_id WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'leads']);
            Csv::send('leads.csv', ['نام', 'موبایل', 'کد ملی', 'مبلغ درخواستی', 'طرح', 'وضعیت', 'تاریخ'],
                array_map(fn ($r) => [$r['full_name'], $r['mobile'], $r['national_code'], $r['requested_amount'], $r['plan_name'], self::STATUSES[$r['status']] ?? $r['status'], Jalali::format(substr($r['created_at'], 0, 10))], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) FROM leads l WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $this->view('leads/index', ['title' => 'درخواست‌های اعتبار', 'rows' => $rows, 'pg' => $pg, 'lf' => $lf, 'statuses' => self::STATUSES], 'leads');
    }

    public function show(array $p): void
    {
        $l = $this->find($p['id']);
        $this->view('leads/show', [
            'title' => 'درخواست اعتبار #' . $l['id'], 'l' => $l, 'statuses' => self::STATUSES,
            'history' => StatusService::history($this->cid(), 'lead', (int) $l['id']),
            'events' => Audit::events($this->cid(), 'lead', (int) $l['id']),
            'internalNotes' => NoteService::list($this->cid(), 'lead', (int) $l['id']),
        ], 'leads');
    }

    public function status(array $p): void
    {
        $l = $this->find($p['id']);
        try {
            StatusService::change($this->cid(), 'lead', (int) $l['id'], $this->input('to_status'), $this->input('reason'), array_keys(self::STATUSES));
            $this->flash('success', 'وضعیت درخواست تغییر کرد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/leads/' . $l['id']);
    }

    /** پیش‌پر کردن فرم مشتری جدید با اطلاعات درخواست */
    public function convert(array $p): void
    {
        $l = $this->find($p['id']);
        $_SESSION['_old'] = ['national_code' => (string) $l['national_code'], 'full_name' => $l['full_name'], 'mobile' => $l['mobile']];
        $this->flash('info', 'اطلاعات درخواست در فرم مشتری جدید وارد شد. پس از ثبت، وضعیت درخواست را «تبدیل به مشتری» کنید.');
        $this->redirect('/customers/create');
    }

    private function find(int $id): array
    {
        return DB::one('SELECT l.*, p.name AS plan_name FROM leads l LEFT JOIN loan_plans p ON p.id = l.plan_id WHERE l.id = ? AND l.company_id = ?', [$id, $this->cid()]) ?? $this->notFound();
    }
}
