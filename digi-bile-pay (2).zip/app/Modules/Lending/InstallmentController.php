<?php
declare(strict_types=1);

namespace App\Modules\Lending;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\ListFilter;
use App\Core\Csv;
use App\Core\Paginator;
use App\Core\Jalali;
use App\Core\Validator;
use App\Core\UserError;
use App\Services\Accounting;
use App\Services\CollectionService;
use App\Services\LateFeeService;

final class InstallmentController extends Controller
{
    public function index(): void
    {
        $filter = $this->input('filter', 'unpaid');
        $today = date('Y-m-d');
        $where = "i.company_id = ? AND l.status IN ('active','closed')";
        $params = [$this->cid()];
        switch ($filter) {
            case 'overdue':
                $where .= " AND i.status <> 'paid' AND i.due_date < ?";
                $params[] = $today;
                break;
            case 'paid':
                $where .= " AND i.status = 'paid'";
                break;
            case 'all':
                break;
            default:
                $filter = 'unpaid';
                $where .= " AND i.status <> 'paid'";
        }
        $remainingSql = '(i.amount - i.paid_amount)';
        $lf = (new ListFilter($_GET, $where, $params))
            ->text('q', ['cu.full_name', 'cu.national_code', 'cu.mobile'])
            ->amount('min', 'max', $remainingSql)
            ->dateRange('from', 'to', 'i.due_date')
            ->sort(['due' => 'i.due_date', 'amount' => $remainingSql, 'customer' => 'cu.full_name'], 'due', 'i.id');
        $lf->v['filter'] = $filter;
        if (!isset($_GET['sort'])) {
            $lf->order = 'i.due_date ASC, i.id ASC';
        }
        $join = 'FROM installments i JOIN loans l ON l.id = i.loan_id JOIN customers cu ON cu.id = l.customer_id';
        $sel = "SELECT i.id, i.seq, i.due_date, i.amount, i.paid_amount, i.status, i.late_fee_accrued, i.late_fee_paid, l.id AS loan_id, l.months,
                    cu.id AS customer_id, cu.full_name, cu.national_code, cu.wallet_balance, cu.mobile,
                    (SELECT n.note FROM collection_notes n WHERE n.installment_id = i.id ORDER BY n.id DESC LIMIT 1) AS last_note,
                    (SELECT n.promise_date FROM collection_notes n WHERE n.installment_id = i.id ORDER BY n.id DESC LIMIT 1) AS promise_date
                $join WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'installments']);
            Csv::send('installments.csv', ['مشتری', 'کد ملی', 'موبایل', 'تسهیلات', 'قسط', 'سررسید', 'مبلغ', 'پرداخت‌شده', 'مانده', 'وضعیت'],
                array_map(static fn ($r) => [$r['full_name'], $r['national_code'], $r['mobile'], $r['loan_id'], $r['seq'] . '/' . $r['months'], Jalali::format($r['due_date']), $r['amount'], $r['paid_amount'], (int) $r['amount'] - (int) $r['paid_amount'], $r['status']], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) $join WHERE {$lf->where}", $lf->params);
        $sum = (int) DB::scalar("SELECT COALESCE(SUM($remainingSql), 0) $join WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $this->view('installments/index', ['title' => 'اقساط و وصول', 'rows' => $rows, 'pg' => $pg, 'filter' => $filter, 'today' => $today, 'lf' => $lf, 'sum' => $sum], 'installments');
    }

    public function pay(array $p): void
    {
        $method = $this->input('method') === 'wallet' ? 'wallet' : 'cash';
        $amount = Validator::amount($this->input('amount'));
        $back = '/installments' . (isset($_POST['return']) && $_POST['return'] === 'overdue' ? '?filter=overdue' : '');

        if ($amount === null) {
            $this->flash('error', 'مبلغ پرداخت معتبر نیست.');
            $this->redirect($back);
        }

        $result = DB::tx(fn () => CollectionService::payInstallment($this->cid(), (int) $p['id'], $amount, $method, Auth::id()));

        if ($result === true) {
            $this->flash('success', 'پرداخت ثبت شد.');
        } else {
            $this->flash('error', (string) $result);
        }
        $this->redirect($back);
    }

    /** محاسبه جریمه تأخیر امروز برای همه اقساط معوق (هر روز برای هر قسط فقط یک‌بار) */
    public function accrueFees(): void
    {
        $r = DB::tx(function () {
            $r = LateFeeService::accrue($this->cid());
            Audit::log('latefee.accrue', 'company', $this->cid(), $r);
            return $r;
        });
        $this->flash('success', $r['installments'] > 0
            ? 'جریمه تأخیر برای ' . number_format($r['installments']) . ' قسط محاسبه شد (جمع: ' . number_format($r['total']) . ' ریال).'
            : 'جریمه جدیدی برای محاسبه وجود نداشت.');
        $this->redirect('/installments?filter=overdue');
    }

    /** دریافت کامل جریمه تأخیر معوق یک قسط */
    public function receiveFee(array $p): void
    {
        $method = $this->input('method') === 'wallet' ? 'wallet' : 'cash';
        $back = '/installments?filter=' . urlencode($this->input('return', 'overdue'));
        try {
            $amount = DB::tx(function () use ($p, $method) {
                $i = DB::one(
                    'SELECT i.id, i.late_fee_accrued, i.late_fee_paid, i.loan_id, l.customer_id FROM installments i JOIN loans l ON l.id = i.loan_id WHERE i.id = ? AND i.company_id = ?',
                    [$p['id'], $this->cid()]
                ) ?? $this->notFound();
                $due = (int) $i['late_fee_accrued'] - (int) $i['late_fee_paid'];
                if ($due <= 0) {
                    throw new UserError('جریمه‌ای برای دریافت وجود ندارد.');
                }
                if ($method === 'wallet') {
                    $n = DB::exec(
                        'UPDATE customers SET wallet_balance = wallet_balance - ? WHERE id = ? AND company_id = ? AND wallet_balance >= ?',
                        [$due, $i['customer_id'], $this->cid(), $due]
                    );
                    if ($n !== 1) {
                        throw new UserError('موجودی کیف پول کافی نیست.');
                    }
                    $balance = (int) DB::scalar('SELECT wallet_balance FROM customers WHERE id = ?', [$i['customer_id']]);
                    DB::exec(
                        "INSERT INTO wallet_transactions (company_id, customer_id, type, amount, balance_after, ref_id, created_by, created_at) VALUES (?, ?, 'installment', ?, ?, ?, ?, ?)",
                        [$this->cid(), $i['customer_id'], -$due, $balance, $i['id'], Auth::id(), date('Y-m-d H:i:s')]
                    );
                }
                $n = DB::exec(
                    'UPDATE installments SET late_fee_paid = late_fee_paid + ? WHERE id = ? AND company_id = ? AND late_fee_paid + ? <= late_fee_accrued',
                    [$due, $i['id'], $this->cid(), $due]
                );
                if ($n !== 1) {
                    throw new UserError('دریافت هم‌زمان شناسایی شد؛ دوباره تلاش کنید.');
                }
                Accounting::post($this->cid(), 'دریافت جریمه تأخیر قسط #' . $i['id'], [
                    [$method === 'wallet' ? Accounting::WALLET : Accounting::CASH, $due, 0],
                    [Accounting::LATE_FEE, 0, $due],
                ], 'latefee', (int) $i['id'], Auth::id());
                Audit::log('latefee.receive', 'installment', (int) $i['id'], ['amount' => $due, 'method' => $method]);
                return $due;
            });
            $this->flash('success', 'جریمه تأخیر ' . number_format($amount) . ' ریال دریافت شد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect($back);
    }

    public function note(array $p): void
    {
        $note = mb_substr($this->input('note'), 0, 250);
        $promiseRaw = $this->input('promise_date');
        $promise = null;
        $back = '/installments?filter=' . urlencode($this->input('return', 'overdue'));

        if (mb_strlen($note) < 3) {
            $this->flash('error', 'متن پیگیری را بنویسید.');
            $this->redirect($back);
        }
        if ($promiseRaw !== '') {
            $promise = Jalali::parse($promiseRaw);
            if ($promise === null) {
                $this->flash('error', 'تاریخ قول پرداخت باید شمسی و به‌صورت ۱۴۰۵/۰۸/۱۵ باشد.');
                $this->redirect($back);
            }
        }
        $inst = DB::one(
            "SELECT i.id FROM installments i JOIN loans l ON l.id = i.loan_id
             WHERE i.id = ? AND i.company_id = ? AND i.status <> 'paid' AND l.status = 'active'",
            [$p['id'], $this->cid()]
        );
        if (!$inst) {
            $this->notFound();
        }
        $id = DB::insert(
            'INSERT INTO collection_notes (company_id, installment_id, user_id, note, promise_date, created_at) VALUES (?, ?, ?, ?, ?, ?)',
            [$this->cid(), $inst['id'], Auth::id(), $note, $promise, date('Y-m-d H:i:s')]
        );
        Audit::log('collection.note', 'installment', (int) $inst['id'], ['note_id' => $id, 'promise_date' => $promise]);
        $this->flash('success', 'پیگیری ثبت شد.');
        $this->redirect($back);
    }
}
