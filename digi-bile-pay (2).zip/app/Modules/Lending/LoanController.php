<?php
declare(strict_types=1);

namespace App\Modules\Lending;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Controller;
use App\Core\Database as DB;
use App\Core\ListFilter;
use App\Core\Jalali;
use App\Core\Csv;
use App\Core\Paginator;
use App\Core\UserError;
use App\Core\Validator;
use App\Services\CreditService;
use App\Services\LoanCalculator;
use App\Services\LoanService;

final class LoanController extends Controller
{
    private const SORTS = ['id' => 'l.id', 'amount' => 'l.principal', 'customer' => 'cu.full_name', 'months' => 'l.months'];

    public function index(): void
    {
        $lf = (new ListFilter($_GET, 'l.company_id = ?', [$this->cid()]))
            ->text('q', ['cu.full_name', 'cu.national_code', 'cu.mobile'])
            ->enum('status', 'l.status', ['pending', 'active', 'rejected', 'closed'])
            ->enum('plan_id', 'l.plan_id', array_map('strval', array_column(DB::all('SELECT id FROM loan_plans WHERE company_id = ?', [$this->cid()]), 'id')))
            ->amount('min', 'max', 'l.principal')
            ->dateRange('from', 'to', 'l.created_at')
            ->sort(self::SORTS, 'id', 'l.id');
        $sel = "SELECT l.id, l.principal, l.months, l.status, l.created_at, cu.full_name, cu.national_code, p.name AS plan_name
                FROM loans l JOIN customers cu ON cu.id = l.customer_id JOIN loan_plans p ON p.id = l.plan_id
                WHERE {$lf->where} ORDER BY {$lf->order}";
        if ($lf->isCsv()) {
            Audit::log('report.export', 'report', null, ['name' => 'loans']);
            Csv::send('loans.csv', ['شماره', 'مشتری', 'کد ملی', 'طرح', 'مبلغ', 'اقساط', 'وضعیت', 'تاریخ'],
                array_map(static fn ($r) => [$r['id'], $r['full_name'], $r['national_code'], $r['plan_name'], $r['principal'], $r['months'], $r['status'], Jalali::format(substr($r['created_at'], 0, 10))], DB::all($sel, $lf->params)));
        }
        $total = (int) DB::scalar("SELECT COUNT(*) FROM loans l JOIN customers cu ON cu.id = l.customer_id WHERE {$lf->where}", $lf->params);
        $sum = (int) DB::scalar("SELECT COALESCE(SUM(l.principal), 0) FROM loans l JOIN customers cu ON cu.id = l.customer_id WHERE {$lf->where}", $lf->params);
        $pg = Paginator::make($total, (int) $this->input('page', '1'));
        $rows = DB::all($sel . ' LIMIT ? OFFSET ?', [...$lf->params, $pg['per'], $pg['offset']]);
        $plans = DB::all('SELECT id, name FROM loan_plans WHERE company_id = ? ORDER BY name', [$this->cid()]);
        $this->view('loans/index', ['title' => 'تسهیلات', 'rows' => $rows, 'pg' => $pg, 'lf' => $lf, 'sum' => $sum, 'plans' => $plans], 'loans');
    }

    public function create(): void
    {
        $customers = DB::all("SELECT id, full_name, national_code, credit_limit FROM customers WHERE company_id = ? AND status = 'active' ORDER BY full_name LIMIT 500", [$this->cid()]);
        $plans = DB::all('SELECT id, name, months, annual_rate_percent, min_amount, max_amount FROM loan_plans WHERE company_id = ? AND is_active = 1 ORDER BY name', [$this->cid()]);
        $this->view('loans/form', [
            'title' => 'درخواست تسهیلات', 'customers' => $customers, 'plans' => $plans,
            'selectedCustomer' => (int) $this->input('customer_id', '0'),
        ], 'loans');
    }

    public function store(): void
    {
        $customerId = (int) $this->input('customer_id', '0');
        $planId = (int) $this->input('plan_id', '0');
        $amount = Validator::amount($this->input('amount'));

        $customer = DB::one("SELECT * FROM customers WHERE id = ? AND company_id = ? AND status = 'active'", [$customerId, $this->cid()]);
        $plan = DB::one('SELECT * FROM loan_plans WHERE id = ? AND company_id = ? AND is_active = 1', [$planId, $this->cid()]);

        $errors = [];
        if (!$customer) {
            $errors[] = 'مشتری فعال انتخاب نشده است.';
        }
        if (!$plan) {
            $errors[] = 'طرح فعال انتخاب نشده است.';
        }
        if ($amount === null) {
            $errors[] = 'مبلغ معتبر نیست.';
        }
        if ($customer && $plan && $amount !== null) {
            if ($amount < (int) $plan['min_amount'] || $amount > (int) $plan['max_amount']) {
                $errors[] = 'مبلغ خارج از بازه مجاز طرح است.';
            }
            $available = CreditService::available($this->cid(), $customerId, (int) $customer['credit_limit']);
            if ($amount > $available) {
                $errors[] = 'مبلغ از اعتبار آزاد مشتری (' . number_format($available) . ' ریال) بیشتر است.';
            }
        }
        if ($errors) {
            $this->fail('/loans/create', $errors);
        }

        $id = LoanService::createPending($this->cid(), $customerId, $plan, $amount, Auth::id());
        Audit::log('loan.request', 'loan', $id, ['customer_id' => $customerId, 'principal' => $amount]);
        $this->flash('success', 'درخواست ثبت شد و در انتظار تأیید است.');
        $this->redirect('/loans/' . $id);
    }

    public function show(array $p): void
    {
        $loan = $this->find($p['id']);
        if ($loan['status'] === 'pending') {
            $schedule = LoanCalculator::schedule((int) $loan['principal'], (int) $loan['months'], (float) $loan['annual_rate_percent'], date('Y-m-d'));
            $isPreview = true;
        } else {
            $schedule = DB::all(
                'SELECT seq, due_date, principal_part, interest_part, amount, paid_amount, status FROM installments WHERE loan_id = ? AND company_id = ? ORDER BY seq',
                [$loan['id'], $this->cid()]
            );
            $isPreview = false;
        }
        $quote = $loan['status'] === 'active' ? LoanService::payoffQuote($this->cid(), (int) $loan['id']) : null;
        $this->view('loans/show', [
            'title' => 'تسهیلات شماره ' . fa($loan['id']), 'loan' => $loan, 'schedule' => $schedule, 'isPreview' => $isPreview, 'quote' => $quote,
            'events' => Audit::events($this->cid(), 'loan', (int) $loan['id']), 'internalNotes' => \App\Services\NoteService::list($this->cid(), 'loan', (int) $loan['id']),
            'canDecide' => $loan['status'] === 'pending' && Auth::can('loans.decide') && (int) $loan['requested_by'] !== Auth::id(),
        ], 'loans');
    }

    /** تسویه زودهنگام با بخشودگی سود اقساط آینده */
    public function payoff(array $p): void
    {
        $loan = $this->find($p['id']);
        $method = $this->input('method') === 'wallet' ? 'wallet' : 'cash';
        try {
            $paid = DB::tx(function () use ($loan, $method) {
                $quote = LoanService::payoffQuote($this->cid(), (int) $loan['id']);
                $paid = LoanService::payoff($this->cid(), (int) $loan['id'], $method, Auth::id());
                Audit::log('loan.payoff', 'loan', (int) $loan['id'], ['paid' => $paid, 'waived_interest' => $quote['waived'], 'method' => $method]);
                return $paid;
            });
            $this->flash('success', 'تسهیلات با پرداخت ' . number_format($paid) . ' ریال تسویه شد.');
        } catch (UserError $e) {
            $this->flash('error', $e->getMessage());
        }
        $this->redirect('/loans/' . $loan['id']);
    }

    public function approve(array $p): void
    {
        $loan = $this->find($p['id']);
        if ((int) $loan['requested_by'] === Auth::id()) {
            $this->flash('error', 'درخواست‌دهنده نمی‌تواند همان درخواست را تأیید کند.');
            $this->redirect('/loans/' . $loan['id']);
        }
        $customer = DB::one('SELECT credit_limit, status FROM customers WHERE id = ? AND company_id = ?', [$loan['customer_id'], $this->cid()]);
        if (!$customer || $customer['status'] !== 'active') {
            $this->flash('error', 'مشتری فعال نیست.');
            $this->redirect('/loans/' . $loan['id']);
        }
        $available = CreditService::available($this->cid(), (int) $loan['customer_id'], (int) $customer['credit_limit'], (int) $loan['id']);
        if ((int) $loan['principal'] > $available) {
            $this->flash('error', 'اعتبار آزاد مشتری برای تأیید کافی نیست.');
            $this->redirect('/loans/' . $loan['id']);
        }

        // شرط status='pending' در سرویس از تأیید دوباره هم‌زمان جلوگیری می‌کند
        $ok = DB::tx(function () use ($loan) {
            if (!LoanService::activate($loan, Auth::id())) {
                return false;
            }
            Audit::log('loan.approve', 'loan', (int) $loan['id'], ['principal' => (int) $loan['principal']]);
            return true;
        });
        $this->flash($ok ? 'success' : 'error', $ok ? 'تسهیلات تأیید و جدول اقساط ایجاد شد.' : 'این درخواست دیگر در وضعیت انتظار نیست.');
        $this->redirect('/loans/' . $loan['id']);
    }

    public function reject(array $p): void
    {
        $loan = $this->find($p['id']);
        $note = mb_substr($this->input('note'), 0, 250);
        if ((int) $loan['requested_by'] === Auth::id()) {
            $this->flash('error', 'درخواست‌دهنده نمی‌تواند همان درخواست را رد کند.');
            $this->redirect('/loans/' . $loan['id']);
        }
        if ($note === '') {
            $this->flash('error', 'دلیل رد درخواست را بنویسید.');
            $this->redirect('/loans/' . $loan['id']);
        }
        $done = DB::tx(function () use ($loan, $note) {
            if (!LoanService::reject($loan, Auth::id(), $note)) {
                return false;
            }
            Audit::log('loan.reject', 'loan', (int) $loan['id'], ['note' => $note]);
            return true;
        });
        if ($done) {
            $this->flash('success', 'درخواست رد شد.');
        } else {
            $this->flash('error', 'این درخواست دیگر در وضعیت انتظار نیست.');
        }
        $this->redirect('/loans/' . $loan['id']);
    }

    private function find(int $id): array
    {
        $l = DB::one(
            'SELECT l.*, cu.full_name, cu.national_code, p.name AS plan_name, ru.full_name AS requester_name, du.full_name AS decider_name
             FROM loans l JOIN customers cu ON cu.id = l.customer_id JOIN loan_plans p ON p.id = l.plan_id
             JOIN users ru ON ru.id = l.requested_by LEFT JOIN users du ON du.id = l.decided_by
             WHERE l.id = ? AND l.company_id = ?',
            [$id, $this->cid()]
        );
        return $l ?? $this->notFound();
    }
}
