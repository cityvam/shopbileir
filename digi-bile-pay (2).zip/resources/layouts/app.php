<?php
/** @var string $title @var string $page @var string $content @var array $menu @var array $flashes */
use App\Core\Auth;

$user = Auth::user();
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="color-scheme" content="light dark">
    <script src="<?= e(asset('js/theme.js')) ?>"></script>
    <title><?= e($title) ?> | دیجی بایل پی</title>
    <link rel="stylesheet" href="<?= e(asset('css/core/variables.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/reset.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/typography.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/brand.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/layout.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/buttons.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/forms.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/tables.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/badges.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/notifications.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/pagination.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/stats.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/filters.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/print.css')) ?>" media="print">
    <?php if (in_array($page, ['dashboard', 'reports'], true)): ?>
    <link rel="stylesheet" href="<?= e(asset('css/components/charts.css')) ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?= e(asset('css/pages/' . $page . '.css')) ?>">
</head>
<body class="pg-<?= e($page) ?>">
<div class="shell">
    <aside class="sidebar" id="sidebar">
        <div class="sidebar__brand">
            <a class="sidebar__home" href="/dashboard" aria-label="صفحه اصلی"><span class="brand-mark"><?= icon('logo', 22) ?></span>
            <div>
                <strong>دیجی بایل پی</strong>
                <small>نگار آذین فدک ایران</small>
            </div></a>
            <button class="btn btn--icon sidebar__close" type="button" data-nav-close aria-label="بستن منو"><?= icon('x', 18) ?></button>
        </div>
        <nav class="sidebar__nav" aria-label="منوی اصلی">
            <?php $section = null; foreach ($menu as $item): ?>
                <?php if (($item['section'] ?? '') !== '' && $item['section'] !== $section): $section = $item['section']; ?>
                    <span class="sidebar__section"><?= e($section) ?></span>
                <?php endif; ?>
                <a class="sidebar__link<?= $item['active'] ? ' is-active' : '' ?>" href="<?= e($item['url']) ?>">
                    <?= icon($item['icon']) ?><span><?= e($item['title']) ?></span>
                </a>
            <?php endforeach; ?>
        </nav>
        <form class="sidebar__logout" method="post" action="/logout">
            <?= csrf_field() ?>
            <button class="btn btn--ghost btn--block" type="submit"><?= icon('logout', 18) ?><span>خروج</span></button>
        </form>
    </aside>
    <button class="scrim" type="button" data-nav-close aria-label="بستن منو" tabindex="-1"></button>
    <div class="main">
        <header class="topbar">
            <button class="btn btn--icon topbar__toggle" type="button" id="sidebarToggle" aria-label="باز کردن منو" aria-controls="sidebar" aria-expanded="false"><?= icon('menu') ?></button>
            <a class="btn btn--ghost btn--sm topbar__home" href="/" title="مشاهده صفحه اصلی (سایت عمومی)"><?= icon('home', 18) ?><span>صفحه اصلی</span></a>
            <h1 class="topbar__title"><?= e($title) ?></h1>
            <button class="topbar__theme" type="button" data-theme-toggle aria-label="تغییر پوسته روشن/تیره" title="پوسته روشن/تیره"><span class="theme-icon--light"><?= icon('sun', 20) ?></span><span class="theme-icon--dark"><?= icon('moon', 20) ?></span></button>
            <?php $alertCount = \App\Services\AlertService::count(\App\Core\Auth::companyId()); ?>
            <a class="topbar__bell" href="/alerts" title="هشدارها" aria-label="هشدارها"><?= icon('bell', 20) ?><?php if ($alertCount > 0): ?><span class="topbar__badge"><?= fa((string) min($alertCount, 99)) ?></span><?php endif; ?></a>
            <a class="topbar__user" href="/account" title="حساب کاربری">
                <span class="avatar" aria-hidden="true"><?= e(mb_substr((string) ($user['full_name'] ?? '؟'), 0, 1)) ?></span>
                <span class="topbar__who">
                    <span class="topbar__name"><?= e($user['full_name'] ?? '') ?></span>
                    <small><?= e(($user['role_name'] ?? '') . ' · ' . ($user['company_name'] ?? '')) ?></small>
                </span>
            </a>
        </header>
        <main class="content">
            <?php foreach ($flashes as [$type, $msg]): ?>
                <div class="notice notice--<?= e($type) ?>" role="alert"><?= e($msg) ?></div>
            <?php endforeach; ?>
            <?= $content ?>
        </main>
    </div>
</div>
<script src="<?= e(asset('js/app.js')) ?>" defer></script>
<?php if (is_file(BASE_PATH . '/public/assets/js/pages/' . $page . '.js')): ?>
<script src="<?= e(asset('js/pages/' . $page . '.js')) ?>" defer></script>
<?php endif; ?>
</body>
</html>
