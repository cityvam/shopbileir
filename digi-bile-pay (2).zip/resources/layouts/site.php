<?php
/** @var string $title @var string $page @var string $content @var array $flashes @var string $brand @var array $merchants @var array $contact @var bool $loggedIn */
$year = (new \DateTime())->format('Y');
$yearFa = fa((string) \App\Core\Jalali::toJalali((int) $year, (int) date('n'), (int) date('j'))[0]);
$nav = [['features', 'امکانات'], ['plans', 'طرح‌های تسهیلاتی'], ['calc', 'محاسبه قسط']];
if (!empty($merchants)) { $nav[] = ['market', 'فروشگاه‌ها']; }
$nav[] = ['faq', 'پرسش‌های متداول'];
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?= e($brand) ?> — اعتبار لحظه‌ای و خرید اقساطی با شرایط شفاف. طرح‌ها را ببینید، قسط خود را محاسبه کنید و درخواست اعتبار ثبت کنید.">
    <meta name="color-scheme" content="light dark">
    <meta property="og:title" content="<?= e($brand) ?> | خرید اقساطی هوشمند">
    <meta property="og:type" content="website">
    <meta name="theme-color" content="#4f46e5">
    <title><?= e($brand) ?> | خرید اقساطی هوشمند</title>
    <script src="<?= e(asset('js/theme.js')) ?>"></script>
    <link rel="stylesheet" href="<?= e(asset('css/core/variables.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/reset.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/typography.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/brand.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/buttons.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/forms.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/notifications.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/pages/site.css')) ?>">
</head>
<body class="pg-site">
<a class="skip-link" href="#main">پرش به محتوا</a>
<header class="site-header" id="top">
    <div class="container site-header__inner">
        <a class="site-brand" href="/" aria-label="<?= e($brand) ?> — صفحه اصلی">
            <?php if (!empty($logo)): ?><img class="brand-logo" src="<?= e($logo) ?>" alt="" width="40" height="40"><?php else: ?><span class="brand-mark"><?= icon('logo', 22) ?></span><?php endif; ?>
            <span class="site-brand__text"><strong><?= e($brand) ?></strong><small>تسهیلات و خرید اقساطی</small></span>
        </a>
        <nav class="site-nav" id="siteNav" aria-label="منوی اصلی">
            <?php foreach ($nav as [$id, $label]): ?><a href="#<?= e($id) ?>"><?= e($label) ?></a><?php endforeach; ?>
            <div class="site-nav__cta">
                <a class="btn btn--ghost" href="/portal">ورود مشتریان</a>
                <a class="btn btn--ghost" href="<?= $loggedIn ? '/dashboard' : '/login' ?>"><?= icon('user', 18) ?><span><?= $loggedIn ? 'ورود به پنل مدیریت' : 'ورود کارکنان' ?></span></a>
                <a class="btn btn--primary" href="#apply">درخواست اعتبار</a>
            </div>
        </nav>
        <div class="site-header__tools">
            <button class="site-icon-btn" type="button" data-theme-toggle aria-label="تغییر پوسته روشن/تیره"><span class="theme-icon--light"><?= icon('sun', 20) ?></span><span class="theme-icon--dark"><?= icon('moon', 20) ?></span></button>
            <button class="site-icon-btn site-header__toggle" type="button" data-site-nav-toggle aria-controls="siteNav" aria-expanded="false" aria-label="باز کردن منو"><?= icon('menu', 22) ?></button>
        </div>
    </div>
</header>

<main id="main">
    <?php if ($flashes): ?>
    <div class="container site-flash" id="flash">
        <?php foreach ($flashes as [$type, $msg]): ?><div class="notice notice--<?= e($type) ?>" role="alert"><?= e($msg) ?></div><?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?= $content ?>
</main>

<footer class="site-footer">
    <div class="container site-footer__grid">
        <div class="site-footer__about">
            <a class="site-brand site-brand--footer" href="/"><?php if (!empty($logo)): ?><img class="brand-logo" src="<?= e($logo) ?>" alt="" width="40" height="40"><?php else: ?><span class="brand-mark"><?= icon('logo', 22) ?></span><?php endif; ?><span class="site-brand__text"><strong><?= e($brand) ?></strong><small>تسهیلات و خرید اقساطی</small></span></a>
            <p><?= e($contact['footer_note'] ?? '') ?></p>
        </div>
        <nav class="site-footer__col" aria-label="دسترسی سریع">
            <h2>دسترسی سریع</h2>
            <?php foreach ($nav as [$id, $label]): ?><a href="#<?= e($id) ?>"><?= e($label) ?></a><?php endforeach; ?>
            <a href="#apply">درخواست اعتبار</a>
        </nav>
        <nav class="site-footer__col" aria-label="حساب کاربری">
            <h2>حساب کاربری</h2>
            <a href="/portal">ورود مشتریان</a>
            <a href="<?= $loggedIn ? '/dashboard' : '/login' ?>"><?= $loggedIn ? 'پنل مدیریت' : 'ورود کارکنان' ?></a>
            <a href="#faq">راهنمای پرداخت اقساط</a>
        </nav>
        <div class="site-footer__col">
            <h2>تماس با ما</h2>
            <?php if (!empty($contact['phone'])): ?><span class="site-footer__item"><?= icon('phone', 16) ?><bdi><?= e($contact['phone']) ?></bdi></span><?php endif; ?>
            <?php if (!empty($contact['email'])): ?><span class="site-footer__item"><?= icon('mail', 16) ?><bdi><?= e($contact['email']) ?></bdi></span><?php endif; ?>
            <?php if (!empty($contact['address'])): ?><span class="site-footer__item"><?= icon('pin', 16) ?><span><?= e($contact['address']) ?></span></span><?php endif; ?>
            <?php if (empty($contact['phone']) && empty($contact['email']) && empty($contact['address'])): ?><a href="#apply">ثبت درخواست و تماس کارشناس</a><?php endif; ?>
        </div>
    </div>
    <div class="container site-footer__bottom">
        <span>© <?= $yearFa ?> <?= e($brand) ?>. همه‌ی حقوق محفوظ است.</span>
        <span>اطلاعات نرخ و اقساط جنبه‌ی اطلاع‌رسانی دارد؛ شرایط نهایی در قرارداد درج می‌شود.</span>
        <a href="#top" class="site-footer__up"><?= icon('arrow-left', 16) ?><span>بازگشت به بالا</span></a>
    </div>
</footer>
<script src="<?= e(asset('js/app.js')) ?>" defer></script>
<script src="<?= e(asset('js/pages/site.js')) ?>" defer></script>
</body>
</html>
