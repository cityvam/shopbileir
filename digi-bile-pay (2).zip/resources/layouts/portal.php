<?php
/** @var string $title @var string $page @var string $content @var array $flashes */
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="color-scheme" content="light dark">
    <script src="<?= e(asset('js/theme.js')) ?>"></script>
    <title><?= e($title) ?> | دیجی بایل پی</title>
    <link rel="stylesheet" href="<?= e(asset('css/core/variables.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/reset.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/typography.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/brand.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/layout.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/buttons.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/forms.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/badges.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/stats.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/tables.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/notifications.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/pages/' . $page . '.css')) ?>">
</head>
<body class="pg-<?= e($page) ?>">
<header class="portal-bar">
    <div class="portal-bar__inner">
        <a class="portal-bar__brand" href="/portal"><?php if (!empty($logo)): ?><img class="brand-logo" src="<?= e($logo) ?>" alt="" width="40" height="40"><?php else: ?><span class="brand-mark"><?= icon('logo', 22) ?></span><?php endif; ?><strong>حساب من</strong></a>
        <div class="portal-bar__tools">
            <a class="btn btn--ghost" href="/">صفحه‌ی اصلی</a>
            <form method="post" action="/portal/logout"><?= csrf_field() ?><button class="btn btn--ghost" type="submit">خروج</button></form>
        </div>
    </div>
</header>
<main class="portal-main">
    <?php foreach ($flashes as [$type, $msg]): ?>
        <div class="notice notice--<?= e($type) ?>" role="alert"><?= e($msg) ?></div>
    <?php endforeach; ?>
    <?= $content ?>
</main>
<script src="<?= e(asset('js/app.js')) ?>" defer></script>
</body>
</html>
