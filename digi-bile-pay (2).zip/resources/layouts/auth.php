<?php
/** @var string $title @var string $page @var string $content @var array $flashes */
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="color-scheme" content="light dark">
    <script src="<?= e(asset('js/theme.js')) ?>"></script>
    <title><?= e($title) ?> | دیجی بایل پی</title>
    <link rel="stylesheet" href="<?= e(asset('css/core/variables.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/reset.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/typography.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/core/brand.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/buttons.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/forms.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/components/notifications.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/pages/' . $page . '.css')) ?>">
</head>
<body class="pg-<?= e($page) ?>">
<main class="auth-wrap">
<?php if ($page === 'login'): ?>
    <aside class="auth-hero" aria-hidden="true">
        <span class="brand-mark brand-mark--lg"><?= icon('logo', 30) ?></span>
        <h2>سامانه یکپارچه اعتبار، اقساط و حسابداری</h2>
        <p>پذیرش، تأیید و وصول تسهیلات، بازار فروشندگان و دفتر کل دوطرفه؛ همه در یک پنل امن و چندشرکتی.</p>
        <ul>
            <li><?= icon('shield', 18) ?><span>کنترل دسترسی نقش‌محور و تأیید دومرحله‌ای</span></li>
            <li><?= icon('scale', 18) ?><span>حسابداری سپیدار‌گونه با تراز و صورت‌های مالی</span></li>
            <li><?= icon('chart', 18) ?><span>گزارش‌های لحظه‌ای مطالبات و وصول</span></li>
        </ul>
    </aside>
<?php endif; ?>
    <div class="auth-panel">
        <?php foreach ($flashes as [$type, $msg]): ?>
            <div class="notice notice--<?= e($type) ?>" role="alert"><?= e($msg) ?></div>
        <?php endforeach; ?>
        <?= $content ?>
    </div>
</main>
<script src="<?= e(asset('js/app.js')) ?>" defer></script>
</body>
</html>
