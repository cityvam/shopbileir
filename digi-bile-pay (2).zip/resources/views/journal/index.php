<?php use App\Core\Auth;
$qs = static function (array $over) use ($f): string {
    $a = array_filter(array_merge($f, $over), static fn ($v) => $v !== '' && $v !== null);
    return http_build_query($a);
};
$sortLink = static function (string $key, string $label) use ($f, $qs): string {
    $dir = $f['sort'] === $key && $f['dir'] === 'asc' ? 'desc' : 'asc';
    $mark = $f['sort'] === $key ? ($f['dir'] === 'asc' ? ' ▲' : ' ▼') : '';
    return '<a class="sort-link" href="/journal?' . e($qs(['sort' => $key, 'dir' => $dir, 'page' => ''])) . '">' . e($label) . $mark . '</a>';
};
$advanced = $f['q'] !== '' || $f['source'] !== '' || $f['min'] !== '' || $f['max'] !== '' || $f['no_from'] !== '' || $f['no_to'] !== '';
?>
<section class="card">
    <div class="card__head">
        <h2>اسناد حسابداری</h2>
        <div class="card__tools">
            <a class="btn btn--secondary btn--sm" href="/journal?<?= e($qs(['format' => 'csv'])) ?>"><?= icon('download', 16) ?><span>CSV</span></a>
            <a class="btn btn--secondary btn--sm" href="/journal?<?= e($qs(['format' => 'xlsx'])) ?>"><?= icon('download', 16) ?><span>Excel</span></a>
            <?php if (Auth::can('accounting.post')): ?><a class="btn btn--primary btn--sm" href="/journal/create"><?= icon('plus', 16) ?><span>سند جدید</span></a><?php endif; ?>
        </div>
    </div>
    <div class="tabs">
        <?php foreach (['' => 'همه', 'final' => 'قطعی', 'draft' => 'موقت'] as $k => $label): ?>
            <a class="tabs__link<?= $f['status'] === $k ? ' is-active' : '' ?>" href="/journal?<?= e($qs(['status' => $k, 'page' => ''])) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
    </div>
    <form class="filter-bar" method="get" action="/journal">
        <input type="hidden" name="status" value="<?= e($f['status']) ?>">
        <div class="field"><label for="from">از تاریخ</label><input class="input input--ltr input--sm" id="from" name="from" value="<?= e($f['from']) ?>" placeholder="1405/01/01"></div>
        <div class="field"><label for="to">تا تاریخ</label><input class="input input--ltr input--sm" id="to" name="to" value="<?= e($f['to']) ?>" placeholder="1405/12/29"></div>
        <div class="field field--grow"><label for="q">جست‌وجو در شرح و مرجع</label><input class="input input--sm" id="q" name="q" value="<?= e($f['q']) ?>"></div>
        <details class="filter-bar__more" <?= $advanced ? 'open' : '' ?>>
            <summary>فیلتر پیشرفته</summary>
            <div class="filter-bar__grid">
                <div class="field"><label for="no_from">از شماره سند</label><input class="input input--ltr input--sm" id="no_from" name="no_from" value="<?= e($f['no_from']) ?>"></div>
                <div class="field"><label for="no_to">تا شماره سند</label><input class="input input--ltr input--sm" id="no_to" name="no_to" value="<?= e($f['no_to']) ?>"></div>
                <div class="field"><label for="min">حداقل مبلغ</label><input class="input input--ltr input--sm" id="min" name="min" value="<?= e($f['min']) ?>" data-money></div>
                <div class="field"><label for="max">حداکثر مبلغ</label><input class="input input--ltr input--sm" id="max" name="max" value="<?= e($f['max']) ?>" data-money></div>
                <div class="field"><label for="source">منشأ</label>
                    <select class="input input--sm" id="source" name="source">
                        <option value="">همه</option><option value="manual" <?= $f['source'] === 'manual' ? 'selected' : '' ?>>دستی</option><option value="auto" <?= $f['source'] === 'auto' ? 'selected' : '' ?>>خودکار</option>
                    </select>
                </div>
            </div>
        </details>
        <div class="filter-bar__actions">
            <button class="btn btn--primary btn--sm" type="submit"><?= icon('search', 16) ?><span>اعمال فیلتر</span></button>
            <a class="btn btn--ghost btn--sm" href="/journal">پاک‌کردن</a>
        </div>
    </form>
    <?php foreach ($errors as $er): ?><p class="neg"><?= e($er) ?></p><?php endforeach; ?>
    <p class="hint"><?= num((int) $sum['c']) ?> سند · جمع مبلغ: <?= money((int) $sum['s']) ?></p>
    <?php if (!$rows): ?><p class="empty">سندی با این فیلترها یافت نشد.</p><?php else: ?>
    <div class="table-wrap"><table class="table table--stack">
        <thead><tr><th><?= $sortLink('no', 'شماره') ?></th><th><?= $sortLink('date', 'تاریخ') ?></th><th>شرح</th><th>مرجع</th><th>منشأ</th><th>وضعیت</th><th><?= $sortLink('amount', 'مبلغ') ?></th><th></th></tr></thead>
        <tbody><?php foreach ($rows as $r): ?>
            <tr<?= $r['reversed_by'] ? ' class="is-muted"' : '' ?>>
                <td>#<?= fa($r['entry_no']) ?></td><td><?= jdate($r['entry_date']) ?></td><td class="wrap"><?= e($r['description']) ?></td>
                <td><?= e($r['reference'] ?? '—') ?></td>
                <td><?= $r['source_type'] === 'manual' ? badge('دستی', 'info') : badge('خودکار', 'muted') ?></td>
                <td><?= $r['status'] === 'draft' ? badge('موقت', 'warn') : badge('قطعی', 'ok') ?><?= $r['reversed_by'] ? ' ' . badge('ابطال‌شده', 'bad') : '' ?><?= $r['reversal_of'] ? ' ' . badge('سند ابطال', 'muted') : '' ?></td>
                <td><?= money((int) $r['amount']) ?></td>
                <td class="table__actions">
                    <a class="btn btn--secondary btn--sm" href="/journal/<?= (int) $r['id'] ?>"><?= icon('eye', 16) ?><span>مشاهده</span></a>
                    <?php if ($r['status'] === 'draft' && $r['source_type'] === 'manual' && Auth::can('accounting.post')): ?>
                        <a class="btn btn--secondary btn--sm" href="/journal/<?= (int) $r['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
