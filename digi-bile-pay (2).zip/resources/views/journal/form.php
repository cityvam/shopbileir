<?php
$isEdit = $e !== null;
$action = $isEdit ? '/journal/' . (int) $e['id'] : '/journal';
$row = static function (array $r, array $accounts, array $details, array $centers, bool $tpl = false): string {
    ob_start(); ?>
    <tr class="je-row">
        <td><select class="input input--sm" name="account_id[]" aria-label="حساب">
            <option value="">انتخاب حساب</option>
            <?php foreach ($accounts as $a): ?><option value="<?= (int) $a['id'] ?>" <?= (string) $r['account_id'] === (string) $a['id'] ? 'selected' : '' ?>><?= fa($a['code']) ?> · <?= e($a['name']) ?></option><?php endforeach; ?>
        </select></td>
        <td><select class="input input--sm" name="detail_id[]" aria-label="تفصیلی"><option value="">—</option>
            <?php foreach ($details as $d): ?><option value="<?= (int) $d['id'] ?>" <?= (string) ($r['detail_id'] ?? '') === (string) $d['id'] ? 'selected' : '' ?>><?= e($d['code']) ?> · <?= e($d['name']) ?></option><?php endforeach; ?></select></td>
        <td><select class="input input--sm" name="cost_center_id[]" aria-label="مرکز هزینه"><option value="">—</option>
            <?php foreach ($centers as $d): ?><option value="<?= (int) $d['id'] ?>" <?= (string) ($r['cost_center_id'] ?? '') === (string) $d['id'] ? 'selected' : '' ?>><?= e($d['code']) ?> · <?= e($d['name']) ?></option><?php endforeach; ?></select></td>
        <td><input class="input input--sm" name="line_desc[]" value="<?= e($r['description']) ?>" placeholder="شرح ردیف (اختیاری)" maxlength="250"></td>
        <td><input class="input input--ltr input--sm je-debit" name="debit[]" value="<?= e($r['debit']) ?>" inputmode="numeric" data-money aria-label="بدهکار"></td>
        <td><input class="input input--ltr input--sm je-credit" name="credit[]" value="<?= e($r['credit']) ?>" inputmode="numeric" data-money aria-label="بستانکار"></td>
        <td><button class="btn btn--icon btn--sm je-remove" type="button" aria-label="حذف ردیف"><?= icon('trash', 16) ?></button></td>
    </tr>
    <?php return (string) ob_get_clean();
};
?>
<form class="card form journal-form" method="post" action="<?= e($action) ?>" id="journalForm">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field"><label for="entry_date">تاریخ سند (شمسی)</label><input class="input input--ltr" id="entry_date" name="entry_date" value="<?= e($date) ?>" placeholder="1405/08/10" required></div>
        <div class="field"><label for="reference">مرجع / شماره مدرک (اختیاری)</label><input class="input" id="reference" name="reference" value="<?= e(old('reference', $e['reference'] ?? '')) ?>" maxlength="60"></div>
        <div class="field field--wide"><label for="description">شرح سند</label><input class="input" id="description" name="description" value="<?= e(old('description', $e['description'] ?? '')) ?>" required></div>
    </div>
    <div class="table-wrap"><table class="table je-table">
        <thead><tr><th>حساب</th><th>تفصیلی</th><th>مرکز هزینه</th><th>شرح ردیف</th><th>بدهکار</th><th>بستانکار</th><th></th></tr></thead>
        <tbody id="jeBody"><?php foreach ($rows as $r) { echo $row($r, $accounts, $details, $centers); } ?></tbody>
        <tfoot>
            <tr><th colspan="4">جمع</th><th id="jeDebit">۰</th><th id="jeCredit">۰</th><th></th></tr>
            <tr><th colspan="4">اختلاف</th><th colspan="2" id="jeDiff" class="je-diff">—</th><th></th></tr>
        </tfoot>
    </table></div>
    <template id="jeTemplate"><?= $row(['account_id' => '', 'debit' => '', 'credit' => '', 'description' => '', 'detail_id' => '', 'cost_center_id' => ''], $accounts, $details, $centers, true) ?></template>
    <div class="form__actions">
        <button class="btn btn--secondary" type="button" id="jeAdd"><?= icon('plus', 16) ?><span>افزودن ردیف</span></button>
        <button class="btn btn--primary" type="submit" name="status" value="final"><?= icon('check', 18) ?><span>ثبت قطعی</span></button>
        <button class="btn btn--secondary" type="submit" name="status" value="draft">ذخیره موقت</button>
        <a class="btn btn--ghost" href="<?= $isEdit ? '/journal/' . (int) $e['id'] : '/journal' ?>">انصراف</a>
    </div>
    <p class="hint">سند قطعی باید متوازن باشد؛ سند موقت می‌تواند ناقص بماند و در گزارش‌ها نمی‌آید. هر ردیف فقط بدهکار یا بستانکار دارد.</p>
</form>
