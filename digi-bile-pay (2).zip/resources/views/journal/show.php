<?php use App\Core\Auth;
$can = Auth::can('accounting.post');
$d = $c = 0;
$manualDraft = $e['status'] === 'draft' && $e['source_type'] === 'manual';
$reversible = $e['status'] === 'final' && $e['source_type'] === 'manual' && !$e['reversed_by'] && !$e['reversal_of'];
?>
<section class="card journal-head">
    <div class="card__head">
        <h2>سند #<?= fa($e['entry_no']) ?> · <?= jdate($e['entry_date']) ?>
            <?= $e['status'] === 'draft' ? badge('موقت', 'warn') : badge('قطعی', 'ok') ?>
            <?= $e['reversed_by'] ? badge('ابطال‌شده', 'bad') : '' ?></h2>
        <div class="card__tools">
            <button class="btn btn--secondary btn--sm" type="button" data-print><?= icon('file-text', 16) ?><span>چاپ / PDF</span></button>
            <a class="btn btn--ghost btn--sm" href="/journal">بازگشت</a>
        </div>
    </div>
    <p><?= e($e['description']) ?></p>
    <dl class="journal-facts">
        <div><dt>مرجع</dt><dd><?= e($e['reference'] ?? '—') ?></dd></div>
        <div><dt>سال مالی</dt><dd><?= $fy ? e($fy['title']) . ($fy['status'] === 'closed' ? ' (بسته)' : '') : '—' ?></dd></div>
        <div><dt>منشأ</dt><dd><?= $e['source_type'] === 'manual' ? 'دستی' : 'خودکار (' . e($e['source_type']) . ($e['source_id'] ? ' #' . fa($e['source_id']) : '') . ')' ?></dd></div>
        <div><dt>ثبت‌کننده</dt><dd><?= e($creator ?? 'سیستم') ?> · <?= jdate($e['created_at'], true) ?></dd></div>
        <?php if ($reversedBy): ?><div><dt>سند ابطال</dt><dd><a href="/journal/<?= (int) $reversedBy['id'] ?>">#<?= fa($reversedBy['entry_no']) ?></a></dd></div><?php endif; ?>
        <?php if ($reversalOf): ?><div><dt>ابطال‌کننده سند</dt><dd><a href="/journal/<?= (int) $reversalOf['id'] ?>">#<?= fa($reversalOf['entry_no']) ?></a></dd></div><?php endif; ?>
    </dl>
</section>

<section class="card">
    <div class="table-wrap"><table class="table">
        <thead><tr><th>کد</th><th>حساب</th><th>تفصیلی</th><th>مرکز هزینه</th><th>شرح ردیف</th><th>بدهکار</th><th>بستانکار</th></tr></thead>
        <tbody><?php foreach ($lines as $l): $d += (int) $l['debit']; $c += (int) $l['credit']; ?>
            <tr><td class="ltr"><?= fa($l['code']) ?></td><td><a href="/accounts/<?= (int) $l['account_id'] ?>"><?= e($l['name']) ?></a></td><td><?= $l['detail_id'] ? '<a href="/dimensions/' . (int) $l['detail_id'] . '">' . e($l['detail_name']) . '</a>' : '—' ?></td><td><?= $l['cost_center_id'] ? '<a href="/dimensions/' . (int) $l['cost_center_id'] . '">' . e($l['cc_name']) . '</a>' : '—' ?></td><td class="wrap"><?= e($l['description'] ?? '') ?></td><td><?= (int) $l['debit'] ? num((int) $l['debit']) : '—' ?></td><td><?= (int) $l['credit'] ? num((int) $l['credit']) : '—' ?></td></tr>
        <?php endforeach; ?></tbody>
        <tfoot><tr><th colspan="5">جمع <?= $d === $c ? '' : badge('نامتوازن', 'bad') ?></th><th><?= num($d) ?></th><th><?= num($c) ?></th></tr></tfoot>
    </table></div>
</section>

<?php if ($can && $manualDraft): ?>
<section class="card journal-actions">
    <p class="hint">سند موقت در هیچ گزارشی شمرده نمی‌شود. پس از قطعی‌شدن، فقط با صدور سند معکوس قابل ابطال است.</p>
    <div class="journal-actions__row">
        <a class="btn btn--secondary" href="/journal/<?= (int) $e['id'] ?>/edit"><?= icon('edit', 18) ?><span>ویرایش</span></a>
        <form method="post" action="/journal/<?= (int) $e['id'] ?>/finalize" data-confirm="سند قطعی شود؟ پس از آن قابل ویرایش نخواهد بود."><?= csrf_field() ?><button class="btn btn--success" type="submit"><?= icon('check', 18) ?><span>قطعی‌سازی</span></button></form>
        <form method="post" action="/journal/<?= (int) $e['id'] ?>/delete" data-confirm="سند موقت حذف شود؟"><?= csrf_field() ?><button class="btn btn--danger" type="submit"><?= icon('trash', 18) ?><span>حذف سند موقت</span></button></form>
    </div>
</section>
<?php elseif ($can && $reversible): ?>
<section class="card journal-actions">
    <p class="hint">سند قطعی حذف یا ویرایش نمی‌شود؛ برای اصلاح، سند معکوس با تاریخ دلخواه (در سال مالی باز) صادر می‌شود و سپس سند درست ثبت کنید.</p>
    <form class="journal-actions__row" method="post" action="/journal/<?= (int) $e['id'] ?>/reverse" data-confirm="سند معکوس صادر شود؟ این عملیات برگشت‌پذیر نیست.">
        <?= csrf_field() ?>
        <div class="field"><label for="date">تاریخ سند ابطال (شمسی)</label><input class="input input--ltr input--sm" id="date" name="date" value="<?= e(jdate(date('Y-m-d'))) ?>"></div>
        <button class="btn btn--danger" type="submit"><?= icon('x', 18) ?><span>ابطال با سند معکوس</span></button>
    </form>
</section>
<?php endif; ?>
