<section class="stat-grid">
    <?php foreach ([
        ['مشتریان فعال', num($stats['customers']), '', 'users', ''],
        ['تسهیلات فعال', num($stats['active_loans']), '', 'file-text', ''],
        ['در انتظار تأیید', num($stats['pending']), '', 'clipboard', 'warn'],
        ['مطالبات باقی‌مانده', money_unit($stats['outstanding']), '', 'wallet', ''],
        ['اقساط معوق', num($stats['overdue_count']), money($stats['overdue_sum']), 'alert', 'bad'],
        ['وصولی این ماه', money_unit($stats['collected_month']), '', 'banknote', 'ok'],
        ['فروش این ماه', money_unit($stats['sales_month']), num($stats['orders_month']) . ' سفارش', 'cart', ''],
        ['فروشندگان فعال', num($stats['merchants']), '', 'store', ''],
    ] as [$label, $value, $sub, $ic, $tone]): ?>
    <article class="stat-card<?= $tone ? ' stat-card--' . $tone : '' ?>">
        <span class="stat-card__icon"><?= icon($ic, 22) ?></span>
        <span class="stat-card__label"><?= e($label) ?></span>
        <strong class="stat-card__value"><?= $value ?></strong>
        <?php if ($sub): ?><small><?= $sub ?></small><?php endif; ?>
    </article>
    <?php endforeach; ?>
</section>

<div class="dash-grid">
    <section class="card"><div class="card__head"><h2>وصولی ۶ ماه اخیر</h2></div><?= $barsChart ?></section>
    <section class="card"><div class="card__head"><h2>وضعیت تسهیلات</h2></div><?= $donut ?></section>
    <section class="card"><div class="card__head"><h2>سن مطالبات معوق</h2></div><?= $agingChart ?></section>
    <section class="card">
        <div class="card__head"><h2>آخرین فعالیت‌ها</h2></div>
        <?php if (!$activity): ?><p class="empty">فعالیتی ثبت نشده است.</p><?php else: ?>
        <ul class="activity"><?php foreach ($activity as $a): ?>
            <li><span class="activity__act ltr"><?= e($a['action']) ?></span><span><?= e($a['full_name'] ?? 'سیستم') ?></span><time><?= jdate($a['created_at'], true) ?></time></li>
        <?php endforeach; ?></ul>
        <?php endif; ?>
    </section>
</div>

<section class="card">
    <div class="card__head">
        <h2>نزدیک‌ترین اقساط</h2>
        <?php if (\App\Core\Auth::can('installments.view')): ?>
            <a class="btn btn--secondary btn--sm" href="/installments">همه اقساط</a>
        <?php endif; ?>
    </div>
    <?php if (!$upcoming): ?>
        <p class="empty">قسط پرداخت‌نشده‌ای وجود ندارد.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="table table--stack">
                <thead><tr><th>مشتری</th><th>تسهیلات</th><th>قسط</th><th>سررسید</th><th>باقی‌مانده</th></tr></thead>
                <tbody>
                <?php foreach ($upcoming as $r): ?>
                    <tr>
                        <td><?= e($r['full_name']) ?></td>
                        <td>#<?= fa($r['loan_id']) ?></td>
                        <td><?= fa($r['seq']) ?></td>
                        <td><?= jdate($r['due_date']) ?><?= $r['due_date'] < $today ? ' ' . badge('معوق', 'bad') : '' ?></td>
                        <td><?= money((int) $r['remaining']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
