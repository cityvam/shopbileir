<?php
/**
 * @var \App\Core\ListFilter $lf
 * @var string $action
 * @var list<array{key:string,label:string,type:string,options?:array<string,string>,adv?:bool,money?:bool}> $fields
 * type: text | date | money | number | select
 */
$main = array_filter($fields, static fn ($f) => empty($f['adv']));
$adv = array_filter($fields, static fn ($f) => !empty($f['adv']));
$advKeys = array_column($adv, 'key');
$render = static function (array $f) use ($lf): void {
    $k = $f['key'];
    $val = $lf->v[$k] ?? '';
    echo '<div class="field' . (($f['type'] ?? '') === 'text' ? ' field--grow' : '') . '"><label for="f_' . e($k) . '">' . e($f['label']) . '</label>';
    if ($f['type'] === 'select') {
        echo '<select class="input input--sm" id="f_' . e($k) . '" name="' . e($k) . '"><option value="">همه</option>';
        foreach ($f['options'] as $ov => $ol) {
            echo '<option value="' . e($ov) . '"' . ((string) $ov === $val ? ' selected' : '') . '>' . e($ol) . '</option>';
        }
        echo '</select>';
    } else {
        $ltr = $f['type'] === 'text' ? '' : ' input--ltr';
        $ph = $f['type'] === 'date' ? ' placeholder="1405/01/01"' : '';
        $money = $f['type'] === 'money' ? ' data-money' : '';
        echo '<input class="input input--sm' . $ltr . '" id="f_' . e($k) . '" name="' . e($k) . '" value="' . e($val) . '"' . $ph . $money . '>';
    }
    echo '</div>';
};
?>
<form class="filter-bar" method="get" action="<?= e($action) ?>">
    <?php foreach ($hidden ?? [] as $hk => $hv): ?><input type="hidden" name="<?= e($hk) ?>" value="<?= e($hv) ?>"><?php endforeach; ?>
    <?php foreach ($main as $f) { $render($f); } ?>
    <?php if ($adv): ?>
        <details class="filter-bar__more" <?= $lf->active($advKeys) ? 'open' : '' ?>>
            <summary>فیلتر پیشرفته</summary>
            <div class="filter-bar__grid"><?php foreach ($adv as $f) { $render($f); } ?></div>
        </details>
    <?php endif; ?>
    <div class="filter-bar__actions">
        <button class="btn btn--primary btn--sm" type="submit"><?= icon('search', 16) ?><span>اعمال فیلتر</span></button>
        <a class="btn btn--secondary btn--sm" href="<?= e($action) ?>">پاک‌کردن</a>
        <?php if (!empty($csv)): ?><a class="btn btn--secondary btn--sm" href="<?= e($action . '?' . $lf->qs(['format' => 'csv'])) ?>"><?= icon('download', 16) ?><span>CSV</span></a><a class="btn btn--secondary btn--sm" href="<?= e($action . '?' . $lf->qs(['format' => 'xlsx'])) ?>"><?= icon('download', 16) ?><span>Excel</span></a><?php endif; ?>
    </div>
</form>
<?php foreach ($lf->errors as $er): ?><p class="neg"><?= e($er) ?></p><?php endforeach; ?>
