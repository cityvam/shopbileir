<?php
/** @var array $pg */
if ($pg['pages'] <= 1) {
    return;
}
$query = $_GET;
unset($query['page']);
$base = '?' . ($query ? http_build_query($query) . '&' : '');
?>
<nav class="pagination" aria-label="صفحه‌بندی">
    <?php if ($pg['page'] > 1): ?>
        <a class="pagination__link" href="<?= e($base . 'page=' . ($pg['page'] - 1)) ?>">قبلی</a>
    <?php endif; ?>
    <span class="pagination__info">صفحه <?= fa($pg['page']) ?> از <?= fa($pg['pages']) ?> (<?= fa($pg['total']) ?> مورد)</span>
    <?php if ($pg['page'] < $pg['pages']): ?>
        <a class="pagination__link" href="<?= e($base . 'page=' . ($pg['page'] + 1)) ?>">بعدی</a>
    <?php endif; ?>
</nav>
