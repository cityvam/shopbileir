<?php /** فیلد کپچای عددی؛ ورودی: $scope */ ?>
<div class="field captcha">
    <label for="captcha_<?= e($scope) ?>">کد امنیتی</label>
    <div class="captcha__row">
        <img class="captcha__img" src="/captcha?scope=<?= e($scope) ?>&amp;r=<?= e(bin2hex(random_bytes(3))) ?>" alt="کد امنیتی ۶ رقمی" width="200" height="68" data-captcha-img data-captcha-src="/captcha?scope=<?= e($scope) ?>">
        <button type="button" class="btn btn--icon" data-captcha-refresh title="کد جدید" aria-label="دریافت کد جدید"><?= icon('refresh', 18) ?></button>
    </div>
    <input class="input input--ltr captcha__input" id="captcha_<?= e($scope) ?>" name="captcha" type="text" inputmode="numeric" pattern="[0-9۰-۹]{6}" maxlength="6" minlength="6" autocomplete="off" placeholder="۶ رقم داخل تصویر" required>
</div>
