<?php
/**
 * تاریخچه‌ی رویدادهای یک موجودیت از گزارش حسابرسی، با نمایش «قبل ← بعد» فیلدهای تغییرکرده.
 * @var list<array> $events  هر رویداد: action, details(json), created_at, full_name
 */
if (empty($events)) {
    return;
}
?>
<section class="card">
    <div class="card__head"><h2>تاریخچه تغییرات</h2></div>
    <ul class="timeline">
        <?php foreach ($events as $ev):
            $d = $ev['details'] ? (json_decode((string) $ev['details'], true) ?: []) : [];
            $changes = is_array($d['changes'] ?? null) ? $d['changes'] : [];
            ?>
            <li>
                <strong><?= e(action_label($ev['action'])) ?></strong>
                <?php if (!empty($d['reason'])): ?><span> — <?= e($d['reason']) ?></span><?php endif; ?>
                <?php foreach ($changes as $f => $pair): if (!is_array($pair)) { continue; } ?>
                    <small class="change"><?= e(field_label((string) $f)) ?>: <span class="change__old"><?= e((string) ($pair[0] ?? '—')) ?></span> ← <span class="change__new"><?= e((string) ($pair[1] ?? '—')) ?></span></small>
                <?php endforeach; ?>
                <small><?= e($ev['full_name'] ?? '—') ?> · <?= jdate($ev['created_at'], true) ?></small>
            </li>
        <?php endforeach; ?>
    </ul>
</section>
