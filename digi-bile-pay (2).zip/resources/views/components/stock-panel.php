<?php
/** @var array $product  @var list<array> $movements */
?>
<section class="card">
    <div class="card__head"><h2>موجودی و حرکت کالا</h2><strong><?= num((int) $product['stock']) ?> عدد</strong></div>
    <form class="status-form" method="post" action="/products/<?= (int) $product['id'] ?>/stock" data-confirm="موجودی تعدیل شود؟">
        <?= csrf_field() ?>
        <div class="field"><label for="mode">نوع تعدیل</label>
            <select class="input" id="mode" name="mode">
                <?php foreach (\App\Services\StockService::KINDS as $k => $l): ?><option value="<?= e($k) ?>"><?= e($l) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="qty">تعداد</label><input class="input input--ltr" id="qty" name="qty" inputmode="numeric" required></div>
        <div class="field field--grow"><label for="stock_reason">دلیل (الزامی)</label><input class="input" id="stock_reason" name="reason" maxlength="300" required placeholder="مثلاً: ورود کالای جدید / مغایرت انبارگردانی"></div>
        <button class="btn btn--primary" type="submit">ثبت تعدیل</button>
    </form>
    <?php if (!$movements): ?>
        <p class="empty">حرکتی ثبت نشده است.</p>
    <?php else: ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>زمان</th><th>نوع</th><th>تغییر</th><th>موجودی پس از</th><th>دلیل</th><th>کاربر</th></tr></thead>
            <tbody><?php foreach ($movements as $m): ?>
                <tr>
                    <td><?= jdate($m['created_at'], true) ?></td>
                    <td><?= e(['add' => 'افزایش', 'remove' => 'کاهش', 'set' => 'شمارش', 'order' => 'سفارش', 'return' => 'برگشت'][$m['kind']] ?? $m['kind']) ?></td>
                    <td class="<?= (int) $m['delta'] < 0 ? 'amount--neg' : 'amount--pos' ?>"><?= (int) $m['delta'] < 0 ? '−' : '+' ?><?= num(abs((int) $m['delta'])) ?></td>
                    <td><?= num((int) $m['balance_after']) ?></td>
                    <td class="wrap"><?= e($m['reason'] ?? ($m['ref_id'] ? 'سفارش/تسهیلات #' . (int) $m['ref_id'] : '—')) ?></td>
                    <td><?= e($m['full_name'] ?? '—') ?></td>
                </tr>
            <?php endforeach; ?></tbody>
        </table></div>
    <?php endif; ?>
</section>
