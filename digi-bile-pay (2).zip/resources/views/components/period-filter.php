<?php /** @var string $action @var string $from @var string $to @var array $errors */ ?>
<form class="period-bar" method="get" action="<?= e($action) ?>">
    <div class="field"><label for="from">از تاریخ</label><input class="input input--ltr input--sm" id="from" name="from" value="<?= e($from) ?>" placeholder="1405/01/01"></div>
    <div class="field"><label for="to">تا تاریخ</label><input class="input input--ltr input--sm" id="to" name="to" value="<?= e($to) ?>" placeholder="1405/12/29"></div>
    <button class="btn btn--primary btn--sm" type="submit"><?= icon('search', 16) ?><span>نمایش</span></button>
    <button class="btn btn--secondary btn--sm" type="submit" name="format" value="csv"><?= icon('download', 16) ?><span>CSV</span></button>
    <button class="btn btn--secondary btn--sm" type="submit" name="format" value="xlsx"><?= icon('download', 16) ?><span>Excel</span></button>
    <button class="btn btn--secondary btn--sm" type="button" data-print><?= icon('file-text', 16) ?><span>چاپ / PDF</span></button>
</form>
<?php foreach ($errors as $er): ?><p class="neg"><?= e($er) ?></p><?php endforeach; ?>
