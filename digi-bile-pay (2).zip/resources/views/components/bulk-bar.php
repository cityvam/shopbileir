<?php
/**
 * نوار تغییر گروهی وضعیت؛ چک‌باکس‌های جدول با form="bulk-form" به این فرم وصل می‌شوند.
 * @var string $action  @var array<string,string> $options
 */
?>
<form class="bulk-bar" id="bulk-form" method="post" action="<?= e($action) ?>" data-confirm="وضعیت موارد انتخاب‌شده تغییر کند؟ دلیل برای همه ثبت می‌شود.">
    <?= csrf_field() ?>
    <span class="bulk-bar__count" data-bulk-count>۰ مورد انتخاب شد</span>
    <select class="input input--sm" name="to_status" aria-label="وضعیت جدید">
        <?php foreach ($options as $k => $label): ?><option value="<?= e($k) ?>"><?= e($label) ?></option><?php endforeach; ?>
    </select>
    <input class="input input--sm bulk-bar__reason" name="reason" maxlength="500" required placeholder="دلیل (الزامی)" aria-label="دلیل">
    <button class="btn btn--secondary btn--sm" type="submit">اعمال روی انتخاب‌شده‌ها</button>
</form>
