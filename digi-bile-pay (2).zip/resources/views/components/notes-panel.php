<?php
/**
 * یادداشت‌های داخلی.
 * @var string $entity  @var int $entityId  @var list<array> $notes  @var bool $canAdd
 */
use App\Core\Auth;
?>
<section class="card">
    <div class="card__head"><h2>یادداشت‌های داخلی</h2></div>
    <?php if ($canAdd): ?>
        <form class="note-add" method="post" action="/notes">
            <?= csrf_field() ?>
            <input type="hidden" name="entity" value="<?= e($entity) ?>">
            <input type="hidden" name="entity_id" value="<?= (int) $entityId ?>">
            <div class="field field--grow"><label for="note_body_<?= e($entity) ?>">یادداشت جدید</label>
                <textarea class="input" id="note_body_<?= e($entity) ?>" name="body" rows="2" maxlength="2000" required placeholder="توضیح، پیگیری یا نکته‌ای که همکاران باید بدانند"></textarea></div>
            <button class="btn btn--primary btn--sm" type="submit">ثبت یادداشت</button>
        </form>
    <?php endif; ?>
    <?php if (!$notes): ?>
        <p class="empty">یادداشتی ثبت نشده است.</p>
    <?php else: ?>
        <ul class="notes">
            <?php foreach ($notes as $n): $mine = (int) $n['created_by'] === Auth::id(); ?>
                <li class="note<?= $n['pinned'] ? ' note--pinned' : '' ?>">
                    <p class="note__body"><?= nl2br(e($n['body'])) ?></p>
                    <small><?= $n['pinned'] ? badge('سنجاق‌شده', 'warn') . ' ' : '' ?><?= e($n['full_name'] ?? '—') ?> · <?= jdate($n['created_at'], true) ?><?= $n['updated_at'] ? ' · ویرایش‌شده' : '' ?></small>
                    <div class="note__actions">
                        <form method="post" action="/notes/<?= (int) $n['id'] ?>/pin"><?= csrf_field() ?><button class="btn btn--ghost btn--sm" type="submit"><?= $n['pinned'] ? 'برداشتن سنجاق' : 'سنجاق' ?></button></form>
                        <?php if ($mine): ?>
                            <details class="note__edit"><summary>ویرایش</summary>
                                <form method="post" action="/notes/<?= (int) $n['id'] ?>"><?= csrf_field() ?>
                                    <textarea class="input" name="body" rows="2" maxlength="2000" required><?= e($n['body']) ?></textarea>
                                    <button class="btn btn--secondary btn--sm" type="submit">ذخیره</button>
                                </form>
                            </details>
                            <form method="post" action="/notes/<?= (int) $n['id'] ?>/delete" data-confirm="یادداشت حذف شود؟"><?= csrf_field() ?><button class="btn btn--ghost btn--sm" type="submit">حذف</button></form>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>
