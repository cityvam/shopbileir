<?php
/**
 * @var string $action  مسیر POST تغییر وضعیت
 * @var string $current وضعیت فعلی
 * @var array<string,string> $options وضعیت‌های قابل انتخاب (کلید → برچسب)
 * @var list<array> $history
 * @var string $kind  نوع نشان وضعیت برای status_badge
 */
use App\Core\Auth;
?>
<section class="card">
    <div class="card__head"><h2>وضعیت و تاریخچه</h2></div>
    <?php if ($canManage): ?>
        <form class="status-form" method="post" action="<?= e($action) ?>" data-confirm="وضعیت تغییر کند؟ دلیل در تاریخچه و گزارش حسابرسی ثبت می‌شود.">
            <?= csrf_field() ?>
            <div class="field">
                <label for="to_status">وضعیت جدید</label>
                <select class="input" id="to_status" name="to_status">
                    <?php foreach ($options as $k => $label): if ($k === $current) { continue; } ?>
                        <option value="<?= e($k) ?>"><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field field--grow">
                <label for="reason">دلیل (الزامی)</label>
                <input class="input" id="reason" name="reason" maxlength="500" required placeholder="مثلاً: عدم پرداخت اقساط سررسیدشده">
            </div>
            <button class="btn btn--primary" type="submit">ثبت تغییر وضعیت</button>
        </form>
    <?php endif; ?>
    <?php if (!$history): ?>
        <p class="empty">تغییر وضعیتی ثبت نشده است.</p>
    <?php else: ?>
        <ul class="timeline">
            <?php foreach ($history as $h): ?>
                <li>
                    <?= status_badge('entity', $h['from_status']) ?> ← <?= status_badge('entity', $h['to_status']) ?>
                    <span><?= e($h['reason']) ?></span>
                    <small><?= e($h['full_name'] ?? '—') ?> · <?= jdate($h['created_at'], true) ?></small>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>
