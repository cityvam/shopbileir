<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>درخواست #<?= fa($l['id']) ?> · <?= e($l['full_name']) ?> <?= status_badge('lead', $l['status']) ?></h2>
        <div class="card__tools">
            <?php if (Auth::can('customers.manage')): ?>
            <form method="post" action="/leads/<?= (int) $l['id'] ?>/convert"><?= csrf_field() ?><button class="btn btn--primary btn--sm" type="submit"><?= icon('plus', 16) ?><span>ایجاد مشتری از این درخواست</span></button></form>
            <?php endif; ?>
            <a class="btn btn--ghost btn--sm" href="/leads">بازگشت</a>
        </div>
    </div>
    <dl class="lead-facts">
        <div><dt>موبایل</dt><dd class="ltr"><?= fa($l['mobile']) ?></dd></div>
        <div><dt>کد ملی</dt><dd class="ltr"><?= $l['national_code'] ? fa($l['national_code']) : '—' ?></dd></div>
        <div><dt>مبلغ درخواستی</dt><dd><?= $l['requested_amount'] ? money((int) $l['requested_amount']) : '—' ?></dd></div>
        <div><dt>طرح موردنظر</dt><dd><?= e($l['plan_name'] ?? '—') ?></dd></div>
        <div><dt>تاریخ ثبت</dt><dd><?= jdate($l['created_at'], true) ?></dd></div>
        <div><dt>نشانی شبکه</dt><dd class="ltr"><?= e($l['ip'] ?? '—') ?></dd></div>
    </dl>
    <?php if ($l['message']): ?><p class="lead-message"><?= nl2br(e($l['message'])) ?></p><?php endif; ?>
</section>
<?php \App\Core\View::partial('notes-panel', ['entity' => 'lead', 'entityId' => (int) $l['id'], 'notes' => $internalNotes, 'canAdd' => true]); ?>
<?php \App\Core\View::partial('status-panel', [
    'action' => '/leads/' . (int) $l['id'] . '/status', 'current' => $l['status'], 'history' => $history,
    'canManage' => Auth::can('customers.manage'), 'options' => $statuses,
]); ?>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
