<?php use App\Core\Auth;
$base = '/leads';
$fields = [
    ['key' => 'q', 'label' => 'جست‌وجو (نام، موبایل، کد ملی)', 'type' => 'text'],
    ['key' => 'status', 'label' => 'وضعیت', 'type' => 'select', 'options' => $statuses],
    ['key' => 'from', 'label' => 'ثبت از تاریخ', 'type' => 'date', 'adv' => true],
    ['key' => 'to', 'label' => 'ثبت تا تاریخ', 'type' => 'date', 'adv' => true],
];
?>
<section class="card">
    <div class="card__head"><h2>درخواست‌های اعتبار از صفحه‌ی عمومی</h2><a class="btn btn--ghost btn--sm" href="/" target="_blank" rel="noopener"><?= icon('home', 16) ?><span>مشاهده صفحه اصلی</span></a></div>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => $base, 'fields' => $fields, 'csv' => true]); ?>
    <p class="result-bar"><?= fa($pg['total']) ?> درخواست یافت شد</p>
    <?php if (!$rows): ?>
        <p class="empty">درخواستی ثبت نشده است.</p>
    <?php else: ?>
        <div class="table-wrap"><table class="table table--stack">
            <thead><tr><th><?= $lf->sortLink($base, 'created', 'شماره') ?></th><th><?= $lf->sortLink($base, 'name', 'نام') ?></th><th>موبایل</th><th><?= $lf->sortLink($base, 'amount', 'مبلغ درخواستی') ?></th><th>طرح</th><th>وضعیت</th><th>تاریخ</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td>#<?= fa($r['id']) ?></td>
                    <td><a href="/leads/<?= (int) $r['id'] ?>"><?= e($r['full_name']) ?></a></td>
                    <td class="ltr"><?= fa($r['mobile']) ?></td>
                    <td><?= $r['requested_amount'] ? money((int) $r['requested_amount']) : '—' ?></td>
                    <td><?= e($r['plan_name'] ?? '—') ?></td>
                    <td><?= status_badge('lead', $r['status']) ?></td>
                    <td><?= jdate($r['created_at'], true) ?></td>
                    <td class="table__actions"><a class="btn btn--secondary btn--sm" href="/leads/<?= (int) $r['id'] ?>"><?= icon('eye', 16) ?><span>مشاهده</span></a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
