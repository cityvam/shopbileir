<?php /** @var array $c @var int $used @var int $available @var array $installments @var array $loans @var array $wallet @var array $payments */
$today = date('Y-m-d');
$typeLabel = ['topup' => 'شارژ کیف پول', 'installment' => 'پرداخت قسط', 'order' => 'خرید'];
?>
<h1 class="portal-title">سلام <?= e($c['full_name']) ?></h1>
<div class="stat-grid">
    <div class="stat-card"><span class="stat-card__label">موجودی کیف پول</span><strong class="stat-card__value"><?= e(money((int) $c['wallet_balance'])) ?></strong><small>ریال</small></div>
    <div class="stat-card"><span class="stat-card__label">اعتبار قابل استفاده</span><strong class="stat-card__value"><?= e(money($available)) ?></strong><small>ریال</small></div>
    <div class="stat-card"><span class="stat-card__label">اعتبار مصرف‌شده</span><strong class="stat-card__value"><?= e(money($used)) ?></strong><small>ریال</small></div>
    <div class="stat-card"><span class="stat-card__label">سقف اعتبار</span><strong class="stat-card__value"><?= e(money((int) $c['credit_limit'])) ?></strong><small>ریال</small></div>
</div>

<section class="card">
    <header class="card__head"><h2>اقساط پیش‌رو و معوق</h2></header>
    <?php if (!$installments): ?>
        <p class="portal-empty">قسط باز یا معوقی ندارید.</p>
    <?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>تسهیلات</th><th>قسط</th><th>سررسید</th><th>باقی‌مانده (ریال)</th><th>وضعیت</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($installments as $i): $rem = (int) $i['amount'] - (int) $i['paid_amount']; $late = $i['due_date'] < $today; ?>
            <tr>
                <td>#<?= e(fa($i['loan_id'])) ?></td>
                <td><?= e(fa($i['seq'])) ?> از <?= e(fa($i['months'])) ?></td>
                <td><?= e(jdate($i['due_date'])) ?></td>
                <td><?= e(money($rem)) ?></td>
                <td><span class="badge badge--<?= $late ? 'danger' : 'muted' ?>"><?= $late ? 'معوق' : 'در انتظار' ?></span></td>
                <td>
                    <form method="post" action="/portal/pay">
                        <?= csrf_field() ?>
                        <input type="hidden" name="kind" value="installment">
                        <input type="hidden" name="installment_id" value="<?= (int) $i['id'] ?>">
                        <input type="hidden" name="amount" value="<?= $rem ?>">
                        <button class="btn btn--primary btn--sm" type="submit">پرداخت آنلاین</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php endif; ?>
</section>

<section class="card">
    <header class="card__head"><h2>شارژ کیف پول</h2></header>
    <form method="post" action="/portal/pay" class="form portal-topup">
        <?= csrf_field() ?>
        <input type="hidden" name="kind" value="topup">
        <div class="field"><label for="amount">مبلغ (ریال)</label>
            <input class="input input--ltr" id="amount" name="amount" type="text" inputmode="numeric" placeholder="مثلاً 5000000" required></div>
        <button class="btn btn--primary" type="submit">پرداخت آنلاین</button>
    </form>
</section>

<section class="card">
    <header class="card__head"><h2>تسهیلات من</h2></header>
    <?php if (!$loans): ?><p class="portal-empty">تسهیلاتی ثبت نشده است.</p><?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>#</th><th>طرح</th><th>مبلغ (ریال)</th><th>مدت</th><th>وضعیت</th></tr></thead>
        <tbody><?php foreach ($loans as $l): ?>
            <tr><td><?= e(fa($l['id'])) ?></td><td><?= e($l['plan_name']) ?></td><td><?= e(money((int) $l['principal'])) ?></td><td><?= e(fa($l['months'])) ?> ماه</td><td><?= status_badge('loan', (string) $l['status']) ?></td></tr>
        <?php endforeach; ?></tbody>
    </table></div><?php endif; ?>
</section>

<section class="card">
    <header class="card__head"><h2>گردش کیف پول</h2></header>
    <?php if (!$wallet): ?><p class="portal-empty">تراکنشی ثبت نشده است.</p><?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>تاریخ</th><th>نوع</th><th>مبلغ (ریال)</th><th>مانده (ریال)</th></tr></thead>
        <tbody><?php foreach ($wallet as $w): ?>
            <tr><td><?= e(jdate($w['created_at'], true)) ?></td><td><?= e($typeLabel[$w['type']] ?? $w['type']) ?></td><td><?= e(money((int) $w['amount'])) ?></td><td><?= e(money((int) $w['balance_after'])) ?></td></tr>
        <?php endforeach; ?></tbody>
    </table></div><?php endif; ?>
</section>

<?php if ($payments): ?>
<section class="card">
    <header class="card__head"><h2>پرداخت‌های آنلاین اخیر</h2></header>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>تاریخ</th><th>نوع</th><th>مبلغ (ریال)</th><th>وضعیت</th><th>کد پیگیری</th></tr></thead>
        <tbody><?php foreach ($payments as $p): ?>
            <tr><td><?= e(jdate($p['paid_at'] ?: $p['created_at'], true)) ?></td><td><?= e($typeLabel[$p['kind']] ?? $p['kind']) ?></td><td><?= e(money((int) $p['amount'])) ?></td><td><?= e(\App\Services\PaymentLinkService::STATUS_LABELS[$p['status']] ?? $p['status']) ?></td><td><bdi><?= e((string) ($p['ref_id'] ?? '—')) ?></bdi></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
</section>
<?php endif; ?>
