<?php /** @var string $step @var string $mobile @var bool $enabled */ ?>
<section class="login-card">
    <div class="login-card__brand">
        <?= icon('logo', 44) ?>
        <h1>ورود مشتریان</h1>
        <p>با شماره‌ی موبایل ثبت‌شده و کد پیامکی وارد شوید.</p>
    </div>
<?php if (!$enabled): ?>
    <div class="notice notice--error">ورود با پیامک فعلاً فعال نیست؛ لطفاً با پشتیبانی تماس بگیرید.</div>
<?php elseif ($step === 'mobile'): ?>
    <form method="post" action="/portal/login" class="form" autocomplete="off">
        <?= csrf_field() ?>
        <div class="field">
            <label for="mobile">شماره‌ی موبایل</label>
            <input class="input input--ltr" id="mobile" name="mobile" type="tel" inputmode="numeric" maxlength="11" placeholder="09123456789" value="<?= e(old('mobile')) ?>" required autofocus>
        </div>
        <?php \App\Core\View::partial('captcha', ['scope' => 'portal']); ?>
        <button class="btn btn--primary btn--block" type="submit">دریافت کد ورود</button>
    </form>
<?php else: ?>
    <form method="post" action="/portal/code" class="form" autocomplete="off">
        <?= csrf_field() ?>
        <p class="portal-hint">کد ۶ رقمی به <bdi><?= e(fa($mobile)) ?></bdi> پیامک شد (۵ دقیقه اعتبار دارد).</p>
        <div class="field">
            <label for="code">کد ورود</label>
            <input class="input input--ltr" id="code" name="code" type="text" inputmode="numeric" maxlength="6" autocomplete="one-time-code" required autofocus>
        </div>
        <button class="btn btn--primary btn--block" type="submit">ورود</button>
        <a class="btn btn--ghost btn--block" href="/portal/login">شماره‌ی دیگر / ارسال دوباره</a>
    </form>
<?php endif; ?>
</section>
