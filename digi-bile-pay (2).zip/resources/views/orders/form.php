<?php if (!$merchant): ?>
<form class="card form order-form" method="get" action="/orders/create">
    <h2>مرحله ۱ از ۲ · انتخاب فروشنده</h2>
    <?php if (!$merchants): ?>
        <p class="empty">فروشنده فعالی وجود ندارد. ابتدا یک فروشنده ثبت کنید.</p>
    <?php else: ?>
    <div class="field"><label for="merchant_id">فروشنده</label>
        <select class="input" id="merchant_id" name="merchant_id" required>
            <option value="">انتخاب کنید</option>
            <?php foreach ($merchants as $m): ?><option value="<?= (int) $m['id'] ?>"><?= e($m['name']) ?></option><?php endforeach; ?>
        </select>
    </div>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ادامه</button>
        <a class="btn btn--ghost" href="/orders">بازگشت</a>
    </div>
    <?php endif; ?>
</form>
<?php else: ?>
<form class="card form order-form" method="post" action="/orders">
    <?= csrf_field() ?>
    <input type="hidden" name="merchant_id" value="<?= (int) $merchant['id'] ?>">
    <h2>مرحله ۲ از ۲ · سفارش از «<?= e($merchant['name']) ?>»</h2>
    <?php if (!$products): ?>
        <p class="empty">این فروشنده محصول فعال و موجود ندارد.</p>
    <?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>محصول</th><th>قیمت</th><th>موجودی</th><th>تعداد</th></tr></thead>
        <tbody><?php foreach ($products as $p): ?>
            <tr>
                <td><?= e($p['name']) ?></td><td><?= money((int) $p['price']) ?></td><td><?= num((int) $p['stock']) ?></td>
                <td><input class="input input--ltr input--sm order-qty" name="qty[<?= (int) $p['id'] ?>]" inputmode="numeric" placeholder="۰" aria-label="تعداد <?= e($p['name']) ?>"></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <div class="form-grid">
        <div class="field"><label for="customer_id">مشتری</label>
            <select class="input" id="customer_id" name="customer_id" required>
                <option value="">انتخاب کنید</option>
                <?php foreach ($customers as $c): ?><option value="<?= (int) $c['id'] ?>"><?= e($c['full_name']) ?> — <?= fa($c['national_code']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="field"><label for="payment_type">روش پرداخت</label>
            <select class="input" id="payment_type" name="payment_type">
                <option value="cash">نقدی (از کیف پول)</option>
                <option value="installment">اقساطی</option>
            </select>
        </div>
        <div class="field"><label for="plan_id">طرح اقساط (فقط خرید اقساطی)</label>
            <select class="input" id="plan_id" name="plan_id">
                <option value="">—</option>
                <?php foreach ($plans as $pl): ?><option value="<?= (int) $pl['id'] ?>"><?= e($pl['name']) ?> · <?= fa($pl['months']) ?> ماه · <?= fa(rtrim(rtrim(number_format((float) $pl['annual_rate_percent'], 2), '0'), '.')) ?>٪</option><?php endforeach; ?>
            </select>
        </div>
    </div>
    <p class="hint">مبلغ کل، کارمزد و اعتبار مشتری هنگام ثبت در سرور محاسبه و کنترل می‌شود. خرید اقساطی پس از تأیید تسهیلات قطعی می‌شود.</p>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ثبت سفارش</button>
        <a class="btn btn--ghost" href="/orders/create">تغییر فروشنده</a>
    </div>
    <?php endif; ?>
</form>
<?php endif; ?>
