<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>سفارش‌ها</h2>
        <?php if (Auth::can('orders.create')): ?>
            <a class="btn btn--primary btn--sm" href="/orders/create"><?= icon('plus', 16) ?><span>سفارش جدید</span></a>
        <?php endif; ?>
    </div>
    <div class="tabs">
        <?php foreach (['' => 'همه', 'pending' => 'در انتظار', 'confirmed' => 'تأییدشده', 'cancelled' => 'لغوشده'] as $k => $label): ?>
            <a class="tabs__link<?= $lf->v['status'] === $k ? ' is-active' : '' ?>" href="/orders?<?= e($lf->qs(['status' => $k, 'page' => ''])) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
    </div>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => '/orders', 'csv' => true, 'hidden' => ['status' => $lf->v['status']], 'fields' => [
        ['key' => 'q', 'label' => 'جست‌وجو (مشتری، کد ملی، فروشنده)', 'type' => 'text'],
        ['key' => 'merchant_id', 'label' => 'فروشنده', 'type' => 'select', 'options' => array_column($merchants, 'name', 'id')],
        ['key' => 'payment_type', 'label' => 'روش پرداخت', 'type' => 'select', 'options' => ['cash' => 'نقدی', 'installment' => 'اقساطی']],
        ['key' => 'min', 'label' => 'حداقل مبلغ', 'type' => 'money', 'adv' => true],
        ['key' => 'max', 'label' => 'حداکثر مبلغ', 'type' => 'money', 'adv' => true],
        ['key' => 'from', 'label' => 'از تاریخ', 'type' => 'date', 'adv' => true],
        ['key' => 'to', 'label' => 'تا تاریخ', 'type' => 'date', 'adv' => true],
    ]]); ?>
    <p class="result-bar"><?= fa($pg['total']) ?> سفارش · جمع مبلغ: <?= money($sum) ?></p>
    <?php if (!$rows): ?><p class="empty">سفارشی یافت نشد.</p><?php else: ?>
    <div class="table-wrap"><table class="table table--stack">
        <thead><tr><th><?= $lf->sortLink('/orders', 'id', 'شماره') ?></th><th><?= $lf->sortLink('/orders', 'customer', 'مشتری') ?></th><th><?= $lf->sortLink('/orders', 'merchant', 'فروشنده') ?></th><th><?= $lf->sortLink('/orders', 'total', 'مبلغ') ?></th><th>روش</th><th>وضعیت</th><th>تاریخ</th><th></th></tr></thead>
        <tbody><?php foreach ($rows as $r): ?>
            <tr>
                <td>#<?= fa($r['id']) ?></td><td><?= e($r['full_name']) ?></td><td><?= e($r['merchant_name']) ?></td>
                <td><?= money((int) $r['total']) ?></td><td><?= $r['payment_type'] === 'cash' ? 'نقدی' : 'اقساطی' ?></td>
                <td><?= status_badge('order', $r['status']) ?></td><td><?= jdate($r['created_at']) ?></td>
                <td class="table__actions"><a class="btn btn--secondary btn--sm" href="/orders/<?= (int) $r['id'] ?>"><?= icon('eye', 16) ?><span>مشاهده</span></a></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
