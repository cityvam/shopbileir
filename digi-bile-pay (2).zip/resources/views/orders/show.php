<section class="card order-head">
    <h2>سفارش #<?= fa($o['id']) ?> <?= status_badge('order', $o['status']) ?></h2>
    <dl class="order-facts">
        <div><dt>مشتری</dt><dd><a href="/customers/<?= (int) $o['customer_id'] ?>"><?= e($o['full_name']) ?></a></dd></div>
        <div><dt>فروشنده</dt><dd><?= e($o['merchant_name']) ?></dd></div>
        <div><dt>روش پرداخت</dt><dd><?= $o['payment_type'] === 'cash' ? 'نقدی (کیف پول)' : 'اقساطی' ?></dd></div>
        <div><dt>جمع سفارش</dt><dd><?= money((int) $o['total']) ?></dd></div>
        <div><dt>کارمزد پلتفرم</dt><dd><?= money((int) $o['commission_amount']) ?></dd></div>
        <div><dt>ثبت‌کننده</dt><dd><?= e($o['creator_name']) ?> · <?= jdate($o['created_at'], true) ?></dd></div>
        <?php if ($o['loan_id']): ?><div><dt>تسهیلات مرتبط</dt><dd><a href="/loans/<?= (int) $o['loan_id'] ?>">#<?= fa($o['loan_id']) ?></a></dd></div><?php endif; ?>
    </dl>
</section>
<section class="card">
    <div class="card__head"><h2>اقلام</h2></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>کالا</th><th>قیمت واحد</th><th>تعداد</th><th>جمع</th></tr></thead>
        <tbody><?php foreach ($items as $i): ?>
            <tr><td><?= e($i['name']) ?></td><td><?= money((int) $i['unit_price']) ?></td><td><?= num((int) $i['qty']) ?></td><td><?= money((int) $i['unit_price'] * (int) $i['qty']) ?></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
</section>
<?php \App\Core\View::partial('notes-panel', ['entity' => 'order', 'entityId' => (int) $o['id'], 'notes' => $internalNotes, 'canAdd' => true]); ?>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
