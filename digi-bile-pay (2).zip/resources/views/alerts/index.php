<?php $labels = ['danger' => 'فوری', 'warning' => 'نیازمند پیگیری', 'info' => 'توصیه']; ?>
<?php if (!$items): ?>
<section class="card alerts-empty"><?= icon('check', 28) ?><h2>هشداری وجود ندارد</h2><p class="hint">اقساط، چک‌ها، تسهیلات و موجودی در وضعیت عادی هستند.</p></section>
<?php else: ?>
<?php $unread = count(array_filter($items, static fn ($a) => !$a['read'])); ?>
<?php if ($unread > 0): ?>
<form class="alerts-readall" method="post" action="/alerts/read"><?= csrf_field() ?><button class="btn btn--ghost btn--sm" type="submit"><?= icon('check', 16) ?><span>علامت‌گذاری همه به‌عنوان خوانده‌شده</span></button></form>
<?php endif; ?>
<section class="alert-list">
<?php foreach ($items as $a): ?>
    <div class="alert-row<?= $a['read'] ? ' is-read' : '' ?>">
    <a class="card alert-item alert-item--<?= e($a['level']) ?>" href="<?= e($a['url']) ?>">
        <span class="alert-item__icon"><?= icon($a['icon'], 22) ?></span>
        <span class="alert-item__body"><strong><?= e($a['title']) ?></strong><small><?= e($a['hint']) ?></small></span>
        <span class="alert-item__level"><?= e($labels[$a['level']]) ?></span>
        <span class="alert-item__count"><?= fa((string) $a['count']) ?></span>
    </a>
    <?php if (!$a['read']): ?><form method="post" action="/alerts/read"><?= csrf_field() ?><input type="hidden" name="key" value="<?= e($a['key']) ?>"><button class="btn btn--icon btn--sm" type="submit" title="خوانده شد" aria-label="خوانده شد"><?= icon('check', 16) ?></button></form><?php endif; ?>
    </div>
<?php endforeach; ?>
</section>
<?php endif; ?>
