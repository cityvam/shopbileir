<section class="error-box">
    <h2>۴۰۴</h2>
    <p>صفحه یا رکورد موردنظر پیدا نشد.</p>
    <a class="btn btn--secondary" href="/">بازگشت</a>
</section>
