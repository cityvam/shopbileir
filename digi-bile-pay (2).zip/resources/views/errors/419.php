<section class="error-box">
    <h2>۴۱۹</h2>
    <p>نشست شما منقضی شده یا درخواست معتبر نیست. صفحه را دوباره باز کنید و تلاش کنید.</p>
    <a class="btn btn--secondary" href="/">بازگشت</a>
</section>
