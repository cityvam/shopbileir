<section class="error-box">
    <h2>۴۰۳</h2>
    <p>شما به این بخش دسترسی ندارید.</p>
    <a class="btn btn--secondary" href="/">بازگشت</a>
</section>
