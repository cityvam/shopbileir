<section class="error-box">
    <h2>۵۰۰</h2>
    <p>خطای داخلی رخ داد. موضوع در گزارش سیستم ثبت شد.</p>
    <a class="btn btn--secondary" href="/">بازگشت</a>
</section>
