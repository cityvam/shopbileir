<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>فروشندگان</h2>
        <?php if (Auth::can('merchants.manage')): ?>
            <a class="btn btn--primary btn--sm" href="/merchants/create"><?= icon('plus', 16) ?><span>فروشنده جدید</span></a>
        <?php endif; ?>
    </div>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => '/merchants', 'csv' => true, 'fields' => [
        ['key' => 'q', 'label' => 'جست‌وجو (نام، رابط، موبایل)', 'type' => 'text'],
        ['key' => 'status', 'label' => 'وضعیت', 'type' => 'select', 'options' => ['active' => 'فعال', 'disabled' => 'غیرفعال']],
        ['key' => 'un_min', 'label' => 'حداقل تسویه‌نشده', 'type' => 'money', 'adv' => true],
        ['key' => 'un_max', 'label' => 'حداکثر تسویه‌نشده', 'type' => 'money', 'adv' => true],
    ]]); ?>
    <?php if (Auth::can('merchants.manage') && $rows): \App\Core\View::partial('bulk-bar', ['action' => '/merchants/bulk-status', 'options' => ['disabled' => 'غیرفعال', 'active' => 'فعال']]); endif; ?>
    <?php if (!$rows): ?>
        <p class="empty">فروشنده‌ای یافت نشد.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="table table--stack">
                <thead><tr><?php if (Auth::can('merchants.manage')): ?><th class="col-check"><input type="checkbox" data-check-all aria-label="انتخاب همه"></th><?php endif; ?><th><?= $lf->sortLink('/merchants', 'name', 'نام') ?></th><th>رابط</th><th>موبایل</th><th>کارمزد</th><th><?= $lf->sortLink('/merchants', 'orders', 'سفارش‌ها') ?></th><th><?= $lf->sortLink('/merchants', 'unsettled', 'تسویه‌نشده (خالص)') ?></th><th>وضعیت</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <?php if (Auth::can('merchants.manage')): ?><td class="col-check"><input type="checkbox" data-bulk form="bulk-form" name="ids[]" value="<?= (int) $r['id'] ?>" aria-label="انتخاب"></td><?php endif; ?>
                        <td><a href="/merchants/<?= (int) $r['id'] ?>"><?= e($r['name']) ?></a></td>
                        <td><?= e($r['contact_name'] ?? '—') ?></td>
                        <td class="ltr"><?= e($r['mobile'] ? fa($r['mobile']) : '—') ?></td>
                        <td><?= fa(rtrim(rtrim(number_format((float) $r['commission_percent'], 2), '0'), '.')) ?>٪</td>
                        <td><?= num((int) $r['orders_count']) ?></td>
                        <td><?= money((int) $r['unsettled']) ?></td>
                        <td><?= status_badge('entity', $r['status']) ?></td>
                        <td class="table__actions">
                            <a class="btn btn--secondary btn--sm" href="/merchants/<?= (int) $r['id'] ?>"><?= icon('eye', 16) ?><span>مشاهده</span></a>
                            <?php if (Auth::can('merchants.manage')): ?>
                                <a class="btn btn--secondary btn--sm" href="/merchants/<?= (int) $r['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
