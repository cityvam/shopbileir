<?php
$isEdit = $merchant !== null;
$action = $isEdit ? '/merchants/' . (int) $merchant['id'] : '/merchants';
$val = static fn (string $k, string $d = '') => old($k, $isEdit ? (string) ($merchant[$k] ?? $d) : $d);
?>
<form class="card form merchant-form" method="post" action="<?= e($action) ?>">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field"><label for="name">نام فروشنده / فروشگاه</label><input class="input" id="name" name="name" value="<?= e($val('name')) ?>" required></div>
        <div class="field"><label for="contact_name">نام رابط</label><input class="input" id="contact_name" name="contact_name" value="<?= e($val('contact_name')) ?>"></div>
        <div class="field"><label for="mobile">موبایل</label><input class="input input--ltr" id="mobile" name="mobile" value="<?= e($val('mobile')) ?>" inputmode="numeric" maxlength="11" placeholder="09123456789"></div>
        <div class="field"><label for="commission_percent">کارمزد پلتفرم (٪ از فروش)</label><input class="input input--ltr" id="commission_percent" name="commission_percent" value="<?= e($val('commission_percent', '0')) ?>" inputmode="decimal" required></div>
    </div>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ذخیره</button>
        <a class="btn btn--ghost" href="/merchants">بازگشت</a>
    </div>
</form>
