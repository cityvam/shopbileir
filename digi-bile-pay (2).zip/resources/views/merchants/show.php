<?php use App\Core\Auth; ?>
<section class="card merchant-head">
    <div class="merchant-head__title">
        <h2><?= e($m['name']) ?> <?= status_badge('entity', $m['status']) ?></h2>
        <p class="hint">رابط: <?= e($m['contact_name'] ?? '—') ?> · موبایل: <?= e($m['mobile'] ? fa($m['mobile']) : '—') ?> · کارمزد: <?= fa(rtrim(rtrim(number_format((float) $m['commission_percent'], 2), '0'), '.')) ?>٪</p>
    </div>
    <div class="merchant-head__actions">
        <?php if (Auth::can('merchants.manage')): ?>
            <a class="btn btn--secondary btn--sm" href="/merchants/<?= (int) $m['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a>
            <a class="btn btn--secondary btn--sm" href="/products/create?merchant_id=<?= (int) $m['id'] ?>"><?= icon('plus', 16) ?><span>محصول جدید</span></a>
        <?php endif; ?>
    </div>
</section>

<section class="stat-grid">
    <article class="stat-card"><span class="stat-card__label">سفارش تسویه‌نشده</span><strong class="stat-card__value"><?= num((int) $unsettled['c']) ?></strong></article>
    <article class="stat-card"><span class="stat-card__label">فروش ناخالص</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $unsettled['gross']) ?></strong></article>
    <article class="stat-card stat-card--warn"><span class="stat-card__label">کارمزد پلتفرم</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $unsettled['comm']) ?></strong></article>
    <article class="stat-card stat-card--ok"><span class="stat-card__label">قابل تسویه (خالص)</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $unsettled['gross'] - (int) $unsettled['comm']) ?></strong></article>
</section>

<?php if (Auth::can('settlements.manage') && (int) $unsettled['c'] > 0): ?>
    <section class="card settle-box">
        <p>مبلغ خالص <strong><?= money((int) $unsettled['gross'] - (int) $unsettled['comm']) ?></strong> برای <?= num((int) $unsettled['c']) ?> سفارش آماده تسویه است.</p>
        <form method="post" action="/merchants/<?= (int) $m['id'] ?>/settle" data-confirm="تسویه ثبت و سند حسابداری صادر شود؟ این عملیات برگشت‌پذیر نیست.">
            <?= csrf_field() ?>
            <button class="btn btn--success" type="submit"><?= icon('banknote', 18) ?><span>ثبت تسویه</span></button>
        </form>
    </section>
<?php endif; ?>

<section class="card">
    <div class="card__head"><h2>محصولات</h2></div>
    <?php if (!$products): ?><p class="empty">محصولی ثبت نشده است.</p><?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>نام</th><th>قیمت</th><th>موجودی</th><th>وضعیت</th></tr></thead>
        <tbody><?php foreach ($products as $p): ?>
            <tr><td><?= e($p['name']) ?></td><td><?= money((int) $p['price']) ?></td><td><?= num((int) $p['stock']) ?></td><td><?= status_badge('entity', $p['status']) ?></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>

<section class="card">
    <div class="card__head"><h2>آخرین سفارش‌ها</h2></div>
    <?php if (!$orders): ?><p class="empty">سفارشی ثبت نشده است.</p><?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>سفارش</th><th>مشتری</th><th>مبلغ</th><th>روش</th><th>وضعیت</th><th>تسویه</th><th>تاریخ</th></tr></thead>
        <tbody><?php foreach ($orders as $o): ?>
            <tr>
                <td><a href="/orders/<?= (int) $o['id'] ?>">#<?= fa($o['id']) ?></a></td>
                <td><?= e($o['full_name']) ?></td><td><?= money((int) $o['total']) ?></td>
                <td><?= $o['payment_type'] === 'cash' ? 'نقدی' : 'اقساطی' ?></td>
                <td><?= status_badge('order', $o['status']) ?></td>
                <td><?= $o['settlement_id'] ? badge('تسویه‌شده', 'ok') : badge('—', 'muted') ?></td>
                <td><?= jdate($o['created_at']) ?></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>

<section class="card">
    <div class="card__head"><h2>تاریخچه تسویه‌ها</h2></div>
    <?php if (!$settlements): ?><p class="empty">هنوز تسویه‌ای انجام نشده است.</p><?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>شماره</th><th>تاریخ</th><th>سفارش‌ها</th><th>ناخالص</th><th>کارمزد</th><th>خالص</th><th>ثبت‌کننده</th></tr></thead>
        <tbody><?php foreach ($settlements as $s): ?>
            <tr><td>#<?= fa($s['id']) ?></td><td><?= jdate($s['created_at'], true) ?></td><td><?= num((int) $s['orders_count']) ?></td><td><?= money((int) $s['gross_amount']) ?></td><td><?= money((int) $s['commission_amount']) ?></td><td><?= money((int) $s['net_amount']) ?></td><td><?= e($s['full_name']) ?></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>

<?php \App\Core\View::partial('notes-panel', ['entity' => 'merchant', 'entityId' => (int) $m['id'], 'notes' => $internalNotes, 'canAdd' => true]); ?>
<?php \App\Core\View::partial('status-panel', [
    'action' => '/merchants/' . (int) $m['id'] . '/status', 'current' => $m['status'], 'history' => $history,
    'canManage' => Auth::can('merchants.manage'), 'options' => ['active' => 'فعال', 'disabled' => 'غیرفعال'],
]); ?>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
