<?php use App\Services\PaymentLinkService;
$st = $r['status'];
$label = PaymentLinkService::STATUS_LABELS[$st] ?? $st;
$badge = ['pending' => 'warn', 'paid' => 'ok', 'failed' => 'bad', 'cancelled' => 'muted', 'expired' => 'muted'][$st] ?? 'muted';
?>
<section class="pay-card">
    <div class="pay-card__brand"><?= icon('logo', 36) ?><strong><?= e($r['company_name']) ?></strong></div>
    <?php if ($result && $result['message']): ?>
        <div class="notice notice--<?= $result['status'] === 'paid' ? 'success' : 'error' ?>" role="alert"><?= e($result['message']) ?></div>
    <?php endif; ?>
    <p class="pay-card__kind"><?= $r['kind'] === 'installment' ? 'پرداخت قسط' : 'شارژ کیف پول' ?> · <?= e($r['full_name']) ?></p>
    <p class="pay-card__amount"><?= money((int) $r['amount']) ?></p>
    <p><span class="badge badge--<?= e($badge) ?>"><?= e($label) ?></span></p>
    <?php if ($st === 'paid'): ?>
        <p class="pay-card__ref">کد پیگیری: <bdi class="ltr"><?= e($r['ref_id'] ?: '—') ?></bdi></p>
        <p class="pay-card__hint">پرداخت شما با موفقیت ثبت شد. از اعتماد شما سپاسگزاریم.</p>
    <?php elseif ($st === 'pending'): ?>
        <?php if ($gatewayOn): ?>
            <form method="post" action="/pay/start?t=<?= e($r['token']) ?>" class="form">
                <?= csrf_field() ?>
                <button class="btn btn--primary btn--lg btn--block" type="submit">پرداخت امن آنلاین</button>
            </form>
            <p class="pay-card__hint">این لینک تا <?= jdate($r['expires_at'], true) ?> معتبر است.</p>
        <?php else: ?>
            <p class="pay-card__hint">پرداخت آنلاین فعلاً در دسترس نیست؛ با پشتیبانی تماس بگیرید.</p>
        <?php endif; ?>
    <?php else: ?>
        <p class="pay-card__hint">این لینک دیگر قابل پرداخت نیست؛ برای دریافت لینک جدید با ما تماس بگیرید.</p>
    <?php endif; ?>
</section>
