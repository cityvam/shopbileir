<section class="pay-card">
    <div class="pay-card__brand"><?= icon('shield', 36) ?><strong>درگاه آزمایشی</strong></div>
    <p class="pay-card__hint">این صفحه فقط برای توسعه است و هیچ وجهی جابه‌جا نمی‌شود.</p>
    <p class="pay-card__amount"><?= money((int) $r['amount']) ?></p>
    <div class="pay-card__actions">
        <a class="btn btn--success btn--lg" href="/pay/return?t=<?= e($r['token']) ?>&amp;Status=OK&amp;Authority=<?= e($r['authority']) ?>">پرداخت موفق</a>
        <a class="btn btn--danger btn--lg" href="/pay/return?t=<?= e($r['token']) ?>&amp;Status=NOK&amp;Authority=<?= e($r['authority']) ?>">انصراف / ناموفق</a>
    </div>
</section>
