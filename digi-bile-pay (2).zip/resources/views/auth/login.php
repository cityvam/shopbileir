<section class="login-card">
    <div class="login-card__brand">
        <?= icon('logo', 44) ?>
        <h1>دیجی بایل پی</h1>
        <p>سامانه یکپارچه مدیریت کسب‌وکار نگار آذین فدک</p>
    </div>
    <form method="post" action="/login" class="form" autocomplete="on">
        <?= csrf_field() ?>
        <div class="field">
            <label for="username">نام کاربری</label>
            <input class="input input--ltr" id="username" name="username" type="text" value="<?= e(old('username')) ?>" autocomplete="username" required autofocus>
        </div>
        <div class="field">
            <label for="password">رمز عبور</label>
            <input class="input input--ltr" id="password" name="password" type="password" autocomplete="current-password" required>
        </div>
        <?php \App\Core\View::partial('captcha', ['scope' => 'login']); ?>
        <button class="btn btn--primary btn--block" type="submit">ورود به سامانه</button>
    </form>
</section>
