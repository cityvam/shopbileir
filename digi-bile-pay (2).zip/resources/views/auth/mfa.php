<section class="login-card">
    <div class="login-card__brand">
        <?= icon('logo', 44) ?>
        <h1>تأیید دومرحله‌ای</h1>
        <p>کد شش‌رقمی برنامه‌ی احراز هویت یا یکی از کدهای بازیابی را وارد کنید.</p>
    </div>
    <form method="post" action="/login/mfa" class="form" autocomplete="off">
        <?= csrf_field() ?>
        <div class="field">
            <label for="code">کد تأیید</label>
            <input class="input input--ltr" id="code" name="code" type="text" inputmode="text" autocomplete="one-time-code" required autofocus>
        </div>
        <button class="btn btn--primary btn--block" type="submit">تأیید و ورود</button>
        <a class="btn btn--ghost btn--block" href="/login">بازگشت</a>
    </form>
</section>
