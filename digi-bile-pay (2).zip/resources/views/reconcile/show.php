<section class="card">
    <div class="card__head"><h2>تطبیق <?= e($acc['name']) ?> <small class="ltr">(<?= e($acc['code']) ?>)</small></h2></div>
    <section class="credit-grid">
        <article class="stat-card"><span class="stat-card__label">مانده دفتر</span><strong class="stat-card__value stat-card__value--money"><?= money($book) ?></strong></article>
        <article class="stat-card stat-card--ok"><span class="stat-card__label">مانده تطبیق‌شده قبلی</span><strong class="stat-card__value stat-card__value--money" id="recPrev" data-value="<?= (int) $reconciledNet ?>"><?= money($reconciledNet) ?></strong></article>
        <article class="stat-card stat-card--warn"><span class="stat-card__label">انتخاب‌شده (جمع بد−بس)</span><strong class="stat-card__value" id="recSel">۰</strong></article>
    </section>
    <?php if ($canPost): ?>
    <form class="rec-import" method="post" action="/reconciliation/<?= (int) $acc['id'] ?>/import" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="field field--grow"><label for="stmt_file">ورود صورت‌حساب بانکی (CSV یا Excel) برای مغایرت‌گیری خودکار</label><input class="input" id="stmt_file" name="file" type="file" accept=".csv,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required></div>
        <button class="btn btn--secondary" type="submit"><?= icon('upload', 16) ?><span>بارگذاری و مغایرت‌گیری</span></button>
    </form>
    <p class="hint">ستون‌ها: <bdi class="ltr">date</bdi> (شمسی)، <bdi class="ltr">description</bdi>، <bdi class="ltr">deposit</bdi>/<bdi class="ltr">withdrawal</bdi> (یا <bdi class="ltr">amount</bdi> با علامت)، و اختیاری <bdi class="ltr">balance</bdi>. جفت‌سازی با مبلغ برابر و حداکثر <?= fa((string) \App\Services\BankStatementImport::DAY_TOLERANCE) ?> روز اختلاف تاریخ انجام می‌شود و تأیید نهایی با شماست.</p>
    <?php endif; ?>
    <?php if ($auto): ?>
    <div class="rec-auto">
        <p><strong><?= fa((string) count($auto['matched'])) ?></strong> ردیف دفتر با صورت‌حساب جفت شد و پیش‌انتخاب است · <strong><?= fa((string) count($auto['unmatched_bank'])) ?></strong> تراکنش بانک در دفتر نیست · <strong><?= fa((string) $auto['unmatched_book']) ?></strong> ردیف دفتر در صورت‌حساب نیست.
            <?php if ($canPost): ?><span class="rec-auto__clear"><form method="post" action="/reconciliation/<?= (int) $acc['id'] ?>/import-clear"><?= csrf_field() ?><button class="btn btn--ghost btn--sm" type="submit">پاک‌کردن نتیجه</button></form></span><?php endif; ?></p>
        <?php foreach ($auto['errors'] as $er): ?><p class="neg"><?= e($er) ?></p><?php endforeach; ?>
        <?php if ($auto['unmatched_bank']): ?>
        <details open><summary>تراکنش‌های بانک که در دفتر نیستند (نیازمند ثبت سند، مثلاً کارمزد)</summary>
            <div class="table-wrap"><table class="table">
                <thead><tr><th>سطر</th><th>تاریخ</th><th>شرح</th><th>واریز</th><th>برداشت</th></tr></thead>
                <tbody><?php foreach ($auto['unmatched_bank'] as $u): ?>
                    <tr><td><?= fa((string) $u['line']) ?></td><td><?= jdate($u['date']) ?></td><td class="wrap"><?= e($u['desc']) ?></td><td><?= $u['deposit'] ? num((int) $u['deposit']) : '—' ?></td><td><?= $u['withdraw'] ? num((int) $u['withdraw']) : '—' ?></td></tr>
                <?php endforeach; ?></tbody>
            </table></div>
        </details>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <form class="period-bar" method="get" action="/reconciliation/<?= (int) $acc['id'] ?>">
        <div class="field"><label for="until">نمایش ردیف‌ها تا تاریخ</label><input class="input input--ltr input--sm" id="until" name="until" value="<?= e($until) ?>"></div>
        <button class="btn btn--primary btn--sm" type="submit"><?= icon('search', 16) ?><span>نمایش</span></button>
    </form>
    <?php if (!$lines): ?><p class="empty">ردیف تطبیق‌نشده‌ای تا این تاریخ وجود ندارد.</p><?php else: ?>
    <form method="post" action="/reconciliation/<?= (int) $acc['id'] ?>" id="recForm" data-confirm="تطبیق ثبت شود؟">
        <?= csrf_field() ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th class="col-check"><input type="checkbox" id="recAll" aria-label="انتخاب همه"></th><th>سند</th><th>تاریخ</th><th>شرح</th><th>بدهکار (واریز)</th><th>بستانکار (برداشت)</th></tr></thead>
            <tbody><?php foreach ($lines as $l): ?>
                <tr>
                    <td class="col-check"><input type="checkbox" class="rec-line" name="ids[]" value="<?= (int) $l['id'] ?>" data-net="<?= (int) $l['debit'] - (int) $l['credit'] ?>" aria-label="انتخاب"<?= $auto && in_array((int) $l['id'], $auto['matched'], true) ? ' checked' : '' ?>></td>
                    <td><a href="/journal/<?= (int) $l['entry_id'] ?>">#<?= fa($l['entry_no']) ?></a></td><td><?= jdate($l['entry_date']) ?></td>
                    <td class="wrap"><?= e($l['description']) ?><?= $l['line_desc'] ? ' — ' . e($l['line_desc']) : '' ?></td>
                    <td><?= (int) $l['debit'] ? num((int) $l['debit']) : '—' ?></td><td><?= (int) $l['credit'] ? num((int) $l['credit']) : '—' ?></td>
                </tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <?php if ($canPost): ?>
        <div class="status-form">
            <div class="field"><label for="statement_date">تاریخ صورت‌حساب</label><input class="input input--ltr" id="statement_date" name="statement_date" value="<?= e($until) ?>" required></div>
            <div class="field"><label for="statement_balance">مانده پایان صورت‌حساب بانک (ریال)</label><input class="input input--ltr" id="statement_balance" name="statement_balance" inputmode="numeric" required placeholder="مثلاً 125000000 یا -5000000"<?= $auto && $auto['closing'] !== null ? ' value="' . e((string) $auto['closing']) . '"' : '' ?>></div>
            <div class="field"><label>اختلاف</label><strong id="recDiff" class="je-diff">—</strong></div>
            <button class="btn btn--primary" type="submit"><?= icon('check', 18) ?><span>ثبت تطبیق</span></button>
        </div>
        <p class="hint">مانده‌ی تطبیق‌شده (قبلی + انتخاب‌شده‌ها) باید دقیقاً با مانده‌ی صورت‌حساب برابر باشد.</p>
        <?php endif; ?>
    </form>
    <?php endif; ?>
</section>
<section class="card">
    <div class="card__head"><h2>تاریخچه تطبیق‌ها</h2></div>
    <?php if (!$history): ?><p class="empty">هنوز تطبیقی ثبت نشده است.</p><?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>تاریخ صورت‌حساب</th><th>مانده</th><th>ردیف‌ها</th><th>ثبت‌کننده</th><th>وضعیت</th><th></th></tr></thead>
        <tbody><?php foreach ($history as $h): ?>
            <tr><td><?= jdate($h['statement_date']) ?></td><td><?= money((int) $h['statement_balance']) ?></td><td><?= num((int) $h['lines_count']) ?></td><td><?= e($h['full_name'] ?? '—') ?> · <?= jdate($h['created_at'], true) ?></td>
                <td><?= $h['status'] === 'active' ? badge('فعال', 'ok') : badge('لغوشده', 'muted') ?></td>
                <td class="table__actions"><?php if ($canPost && $h['status'] === 'active' && (int) $h['id'] === $lastActive): ?>
                    <form method="post" action="/reconciliation/<?= (int) $h['id'] ?>/undo" data-confirm="آخرین تطبیق لغو شود؟"><?= csrf_field() ?><button class="btn btn--ghost btn--sm" type="submit">لغو تطبیق</button></form>
                <?php endif; ?></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>
