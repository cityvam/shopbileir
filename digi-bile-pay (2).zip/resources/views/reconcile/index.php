<section class="card">
    <div class="card__head"><h2>تطبیق بانکی</h2></div>
    <p class="hint">حساب بانک یا صندوق را انتخاب کنید و ردیف‌های دفتر را با صورت‌حساب بانک تطبیق دهید. فقط اسناد قطعی شمرده می‌شوند.</p>
    <?php if (!$accounts): ?><p class="empty">هنوز حساب دارایی گردش‌دار وجود ندارد.</p><?php else: ?>
    <div class="table-wrap"><table class="table table--stack">
        <thead><tr><th>کد</th><th>حساب</th><th>مانده دفتر</th><th>ردیف‌های تطبیق‌نشده</th><th>آخرین تطبیق</th><th></th></tr></thead>
        <tbody><?php foreach ($accounts as $a): ?>
            <tr><td class="ltr"><?= fa($a['code']) ?></td><td><?= e($a['name']) ?></td><td><?= money((int) $a['book']) ?></td>
                <td><?= (int) $a['open_lines'] > 0 ? badge(num((int) $a['open_lines']), 'warn') : badge('کامل', 'ok') ?></td>
                <td><?= jdate($a['last_date']) ?></td>
                <td class="table__actions"><a class="btn btn--secondary btn--sm" href="/reconciliation/<?= (int) $a['id'] ?>"><?= icon('check', 16) ?><span>تطبیق</span></a></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>
