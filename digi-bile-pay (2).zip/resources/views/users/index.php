<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>کاربران شرکت</h2>
        <?php if (Auth::can('users.manage')): ?>
            <a class="btn btn--primary btn--sm" href="/users/create"><?= icon('plus', 16) ?><span>کاربر جدید</span></a>
        <?php endif; ?>
    </div>
    <div class="table-wrap">
        <table class="table table--stack">
            <thead><tr><th>نام کاربری</th><th>نام</th><th>موبایل</th><th>نقش</th><th>وضعیت</th><th>آخرین ورود</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="ltr"><?= e($r['username']) ?></td>
                    <td><?= e($r['full_name']) ?></td>
                    <td class="ltr"><?= e($r['mobile'] ?? '—') ?></td>
                    <td><?= e($r['role_name']) ?></td>
                    <td><?= status_badge('entity', $r['status']) ?></td>
                    <td><?= jdate($r['last_login_at'], true) ?></td>
                    <td class="table__actions">
                        <?php if (Auth::can('users.manage')): ?>
                            <a class="btn btn--secondary btn--sm" href="/users/<?= (int) $r['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
