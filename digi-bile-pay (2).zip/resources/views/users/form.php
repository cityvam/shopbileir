<?php
$isEdit = $user !== null;
$action = $isEdit ? '/users/' . (int) $user['id'] : '/users';
$val = static fn (string $k, string $d = '') => old($k, $isEdit ? (string) ($user[$k] ?? $d) : $d);
?>
<form class="card form user-form" method="post" action="<?= e($action) ?>">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field">
            <label for="username">نام کاربری</label>
            <input class="input input--ltr" id="username" name="username" value="<?= e($val('username')) ?>" <?= $isEdit ? 'disabled' : 'required' ?> autocomplete="off">
        </div>
        <div class="field">
            <label for="full_name">نام و نام خانوادگی</label>
            <input class="input" id="full_name" name="full_name" value="<?= e($val('full_name')) ?>" required>
        </div>
        <div class="field">
            <label for="mobile">موبایل</label>
            <input class="input input--ltr" id="mobile" name="mobile" value="<?= e($val('mobile')) ?>" inputmode="numeric" maxlength="11">
        </div>
        <div class="field">
            <label for="role_id">نقش</label>
            <select class="input" id="role_id" name="role_id" required>
                <?php foreach ($roles as $r): ?>
                    <option value="<?= (int) $r['id'] ?>" <?= (string) $val('role_id') === (string) $r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field">
            <label for="password"><?= $isEdit ? 'رمز عبور جدید (خالی = بدون تغییر)' : 'رمز عبور (حداقل ۱۰ نویسه، حرف و عدد)' ?></label>
            <input class="input input--ltr" id="password" name="password" type="password" autocomplete="new-password" <?= $isEdit ? '' : 'required' ?>>
        </div>
    </div>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ذخیره</button>
        <a class="btn btn--ghost" href="/users">بازگشت</a>
    </div>
</form>
<?php if ($isEdit): ?>
<?php \App\Core\View::partial('status-panel', ['action' => '/users/' . (int) $user['id'] . '/status', 'current' => $user['status'], 'history' => $history, 'canManage' => (int) $user['id'] !== \App\Core\Auth::id(), 'options' => ['active' => 'فعال', 'disabled' => 'غیرفعال']]); ?>
<section class="card">
    <h2>تأیید دومرحله‌ای</h2>
<?php if ((int) $user['mfa_enabled'] === 1): ?>
    <p><span class="badge badge--success">فعال</span></p>
<?php if ((int) $user['id'] !== \App\Core\Auth::id()): ?>
    <form method="post" action="/users/<?= (int) $user['id'] ?>/mfa-reset" data-confirm="تأیید دومرحله‌ای این کاربر بازنشانی شود؟">
        <?= csrf_field() ?>
        <button class="btn btn--danger" type="submit">بازنشانی (مثلاً گم‌شدن گوشی)</button>
    </form>
<?php endif; ?>
<?php else: ?>
    <p class="hint">غیرفعال</p>
<?php endif; ?>
</section>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
<?php endif; ?>
