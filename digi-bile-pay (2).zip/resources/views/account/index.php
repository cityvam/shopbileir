<section class="card account-info">
    <h2>مشخصات</h2>
    <dl class="account-facts">
        <div><dt>نام کاربری</dt><dd class="ltr"><?= e($u['username']) ?></dd></div>
        <div><dt>نام کامل</dt><dd><?= e($u['full_name']) ?></dd></div>
        <div><dt>موبایل</dt><dd><?= e($u['mobile'] ? fa($u['mobile']) : '—') ?></dd></div>
        <div><dt>آخرین ورود</dt><dd><?= $u['last_login_at'] ? jdate($u['last_login_at'], true) : '—' ?></dd></div>
    </dl>
</section>
<form class="card form password-form" method="post" action="/account/password">
    <?= csrf_field() ?>
    <h2>تغییر رمز عبور</h2>
    <div class="form-grid">
        <div class="field"><label for="current_password">رمز فعلی</label><input class="input input--ltr" type="password" id="current_password" name="current_password" autocomplete="current-password" required></div>
        <div class="field"><label for="new_password">رمز جدید</label><input class="input input--ltr" type="password" id="new_password" name="new_password" autocomplete="new-password" required></div>
        <div class="field"><label for="confirm_password">تکرار رمز جدید</label><input class="input input--ltr" type="password" id="confirm_password" name="confirm_password" autocomplete="new-password" required></div>
    </div>
    <p class="hint">حداقل ۱۰ کاراکتر شامل حرف و عدد.</p>
    <div class="form__actions"><button class="btn btn--primary" type="submit"><?= icon('key', 16) ?><span>تغییر رمز</span></button></div>
</form>
<section class="card mfa-card">
    <h2>تأیید دومرحله‌ای (TOTP)</h2>
<?php if ((int) $u['mfa_enabled'] === 1): ?>
    <p><span class="badge badge--success">فعال</span> <span class="hint">کدهای بازیابی باقی‌مانده: <?= fa((string) $codesLeft) ?></span></p>
    <form method="post" action="/account/mfa/recovery" class="form mfa-inline">
        <?= csrf_field() ?>
        <div class="field"><label for="rc_pw">رمز عبور فعلی</label><input class="input input--ltr" type="password" id="rc_pw" name="current_password" autocomplete="current-password" required></div>
        <button class="btn btn--ghost" type="submit">تولید مجدد کدهای بازیابی</button>
    </form>
    <form method="post" action="/account/mfa/disable" class="form mfa-inline">
        <?= csrf_field() ?>
        <div class="field"><label for="dis_pw">رمز عبور فعلی</label><input class="input input--ltr" type="password" id="dis_pw" name="current_password" autocomplete="current-password" required></div>
        <button class="btn btn--danger" type="submit">غیرفعال‌سازی</button>
    </form>
<?php else: ?>
    <p class="hint">با فعال‌سازی، هنگام ورود علاوه بر رمز عبور، کد شش‌رقمی برنامه‌ی احراز هویت (Google Authenticator، Aegis و مشابه) لازم است.</p>
    <a class="btn btn--primary" href="/account/mfa">فعال‌سازی</a>
<?php endif; ?>
</section>
<section class="card">
    <h2>مجوزهای من</h2>
    <div class="perm-list"><?php foreach ($perms as $p): ?><span class="badge badge--muted ltr"><?= e($p) ?></span><?php endforeach; ?></div>
</section>
