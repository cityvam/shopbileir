<?php if ($codes !== null): ?>
<section class="card mfa-card">
    <h2>کدهای بازیابی</h2>
    <p class="hint">این کدها فقط همین یک‌بار نمایش داده می‌شوند. هر کد یک‌بار مصرف است؛ آن‌ها را در جای امن نگه دارید.</p>
    <ul class="mfa-codes ltr"><?php foreach ($codes as $c): ?><li><?= e($c) ?></li><?php endforeach; ?></ul>
    <a class="btn btn--primary" href="/account">انجام شد</a>
</section>
<?php else: ?>
<section class="card mfa-card">
    <h2>فعال‌سازی تأیید دومرحله‌ای</h2>
    <ol class="mfa-steps">
        <li>در برنامه‌ی احراز هویت، گزینه‌ی افزودن حساب با «کلید دستی» را بزنید.</li>
        <li>کلید زیر را وارد کنید (نوع: مبتنی بر زمان).</li>
        <li>کد شش‌رقمی نمایش‌داده‌شده را در پایین وارد کنید.</li>
    </ol>
    <p class="mfa-secret ltr"><?= e($chunks) ?></p>
    <p class="hint ltr mfa-uri"><?= e($uri) ?></p>
    <form method="post" action="/account/mfa/enable" class="form mfa-inline">
        <?= csrf_field() ?>
        <div class="field"><label for="code">کد شش‌رقمی</label><input class="input input--ltr" id="code" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required autofocus></div>
        <button class="btn btn--primary" type="submit">تأیید و فعال‌سازی</button>
        <a class="btn btn--ghost" href="/account">انصراف</a>
    </form>
</section>
<?php endif; ?>
