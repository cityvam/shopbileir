<section class="stat-grid">
    <article class="stat-card stat-card--ok"><span class="stat-card__label">وصولی ۶ ماه اخیر</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $monthlyTotal) ?></strong></article>
    <?php foreach (['pending' => ['در انتظار تأیید', 'warn'], 'active' => ['تسهیلات فعال', 'ok'], 'closed' => ['تسویه‌شده', ''], 'rejected' => ['ردشده', 'bad']] as $k => [$label, $tone]): ?>
        <article class="stat-card<?= $tone ? ' stat-card--' . $tone : '' ?>"><span class="stat-card__label"><?= e($label) ?></span><strong class="stat-card__value"><?= num((int) ($portfolio[$k]['count'] ?? 0)) ?></strong><small><?= money((int) ($portfolio[$k]['principal'] ?? 0)) ?></small></article>
    <?php endforeach; ?>
</section>
<div class="report-grid">
    <section class="card"><div class="card__head"><h2>وصولی ماهانه</h2></div><?= $monthlyChart ?></section>
    <section class="card">
        <div class="card__head"><h2>سن مطالبات معوق</h2><span class="card__actions"><a class="btn btn--secondary btn--sm" href="/reports/overdue.csv"><?= icon('download', 16) ?><span>CSV</span></a> <a class="btn btn--secondary btn--sm" href="/reports/overdue.csv?format=xlsx"><?= icon('download', 16) ?><span>Excel</span></a></span></div>
        <?= $agingChart ?>
    </section>
</div>
<section class="card">
    <div class="card__head"><h2>بدهکاران معوق برتر</h2></div>
    <?php if (!$debtors): ?><p class="empty">قسط معوقی وجود ندارد.</p><?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>مشتری</th><th>اقساط معوق</th><th>مبلغ معوق</th></tr></thead>
        <tbody><?php foreach ($debtors as $d): ?>
            <tr><td><a href="/customers/<?= (int) $d['id'] ?>"><?= e($d['full_name']) ?></a></td><td><?= num((int) $d['cnt']) ?></td><td><span class="neg"><?= money((int) $d['rem']) ?></span></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>
<section class="card">
    <div class="card__head"><h2>عملکرد فروشندگان</h2></div>
    <?php if (!$merchants): ?><p class="empty">فروشنده‌ای ثبت نشده است.</p><?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>فروشنده</th><th>سفارش تأییدشده</th><th>فروش</th><th>کارمزد</th></tr></thead>
        <tbody><?php foreach ($merchants as $m): ?>
            <tr><td><a href="/merchants/<?= (int) $m['id'] ?>"><?= e($m['name']) ?></a></td><td><?= num((int) $m['orders_count']) ?></td><td><?= money((int) $m['sales']) ?></td><td><?= money((int) $m['commission']) ?></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>
