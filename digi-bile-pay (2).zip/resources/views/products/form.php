<?php
$isEdit = $product !== null;
$action = $isEdit ? '/products/' . (int) $product['id'] : '/products';
$val = static fn (string $k, string $d = '') => old($k, $isEdit ? (string) ($product[$k] ?? $d) : $d);
$selected = (int) old('merchant_id', (string) $selMerchant);
?>
<form class="card form product-form" method="post" action="<?= e($action) ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="form-grid">
        <?php if (!$isEdit): ?>
        <div class="field"><label for="merchant_id">فروشنده</label>
            <select class="input" id="merchant_id" name="merchant_id" required>
                <option value="">انتخاب کنید</option>
                <?php foreach ($merchants as $m): ?><option value="<?= (int) $m['id'] ?>" <?= $selected === (int) $m['id'] ? 'selected' : '' ?>><?= e($m['name']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <div class="field"><label for="name">نام محصول</label><input class="input" id="name" name="name" value="<?= e($val('name')) ?>" required></div>
        <div class="field"><label for="sku">کد کالا (اختیاری)</label><input class="input input--ltr" id="sku" name="sku" value="<?= e($val('sku')) ?>"></div>
        <div class="field"><label for="price">قیمت (ریال)</label><input class="input input--ltr" id="price" name="price" value="<?= e($val('price')) ?>" inputmode="numeric" data-money required></div>
        <div class="field field--wide product-image">
            <?php if (!empty($image)): ?><img class="product-image__img" src="<?= e($image) ?>" alt="تصویر فعلی محصول" width="88" height="88"><?php endif; ?>
            <div class="field"><label for="image">تصویر محصول (اختیاری؛ PNG/JPG/WebP تا ۲ مگابایت)</label><input class="input" id="image" name="image" type="file" accept="image/png,image/jpeg,image/webp"></div>
            <label class="check"><input type="checkbox" name="crop_square" value="1"> برش مربعی از وسط تصویر</label>
            <?php if (!empty($image)): ?><label class="check"><input type="checkbox" name="remove_image" value="1"> حذف تصویر</label><?php endif; ?>
        </div>
        <?php if (!$isEdit): ?>
        <div class="field"><label for="stock">موجودی اولیه</label><input class="input input--ltr" id="stock" name="stock" value="<?= e($val('stock', '0')) ?>" inputmode="numeric" required></div>
        <?php else: ?>
        <p class="hint field--wide">موجودی و وضعیت فقط از پنل‌های پایین صفحه (با ثبت دلیل و تاریخچه) تغییر می‌کنند.</p>
        <?php endif; ?>
    </div>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ذخیره</button>
        <a class="btn btn--ghost" href="/products">بازگشت</a>
    </div>
</form>
<?php if ($isEdit): ?>
<?php \App\Core\View::partial('stock-panel', ['product' => $product, 'movements' => $movements]); ?>
<?php \App\Core\View::partial('status-panel', ['action' => '/products/' . (int) $product['id'] . '/status', 'current' => $product['status'], 'history' => $history, 'canManage' => true, 'options' => ['active' => 'فعال', 'disabled' => 'غیرفعال']]); ?>
<?php \App\Core\View::partial('notes-panel', ['entity' => 'product', 'entityId' => (int) $product['id'], 'notes' => $internalNotes, 'canAdd' => true]); ?>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
<?php endif; ?>
