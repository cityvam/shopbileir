<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>محصولات</h2>
        <?php if (Auth::can('products.manage')): ?>
            <a class="btn btn--primary btn--sm" href="/products/create"><?= icon('plus', 16) ?><span>محصول جدید</span></a>
        <?php endif; ?>
    </div>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => '/products', 'csv' => true, 'fields' => [
        ['key' => 'q', 'label' => 'جست‌وجو (نام، کد کالا، فروشنده)', 'type' => 'text'],
        ['key' => 'merchant_id', 'label' => 'فروشنده', 'type' => 'select', 'options' => array_column($merchants, 'name', 'id')],
        ['key' => 'status', 'label' => 'وضعیت', 'type' => 'select', 'options' => ['active' => 'فعال', 'disabled' => 'غیرفعال']],
        ['key' => 'stock', 'label' => 'موجودی', 'type' => 'select', 'options' => ['out' => 'ناموجود', 'low' => 'کم‌موجودی (۵ یا کمتر)'], 'adv' => true],
        ['key' => 'min', 'label' => 'حداقل قیمت', 'type' => 'money', 'adv' => true],
        ['key' => 'max', 'label' => 'حداکثر قیمت', 'type' => 'money', 'adv' => true],
    ]]); ?>
    <?php if (Auth::can('products.manage') && $rows): \App\Core\View::partial('bulk-bar', ['action' => '/products/bulk-status', 'options' => ['disabled' => 'غیرفعال', 'active' => 'فعال']]); endif; ?>
    <p class="result-bar"><?= fa($pg['total']) ?> محصول</p>
    <?php if (!$rows): ?><p class="empty">محصولی یافت نشد.</p><?php else: ?>
    <div class="table-wrap"><table class="table table--stack">
        <thead><tr><?php if (Auth::can('products.manage')): ?><th class="col-check"><input type="checkbox" data-check-all aria-label="انتخاب همه"></th><?php endif; ?><th><?= $lf->sortLink('/products', 'name', 'نام') ?></th><th>کد کالا</th><th>فروشنده</th><th><?= $lf->sortLink('/products', 'price', 'قیمت') ?></th><th><?= $lf->sortLink('/products', 'stock', 'موجودی') ?></th><th>وضعیت</th><th></th></tr></thead>
        <tbody><?php foreach ($rows as $r): ?>
            <tr>
                <?php if (Auth::can('products.manage')): ?><td class="col-check"><input type="checkbox" data-bulk form="bulk-form" name="ids[]" value="<?= (int) $r['id'] ?>" aria-label="انتخاب"></td><?php endif; ?>
                <td><?= e($r['name']) ?></td><td class="ltr"><?= e($r['sku'] ?? '—') ?></td><td><?= e($r['merchant_name']) ?></td>
                <td><?= money((int) $r['price']) ?></td>
                <td><?= (int) $r['stock'] === 0 ? badge('ناموجود', 'bad') : num((int) $r['stock']) ?></td>
                <td><?= status_badge('entity', $r['status']) ?></td>
                <td class="table__actions"><?php if (Auth::can('products.manage')): ?><a class="btn btn--secondary btn--sm" href="/products/<?= (int) $r['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a><?php endif; ?></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
