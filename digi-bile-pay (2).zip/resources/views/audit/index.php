<section class="card">
    <div class="card__head"><h2>رویدادهای حسابرسی</h2></div>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => '/audit', 'csv' => true, 'fields' => [
        ['key' => 'q', 'label' => 'جست‌وجو در رویداد، موجودیت و جزئیات', 'type' => 'text'],
        ['key' => 'user_id', 'label' => 'کاربر', 'type' => 'select', 'options' => array_column($users, 'full_name', 'id')],
        ['key' => 'entity', 'label' => 'موجودیت', 'type' => 'select', 'options' => array_combine($entities, $entities)],
        ['key' => 'from', 'label' => 'از تاریخ', 'type' => 'date', 'adv' => true],
        ['key' => 'to', 'label' => 'تا تاریخ', 'type' => 'date', 'adv' => true],
    ]]); ?>
    <p class="result-bar"><?= fa($pg['total']) ?> رویداد</p>
    <?php if (!$rows): ?>
        <p class="empty">رویدادی یافت نشد.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="table table--stack">
                <thead><tr><th><?= $lf->sortLink('/audit', 'time', 'زمان') ?></th><th><?= $lf->sortLink('/audit', 'user', 'کاربر') ?></th><th><?= $lf->sortLink('/audit', 'action', 'رویداد') ?></th><th>موجودیت</th><th>جزئیات</th><th>IP</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?= jdate($r['created_at'], true) ?></td>
                        <td><?= e($r['full_name'] ?? '—') ?></td>
                        <td class="ltr"><?= e($r['action']) ?></td>
                        <td class="ltr"><?= e($r['entity']) ?><?= $r['entity_id'] ? ' #' . (int) $r['entity_id'] : '' ?></td>
                        <td class="audit-details ltr"><?= e($r['details'] ?? '') ?></td>
                        <td class="ltr"><?= e($r['ip'] ?? '') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
