<?php
$isEdit = $plan !== null;
$action = $isEdit ? '/plans/' . (int) $plan['id'] : '/plans';
$val = static fn (string $k, string $d = '') => old($k, $isEdit ? (string) ($plan[$k] ?? $d) : $d);
$active = old('name') !== '' ? old('is_active') === '1' : (!$isEdit || (int) $plan['is_active'] === 1);
?>
<form class="card form plan-form" method="post" action="<?= e($action) ?>">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field">
            <label for="name">نام طرح</label>
            <input class="input" id="name" name="name" value="<?= e($val('name')) ?>" required>
        </div>
        <div class="field">
            <label for="months">تعداد اقساط (ماه)</label>
            <input class="input input--ltr" id="months" name="months" value="<?= e($val('months')) ?>" inputmode="numeric" required>
        </div>
        <div class="field">
            <label for="annual_rate_percent">نرخ سود سالانه (٪)</label>
            <input class="input input--ltr" id="annual_rate_percent" name="annual_rate_percent" value="<?= e($val('annual_rate_percent')) ?>" inputmode="decimal" required>
        </div>
        <div class="field">
            <label for="fee_percent">کارمزد (٪ از اصل)</label>
            <input class="input input--ltr" id="fee_percent" name="fee_percent" value="<?= e($val('fee_percent', '0')) ?>" inputmode="decimal">
        </div>
        <div class="field">
            <label for="late_fee_daily_percent">جریمه تأخیر روزانه (٪ از باقی‌مانده قسط)</label>
            <input class="input input--ltr" id="late_fee_daily_percent" name="late_fee_daily_percent" value="<?= e($val('late_fee_daily_percent', '0')) ?>" inputmode="decimal">
        </div>
        <div class="field">
            <label for="min_amount">حداقل مبلغ (ریال)</label>
            <input class="input input--ltr" id="min_amount" name="min_amount" value="<?= e($val('min_amount')) ?>" inputmode="numeric" data-money required>
        </div>
        <div class="field">
            <label for="max_amount">حداکثر مبلغ (ریال)</label>
            <input class="input input--ltr" id="max_amount" name="max_amount" value="<?= e($val('max_amount')) ?>" inputmode="numeric" data-money required>
        </div>
    </div>
    <?php if (!$isEdit): ?><label class="check"><input type="checkbox" name="is_active" value="1" <?= $active ? 'checked' : '' ?>><span>طرح فعال است</span></label>
    <?php else: ?><p class="hint">وضعیت طرح از پنل پایین صفحه (با ثبت دلیل) تغییر می‌کند. تغییر شرایط روی تسهیلات قبلی اثر ندارد.</p><?php endif; ?>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ذخیره</button>
        <a class="btn btn--ghost" href="/plans">بازگشت</a>
    </div>
</form>
<?php if ($isEdit): ?>
<?php \App\Core\View::partial('status-panel', ['action' => '/plans/' . (int) $plan['id'] . '/status', 'current' => (int) $plan['is_active'] === 1 ? 'active' : 'disabled', 'history' => $history, 'canManage' => true, 'options' => ['active' => 'فعال', 'disabled' => 'غیرفعال']]); ?>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
<?php endif; ?>
