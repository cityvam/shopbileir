<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>طرح‌های تسهیلاتی</h2>
        <?php if (Auth::can('plans.manage')): ?>
            <a class="btn btn--primary btn--sm" href="/plans/create"><?= icon('plus', 16) ?><span>طرح جدید</span></a>
        <?php endif; ?>
    </div>
    <?php if (!$rows): ?>
        <p class="empty">هنوز طرحی تعریف نشده است.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="table table--stack">
                <thead><tr><th>نام</th><th>اقساط</th><th>نرخ سالانه</th><th>کارمزد</th><th>جریمه روزانه</th><th>بازه مبلغ</th><th>وضعیت</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?= e($r['name']) ?></td>
                        <td><?= fa($r['months']) ?> ماه</td>
                        <td><?= fa(rtrim(rtrim(number_format((float) $r['annual_rate_percent'], 2), '0'), '.')) ?>٪</td>
                        <td><?= fa(rtrim(rtrim(number_format((float) $r['fee_percent'], 2), '0'), '.')) ?>٪</td>
                        <td><?= fa(rtrim(rtrim(number_format((float) $r['late_fee_daily_percent'], 2), '0'), '.') ?: '0') ?>٪</td>
                        <td><?= num((int) $r['min_amount']) ?> تا <?= money((int) $r['max_amount']) ?></td>
                        <td><?= $r['is_active'] ? badge('فعال', 'ok') : badge('غیرفعال', 'muted') ?></td>
                        <td class="table__actions">
                            <?php if (Auth::can('plans.manage')): ?>
                                <a class="btn btn--secondary btn--sm" href="/plans/<?= (int) $r['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
