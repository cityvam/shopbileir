<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>نقش‌های شرکت</h2>
        <?php if (Auth::can('roles.manage')): ?>
            <a class="btn btn--primary btn--sm" href="/roles/create"><?= icon('plus', 16) ?><span>نقش جدید</span></a>
        <?php endif; ?>
    </div>
    <div class="table-wrap">
        <table class="table table--stack">
            <thead><tr><th>نقش</th><th>نوع</th><th>مجوزها</th><th>کاربران</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= e($r['name']) ?></td>
                    <td><?= $r['is_system'] ? badge('سیستمی', 'info') : badge('سفارشی', 'muted') ?></td>
                    <td><?= fa($r['perm_count']) ?></td>
                    <td><?= fa($r['user_count']) ?></td>
                    <td class="table__actions">
                        <?php if (Auth::can('roles.manage') && !$r['is_system']): ?>
                            <a class="btn btn--secondary btn--sm" href="/roles/<?= (int) $r['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a>
                            <form method="post" action="/roles/<?= (int) $r['id'] ?>/delete" data-confirm="این نقش حذف شود؟">
                                <?= csrf_field() ?>
                                <button class="btn btn--danger btn--sm" type="submit"><?= icon('trash', 16) ?><span>حذف</span></button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
