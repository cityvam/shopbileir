<?php
use App\Core\Permissions;
use App\Core\View;

$isEdit = $role !== null;
$action = $isEdit ? '/roles/' . (int) $role['id'] : '/roles';
$checked = View::oldArray('perms') ?: $granted;
?>
<form class="card form role-form" method="post" action="<?= e($action) ?>">
    <?= csrf_field() ?>
    <div class="field">
        <label for="name">نام نقش</label>
        <input class="input" id="name" name="name" value="<?= e(old('name', $isEdit ? $role['name'] : '')) ?>" required>
    </div>
    <p class="hint">فقط مجوزهایی را می‌توانید اعطا کنید که خودتان دارید.</p>
    <div class="perm-grid">
        <?php foreach (Permissions::groups() as $group => $perms): ?>
            <fieldset class="perm-group">
                <legend><?= e($group) ?></legend>
                <?php foreach ($perms as $key => $label): ?>
                    <?php $canGrant = in_array($key, $held, true); ?>
                    <label class="check<?= $canGrant ? '' : ' is-disabled' ?>">
                        <input type="checkbox" name="perms[]" value="<?= e($key) ?>" <?= in_array($key, $checked, true) ? 'checked' : '' ?> <?= $canGrant ? '' : 'disabled' ?>>
                        <span><?= e($label) ?></span>
                    </label>
                <?php endforeach; ?>
            </fieldset>
        <?php endforeach; ?>
    </div>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ذخیره</button>
        <a class="btn btn--ghost" href="/roles">بازگشت</a>
    </div>
</form>
