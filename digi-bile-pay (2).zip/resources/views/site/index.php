<?php
/** @var string $brand @var list<array> $plans @var list<array> $merchants @var list<array> $products @var ?array $quote @var int $planId @var int $amount @var bool $loggedIn */
$maxMonths = $plans ? max(array_column($plans, 'months')) : 0;
$minRate = $plans ? min(array_map(static fn ($p) => (float) $p['annual_rate_percent'], $plans)) : 0;
$maxAmount = $plans ? max(array_column($plans, 'max_amount')) : 0;
$selPlan = $planId ?: ($plans[0]['id'] ?? 0);
$steps = [
    ['file-text', 'ثبت درخواست', 'فرم کوتاه را پر کنید؛ مبلغ و طرح دلخواه را هم می‌توانید اعلام کنید.'],
    ['shield', 'بررسی و تعیین سقف', 'کارشناسان اطلاعات شما را بررسی و سقف اعتبار را اعلام می‌کنند.'],
    ['cart', 'خرید از فروشگاه', 'از فروشگاه‌های طرف قرارداد خرید کنید؛ مبلغ از اعتبار شما کسر می‌شود.'],
    ['calendar', 'پرداخت اقساط', 'اقساط را در سررسید بپردازید یا با تسویه‌ی زودهنگام سود باقی‌مانده را حذف کنید.'],
];
$features = [
    ['scale', 'شفافیت کامل', 'نرخ سالانه، کارمزد و مبلغ هر قسط پیش از ثبت درخواست در دسترس است؛ هزینه‌ی پنهانی وجود ندارد.'],
    ['zap', 'تصمیم سریع', 'درخواست‌ها به‌صورت متمرکز ثبت و پیگیری می‌شوند و وضعیت آن‌ها در پنل کارشناسان همیشه به‌روز است.'],
    ['refresh', 'تسویه‌ی زودهنگام', 'هر زمان بخواهید می‌توانید باقی‌مانده را تسویه کنید؛ سود اقساط آینده محاسبه نمی‌شود.'],
    ['wallet', 'کیف پول', 'شارژ کیف پول و پرداخت اقساط از آن، با دفتر کامل تراکنش‌ها.'],
    ['lock', 'امنیت اطلاعات', 'دسترسی نقش‌محور، تأیید دومرحله‌ای برای کاربران و ثبت کامل رویدادهای سامانه.'],
    ['store', 'شبکه‌ی فروشگاه‌ها', 'خرید اقساطی از فروشندگان طرف قرارداد با تسویه‌ی منظم و حسابداری دقیق.'],
];
?>
<section class="hero" id="hero">
    <div class="container hero__grid">
        <div class="hero__copy">
            <span class="eyebrow"><?= icon('zap', 16) ?><?= e($copy['eyebrow']) ?></span>
            <h1><?= nl2br(e($copy['hero_title'])) ?></h1>
            <p class="lead"><?= e($copy['hero_lead']) ?></p>
            <div class="hero__actions">
                <a class="btn btn--primary btn--lg" href="#apply">درخواست اعتبار<?= icon('arrow-left', 18) ?></a>
                <a class="btn btn--ghost btn--lg" href="#calc">محاسبه‌ی قسط</a>
            </div>
            <?php if ($plans): ?>
            <ul class="hero__facts" aria-label="خلاصه‌ی شرایط">
                <li><strong>تا <?= fa((string) $maxMonths) ?> ماه</strong><span>تقسیط</span></li>
                <li><strong>از <?= fa((string) (float) $minRate) ?>٪</strong><span>نرخ سالانه</span></li>
                <li><strong>تا <?= fa(number_format(intdiv((int) $maxAmount, 1000000))) ?> میلیون</strong><span>ریال اعتبار</span></li>
            </ul>
            <?php endif; ?>
        </div>
        <div class="hero__visual" aria-hidden="true">
            <div class="vcard">
                <div class="vcard__top"><span class="brand-mark"><?= icon('logo', 20) ?></span><span class="vcard__tag">نمونه‌ی نمایشی</span></div>
                <div class="vcard__label">اعتبار قابل استفاده</div>
                <div class="vcard__amount">۴۰٬۰۰۰٬۰۰۰ <small>ریال</small></div>
                <div class="vcard__bar"><span class="vcard__fill"></span></div>
                <div class="vcard__row"><span>استفاده‌شده ۶۵٪</span><span>سقف ۶۰٬۰۰۰٬۰۰۰</span></div>
            </div>
            <div class="vchip vchip--a"><span class="vchip__icon"><?= icon('check', 18) ?></span><div><strong>درخواست تأیید شد</strong><small>طرح ۶ ماهه</small></div></div>
            <div class="vchip vchip--b"><span class="vchip__icon vchip__icon--warn"><?= icon('calendar', 18) ?></span><div><strong>قسط بعدی</strong><small>۸٬۵۰۰٬۰۰۰ ریال</small></div></div>
        </div>
    </div>
</section>

<section class="section" id="how">
    <div class="container">
        <header class="section__head"><span class="eyebrow">چطور کار می‌کند</span><h2>چهار قدم تا اولین خرید اقساطی</h2></header>
        <ol class="steps">
            <?php foreach ($steps as $i => [$ic, $t, $d]): ?>
            <li class="step"><span class="step__num"><?= fa((string) ($i + 1)) ?></span><span class="step__icon"><?= icon($ic, 22) ?></span><h3><?= e($t) ?></h3><p><?= e($d) ?></p></li>
            <?php endforeach; ?>
        </ol>
    </div>
</section>

<section class="section section--alt" id="features">
    <div class="container">
        <header class="section__head"><span class="eyebrow">چرا <?= e($brand) ?></span><h2>ساده برای شما، دقیق برای کسب‌وکار</h2></header>
        <div class="features">
            <?php foreach ($features as [$ic, $t, $d]): ?>
            <article class="feature"><span class="feature__icon"><?= icon($ic, 22) ?></span><h3><?= e($t) ?></h3><p><?= e($d) ?></p></article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section" id="plans">
    <div class="container">
        <header class="section__head"><span class="eyebrow">طرح‌های تسهیلاتی</span><h2>طرح مناسب خودتان را انتخاب کنید</h2><p>همه‌ی نرخ‌ها سالانه و اقساط مساوی ماهانه است.</p></header>
        <?php if (!$plans): ?>
            <p class="empty">در حال حاضر طرح فعالی برای نمایش وجود ندارد.</p>
        <?php else: ?>
        <div class="plans">
            <?php foreach ($plans as $p): ?>
            <article class="plan">
                <header><h3><?= e($p['name']) ?></h3><span class="plan__months"><?= fa((string) $p['months']) ?> <small>ماهه</small></span></header>
                <dl>
                    <div><dt>نرخ سالانه</dt><dd><?= fa((string) (float) $p['annual_rate_percent']) ?>٪</dd></div>
                    <div><dt>کارمزد</dt><dd><?= (float) $p['fee_percent'] > 0 ? fa((string) (float) $p['fee_percent']) . '٪' : 'ندارد' ?></dd></div>
                    <div><dt>حداقل مبلغ</dt><dd><?= money((int) $p['min_amount']) ?></dd></div>
                    <div><dt>حداکثر مبلغ</dt><dd><?= money((int) $p['max_amount']) ?></dd></div>
                </dl>
                <p class="plan__sample">برای <?= money((int) $p['min_amount']) ?> حدود <strong><?= money((int) $p['sample']) ?></strong> در ماه</p>
                <a class="btn btn--secondary btn--block" data-plan="<?= (int) $p['id'] ?>" data-amount="<?= (int) $p['min_amount'] ?>" href="/?plan=<?= (int) $p['id'] ?>&amp;amount=<?= (int) $p['min_amount'] ?>#calc">محاسبه‌ی این طرح</a>
            </article>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php if ($plans): ?>
<section class="section section--alt" id="calc">
    <div class="container calc">
        <div class="calc__intro">
            <span class="eyebrow">ماشین‌حساب قسط</span>
            <h2>قسط ماهانه‌ی خود را ببینید</h2>
            <p>مبلغ و طرح را انتخاب کنید؛ قسط ماهانه، مجموع سود و کارمزد و جدول کامل اقساط بلافاصله نمایش داده می‌شود.</p>
            <p class="hint">محاسبه به‌صورت نمونه و بر اساس نرخ فعلی طرح است.</p>
        </div>
        <div class="calc__box card">
            <form class="form calc__form" method="get" action="/#calc" id="calcForm">
                <div class="field"><label for="calcPlan">طرح</label>
                    <select class="input" id="calcPlan" name="plan">
                        <?php foreach ($plans as $p): ?><option value="<?= (int) $p['id'] ?>" data-min="<?= (int) $p['min_amount'] ?>" data-max="<?= (int) $p['max_amount'] ?>"<?= (int) $p['id'] === (int) $selPlan ? ' selected' : '' ?>><?= e($p['name']) ?> — <?= fa((string) $p['months']) ?> ماهه</option><?php endforeach; ?>
                    </select></div>
                <div class="field"><label for="calcAmount">مبلغ (ریال)</label>
                    <input class="input input--ltr" id="calcAmount" name="amount" inputmode="numeric" data-money autocomplete="off" value="<?= $amount ? e(number_format($amount)) : '' ?>" placeholder="مثلاً 20,000,000"></div>
                <button class="btn btn--primary" type="submit">محاسبه</button>
            </form>
            <div class="quote" id="quote" aria-live="polite">
                <p class="quote__error" data-q-error<?= ($quote && isset($quote['error'])) ? '' : ' hidden' ?>><?= ($quote && isset($quote['error'])) ? e($quote['error']) : '' ?></p>
                <p class="quote__idle" data-q-idle<?= $quote ? ' hidden' : '' ?>>مبلغ را وارد کنید تا قسط محاسبه شود.</p>
                <div class="quote__result" data-q-result<?= ($quote && !isset($quote['error'])) ? '' : ' hidden' ?>>
                    <div class="quote__main"><span>قسط ماهانه</span><strong data-q="monthly"><?= ($quote && !isset($quote['error'])) ? e($quote['monthly']) : '' ?></strong><small>اولین سررسید: <span data-q="first_due"><?= ($quote && !isset($quote['error'])) ? e($quote['first_due']) : '' ?></span></small></div>
                    <dl class="quote__grid">
                        <div><dt>تعداد اقساط</dt><dd data-q="months"><?= ($quote && !isset($quote['error'])) ? e($quote['months']) : '' ?></dd></div>
                        <div><dt>مجموع سود</dt><dd data-q="interest"><?= ($quote && !isset($quote['error'])) ? e($quote['interest']) : '' ?></dd></div>
                        <div><dt>کارمزد</dt><dd data-q="fee"><?= ($quote && !isset($quote['error'])) ? e($quote['fee']) : '' ?></dd></div>
                        <div><dt>مجموع پرداختی</dt><dd data-q="total"><?= ($quote && !isset($quote['error'])) ? e($quote['total']) : '' ?></dd></div>
                    </dl>
                    <details class="quote__table"><summary>مشاهده‌ی جدول اقساط</summary>
                        <div class="table-wrap"><table class="sch"><thead><tr><th>قسط</th><th>سررسید</th><th>مبلغ</th></tr></thead>
                            <tbody data-q-rows><?php if ($quote && !isset($quote['error'])): foreach ($quote['rows'] as $r): ?><tr><td><?= e($r['seq']) ?></td><td><?= e($r['due']) ?></td><td><?= e($r['amount']) ?></td></tr><?php endforeach; endif; ?></tbody></table></div>
                    </details>
                    <a class="btn btn--primary btn--block" href="#apply" data-apply-from-quote>ثبت درخواست با این طرح<?= icon('arrow-left', 18) ?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($merchants): ?>
<section class="section" id="market">
    <div class="container">
        <header class="section__head"><span class="eyebrow">فروشگاه‌های طرف قرارداد</span><h2>از کجا می‌توانید خرید کنید؟</h2></header>
        <ul class="merchants">
            <?php foreach ($merchants as $m): ?>
            <li class="merchant"><span class="merchant__avatar"><?= e(mb_substr($m['name'], 0, 1)) ?></span><div><strong><?= e($m['name']) ?></strong><small><?= (int) $m['products'] > 0 ? fa((string) $m['products']) . ' کالای موجود' : 'فروشگاه فعال' ?></small></div></li>
            <?php endforeach; ?>
        </ul>
        <?php if ($products): ?>
        <div class="products">
            <?php foreach ($products as $pr): ?>
            <article class="product">
                <?php if (!empty($pr['image'])): ?><img class="product__img" src="<?= e($pr['image']) ?>" alt="<?= e($pr['name']) ?>" width="64" height="64" loading="lazy"><?php else: ?><span class="product__icon"><?= icon('box', 22) ?></span><?php endif; ?>
                <h3><?= e($pr['name']) ?></h3>
                <small><?= e($pr['merchant']) ?></small>
                <div class="product__price"><?= money((int) $pr['price']) ?></div>
                <?php if ($pr['plan']): ?>
                <span class="product__monthly">از ماهی <strong><?= money((int) $pr['monthly']) ?></strong> · <?= fa((string) $pr['plan']['months']) ?> ماهه</span>
                <a class="btn btn--secondary btn--sm" data-plan="<?= (int) $pr['plan']['id'] ?>" data-amount="<?= (int) $pr['price'] ?>" href="/?plan=<?= (int) $pr['plan']['id'] ?>&amp;amount=<?= (int) $pr['price'] ?>#calc">محاسبه‌ی قسط</a>
                <?php endif; ?>
            </article>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<section class="section section--alt" id="faq">
    <div class="container faq-wrap">
        <header class="section__head"><span class="eyebrow">پرسش‌های متداول</span><h2>پاسخ سؤال‌های رایج</h2></header>
        <div class="faq">
            <?php foreach ($faq as [$q, $a]): ?>
            <details class="faq__item"><summary><?= e($q) ?></summary><p><?= e($a) ?></p></details>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section" id="apply">
    <div class="container apply">
        <div class="apply__intro">
            <span class="eyebrow">درخواست اعتبار</span>
            <h2>همین حالا درخواست خود را ثبت کنید</h2>
            <p>اطلاعات خود را وارد کنید تا یکی از کارشناسان با شما تماس بگیرد. ثبت درخواست هیچ تعهدی ایجاد نمی‌کند.</p>
            <ul class="apply__points">
                <li><?= icon('check', 18) ?>پاسخ‌گویی توسط کارشناس</li>
                <li><?= icon('check', 18) ?>بدون هزینه‌ی ثبت درخواست</li>
                <li><?= icon('check', 18) ?>اطلاعات شما نزد ما محفوظ است</li>
            </ul>
        </div>
        <form class="card form apply__form" method="post" action="/apply" id="applyForm">
            <?= csrf_field() ?>
            <div class="form-grid">
                <div class="field"><label for="a_name">نام و نام خانوادگی</label><input class="input" id="a_name" name="full_name" maxlength="150" required autocomplete="name" value="<?= e(old('full_name')) ?>"></div>
                <div class="field"><label for="a_mobile">شماره موبایل</label><input class="input input--ltr" id="a_mobile" name="mobile" inputmode="numeric" maxlength="11" required autocomplete="tel" placeholder="09121234567" value="<?= e(old('mobile')) ?>"></div>
                <div class="field"><label for="a_nc">کد ملی <small>(اختیاری)</small></label><input class="input input--ltr" id="a_nc" name="national_code" inputmode="numeric" maxlength="10" value="<?= e(old('national_code')) ?>"></div>
                <div class="field"><label for="a_amount">مبلغ درخواستی (ریال) <small>(اختیاری)</small></label><input class="input input--ltr" id="a_amount" name="requested_amount" inputmode="numeric" data-money value="<?= e(old('requested_amount')) ?>"></div>
                <div class="field field--wide"><label for="a_plan">طرح موردنظر <small>(اختیاری)</small></label>
                    <select class="input" id="a_plan" name="plan_id"><option value="">هنوز مطمئن نیستم</option>
                        <?php foreach ($plans as $p): ?><option value="<?= (int) $p['id'] ?>"<?= (string) old('plan_id') === (string) $p['id'] ? ' selected' : '' ?>><?= e($p['name']) ?> — <?= fa((string) $p['months']) ?> ماهه</option><?php endforeach; ?>
                    </select></div>
                <div class="field field--wide"><label for="a_msg">توضیحات <small>(اختیاری)</small></label><textarea class="input" id="a_msg" name="message" maxlength="500" rows="3"><?= e(old('message')) ?></textarea></div>
            </div>
            <div class="hp" aria-hidden="true"><label for="a_web">وب‌سایت</label><input id="a_web" name="website" tabindex="-1" autocomplete="off"></div>
            <?php \App\Core\View::partial('captcha', ['scope' => 'apply']); ?>
            <button class="btn btn--primary btn--lg" type="submit">ثبت درخواست اعتبار</button>
        </form>
    </div>
</section>
