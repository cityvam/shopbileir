<form class="form" method="post" action="/site-settings" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <section class="card">
        <div class="card__head">
            <h2>متن‌ها و اطلاعات تماس</h2>
            <a class="btn btn--ghost btn--sm" href="/" target="_blank" rel="noopener"><?= icon('home', 16) ?><span>مشاهده صفحه اصلی</span></a>
        </div>
        <?php if (!$isPublic): ?><p class="notice notice--warning">صفحه‌ی عمومی فعلاً محتوای شرکت دیگری را نشان می‌دهد؛ ویرایش‌های این شرکت فقط وقتی دیده می‌شود که این شرکت صفحه‌ی عمومی باشد (<bdi class="ltr">PUBLIC_COMPANY_CODE</bdi>).</p><?php endif; ?>
        <p class="hint">فیلد خالی یعنی استفاده از متن پیش‌فرض (و برای تماس، مقدار <bdi class="ltr">SITE_*</bdi> در <bdi class="ltr">.env</bdi>).</p>
        <div class="form-grid">
            <?php foreach ($fields as $k => [$label, $max]): $long = in_array($k, ['hero_lead', 'footer_note', 'address', 'hero_title'], true); ?>
            <div class="field<?= $long ? ' field--wide' : '' ?>">
                <label for="s_<?= e($k) ?>"><?= e($label) ?> <small>(حداکثر <?= fa((string) $max) ?> نویسه)</small></label>
                <?php if ($long): ?>
                    <textarea class="input" id="s_<?= e($k) ?>" name="<?= e($k) ?>" rows="<?= $k === 'hero_title' ? 2 : 3 ?>" maxlength="<?= (int) $max ?>" placeholder="<?= e($defaults[$k] ?? '') ?>"><?= e(old($k) !== '' ? old($k) : ($stored[$k] ?? '')) ?></textarea>
                <?php else: ?>
                    <input class="input<?= in_array($k, ['phone', 'email'], true) ? ' input--ltr' : '' ?>" id="s_<?= e($k) ?>" name="<?= e($k) ?>" maxlength="<?= (int) $max ?>" value="<?= e(old($k) !== '' ? old($k) : ($stored[$k] ?? '')) ?>" placeholder="<?= e($defaults[$k] ?? '') ?>">
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <section class="card">
        <div class="card__head"><h2>لوگوی شرکت</h2></div>
        <p class="hint">PNG، JPG یا WebP تا ۲ مگابایت؛ تصویر بازسازی و حداکثر ۴۸۰ پیکسل می‌شود. لوگو در هدر صفحه‌ی اصلی و پرتال مشتری نمایش داده می‌شود.</p>
        <div class="logo-edit">
            <?php if (!empty($logo)): ?><img class="logo-edit__img" src="<?= e($logo) ?>" alt="لوگوی فعلی" width="96" height="96"><?php endif; ?>
            <div class="field"><label for="s_logo">انتخاب فایل لوگو</label><input class="input" id="s_logo" name="logo" type="file" accept="image/png,image/jpeg,image/webp"></div>
            <label class="check"><input type="checkbox" name="crop_square" value="1"> برش مربعی از وسط تصویر</label>
            <?php if (!empty($logo)): ?><label class="check"><input type="checkbox" name="remove_logo" value="1"> حذف لوگوی فعلی</label><?php endif; ?>
        </div>
    </section>
    <section class="card">
        <div class="card__head"><h2>پرسش‌های متداول</h2></div>
        <p class="hint">ترتیب نمایش همین ترتیب است. ردیف کاملاً خالی نادیده گرفته می‌شود؛ حداکثر <?= fa((string) $maxFaq) ?> پرسش. اگر همه‌ی ردیف‌ها خالی شوند، پرسش‌های پیش‌فرض نمایش داده می‌شود.</p>
        <div class="faq-edit">
            <?php foreach (array_pad($faq, count($faq) + 2, ['', '']) as $i => [$q, $a]): ?>
            <div class="faq-edit__row">
                <div class="field"><label for="fq_<?= (int) $i ?>">پرسش <?= fa((string) ($i + 1)) ?></label><input class="input" id="fq_<?= (int) $i ?>" name="faq_q[]" maxlength="200" value="<?= e($q) ?>"></div>
                <div class="field"><label for="fa_<?= (int) $i ?>">پاسخ</label><textarea class="input" id="fa_<?= (int) $i ?>" name="faq_a[]" rows="2" maxlength="800"><?= e($a) ?></textarea></div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <div class="form__actions"><button class="btn btn--primary btn--lg" type="submit">ذخیره‌ی محتوا</button></div>
</form>
