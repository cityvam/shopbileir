<?php use App\Services\Accounting; $system = (int) $acc['is_system'] === 1; ?>
<form class="card form account-form" method="post" action="/accounts/<?= (int) $acc['id'] ?>">
    <?= csrf_field() ?>
    <h2><?= e($acc['name']) ?> <?= $system ? badge('سیستمی', 'muted') : '' ?></h2>
    <div class="form-grid">
        <div class="field"><label for="code">کد حساب</label>
            <input class="input input--ltr" id="code" name="code" value="<?= e(old('code', $acc['code'])) ?>" <?= ($hasLines || $system) ? 'disabled' : '' ?> inputmode="numeric" maxlength="10">
            <?php if ($hasLines || $system): ?><small>کد حساب سیستمی یا دارای گردش تغییر نمی‌کند.</small><?php endif; ?>
        </div>
        <div class="field"><label for="name">نام حساب</label><input class="input" id="name" name="name" value="<?= e(old('name', $acc['name'])) ?>" required></div>
        <div class="field"><label for="parent_id">زیرمجموعه‌ی (والد)</label>
            <select class="input" id="parent_id" name="parent_id" <?= $system ? 'disabled' : '' ?>>
                <?php foreach ($parents as $n): if ($n['type'] !== $acc['type']) { continue; } ?>
                    <option value="<?= (int) $n['id'] ?>" <?= (int) $acc['parent_id'] === (int) $n['id'] ? 'selected' : '' ?>><?= str_repeat('— ', (int) $n['depth']) ?><?= fa($n['code']) ?> · <?= e($n['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field"><label>نوع</label><input class="input" value="<?= e(Accounting::typeLabel($acc['type'])) ?>" disabled></div>
    </div>
    <label class="check <?= $system ? 'is-disabled' : '' ?>"><input type="checkbox" name="is_active" value="1" <?= $acc['is_active'] ? 'checked' : '' ?> <?= $system ? 'disabled' : '' ?>><span>حساب فعال است (حساب غیرفعال سند نمی‌پذیرد؛ فقط حساب بدون مانده غیرفعال می‌شود)</span></label>
    <?php if ($system): ?><input type="hidden" name="is_active" value="1"><?php endif; ?>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ذخیره</button>
        <a class="btn btn--ghost" href="/accounts">بازگشت</a>
    </div>
</form>
