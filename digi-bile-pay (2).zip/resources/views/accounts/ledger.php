<?php use App\Services\Accounting; ?>
<section class="stat-grid">
    <article class="stat-card"><span class="stat-card__label">حساب</span><strong class="stat-card__value stat-card__value--money"><?= fa($acc['code']) ?> · <?= e($acc['name']) ?></strong><small><?= e(Accounting::typeLabel($acc['type'])) ?><?= $multi ? ' · شامل زیرمجموعه‌ها' : '' ?></small></article>
    <article class="stat-card"><span class="stat-card__label">مانده اول دوره</span><strong class="stat-card__value stat-card__value--money"><?= money($openBalance) ?></strong></article>
    <article class="stat-card"><span class="stat-card__label">گردش بدهکار / بستانکار</span><strong class="stat-card__value stat-card__value--money"><?= num($debit) ?> / <?= num($credit) ?></strong></article>
    <article class="stat-card stat-card--ok"><span class="stat-card__label">مانده پایان دوره</span><strong class="stat-card__value stat-card__value--money"><?= money($balance) ?></strong></article>
</section>
<section class="card">
    <div class="card__head"><h2>دفتر معین / کل</h2><a class="btn btn--ghost btn--sm" href="/accounts">بازگشت</a></div>
    <?php \App\Core\View::partial('period-filter', ['action' => '/accounts/' . (int) $acc['id'], 'from' => $from, 'to' => $to, 'errors' => $errors]); ?>
    <?php if (!$lines): ?><p class="empty">در این بازه گردشی ثبت نشده است.</p><?php else: ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>سند</th><th>تاریخ</th><?php if ($multi): ?><th>حساب</th><?php endif; ?><th>شرح</th><th>بدهکار</th><th>بستانکار</th><th>مانده</th></tr></thead>
        <tbody><?php foreach ($lines as $l): ?>
            <tr>
                <td><a href="/journal/<?= (int) $l['entry_id'] ?>">#<?= fa($l['entry_no']) ?></a></td>
                <td><?= jdate($l['entry_date']) ?></td>
                <?php if ($multi): ?><td><?= fa($l['code']) ?> · <?= e($l['name']) ?></td><?php endif; ?>
                <td class="wrap"><?= e($l['description']) ?><?= $l['line_desc'] ? '<br><small>' . e($l['line_desc']) . '</small>' : '' ?></td>
                <td><?= (int) $l['debit'] ? num((int) $l['debit']) : '—' ?></td>
                <td><?= (int) $l['credit'] ? num((int) $l['credit']) : '—' ?></td>
                <td><?= num((int) $l['running']) ?></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>
