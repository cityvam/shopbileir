<?php use App\Services\Accounting;
$dc = static function (int $v): string { return $v === 0 ? '—' : num(abs($v)); };
$bal = $tot['debit'] === $tot['credit'] && $tot['open'] === 0 && $tot['close'] === 0;
?>
<section class="card">
    <div class="card__head"><h2>تراز آزمایشی شش‌ستونی</h2><?= $bal ? badge('متوازن', 'ok') : badge('نامتوازن', 'bad') ?></div>
    <?php \App\Core\View::partial('period-filter', ['action' => '/trial-balance', 'from' => $from, 'to' => $to, 'errors' => $errors]); ?>
    <div class="table-wrap"><table class="table tree">
        <thead>
            <tr><th rowspan="2">کد</th><th rowspan="2">حساب</th><th colspan="2">مانده اول دوره</th><th colspan="2">گردش دوره</th><th colspan="2">مانده پایان دوره</th></tr>
            <tr><th>بدهکار</th><th>بستانکار</th><th>بدهکار</th><th>بستانکار</th><th>بدهکار</th><th>بستانکار</th></tr>
        </thead>
        <tbody><?php foreach ($tree as $n): ?>
            <tr class="<?= $n['kids'] > 0 ? 'tree__group' : '' ?>">
                <td class="ltr"><?= fa($n['code']) ?></td>
                <td><span class="tree__indent tree__indent--<?= min(3, (int) $n['depth']) ?>"></span><a href="/accounts/<?= (int) $n['id'] ?>?from=<?= e($from) ?>&amp;to=<?= e($to) ?>"><?= e($n['name']) ?></a></td>
                <td><?= $dc(max(0, $n['open'])) ?></td><td><?= $dc(max(0, -$n['open'])) ?></td>
                <td><?= $dc($n['debit']) ?></td><td><?= $dc($n['credit']) ?></td>
                <td><?= $dc(max(0, $n['close'])) ?></td><td><?= $dc(max(0, -$n['close'])) ?></td>
            </tr>
        <?php endforeach; ?></tbody>
        <tfoot><tr><th colspan="2">جمع (حساب‌های سطح آخر)</th>
            <th><?= num(max(0, $tot['open'])) ?></th><th><?= num(max(0, -$tot['open'])) ?></th>
            <th><?= num($tot['debit']) ?></th><th><?= num($tot['credit']) ?></th>
            <th><?= num(max(0, $tot['close'])) ?></th><th><?= num(max(0, -$tot['close'])) ?></th></tr></tfoot>
    </table></div>
</section>
