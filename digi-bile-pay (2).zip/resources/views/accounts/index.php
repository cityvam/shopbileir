<?php use App\Core\Auth; use App\Services\Accounting; ?>
<section class="card">
    <div class="card__head">
        <h2>سرفصل حساب‌ها</h2>
        <div class="card__tools"><a class="btn btn--secondary btn--sm" href="/trial-balance"><?= icon('scale', 16) ?><span>تراز آزمایشی</span></a></div>
    </div>
    <p class="hint">ساختار درختی: گروه ← حساب. فقط حساب‌های سطح آخر (بدون زیرمجموعه) سند می‌پذیرند و مانده گروه‌ها مجموع زیرمجموعه‌هاست. فقط اسناد قطعی شمرده می‌شوند.</p>
    <div class="table-wrap"><table class="table tree">
        <thead><tr><th>کد</th><th>نام حساب</th><th>نوع</th><th>گردش بدهکار</th><th>گردش بستانکار</th><th>مانده</th><th>وضعیت</th><th></th></tr></thead>
        <tbody><?php foreach ($tree as $n): ?>
            <tr class="<?= $n['kids'] > 0 ? 'tree__group' : '' ?><?= $n['is_active'] ? '' : ' is-muted' ?>">
                <td class="ltr"><?= fa($n['code']) ?></td>
                <td><span class="tree__indent tree__indent--<?= min(3, (int) $n['depth']) ?>"></span><a href="/accounts/<?= (int) $n['id'] ?>"><?= e($n['name']) ?></a><?= $n['is_system'] ? ' ' . badge('سیستمی', 'muted') : '' ?></td>
                <td><?= e(Accounting::typeLabel($n['type'])) ?></td>
                <td><?= num($n['debit']) ?></td><td><?= num($n['credit']) ?></td>
                <td><strong><?= money($n['balance']) ?></strong></td>
                <td><?= $n['is_active'] ? badge('فعال', 'ok') : badge('غیرفعال', 'muted') ?></td>
                <td class="table__actions">
                    <a class="btn btn--secondary btn--sm" href="/accounts/<?= (int) $n['id'] ?>"><?= icon('book', 16) ?><span>دفتر</span></a>
                    <?php if (Auth::can('accounting.post')): ?><a class="btn btn--secondary btn--sm" href="/accounts/<?= (int) $n['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a><?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
</section>
<?php if (Auth::can('accounting.post')): ?>
<form class="card form account-form" method="post" action="/accounts">
    <?= csrf_field() ?>
    <h2>افزودن حساب</h2>
    <div class="form-grid">
        <div class="field"><label for="parent_id">زیرمجموعه‌ی (والد)</label>
            <select class="input" id="parent_id" name="parent_id" required>
                <option value="">انتخاب کنید</option>
                <?php foreach ($parents as $n): ?><option value="<?= (int) $n['id'] ?>"><?= str_repeat('— ', (int) $n['depth']) ?><?= fa($n['code']) ?> · <?= e($n['name']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="field"><label for="code">کد حساب</label><input class="input input--ltr" id="code" name="code" inputmode="numeric" maxlength="10" required></div>
        <div class="field"><label for="name">نام حساب</label><input class="input" id="name" name="name" required></div>
    </div>
    <p class="hint">نوع حساب از والد ارث‌بری می‌شود. حسابی که گردش دارد نمی‌تواند والد شود.</p>
    <div class="form__actions"><button class="btn btn--primary" type="submit"><?= icon('plus', 16) ?><span>افزودن</span></button></div>
</form>
<?php endif; ?>
