<?php
$list = static function (array $rows): void {
    foreach ($rows as $r) {
        echo '<tr><td class="ltr">' . fa($r['code']) . '</td><td>' . e($r['name']) . '</td><td>' . money($r['balance']) . '</td></tr>';
    }
};
?>
<section class="card">
    <?php \App\Core\View::partial('period-filter', ['action' => '/statements', 'from' => $from, 'to' => $to, 'errors' => $errors]); ?>
</section>

<section class="card">
    <div class="card__head"><h2>صورت سود و زیان (<?= e($from) ?> تا <?= e($to) ?>)</h2></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>کد</th><th>حساب</th><th>مبلغ</th></tr></thead>
        <tbody>
            <tr class="sub"><th colspan="3">درآمدها</th></tr><?php $list($revenue); ?>
            <tr class="sub"><th colspan="3">هزینه‌ها</th></tr><?php $list($expense); ?>
        </tbody>
        <tfoot><tr><th colspan="2"><?= $periodProfit >= 0 ? 'سود دوره' : 'زیان دوره' ?></th><th class="<?= $periodProfit < 0 ? 'neg' : '' ?>"><?= money(abs($periodProfit)) ?></th></tr></tfoot>
    </table></div>
</section>

<section class="card">
    <div class="card__head"><h2>ترازنامه تا <?= e($to) ?></h2><?= $sumAssets === $sumLiabilities + $sumEquity + $profitToDate ? badge('متوازن', 'ok') : badge('نامتوازن', 'bad') ?></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>کد</th><th>حساب</th><th>مبلغ</th></tr></thead>
        <tbody>
            <tr class="sub"><th colspan="3">دارایی‌ها</th></tr><?php $list($assets); ?>
            <tr class="sub"><th colspan="3">بدهی‌ها</th></tr><?php $list($liabilities); ?>
            <tr class="sub"><th colspan="3">حقوق صاحبان سرمایه</th></tr><?php $list($equity); ?>
            <tr><td></td><td>سود (زیان) انباشته</td><td><?= money($profitToDate) ?></td></tr>
        </tbody>
        <tfoot>
            <tr><th colspan="2">جمع دارایی‌ها</th><th><?= money($sumAssets) ?></th></tr>
            <tr><th colspan="2">جمع بدهی‌ها و حقوق صاحبان سرمایه</th><th><?= money($sumLiabilities + $sumEquity + $profitToDate) ?></th></tr>
        </tfoot>
    </table></div>
</section>
