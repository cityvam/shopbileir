<?php use App\Core\Auth;
$base = '/notifications';
$fields = [
    ['key' => 'q', 'label' => 'جست‌وجو (مشتری، شماره، متن)', 'type' => 'text'],
    ['key' => 'status', 'label' => 'وضعیت', 'type' => 'select', 'options' => \App\Services\NotificationService::STATUS_LABELS],
    ['key' => 'template', 'label' => 'نوع پیام', 'type' => 'select', 'options' => $templates, 'adv' => true],
    ['key' => 'from', 'label' => 'از تاریخ', 'type' => 'date', 'adv' => true],
    ['key' => 'to', 'label' => 'تا تاریخ', 'type' => 'date', 'adv' => true],
];
$badge = ['queued' => 'warn', 'sent' => 'ok', 'failed' => 'bad'];
?>
<section class="card">
    <div class="card__head">
        <h2>پیامک‌ها و یادآوری اقساط</h2>
        <?php if (Auth::can('installments.collect')): ?>
        <form method="post" action="/notifications/run" data-confirm="یادآوری‌های جدید ساخته و صف پیامک ارسال شود؟"><?= csrf_field() ?><button class="btn btn--primary btn--sm" type="submit"><?= icon('zap', 16) ?><span>تولید یادآوری و ارسال</span></button></form>
        <?php endif; ?>
    </div>
    <?php if (!$driverOn): ?>
        <div class="notice notice--warning nt-warn">درایور پیامک فعال نیست؛ پیام‌ها فقط در صف می‌مانند. مقدار <bdi class="ltr">SMS_DRIVER</bdi> را در <bdi class="ltr">.env</bdi> روی <bdi class="ltr">log</bdi> یا <bdi class="ltr">kavenegar</bdi> بگذارید.</div>
    <?php endif; ?>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => $base, 'fields' => $fields, 'csv' => true]); ?>
    <p class="result-bar"><?= fa($pg['total']) ?> پیام · در صف: <?= fa($queued) ?></p>
    <?php if (!$rows): ?>
        <p class="empty">پیامی ثبت نشده است.</p>
    <?php else: ?>
        <div class="table-wrap"><table class="table table--stack">
            <thead><tr><th><?= $lf->sortLink($base, 'created', 'شماره') ?></th><th><?= $lf->sortLink($base, 'customer', 'مشتری') ?></th><th>گیرنده</th><th>نوع</th><th>متن</th><th>وضعیت</th><th>تاریخ</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td>#<?= fa($r['id']) ?></td>
                    <td><?php if ($r['customer_id']): ?><a href="/customers/<?= (int) $r['customer_id'] ?>"><?= e($r['full_name']) ?></a><?php else: ?>—<?php endif; ?></td>
                    <td class="ltr"><?= fa($r['recipient']) ?></td>
                    <td><?= e($templates[$r['template']] ?? $r['template']) ?></td>
                    <td class="nt-body"><?= e($r['body']) ?><?php if ($r['last_error']): ?><small class="nt-err"><?= e($r['last_error']) ?></small><?php endif; ?></td>
                    <td><span class="badge badge--<?= e($badge[$r['status']] ?? 'muted') ?>"><?= e(\App\Services\NotificationService::STATUS_LABELS[$r['status']] ?? $r['status']) ?></span></td>
                    <td><?= jdate($r['created_at'], true) ?></td>
                    <td class="table__actions"><?php if ($r['status'] === 'failed' && Auth::can('installments.collect')): ?><form method="post" action="/notifications/<?= (int) $r['id'] ?>/retry"><?= csrf_field() ?><button class="btn btn--secondary btn--sm" type="submit"><?= icon('refresh', 16) ?><span>تلاش مجدد</span></button></form><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
