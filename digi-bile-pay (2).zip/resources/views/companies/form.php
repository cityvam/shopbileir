<form class="card form company-form" method="post" action="/companies">
    <?= csrf_field() ?>
    <h2>اطلاعات شرکت</h2>
    <div class="form-grid">
        <div class="field">
            <label for="code">کد شرکت (لاتین)</label>
            <input class="input input--ltr" id="code" name="code" value="<?= e(old('code')) ?>" required maxlength="40">
        </div>
        <div class="field">
            <label for="name">نام شرکت</label>
            <input class="input" id="name" name="name" value="<?= e(old('name')) ?>" required>
        </div>
        <div class="field">
            <label for="brand_name">نام برند (اختیاری)</label>
            <input class="input" id="brand_name" name="brand_name" value="<?= e(old('brand_name')) ?>">
        </div>
        <div class="field">
            <label for="parent_id">شرکت مادر</label>
            <select class="input" id="parent_id" name="parent_id">
                <option value="0">— بدون شرکت مادر —</option>
                <?php foreach ($parents as $p): ?>
                    <option value="<?= (int) $p['id'] ?>" <?= old('parent_id') == $p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <h2>کاربر مدیر شرکت</h2>
    <p class="hint">نقش‌های پیش‌فرض شرکت به‌طور خودکار ساخته می‌شود و این کاربر نقش «مدیر شرکت» را می‌گیرد.</p>
    <div class="form-grid">
        <div class="field">
            <label for="admin_username">نام کاربری</label>
            <input class="input input--ltr" id="admin_username" name="admin_username" value="<?= e(old('admin_username')) ?>" required autocomplete="off">
        </div>
        <div class="field">
            <label for="admin_name">نام و نام خانوادگی</label>
            <input class="input" id="admin_name" name="admin_name" value="<?= e(old('admin_name')) ?>" required>
        </div>
        <div class="field">
            <label for="admin_password">رمز عبور (حداقل ۱۰ نویسه، حرف و عدد)</label>
            <input class="input input--ltr" id="admin_password" name="admin_password" type="password" required autocomplete="new-password">
        </div>
    </div>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ثبت شرکت</button>
        <a class="btn btn--ghost" href="/companies">بازگشت</a>
    </div>
</form>
