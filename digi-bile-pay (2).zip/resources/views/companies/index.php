<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>فهرست شرکت‌ها و برندها</h2>
        <?php if (Auth::can('companies.manage')): ?>
            <a class="btn btn--primary btn--sm" href="/companies/create"><?= icon('plus', 16) ?><span>شرکت جدید</span></a>
        <?php endif; ?>
    </div>
    <div class="table-wrap">
        <table class="table table--stack">
            <thead><tr><th>کد</th><th>نام</th><th>برند</th><th>شرکت مادر</th><th>وضعیت</th><th>ثبت</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="ltr"><?= e($r['code']) ?></td>
                    <td><?= e($r['name']) ?></td>
                    <td><?= e($r['brand_name'] ?? '—') ?></td>
                    <td><?= e($r['parent_name'] ?? '—') ?></td>
                    <td><?= status_badge('entity', $r['status']) ?></td>
                    <td><?= jdate($r['created_at']) ?></td>
                    <td class="table__actions">
                        <?php if (Auth::can('companies.manage') && (int) $r['id'] !== Auth::companyId()): ?>
                            <form method="post" action="/companies/<?= (int) $r['id'] ?>/status" data-confirm="وضعیت این شرکت تغییر کند؟">
                                <?= csrf_field() ?>
                                <button class="btn btn--secondary btn--sm" type="submit"><?= $r['status'] === 'active' ? 'تعلیق' : 'فعال‌سازی' ?></button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
