<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>سال‌های مالی</h2>
        <?php if (Auth::can('accounting.post')): ?>
            <form method="post" action="/fiscal-years" data-confirm="سال مالی بعدی ایجاد شود؟"><?= csrf_field() ?><button class="btn btn--primary btn--sm" type="submit"><?= icon('plus', 16) ?><span>سال مالی بعدی</span></button></form>
        <?php endif; ?>
    </div>
    <p class="hint">هر سند باید در یک سال مالی باز ثبت شود. «سند اختتامیه» مانده درآمد و هزینه را به سود (زیان) انباشته منتقل می‌کند (صورت سود و زیان همان سال بدون تغییر می‌ماند). بستن سال مالی ثبت، ویرایش و ابطال سند در آن را قفل می‌کند و فقط وقتی ممکن است که سند موقت نداشته باشد.</p>
    <div class="table-wrap"><table class="table table--stack">
        <thead><tr><th>عنوان</th><th>از</th><th>تا</th><th>اسناد قطعی</th><th>اسناد موقت</th><th>سند اختتامیه</th><th>وضعیت</th><th></th></tr></thead>
        <tbody><?php foreach ($rows as $r): ?>
            <tr>
                <td><?= e($r['title']) ?></td><td><?= jdate($r['start_date']) ?></td><td><?= jdate($r['end_date']) ?></td>
                <td><?= num((int) $r['finals']) ?></td><td><?= (int) $r['drafts'] > 0 ? badge(num((int) $r['drafts']), 'warn') : '—' ?></td>
                <td><?= $r['closing_id'] ? '<a href="/journal/' . (int) $r['closing_id'] . '">مشاهده</a>' : '—' ?></td>
                <td><?= $r['status'] === 'open' ? badge('باز', 'ok') : badge('بسته', 'bad') ?><?= $r['closer'] ? ' <small>' . e($r['closer']) . ' · ' . jdate($r['closed_at']) . '</small>' : '' ?></td>
                <td class="table__actions">
                    <a class="btn btn--secondary btn--sm" href="/journal?from=<?= e(jdate($r['start_date'])) ?>&amp;to=<?= e(jdate($r['end_date'])) ?>"><?= icon('file-text', 16) ?><span>اسناد</span></a>
                    <?php if (Auth::can('accounting.post')): ?>
                        <?php if ($r['status'] === 'open'): ?>
                            <?php if ($r['closing_id']): ?>
                                <form method="post" action="/fiscal-years/<?= (int) $r['id'] ?>/closing/undo" data-confirm="سند اختتامیه با سند معکوس ابطال شود؟"><?= csrf_field() ?><button class="btn btn--secondary btn--sm" type="submit">ابطال اختتامیه</button></form>
                            <?php else: ?>
                                <form method="post" action="/fiscal-years/<?= (int) $r['id'] ?>/closing" data-confirm="سند اختتامیه صادر شود؟ مانده درآمدها و هزینه‌ها به سود (زیان) انباشته منتقل می‌شود."><?= csrf_field() ?><button class="btn btn--secondary btn--sm" type="submit">سند اختتامیه</button></form>
                            <?php endif; ?>
                            <form method="post" action="/fiscal-years/<?= (int) $r['id'] ?>/close" data-confirm="سال مالی بسته شود؟ پس از بستن، ثبت سند در آن ممکن نیست."><?= csrf_field() ?><button class="btn btn--danger btn--sm" type="submit">بستن</button></form>
                        <?php else: ?>
                            <form method="post" action="/fiscal-years/<?= (int) $r['id'] ?>/reopen" data-confirm="سال مالی بازگشایی شود؟"><?= csrf_field() ?><button class="btn btn--secondary btn--sm" type="submit">بازگشایی</button></form>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
</section>
