<?php $selC = (int) old('customer_id', (string) $selectedCustomer); ?>
<?php if (!$customers || !$plans): ?>
    <section class="card"><p class="empty">برای ثبت درخواست، حداقل یک مشتری فعال و یک طرح فعال لازم است.</p></section>
<?php else: ?>
<form class="card form loan-form" method="post" action="/loans">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field">
            <label for="customer_id">مشتری</label>
            <select class="input" id="customer_id" name="customer_id" required>
                <option value="">انتخاب کنید…</option>
                <?php foreach ($customers as $c): ?>
                    <option value="<?= (int) $c['id'] ?>" <?= $selC === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['full_name']) ?> — <?= fa($c['national_code']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field">
            <label for="plan_id">طرح تسهیلاتی</label>
            <select class="input" id="plan_id" name="plan_id" required>
                <option value="">انتخاب کنید…</option>
                <?php foreach ($plans as $p): ?>
                    <option value="<?= (int) $p['id'] ?>" <?= (int) old('plan_id', '0') === (int) $p['id'] ? 'selected' : '' ?>>
                        <?= e($p['name']) ?> (<?= fa($p['months']) ?> ماه، <?= fa((float) $p['annual_rate_percent']) ?>٪، <?= num((int) $p['min_amount']) ?>–<?= num((int) $p['max_amount']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field">
            <label for="amount">مبلغ تسهیلات (ریال)</label>
            <input class="input input--ltr" id="amount" name="amount" value="<?= e(old('amount')) ?>" inputmode="numeric" data-money required>
        </div>
    </div>
    <p class="hint">جدول اقساط پس از ثبت درخواست نمایش داده می‌شود. تأیید باید توسط کاربر دیگری انجام شود.</p>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ثبت درخواست</button>
        <a class="btn btn--ghost" href="/loans">بازگشت</a>
    </div>
</form>
<?php endif; ?>
