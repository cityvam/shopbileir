<section class="card loan-head">
    <div class="loan-head__title">
        <h2>تسهیلات #<?= fa($loan['id']) ?> <?= status_badge('loan', $loan['status']) ?></h2>
        <p class="hint">مشتری: <a href="/customers/<?= (int) $loan['customer_id'] ?>"><?= e($loan['full_name']) ?></a> · طرح: <?= e($loan['plan_name']) ?></p>
    </div>
    <dl class="loan-facts">
        <div><dt>اصل تسهیلات</dt><dd><?= money((int) $loan['principal']) ?></dd></div>
        <div><dt>نرخ سالانه</dt><dd><?= fa((float) $loan['annual_rate_percent']) ?>٪</dd></div>
        <div><dt>تعداد اقساط</dt><dd><?= fa($loan['months']) ?></dd></div>
        <div><dt>مجموع سود</dt><dd><?= money((int) $loan['total_interest']) ?></dd></div>
        <div><dt>مجموع بازپرداخت</dt><dd><?= money((int) $loan['total_payable']) ?></dd></div>
        <div><dt>کارمزد</dt><dd><?= money((int) $loan['fee_amount']) ?></dd></div>
        <div><dt>درخواست‌دهنده</dt><dd><?= e($loan['requester_name']) ?> · <?= jdate($loan['created_at'], true) ?></dd></div>
        <?php if ($loan['decided_at']): ?>
            <div><dt>تصمیم‌گیرنده</dt><dd><?= e($loan['decider_name'] ?? '—') ?> · <?= jdate($loan['decided_at'], true) ?></dd></div>
        <?php endif; ?>
        <?php if ($loan['decision_note']): ?>
            <div><dt>دلیل رد</dt><dd><?= e($loan['decision_note']) ?></dd></div>
        <?php endif; ?>
    </dl>
</section>

<?php if ($canDecide): ?>
    <section class="card decision">
        <form method="post" action="/loans/<?= (int) $loan['id'] ?>/approve" data-confirm="تسهیلات تأیید و جدول اقساط ایجاد شود؟">
            <?= csrf_field() ?>
            <button class="btn btn--success" type="submit"><?= icon('check', 18) ?><span>تأیید تسهیلات</span></button>
        </form>
        <form class="decision__reject" method="post" action="/loans/<?= (int) $loan['id'] ?>/reject" data-confirm="درخواست رد شود؟">
            <?= csrf_field() ?>
            <input class="input" name="note" placeholder="دلیل رد درخواست" maxlength="250" required>
            <button class="btn btn--danger" type="submit"><?= icon('x', 18) ?><span>رد درخواست</span></button>
        </form>
    </section>
<?php elseif ($loan['status'] === 'pending'): ?>
    <p class="notice notice--info">تأیید یا رد این درخواست باید توسط کاربر دیگری با مجوز مربوطه انجام شود.</p>
<?php endif; ?>

<?php if ($quote && $quote['total'] > 0 && \App\Core\Auth::can('installments.collect')): ?>
    <section class="card payoff">
        <div class="card__head"><h2>تسویه زودهنگام</h2></div>
        <p>مبلغ تسویه امروز <strong><?= money($quote['total']) ?></strong> است<?= $quote['waived'] > 0 ? ' و سود اقساط آینده به مبلغ <strong>' . money($quote['waived']) . '</strong> بخشوده می‌شود' : '' ?>.</p>
        <form class="payoff__form" method="post" action="/loans/<?= (int) $loan['id'] ?>/payoff" data-confirm="تسهیلات تسویه و بسته شود؟ این عملیات برگشت‌پذیر نیست.">
            <?= csrf_field() ?>
            <select class="input" name="method" aria-label="روش پرداخت"><option value="cash">نقدی</option><option value="wallet">کیف پول مشتری</option></select>
            <button class="btn btn--success" type="submit"><?= icon('check', 18) ?><span>تسویه و بستن تسهیلات</span></button>
        </form>
    </section>
<?php endif; ?>

<section class="card">
    <div class="card__head"><h2><?= $isPreview ? 'پیش‌نمایش جدول اقساط' : 'جدول اقساط' ?></h2></div>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr><th>قسط</th><th>سررسید</th><th>اصل</th><th>سود</th><th>مبلغ قسط</th><?php if (!$isPreview): ?><th>پرداخت‌شده</th><th>وضعیت</th><?php endif; ?></tr>
            </thead>
            <tbody>
            <?php foreach ($schedule as $r): ?>
                <tr>
                    <td><?= fa($r['seq']) ?></td>
                    <td><?= jdate($r['due_date']) ?></td>
                    <td><?= money((int) $r['principal_part']) ?></td>
                    <td><?= money((int) $r['interest_part']) ?></td>
                    <td><?= money((int) $r['amount']) ?></td>
                    <?php if (!$isPreview): ?>
                        <td><?= money((int) $r['paid_amount']) ?></td>
                        <td><?= status_badge('installment', $r['status']) ?></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
<?php \App\Core\View::partial('notes-panel', ['entity' => 'loan', 'entityId' => (int) $loan['id'], 'notes' => $internalNotes, 'canAdd' => true]); ?>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
