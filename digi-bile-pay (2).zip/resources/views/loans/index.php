<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head">
        <h2>تسهیلات</h2>
        <?php if (Auth::can('loans.create')): ?>
            <a class="btn btn--primary btn--sm" href="/loans/create"><?= icon('plus', 16) ?><span>درخواست جدید</span></a>
        <?php endif; ?>
    </div>
    <div class="tabs" role="tablist">
        <?php foreach (['' => 'همه', 'pending' => 'در انتظار', 'active' => 'فعال', 'closed' => 'تسویه‌شده', 'rejected' => 'ردشده'] as $k => $label): ?>
            <a class="tabs__link<?= $lf->v['status'] === $k ? ' is-active' : '' ?>" href="/loans?<?= e($lf->qs(['status' => $k, 'page' => ''])) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
    </div>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => '/loans', 'csv' => true, 'hidden' => ['status' => $lf->v['status']], 'fields' => [
        ['key' => 'q', 'label' => 'جست‌وجو (نام، کد ملی، موبایل مشتری)', 'type' => 'text'],
        ['key' => 'plan_id', 'label' => 'طرح', 'type' => 'select', 'options' => array_column($plans, 'name', 'id'), 'adv' => true],
        ['key' => 'min', 'label' => 'حداقل مبلغ', 'type' => 'money', 'adv' => true],
        ['key' => 'max', 'label' => 'حداکثر مبلغ', 'type' => 'money', 'adv' => true],
        ['key' => 'from', 'label' => 'از تاریخ', 'type' => 'date', 'adv' => true],
        ['key' => 'to', 'label' => 'تا تاریخ', 'type' => 'date', 'adv' => true],
    ]]); ?>
    <p class="result-bar"><?= fa($pg['total']) ?> مورد · جمع مبلغ: <?= money($sum) ?></p>
    <?php if (!$rows): ?>
        <p class="empty">موردی یافت نشد.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="table table--stack">
                <thead><tr><th><?= $lf->sortLink('/loans', 'id', 'شماره') ?></th><th><?= $lf->sortLink('/loans', 'customer', 'مشتری') ?></th><th>طرح</th><th><?= $lf->sortLink('/loans', 'amount', 'مبلغ') ?></th><th><?= $lf->sortLink('/loans', 'months', 'اقساط') ?></th><th>وضعیت</th><th>تاریخ</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td>#<?= fa($r['id']) ?></td>
                        <td><?= e($r['full_name']) ?></td>
                        <td><?= e($r['plan_name']) ?></td>
                        <td><?= money((int) $r['principal']) ?></td>
                        <td><?= fa($r['months']) ?></td>
                        <td><?= status_badge('loan', $r['status']) ?></td>
                        <td><?= jdate($r['created_at']) ?></td>
                        <td class="table__actions"><a class="btn btn--secondary btn--sm" href="/loans/<?= (int) $r['id'] ?>"><?= icon('eye', 16) ?><span>مشاهده</span></a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
