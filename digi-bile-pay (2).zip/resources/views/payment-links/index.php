<?php
$base = '/payment-links';
$fields = [
    ['key' => 'q', 'label' => 'جست‌وجو (نام، کد ملی، موبایل، کد پیگیری)', 'type' => 'text'],
    ['key' => 'status', 'label' => 'وضعیت', 'type' => 'select', 'options' => \App\Services\PaymentLinkService::STATUS_LABELS],
    ['key' => 'kind', 'label' => 'نوع', 'type' => 'select', 'options' => ['installment' => 'قسط', 'topup' => 'شارژ کیف پول'], 'adv' => true],
    ['key' => 'min', 'label' => 'مبلغ از', 'type' => 'money', 'adv' => true],
    ['key' => 'max', 'label' => 'مبلغ تا', 'type' => 'money', 'adv' => true],
    ['key' => 'from', 'label' => 'ساخت از تاریخ', 'type' => 'date', 'adv' => true],
    ['key' => 'to', 'label' => 'ساخت تا تاریخ', 'type' => 'date', 'adv' => true],
];
$badge = ['pending' => 'warn', 'paid' => 'ok', 'failed' => 'bad', 'cancelled' => 'muted', 'expired' => 'muted'];
?>
<section class="card">
    <div class="card__head"><h2>لینک‌های پرداخت آنلاین</h2></div>
    <?php if (!$gatewayOn): ?>
        <div class="notice notice--warning pl-warn">درگاه پرداخت فعال نیست؛ مقدار <bdi class="ltr">PAYMENT_GATEWAY</bdi> را در فایل <bdi class="ltr">.env</bdi> تنظیم کنید. لینک‌ها ساخته می‌شوند اما مشتری نمی‌تواند پرداخت کند.</div>
    <?php endif; ?>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => $base, 'fields' => $fields, 'csv' => true]); ?>
    <p class="result-bar"><?= fa($pg['total']) ?> لینک · جمع پرداخت‌شده‌ی این فیلتر: <?= money($paidSum) ?></p>
    <?php if (!$rows): ?>
        <p class="empty">لینکی ساخته نشده است. از صفحه‌ی اقساط یا پروفایل مشتری لینک بسازید.</p>
    <?php else: ?>
        <div class="table-wrap"><table class="table table--stack">
            <thead><tr><th><?= $lf->sortLink($base, 'created', 'شماره') ?></th><th><?= $lf->sortLink($base, 'customer', 'مشتری') ?></th><th>نوع</th><th><?= $lf->sortLink($base, 'amount', 'مبلغ') ?></th><th>وضعیت</th><th>درگاه / پیگیری</th><th>تاریخ ساخت</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td>#<?= fa($r['id']) ?></td>
                    <td><a href="/customers/<?= (int) $r['customer_id'] ?>"><?= e($r['full_name']) ?></a></td>
                    <td><?= $r['kind'] === 'installment' ? 'قسط' : 'شارژ کیف پول' ?></td>
                    <td><?= money((int) $r['amount']) ?></td>
                    <td><span class="badge badge--<?= e($badge[$r['status']] ?? 'muted') ?>"><?= e(\App\Services\PaymentLinkService::STATUS_LABELS[$r['status']] ?? $r['status']) ?></span></td>
                    <td class="ltr"><?= e(trim(($r['gateway'] ?? '') . ' ' . ($r['ref_id'] ?? '')) ?: '—') ?></td>
                    <td><?= jdate($r['created_at'], true) ?></td>
                    <td class="table__actions"><a class="btn btn--secondary btn--sm" href="/payment-links/<?= (int) $r['id'] ?>"><?= icon('eye', 16) ?><span>مشاهده</span></a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
