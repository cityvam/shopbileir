<?php use App\Core\Auth;
$badge = ['pending' => 'warn', 'paid' => 'ok', 'failed' => 'bad', 'cancelled' => 'muted', 'expired' => 'muted'];
?>
<section class="card">
    <div class="card__head">
        <h2>لینک پرداخت #<?= fa($r['id']) ?> · <?= e($r['full_name']) ?> <span class="badge badge--<?= e($badge[$r['status']] ?? 'muted') ?>"><?= e(\App\Services\PaymentLinkService::STATUS_LABELS[$r['status']] ?? $r['status']) ?></span></h2>
        <div class="card__tools">
            <?php if ($r['status'] === 'pending' && Auth::can('installments.collect')): ?>
                <form method="post" action="/payment-links/<?= (int) $r['id'] ?>/cancel" data-confirm="این لینک لغو شود؟"><?= csrf_field() ?><button class="btn btn--danger btn--sm" type="submit">لغو لینک</button></form>
            <?php endif; ?>
            <a class="btn btn--ghost btn--sm" href="/payment-links">بازگشت</a>
        </div>
    </div>
    <dl class="pl-facts">
        <div><dt>نوع</dt><dd><?= $r['kind'] === 'installment' ? 'پرداخت قسط' : 'شارژ کیف پول' ?></dd></div>
        <div><dt>مبلغ</dt><dd><?= money((int) $r['amount']) ?></dd></div>
        <div><dt>موبایل مشتری</dt><dd class="ltr"><?= fa($r['mobile'] ?? '') ?></dd></div>
        <div><dt>اعتبار تا</dt><dd><?= jdate($r['expires_at'], true) ?></dd></div>
        <div><dt>درگاه</dt><dd class="ltr"><?= e($r['gateway'] ?: '—') ?></dd></div>
        <div><dt>کد پیگیری</dt><dd class="ltr"><?= e($r['ref_id'] ?: '—') ?></dd></div>
        <?php if ($r['paid_at']): ?><div><dt>زمان پرداخت</dt><dd><?= jdate($r['paid_at'], true) ?></dd></div><?php endif; ?>
    </dl>
    <?php if ($r['note']): ?><p class="notice notice--warning"><?= e($r['note']) ?></p><?php endif; ?>
    <?php if ($r['status'] === 'pending'): ?>
        <div class="field">
            <label for="pl_url">لینک پرداخت برای مشتری</label>
            <div class="pl-url">
                <input class="input" id="pl_url" value="<?= e($url) ?>" readonly>
                <button class="btn btn--secondary" type="button" data-copy="#pl_url"><?= icon('check', 16) ?><span>کپی لینک</span></button>
            </div>
        </div>
        <?php if (!$gatewayOn): ?><p class="notice notice--warning">درگاه پرداخت فعال نیست؛ مشتری هنوز نمی‌تواند از این لینک پرداخت کند.</p><?php endif; ?>
    <?php endif; ?>
</section>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
