<?php use App\Services\ChequeService;
$isIssued = $c['direction'] === 'issued';
$needsBank = fn (string $to) => in_array($to, ['deposited', 'cleared', 'passed'], true); ?>
<section class="card customer-head">
    <div>
        <h2>چک <?= $isIssued ? 'صادره' : 'دریافتی' ?> <span class="ltr"><?= e($c['cheque_no']) ?></span> <?= status_badge('entity', $c['status']) ?></h2>
        <p class="hint"><?= e($c['bank_name']) ?> · <?= e($c['party']) ?><?= $detail ? ' · تفصیلی: <a href="/dimensions/' . (int) $detail['id'] . '">' . e($detail['name']) . '</a>' : '' ?></p>
    </div>
</section>
<section class="credit-grid">
    <article class="stat-card"><span class="stat-card__label">مبلغ</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $c['amount']) ?></strong></article>
    <article class="stat-card"><span class="stat-card__label">تاریخ صدور</span><strong class="stat-card__value"><?= jdate($c['issue_date']) ?></strong></article>
    <article class="stat-card <?= in_array($c['status'], ['in_hand', 'deposited', 'issued'], true) && $c['due_date'] < date('Y-m-d') ? 'stat-card--bad' : '' ?>"><span class="stat-card__label">سررسید</span><strong class="stat-card__value"><?= jdate($c['due_date']) ?></strong></article>
</section>
<section class="card">
    <dl class="journal-facts">
        <div><dt>حساب مقابل</dt><dd><?= $counter ? e($counter['name']) : '—' ?></dd></div>
        <div><dt>حساب بانک/صندوق</dt><dd><?= $bank ? e($bank['name']) : '—' ?></dd></div>
        <div><dt>سند ثبت</dt><dd><?= $regEntry ? '<a href="/journal/' . (int) $regEntry['id'] . '">#' . fa($regEntry['entry_no']) . '</a>' : '—' ?></dd></div>
        <div><dt>سند وصول/پاس/برگشت</dt><dd><?= $finalEntry ? '<a href="/journal/' . (int) $finalEntry['id'] . '">#' . fa($finalEntry['entry_no']) . '</a>' : '—' ?></dd></div>
        <?php if ($c['endorsed_to']): ?><div><dt>پشت‌نویسی‌شده به</dt><dd><?= e($c['endorsed_to']) ?></dd></div><?php endif; ?>
        <div><dt>توضیحات</dt><dd><?= e($c['description'] ?? '—') ?></dd></div>
    </dl>
</section>
<?php if ($canPost && $c['direction'] === 'received' && $c['status'] === 'in_hand'): ?>
<section class="card">
    <div class="card__head"><h2>پشت‌نویسی به شخص ثالث</h2></div>
    <form class="status-form" method="post" action="/cheques/<?= (int) $c['id'] ?>/endorse" data-confirm="چک پشت‌نویسی شود؟ سند حسابداری خودکار صادر می‌شود.">
        <?= csrf_field() ?>
        <div class="field field--grow"><label for="endorsee">پشت‌نویسی به (نام شخص)</label><input class="input" id="endorsee" name="endorsee" maxlength="120" required></div>
        <div class="field"><label for="counter_account_id_e">حساب طرف پشت‌نویسی (بدهی که تسویه می‌شود)</label>
            <select class="input" id="counter_account_id_e" name="counter_account_id" required><option value="">انتخاب کنید</option>
                <?php foreach ($choices['accounts'] as $a): ?><option value="<?= (int) $a['id'] ?>"><?= fa($a['code']) ?> · <?= e($a['name']) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label for="detail_id_e">تفصیلی (اختیاری)</label>
            <select class="input" id="detail_id_e" name="detail_id"><option value="">—</option>
                <?php foreach ($choices['details'] as $d): ?><option value="<?= (int) $d['id'] ?>"><?= e($d['name']) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label for="date_e">تاریخ (شمسی)</label><input class="input input--ltr" id="date_e" name="date" placeholder="<?= e(\App\Core\Jalali::format(date('Y-m-d'))) ?>"></div>
        <button class="btn btn--primary" type="submit">پشت‌نویسی</button>
    </form>
    <p class="hint">سند: بدهکار حساب طرف پشت‌نویسی ← بستانکار اسناد دریافتنی. چک از دارایی‌های نزد صندوق خارج می‌شود.</p>
</section>
<?php elseif ($canPost && $c['status'] === 'endorsed'): ?>
<section class="card">
    <div class="card__head"><h2>بازگشت پشت‌نویسی</h2></div>
    <form class="status-form" method="post" action="/cheques/<?= (int) $c['id'] ?>/unendorse" data-confirm="پشت‌نویسی بازگردانده و سند آن معکوس شود؟">
        <?= csrf_field() ?>
        <div class="field"><label for="date_u">تاریخ (شمسی)</label><input class="input input--ltr" id="date_u" name="date" placeholder="<?= e(\App\Core\Jalali::format(date('Y-m-d'))) ?>"></div>
        <div class="field field--grow"><label for="reason_u">دلیل (الزامی)</label><input class="input" id="reason_u" name="reason" maxlength="500" required></div>
        <button class="btn btn--danger" type="submit">بازگشت به صندوق</button>
    </form>
</section>
<?php endif; ?>
<?php if ($canPost && $next): ?>
<section class="card">
    <div class="card__head"><h2>تغییر وضعیت چک</h2></div>
    <form class="status-form" method="post" action="/cheques/<?= (int) $c['id'] ?>/status" data-confirm="وضعیت چک تغییر کند؟ در صورت نیاز سند حسابداری خودکار صادر می‌شود.">
        <?= csrf_field() ?>
        <div class="field"><label for="to_status">وضعیت جدید</label>
            <select class="input" id="to_status" name="to_status"><?php foreach ($next as $k => $l): ?><option value="<?= e($k) ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label for="date">تاریخ (شمسی)</label><input class="input input--ltr" id="date" name="date" placeholder="<?= e(\App\Core\Jalali::format(date('Y-m-d'))) ?>"></div>
        <div class="field"><label for="bank_account_id">حساب بانک/صندوق</label>
            <select class="input" id="bank_account_id" name="bank_account_id"><option value="">پیش‌فرض چک</option>
                <?php foreach ($banks as $a): ?><option value="<?= (int) $a['id'] ?>" <?= (int) $c['bank_account_id'] === (int) $a['id'] ? 'selected' : '' ?>><?= fa($a['code']) ?> · <?= e($a['name']) ?></option><?php endforeach; ?></select></div>
        <div class="field field--grow"><label for="reason">دلیل (برای برگشت/ابطال الزامی)</label><input class="input" id="reason" name="reason" maxlength="500"></div>
        <button class="btn btn--primary" type="submit">ثبت</button>
    </form>
    <p class="hint">وصول/پاس: سند «بانک ↔ اسناد» صادر می‌شود. برگشت یا ابطال: سند ثبت اولیه معکوس می‌شود. واگذاری به بانک و بازگشت به صندوق سند ندارند.</p>
</section>
<form class="card form" method="post" action="/cheques/<?= (int) $c['id'] ?>">
    <?= csrf_field() ?>
    <div class="card__head"><h2>ویرایش اطلاعات غیرمالی</h2></div>
    <div class="form-grid">
        <div class="field"><label for="party_e">طرف حساب</label><input class="input" id="party_e" name="party" value="<?= e($c['party']) ?>" maxlength="120" required></div>
        <div class="field"><label for="due_date_e">سررسید (شمسی)</label><input class="input input--ltr" id="due_date_e" name="due_date" value="<?= e(\App\Core\Jalali::format($c['due_date'])) ?>" required></div>
        <div class="field field--wide"><label for="description_e">توضیحات</label><input class="input" id="description_e" name="description" value="<?= e($c['description'] ?? '') ?>" maxlength="250"></div>
    </div>
    <p class="hint">مبلغ و حساب‌ها حسابداری شده‌اند؛ برای تغییر آن‌ها چک را ابطال و دوباره ثبت کنید.</p>
    <div class="form__actions"><button class="btn btn--secondary" type="submit">ذخیره</button></div>
</form>
<?php endif; ?>
<?php \App\Core\View::partial('status-panel', ['action' => '', 'current' => $c['status'], 'history' => $history, 'canManage' => false, 'options' => []]); ?>
<?php \App\Core\View::partial('notes-panel', ['entity' => 'cheque', 'entityId' => (int) $c['id'], 'notes' => $internalNotes, 'canAdd' => true]); ?>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
