<?php use App\Core\Auth;
use App\Services\ChequeService;
$base = '/cheques';
$fields = [
    ['key' => 'q', 'label' => 'جست‌وجو (شماره، طرف حساب، بانک)', 'type' => 'text'],
    ['key' => 'direction', 'label' => 'جهت', 'type' => 'select', 'options' => ['received' => 'دریافتی', 'issued' => 'صادره']],
    ['key' => 'status', 'label' => 'وضعیت', 'type' => 'select', 'options' => ChequeService::STATUS_LABELS],
    ['key' => 'due', 'label' => 'سررسید', 'type' => 'select', 'options' => ['overdue' => 'گذشته و باز', 'week' => 'تا ۷ روز آینده']],
    ['key' => 'from', 'label' => 'سررسید از', 'type' => 'date', 'adv' => true],
    ['key' => 'to', 'label' => 'سررسید تا', 'type' => 'date', 'adv' => true],
    ['key' => 'min', 'label' => 'حداقل مبلغ', 'type' => 'money', 'adv' => true],
    ['key' => 'max', 'label' => 'حداکثر مبلغ', 'type' => 'money', 'adv' => true],
];
?>
<section class="credit-grid">
    <article class="stat-card stat-card--ok"><span class="stat-card__label">چک‌های دریافتی در جریان</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $sum['rec']) ?></strong></article>
    <article class="stat-card stat-card--warn"><span class="stat-card__label">چک‌های صادره در جریان</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $sum['iss']) ?></strong></article>
    <article class="stat-card stat-card--bad"><span class="stat-card__label">سررسید گذشته (باز)</span><strong class="stat-card__value"><?= num((int) $sum['overdue']) ?></strong></article>
    <article class="stat-card"><span class="stat-card__label">سررسید ۷ روز آینده</span><strong class="stat-card__value"><?= num((int) $sum['week']) ?></strong></article>
</section>
<section class="card">
    <div class="card__head">
        <h2>چک‌ها</h2>
        <?php if (Auth::can('accounting.post')): ?><a class="btn btn--primary btn--sm" href="/cheques/create"><?= icon('plus', 16) ?><span>ثبت چک</span></a><?php endif; ?>
    </div>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => $base, 'fields' => $fields, 'csv' => true]); ?>
    <p class="result-bar"><?= fa($pg['total']) ?> چک</p>
    <?php if (!$rows): ?><p class="empty">چکی یافت نشد.</p><?php else: ?>
    <div class="table-wrap"><table class="table table--stack">
        <thead><tr><th>جهت</th><th>شماره</th><th>بانک</th><th><?= $lf->sortLink($base, 'party', 'طرف حساب') ?></th><th><?= $lf->sortLink($base, 'amount', 'مبلغ') ?></th><th><?= $lf->sortLink($base, 'due', 'سررسید') ?></th><th>وضعیت</th><th></th></tr></thead>
        <tbody><?php foreach ($rows as $r): $open = in_array($r['status'], ['in_hand', 'deposited', 'issued'], true); ?>
            <tr>
                <td><?= $r['direction'] === 'received' ? badge('دریافتی', 'ok') : badge('صادره', 'warn') ?></td>
                <td class="ltr"><a href="/cheques/<?= (int) $r['id'] ?>"><?= e($r['cheque_no']) ?></a></td>
                <td><?= e($r['bank_name']) ?></td><td><?= e($r['party']) ?></td><td><?= money((int) $r['amount']) ?></td>
                <td><?= jdate($r['due_date']) ?><?= $open && $r['due_date'] < $today ? ' ' . badge('سررسید گذشته', 'bad') : '' ?></td>
                <td><?= status_badge('entity', $r['status']) ?></td>
                <td class="table__actions"><a class="btn btn--secondary btn--sm" href="/cheques/<?= (int) $r['id'] ?>"><?= icon('eye', 16) ?><span>مشاهده</span></a></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
