<form class="card form" method="post" action="/cheques">
    <?= csrf_field() ?>
    <p class="hint">با ثبت چک، سند حسابداری خودکار صادر می‌شود: چک دریافتی «بدهکار اسناد دریافتنی / بستانکار حساب مقابل» و چک صادره «بدهکار حساب مقابل / بستانکار اسناد پرداختنی».</p>
    <div class="form-grid">
        <div class="field"><label for="direction">جهت</label>
            <select class="input" id="direction" name="direction" required>
                <option value="received" <?= old('direction') === 'received' ? 'selected' : '' ?>>دریافتی (از مشتری/طرف حساب)</option>
                <option value="issued" <?= old('direction') === 'issued' ? 'selected' : '' ?>>صادره (به فروشنده/طرف حساب)</option>
            </select></div>
        <div class="field"><label for="cheque_no">شماره چک / صیاد</label><input class="input input--ltr" id="cheque_no" name="cheque_no" value="<?= e(old('cheque_no')) ?>" maxlength="30" required></div>
        <div class="field"><label for="bank_name">بانک</label><input class="input" id="bank_name" name="bank_name" value="<?= e(old('bank_name')) ?>" maxlength="60" required></div>
        <div class="field"><label for="party">طرف حساب</label><input class="input" id="party" name="party" value="<?= e(old('party')) ?>" maxlength="120" required></div>
        <div class="field"><label for="amount">مبلغ (ریال)</label><input class="input input--ltr" id="amount" name="amount" value="<?= e(old('amount')) ?>" inputmode="numeric" data-money required></div>
        <div class="field"><label for="issue_date">تاریخ صدور</label><input class="input input--ltr" id="issue_date" name="issue_date" value="<?= e(old('issue_date', \App\Core\Jalali::format(date('Y-m-d')))) ?>" placeholder="1405/08/10" required></div>
        <div class="field"><label for="due_date">تاریخ سررسید</label><input class="input input--ltr" id="due_date" name="due_date" value="<?= e(old('due_date')) ?>" placeholder="1405/09/10" required></div>
        <div class="field"><label for="counter_account_id">حساب مقابل</label>
            <select class="input" id="counter_account_id" name="counter_account_id" required><option value="">انتخاب حساب</option>
                <?php foreach ($accounts as $a): ?><option value="<?= (int) $a['id'] ?>" <?= (string) old('counter_account_id') === (string) $a['id'] ? 'selected' : '' ?>><?= fa($a['code']) ?> · <?= e($a['name']) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="detail_id">حساب تفصیلی (اختیاری)</label>
            <select class="input" id="detail_id" name="detail_id"><option value="">—</option>
                <?php foreach ($details as $d): ?><option value="<?= (int) $d['id'] ?>" <?= (string) old('detail_id') === (string) $d['id'] ? 'selected' : '' ?>><?= e($d['code']) ?> · <?= e($d['name']) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field"><label for="bank_account_id">حساب بانک/صندوق پیش‌فرض (اختیاری)</label>
            <select class="input" id="bank_account_id" name="bank_account_id"><option value="">—</option>
                <?php foreach ($banks as $a): ?><option value="<?= (int) $a['id'] ?>" <?= (string) old('bank_account_id') === (string) $a['id'] ? 'selected' : '' ?>><?= fa($a['code']) ?> · <?= e($a['name']) ?></option><?php endforeach; ?>
            </select></div>
        <div class="field field--wide"><label for="description">توضیحات (اختیاری)</label><input class="input" id="description" name="description" value="<?= e(old('description')) ?>" maxlength="250"></div>
    </div>
    <div class="form__actions"><button class="btn btn--primary" type="submit">ثبت چک و صدور سند</button><a class="btn btn--ghost" href="/cheques">بازگشت</a></div>
</form>
