<?php
$isEdit = $customer !== null;
$action = $isEdit ? '/customers/' . (int) $customer['id'] : '/customers';
$val = static fn (string $k, string $d = '') => old($k, $isEdit ? (string) ($customer[$k] ?? $d) : $d);
?>
<form class="card form customer-form" method="post" action="<?= e($action) ?>">
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field">
            <label for="national_code">کد ملی</label>
            <input class="input input--ltr" id="national_code" name="national_code" value="<?= e($val('national_code')) ?>" inputmode="numeric" maxlength="10" <?= $isEdit ? 'disabled' : 'required' ?>>
        </div>
        <div class="field">
            <label for="full_name">نام و نام خانوادگی</label>
            <input class="input" id="full_name" name="full_name" value="<?= e($val('full_name')) ?>" required>
        </div>
        <div class="field">
            <label for="mobile">موبایل</label>
            <input class="input input--ltr" id="mobile" name="mobile" value="<?= e($val('mobile')) ?>" inputmode="numeric" maxlength="11" required>
        </div>
        <div class="field">
            <label for="credit_limit">سقف اعتبار (ریال)</label>
            <input class="input input--ltr" id="credit_limit" name="credit_limit" value="<?= e($val('credit_limit', '0')) ?>" inputmode="numeric" data-money>
        </div>
    </div>
    <div class="form__actions">
        <button class="btn btn--primary" type="submit">ذخیره</button>
        <a class="btn btn--ghost" href="<?= $isEdit ? '/customers/' . (int) $customer['id'] : '/customers' ?>">بازگشت</a>
    </div>
</form>
