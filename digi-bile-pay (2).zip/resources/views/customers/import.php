<section class="card">
    <div class="card__head"><h2>درون‌ریزی گروهی مشتریان</h2><a class="btn btn--ghost btn--sm" href="/customers/import/template"><?= icon('download', 16) ?><span>دریافت فایل نمونه</span></a></div>
    <p class="hint">ستون‌ها: <span class="ltr">national_code, full_name, mobile, credit_limit</span> (سقف اعتبار اختیاری). حداکثر ۱٬۰۰۰ سطر و ۱ مگابایت. اگر حتی یک سطر خطا داشته باشد هیچ‌کدام ثبت نمی‌شود؛ ابتدا «فقط بررسی» را بزنید.</p>
    <form method="post" action="/customers/import" enctype="multipart/form-data" class="form import-form">
        <?= csrf_field() ?>
        <div class="field"><label for="file">فایل CSV</label><input class="input" type="file" id="file" name="file" accept=".csv,text/csv" required></div>
        <div class="field"><label for="mode">عملیات</label>
            <select class="input" id="mode" name="mode"><option value="check">فقط بررسی (بدون ثبت)</option><option value="import">بررسی و ثبت</option></select></div>
        <button class="btn btn--primary" type="submit">اجرا</button>
        <a class="btn btn--ghost" href="/customers">بازگشت</a>
    </form>
</section>
<?php if ($result !== null): ?>
<section class="card">
<?php if ($result['fatal'] !== null): ?>
    <p class="import-msg import-msg--bad"><?= e($result['fatal']) ?></p>
<?php elseif ($committed > 0): ?>
    <p class="import-msg import-msg--ok"><?= fa((string) $committed) ?> مشتری ثبت شد.</p>
<?php elseif ($result['bad'] > 0): ?>
    <p class="import-msg import-msg--bad"><?= fa((string) $result['bad']) ?> سطر دارای خطا است؛ چیزی ثبت نشد. فایل را اصلاح و دوباره بارگذاری کنید.</p>
<?php else: ?>
    <p class="import-msg import-msg--ok">همه‌ی <?= fa((string) count($result['rows'])) ?> سطر سالم است. برای ثبت، عملیات «بررسی و ثبت» را اجرا کنید.</p>
<?php endif; ?>
<?php if ($result['rows']): ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>سطر</th><th>کد ملی</th><th>نام</th><th>موبایل</th><th>سقف اعتبار (ریال)</th><th>نتیجه</th></tr></thead>
        <tbody><?php foreach ($result['rows'] as $r): ?>
            <tr class="<?= $r['errors'] ? 'is-bad' : '' ?>">
                <td><?= fa((string) $r['line']) ?></td><td class="ltr"><?= e($r['data']['national_code']) ?></td><td><?= e($r['data']['full_name']) ?></td>
                <td class="ltr"><?= e($r['data']['mobile']) ?></td><td><?= fa(number_format($r['data']['credit_limit'])) ?></td>
                <td><?= $r['errors'] ? '<span class="badge badge--danger">' . e(implode('، ', $r['errors'])) . '</span>' : '<span class="badge badge--success">سالم</span>' ?></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
<?php endif; ?>
</section>
<?php endif; ?>
