<?php use App\Core\Auth; ?>
<section class="card customer-head">
    <div>
        <h2><?= e($c['full_name']) ?> <?= status_badge('entity', $c['status']) ?></h2>
        <p class="hint">کد ملی: <span class="ltr"><?= fa($c['national_code']) ?></span> · موبایل: <span class="ltr"><?= fa($c['mobile']) ?></span></p>
    </div>
    <div class="customer-head__actions">
        <?php if (Auth::can('customers.manage')): ?>
            <a class="btn btn--secondary btn--sm" href="/customers/<?= (int) $c['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a>
        <?php endif; ?>
        <?php if (Auth::can('loans.create') && $c['status'] === 'active'): ?>
            <a class="btn btn--primary btn--sm" href="/loans/create?customer_id=<?= (int) $c['id'] ?>"><?= icon('plus', 16) ?><span>درخواست تسهیلات</span></a>
        <?php endif; ?>
    </div>
</section>

<section class="credit-grid">
    <article class="stat-card"><span class="stat-card__label">سقف اعتبار</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $c['credit_limit']) ?></strong></article>
    <article class="stat-card stat-card--warn"><span class="stat-card__label">اعتبار مصرف‌شده</span><strong class="stat-card__value stat-card__value--money"><?= money($used) ?></strong></article>
    <article class="stat-card stat-card--ok"><span class="stat-card__label">اعتبار آزاد</span><strong class="stat-card__value stat-card__value--money"><?= money($available) ?></strong></article>
    <article class="stat-card"><span class="stat-card__label">موجودی کیف پول</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $c['wallet_balance']) ?></strong></article>
</section>

<section class="credit-grid">
    <article class="stat-card"><span class="stat-card__label">مانده اقساط جاری</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $debt['remaining']) ?></strong></article>
    <article class="stat-card stat-card--bad"><span class="stat-card__label">مبلغ معوق</span><strong class="stat-card__value stat-card__value--money"><?= money((int) $debt['overdue']) ?></strong></article>
    <article class="stat-card"><span class="stat-card__label">تعداد اقساط معوق</span><strong class="stat-card__value"><?= num((int) $debt['overdue_count']) ?></strong></article>
</section>

<?php if (Auth::can('wallet.topup')): ?>
    <form class="card form topup-form" method="post" action="/customers/<?= (int) $c['id'] ?>/topup" data-confirm="کیف پول شارژ شود؟">
        <?= csrf_field() ?>
        <div class="field">
            <label for="amount">شارژ کیف پول (ریال)</label>
            <input class="input input--ltr" id="amount" name="amount" inputmode="numeric" data-money required>
        </div>
        <button class="btn btn--primary" type="submit">ثبت شارژ</button>
    </form>
    <form class="card form topup-form" method="post" action="/customers/<?= (int) $c['id'] ?>/pay-link">
        <?= csrf_field() ?>
        <div class="field">
            <label for="amount_link">لینک پرداخت آنلاین شارژ (ریال)</label>
            <input class="input input--ltr" id="amount_link" name="amount" inputmode="numeric" data-money required>
        </div>
        <button class="btn btn--secondary" type="submit"><?= icon('zap', 16) ?><span>ساخت لینک</span></button>
    </form>
<?php endif; ?>

<?php if (Auth::can('customers.manage')): ?>
    <form class="card form topup-form" method="post" action="/customers/<?= (int) $c['id'] ?>/sms" data-confirm="پیامک برای مشتری ارسال شود؟">
        <?= csrf_field() ?>
        <div class="field field--grow">
            <label for="sms_body">ارسال پیامک به <?= e($c['full_name']) ?></label>
            <input class="input" id="sms_body" name="body" maxlength="300" required placeholder="متن پیامک">
        </div>
        <button class="btn btn--secondary" type="submit"><?= icon('mail', 16) ?><span>ارسال</span></button>
    </form>
<?php endif; ?>

<section class="card">
    <div class="card__head"><h2>تسهیلات</h2></div>
    <?php if (!$loans): ?>
        <p class="empty">تسهیلاتی ثبت نشده است.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>شماره</th><th>طرح</th><th>مبلغ</th><th>اقساط</th><th>وضعیت</th><th>تاریخ</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($loans as $l): ?>
                    <tr>
                        <td>#<?= fa($l['id']) ?></td>
                        <td><?= e($l['plan_name']) ?></td>
                        <td><?= money((int) $l['principal']) ?></td>
                        <td><?= fa($l['months']) ?></td>
                        <td><?= status_badge('loan', $l['status']) ?></td>
                        <td><?= jdate($l['created_at']) ?></td>
                        <td class="table__actions"><a class="btn btn--secondary btn--sm" href="/loans/<?= (int) $l['id'] ?>"><?= icon('eye', 16) ?><span>مشاهده</span></a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<section class="card">
    <div class="card__head"><h2>گردش کیف پول</h2></div>
    <?php if (!$wallet): ?>
        <p class="empty">تراکنشی ثبت نشده است.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>نوع</th><th>مبلغ</th><th>مانده</th><th>زمان</th></tr></thead>
                <tbody>
                <?php foreach ($wallet as $w): ?>
                    <tr>
                        <td><?= $w['type'] === 'topup' ? 'شارژ' : 'پرداخت قسط' ?></td>
                        <td class="<?= (int) $w['amount'] < 0 ? 'amount--neg' : 'amount--pos' ?>"><?= (int) $w['amount'] < 0 ? '−' : '+' ?><?= money(abs((int) $w['amount'])) ?></td>
                        <td><?= money((int) $w['balance_after']) ?></td>
                        <td><?= jdate($w['created_at'], true) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<section class="card">
    <div class="card__head"><h2>آخرین سفارش‌ها</h2></div>
    <?php if (!$orders): ?>
        <p class="empty">سفارشی ثبت نشده است.</p>
    <?php else: ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>سفارش</th><th>فروشنده</th><th>مبلغ</th><th>روش</th><th>وضعیت</th><th>تاریخ</th></tr></thead>
            <tbody><?php foreach ($orders as $o): ?>
                <tr><td><a href="/orders/<?= (int) $o['id'] ?>">#<?= fa($o['id']) ?></a></td><td><?= e($o['merchant_name']) ?></td><td><?= money((int) $o['total']) ?></td>
                    <td><?= $o['payment_type'] === 'cash' ? 'نقدی' : 'اقساطی' ?></td><td><?= status_badge('order', $o['status']) ?></td><td><?= jdate($o['created_at']) ?></td></tr>
            <?php endforeach; ?></tbody>
        </table></div>
    <?php endif; ?>
</section>

<section class="card">
    <div class="card__head"><h2>یادداشت‌های وصول</h2></div>
    <?php if (!$notes): ?>
        <p class="empty">یادداشتی ثبت نشده است.</p>
    <?php else: ?>
        <ul class="timeline">
            <?php foreach ($notes as $n): ?>
                <li><?= e($n['note']) ?>
                    <small>وام #<?= fa($n['loan_id']) ?> · قسط <?= fa($n['seq']) ?> · <?= e($n['full_name'] ?? '—') ?> · <?= jdate($n['created_at'], true) ?><?= $n['promise_date'] ? ' · قول پرداخت: ' . jdate($n['promise_date']) : '' ?></small>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>

<?php \App\Core\View::partial('notes-panel', ['entity' => 'customer', 'entityId' => (int) $c['id'], 'notes' => $internalNotes, 'canAdd' => true]); ?>
<?php \App\Core\View::partial('status-panel', [
    'action' => '/customers/' . (int) $c['id'] . '/status', 'current' => $c['status'], 'history' => $history,
    'canManage' => Auth::can('customers.manage'), 'options' => ['active' => 'فعال', 'blocked' => 'مسدود'],
]); ?>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
