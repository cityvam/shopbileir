<?php use App\Core\Auth;
$base = '/customers';
$fields = [
    ['key' => 'q', 'label' => 'جست‌وجو (نام، کد ملی، موبایل)', 'type' => 'text'],
    ['key' => 'status', 'label' => 'وضعیت', 'type' => 'select', 'options' => ['active' => 'فعال', 'blocked' => 'مسدود']],
    ['key' => 'overdue', 'label' => 'معوقه', 'type' => 'select', 'options' => ['1' => 'دارای قسط معوق'], 'adv' => true],
    ['key' => 'credit_min', 'label' => 'حداقل سقف اعتبار', 'type' => 'money', 'adv' => true],
    ['key' => 'credit_max', 'label' => 'حداکثر سقف اعتبار', 'type' => 'money', 'adv' => true],
    ['key' => 'debt_min', 'label' => 'حداقل بدهی جاری', 'type' => 'money', 'adv' => true],
    ['key' => 'debt_max', 'label' => 'حداکثر بدهی جاری', 'type' => 'money', 'adv' => true],
    ['key' => 'from', 'label' => 'ثبت از تاریخ', 'type' => 'date', 'adv' => true],
    ['key' => 'to', 'label' => 'ثبت تا تاریخ', 'type' => 'date', 'adv' => true],
];
?>
<section class="card">
    <div class="card__head">
        <h2>فهرست مشتریان</h2>
        <?php if (Auth::can('customers.manage')): ?>
            <a class="btn btn--ghost btn--sm" href="/customers/import"><?= icon('upload', 16) ?><span>درون‌ریزی CSV</span></a>
            <a class="btn btn--primary btn--sm" href="/customers/create"><?= icon('plus', 16) ?><span>مشتری جدید</span></a>
        <?php endif; ?>
    </div>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => $base, 'fields' => $fields, 'csv' => true]); ?>
    <?php if (Auth::can('customers.manage') && $rows): \App\Core\View::partial('bulk-bar', ['action' => '/customers/bulk-status', 'options' => ['blocked' => 'مسدود', 'active' => 'فعال']]); endif; ?>
    <p class="result-bar"><?= fa($pg['total']) ?> مشتری یافت شد</p>
    <?php if (!$rows): ?>
        <p class="empty">مشتری‌ای یافت نشد.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="table table--stack">
                <thead><tr>
                    <?php if (Auth::can('customers.manage')): ?><th class="col-check"><input type="checkbox" data-check-all aria-label="انتخاب همه"></th><?php endif; ?>
                    <th><?= $lf->sortLink($base, 'name', 'نام') ?></th><th>کد ملی</th><th>موبایل</th>
                    <th><?= $lf->sortLink($base, 'credit', 'سقف اعتبار') ?></th>
                    <th><?= $lf->sortLink($base, 'wallet', 'کیف پول') ?></th>
                    <th><?= $lf->sortLink($base, 'debt', 'بدهی جاری') ?></th>
                    <th>وضعیت</th><th></th>
                </tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <?php if (Auth::can('customers.manage')): ?><td class="col-check"><input type="checkbox" data-bulk form="bulk-form" name="ids[]" value="<?= (int) $r['id'] ?>" aria-label="انتخاب"></td><?php endif; ?>
                        <td><a href="/customers/<?= (int) $r['id'] ?>"><?= e($r['full_name']) ?></a></td>
                        <td class="ltr"><?= fa($r['national_code']) ?></td>
                        <td class="ltr"><?= fa($r['mobile']) ?></td>
                        <td><?= money((int) $r['credit_limit']) ?></td>
                        <td><?= money((int) $r['wallet_balance']) ?></td>
                        <td><?= (int) $r['debt'] > 0 ? money((int) $r['debt']) : '—' ?></td>
                        <td><?= status_badge('entity', $r['status']) ?></td>
                        <td class="table__actions"><a class="btn btn--secondary btn--sm" href="/customers/<?= (int) $r['id'] ?>"><?= icon('eye', 16) ?><span>مشاهده</span></a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
