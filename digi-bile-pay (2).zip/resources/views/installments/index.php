<?php use App\Core\Auth; ?>
<section class="card">
    <div class="card__head"><h2>اقساط و وصول</h2></div>
    <?php if (Auth::can('installments.collect')): ?>
        <form class="accrue-form" method="post" action="/installments/accrue-fees" data-confirm="جریمه تأخیر امروز برای همه اقساط معوق محاسبه شود؟">
            <?= csrf_field() ?>
            <button class="btn btn--secondary btn--sm" type="submit"><?= icon('alert', 16) ?><span>محاسبه جریمه تأخیر امروز</span></button>
        </form>
    <?php endif; ?>
    <div class="tabs">
        <?php foreach (['unpaid' => 'پرداخت‌نشده', 'overdue' => 'معوق', 'paid' => 'پرداخت‌شده', 'all' => 'همه'] as $k => $label): ?>
            <a class="tabs__link<?= $filter === $k ? ' is-active' : '' ?>" href="/installments?<?= e($lf->qs(['filter' => $k, 'page' => ''])) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
    </div>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => '/installments', 'csv' => true, 'hidden' => ['filter' => $filter], 'fields' => [
        ['key' => 'q', 'label' => 'جست‌وجو (نام، کد ملی، موبایل)', 'type' => 'text'],
        ['key' => 'from', 'label' => 'سررسید از', 'type' => 'date'],
        ['key' => 'to', 'label' => 'سررسید تا', 'type' => 'date'],
        ['key' => 'min', 'label' => 'حداقل مانده', 'type' => 'money', 'adv' => true],
        ['key' => 'max', 'label' => 'حداکثر مانده', 'type' => 'money', 'adv' => true],
    ]]); ?>
    <p class="result-bar"><?= fa($pg['total']) ?> قسط · جمع مانده: <?= money($sum) ?></p>
    <?php if (!$rows): ?>
        <p class="empty">موردی یافت نشد.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table class="table table--stack">
                <thead><tr><th><?= $lf->sortLink('/installments', 'customer', 'مشتری') ?></th><th>تسهیلات</th><th>قسط</th><th><?= $lf->sortLink('/installments', 'due', 'سررسید') ?></th><th><?= $lf->sortLink('/installments', 'amount', 'مبلغ') ?></th><th>پرداخت‌شده</th><th>وضعیت</th><th>جریمه تأخیر</th><th>پیگیری</th><?php if (Auth::can('installments.collect')): ?><th>وصول</th><?php endif; ?></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <?php $remaining = (int) $r['amount'] - (int) $r['paid_amount']; ?>
                    <tr>
                        <td><a href="/customers/<?= (int) $r['customer_id'] ?>"><?= e($r['full_name']) ?></a></td>
                        <td><a href="/loans/<?= (int) $r['loan_id'] ?>">#<?= fa($r['loan_id']) ?></a></td>
                        <td><?= fa($r['seq']) ?> از <?= fa($r['months']) ?></td>
                        <td><?= jdate($r['due_date']) ?><?= $r['status'] !== 'paid' && $r['due_date'] < $today ? ' ' . badge('معوق', 'bad') : '' ?></td>
                        <td><?= money((int) $r['amount']) ?></td>
                        <td><?= money((int) $r['paid_amount']) ?></td>
                        <td><?= status_badge('installment', $r['status']) ?></td>
                        <?php $feeDue = (int) $r['late_fee_accrued'] - (int) $r['late_fee_paid']; ?>
                        <td class="fee-cell">
                            <?php if ($feeDue > 0): ?>
                                <span class="neg"><?= money($feeDue) ?></span>
                                <?php if (Auth::can('installments.collect')): ?>
                                    <form class="fee-form" method="post" action="/installments/<?= (int) $r['id'] ?>/late-fee" data-confirm="جریمه تأخیر دریافت شود؟">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="return" value="<?= e($filter) ?>">
                                        <select class="input input--sm" name="method" aria-label="روش دریافت جریمه"><option value="cash">نقدی</option><option value="wallet">کیف پول</option></select>
                                        <button class="btn btn--secondary btn--sm" type="submit">دریافت</button>
                                    </form>
                                <?php endif; ?>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                        <td class="wrap note-cell">
                            <?php if (!empty($r['last_note'])): ?>
                                <span class="note-cell__text"><?= e($r['last_note']) ?></span>
                                <?php if (!empty($r['promise_date'])): ?><small>قول پرداخت: <?= jdate($r['promise_date']) ?></small><?php endif; ?>
                            <?php else: ?>—<?php endif; ?>
                            <?php if ($r['status'] !== 'paid' && Auth::can('installments.collect')): ?>
                                <details class="note-form">
                                    <summary><?= icon('note', 14) ?> ثبت پیگیری</summary>
                                    <form method="post" action="/installments/<?= (int) $r['id'] ?>/note">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="return" value="<?= e($filter) ?>">
                                        <input class="input input--sm" name="note" maxlength="250" placeholder="نتیجه تماس / پیگیری" required>
                                        <input class="input input--sm input--ltr" name="promise_date" placeholder="قول پرداخت 1405/08/20">
                                        <button class="btn btn--secondary btn--sm" type="submit">ثبت</button>
                                    </form>
                                </details>
                            <?php endif; ?>
                        </td>
                        <?php if (Auth::can('installments.collect')): ?>
                            <td>
                                <?php if ($remaining > 0): ?>
                                    <form class="pay-form" method="post" action="/installments/<?= (int) $r['id'] ?>/pay" data-confirm="پرداخت ثبت شود؟">
                                        <?= csrf_field() ?>
                                        <?php if ($filter === 'overdue'): ?><input type="hidden" name="return" value="overdue"><?php endif; ?>
                                        <input class="input input--ltr input--sm" name="amount" value="<?= e((string) $remaining) ?>" inputmode="numeric" data-money aria-label="مبلغ پرداخت">
                                        <select class="input input--sm" name="method" aria-label="روش پرداخت">
                                            <option value="cash">نقدی</option>
                                            <option value="wallet">کیف پول</option>
                                        </select>
                                        <button class="btn btn--primary btn--sm" type="submit">ثبت</button>
                                    </form>
                                    <form class="pay-link-form" method="post" action="/installments/<?= (int) $r['id'] ?>/pay-link">
                                        <?= csrf_field() ?>
                                        <button class="btn btn--ghost btn--sm" type="submit" title="ساخت لینک پرداخت آنلاین برای مشتری"><?= icon('zap', 14) ?><span>لینک پرداخت</span></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    <?php \App\Core\View::partial('pagination', ['pg' => $pg]); ?>
</section>
