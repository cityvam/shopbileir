<form class="card form" method="post" action="/dimensions/<?= (int) $d['id'] ?>">
    <?= csrf_field() ?>
    <p class="hint">نوع: <?= e($kinds[$d['kind']]) ?> (قابل تغییر نیست)</p>
    <div class="form-grid">
        <div class="field"><label for="code">کد</label><input class="input input--ltr" id="code" name="code" value="<?= e(old('code', $d['code'])) ?>" maxlength="20" required></div>
        <div class="field"><label for="name">نام</label><input class="input" id="name" name="name" value="<?= e(old('name', $d['name'])) ?>" maxlength="120" required></div>
    </div>
    <div class="form__actions"><button class="btn btn--primary" type="submit">ذخیره</button><a class="btn btn--ghost" href="/dimensions">بازگشت</a></div>
</form>
<?php \App\Core\View::partial('history-panel', ['events' => $events]); ?>
