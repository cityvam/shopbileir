<?php use App\Core\Auth;
$can = Auth::can('accounting.post'); ?>
<section class="card">
    <div class="card__head"><h2>تفصیلی و مرکز هزینه</h2></div>
    <p class="hint">«تفصیلی» برای طرف‌حساب‌ها (شخص، بانک، شریک…) و «مرکز هزینه» برای بخش‌ها/پروژه‌هاست. هر ردیف سند می‌تواند هر دو را داشته باشد و گزارش گردش هر کدام جداگانه گرفته می‌شود.</p>
    <?php if ($can): ?>
        <form class="status-form" method="post" action="/dimensions">
            <?= csrf_field() ?>
            <div class="field"><label for="kind">نوع</label><select class="input" id="kind" name="kind"><?php foreach ($kinds as $k => $l): ?><option value="<?= e($k) ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
            <div class="field"><label for="code">کد</label><input class="input input--ltr" id="code" name="code" maxlength="20" required></div>
            <div class="field field--grow"><label for="name">نام</label><input class="input" id="name" name="name" maxlength="120" required></div>
            <button class="btn btn--primary" type="submit"><?= icon('plus', 16) ?><span>افزودن</span></button>
        </form>
    <?php endif; ?>
    <?php \App\Core\View::partial('filter-bar', ['lf' => $lf, 'action' => '/dimensions', 'csv' => true, 'fields' => [
        ['key' => 'q', 'label' => 'جست‌وجو (نام یا کد)', 'type' => 'text'],
        ['key' => 'kind', 'label' => 'نوع', 'type' => 'select', 'options' => $kinds],
        ['key' => 'status', 'label' => 'وضعیت', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال']],
    ]]); ?>
    <?php if (!$rows): ?><p class="empty">موردی تعریف نشده است.</p><?php else: ?>
    <div class="table-wrap"><table class="table table--stack">
        <thead><tr><th><?= $lf->sortLink('/dimensions', 'code', 'کد') ?></th><th><?= $lf->sortLink('/dimensions', 'name', 'نام') ?></th><th>نوع</th><th>ردیف‌های سند</th><th><?= $lf->sortLink('/dimensions', 'turnover', 'گردش بدهکار') ?></th><th>وضعیت</th><th></th></tr></thead>
        <tbody><?php foreach ($rows as $r): ?>
            <tr class="<?= (int) $r['is_active'] ? '' : 'is-muted' ?>">
                <td class="ltr"><?= e($r['code']) ?></td>
                <td><a href="/dimensions/<?= (int) $r['id'] ?>"><?= e($r['name']) ?></a></td>
                <td><?= e($kinds[$r['kind']]) ?></td><td><?= num((int) $r['uses']) ?></td><td><?= money((int) $r['turnover']) ?></td>
                <td><?= (int) $r['is_active'] ? badge('فعال', 'ok') : badge('غیرفعال', 'muted') ?></td>
                <td class="table__actions">
                    <a class="btn btn--secondary btn--sm" href="/dimensions/<?= (int) $r['id'] ?>"><?= icon('file-text', 16) ?><span>گردش</span></a>
                    <?php if ($can): ?>
                        <a class="btn btn--secondary btn--sm" href="/dimensions/<?= (int) $r['id'] ?>/edit"><?= icon('edit', 16) ?><span>ویرایش</span></a>
                        <form method="post" action="/dimensions/<?= (int) $r['id'] ?>/toggle" data-confirm="وضعیت تغییر کند؟"><?= csrf_field() ?><button class="btn btn--ghost btn--sm" type="submit"><?= (int) $r['is_active'] ? 'غیرفعال‌سازی' : 'فعال‌سازی' ?></button></form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>
