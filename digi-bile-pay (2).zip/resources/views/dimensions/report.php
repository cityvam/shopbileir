<section class="card">
    <div class="card__head"><h2>گردش <?= e($d['name']) ?> <small class="ltr">(<?= e($d['code']) ?>)</small></h2></div>
    <?php \App\Core\View::partial('period-filter', ['action' => $action, 'from' => $from, 'to' => $to, 'errors' => $errors]); ?>
    <?php if (!$byAccount): ?><p class="empty">در این بازه گردش قطعی‌ای ثبت نشده است.</p><?php else: $td = $tc = 0; ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>کد</th><th>حساب</th><th>بدهکار</th><th>بستانکار</th><th>مانده</th></tr></thead>
        <tbody><?php foreach ($byAccount as $r): $td += (int) $r['d']; $tc += (int) $r['c']; $net = (int) $r['d'] - (int) $r['c']; ?>
            <tr><td class="ltr"><?= fa($r['code']) ?></td><td><a href="/accounts/<?= (int) $r['id'] ?>"><?= e($r['name']) ?></a></td><td><?= num((int) $r['d']) ?></td><td><?= num((int) $r['c']) ?></td><td><?= num(abs($net)) ?> <?= $net === 0 ? '' : ($net > 0 ? 'بد' : 'بس') ?></td></tr>
        <?php endforeach; ?></tbody>
        <tfoot><tr><th colspan="2">جمع</th><th><?= num($td) ?></th><th><?= num($tc) ?></th><th><?= num(abs($td - $tc)) ?> <?= $td === $tc ? '' : ($td > $tc ? 'بد' : 'بس') ?></th></tr></tfoot>
    </table></div>
    <?php endif; ?>
</section>
<?php if ($lines): ?>
<section class="card">
    <div class="card__head"><h2>ریز اسناد</h2></div>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>سند</th><th>تاریخ</th><th>شرح</th><th>حساب</th><th>بدهکار</th><th>بستانکار</th></tr></thead>
        <tbody><?php foreach ($lines as $l): ?>
            <tr><td><a href="/journal/<?= (int) $l['entry_id'] ?>">#<?= fa($l['entry_no']) ?></a></td><td><?= jdate($l['entry_date']) ?></td>
                <td class="wrap"><?= e($l['description']) ?><?= $l['line_desc'] ? ' — ' . e($l['line_desc']) : '' ?></td><td><?= e($l['name']) ?></td>
                <td><?= (int) $l['debit'] ? num((int) $l['debit']) : '—' ?></td><td><?= (int) $l['credit'] ? num((int) $l['credit']) : '—' ?></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
</section>
<?php endif; ?>
