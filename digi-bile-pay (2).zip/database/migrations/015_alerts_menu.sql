-- مرکز هشدارها: هشدارها زنده از داده‌ها محاسبه می‌شوند؛ فقط ورودی منو لازم است
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('alerts', 'هشدارها', 'bell', '/alerts', 'dashboard.view', 11);
