-- هسته: شرکت‌ها، نقش‌ها، مجوزها، کاربران، حسابرسی، منو
CREATE TABLE companies (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  parent_id BIGINT UNSIGNED NULL,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(190) NOT NULL,
  brand_name VARCHAR(190) NULL,
  status ENUM('active','suspended') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_companies_parent FOREIGN KEY (parent_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_companies_code ON companies (code);

CREATE TABLE roles (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  slug VARCHAR(60) NOT NULL,
  name VARCHAR(120) NOT NULL,
  is_system TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_roles_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_roles_company_slug ON roles (company_id, slug);

CREATE TABLE role_permissions (
  role_id BIGINT UNSIGNED NOT NULL,
  permission VARCHAR(80) NOT NULL,
  PRIMARY KEY (role_id, permission),
  CONSTRAINT fk_roleperm_role FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  role_id BIGINT UNSIGNED NOT NULL,
  username VARCHAR(80) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  mobile VARCHAR(11) NULL,
  password_hash VARCHAR(255) NOT NULL,
  status ENUM('active','disabled') NOT NULL DEFAULT 'active',
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_users_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_users_username ON users (username);
CREATE INDEX ix_users_company ON users (company_id);

CREATE TABLE login_attempts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(80) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  success TINYINT(1) NOT NULL,
  attempted_at DATETIME NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_login_attempts_user ON login_attempts (username, attempted_at);
CREATE INDEX ix_login_attempts_ip ON login_attempts (ip, attempted_at);

CREATE TABLE audit_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NULL,
  user_id BIGINT UNSIGNED NULL,
  action VARCHAR(80) NOT NULL,
  entity VARCHAR(60) NOT NULL,
  entity_id BIGINT UNSIGNED NULL,
  details TEXT NULL,
  ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_audit_company_date ON audit_logs (company_id, created_at);
CREATE INDEX ix_audit_entity ON audit_logs (entity, entity_id);

CREATE TABLE menu_items (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  menu_key VARCHAR(60) NOT NULL,
  title VARCHAR(120) NOT NULL,
  icon VARCHAR(40) NOT NULL,
  url VARCHAR(120) NOT NULL,
  permission VARCHAR(80) NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_menu_key ON menu_items (menu_key);

INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('dashboard', 'داشبورد', 'dashboard', '/dashboard', 'dashboard.view', 10);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('customers', 'مشتریان', 'id-card', '/customers', 'customers.view', 20);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('plans', 'طرح‌های تسهیلاتی', 'tag', '/plans', 'plans.view', 30);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('loans', 'تسهیلات', 'file-text', '/loans', 'loans.view', 40);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('installments', 'اقساط و وصول', 'calendar', '/installments', 'installments.view', 50);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('companies', 'شرکت‌ها', 'building', '/companies', 'companies.view', 60);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('users', 'کاربران', 'users', '/users', 'users.view', 70);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('roles', 'نقش‌ها و مجوزها', 'shield', '/roles', 'roles.view', 80);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order) VALUES ('audit', 'گزارش حسابرسی', 'clipboard', '/audit', 'audit.view', 90);
