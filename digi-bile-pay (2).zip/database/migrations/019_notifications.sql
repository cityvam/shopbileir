-- صف پیامک/اعلان و وضعیت «خوانده‌شد» هشدارهای هر کاربر
CREATE TABLE notifications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  customer_id BIGINT UNSIGNED NULL,
  channel VARCHAR(10) NOT NULL DEFAULT 'sms',
  recipient VARCHAR(20) NOT NULL,
  template VARCHAR(30) NOT NULL,
  body VARCHAR(500) NOT NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'queued',
  attempts INT NOT NULL DEFAULT 0,
  last_error VARCHAR(250) NULL,
  provider_ref VARCHAR(80) NULL,
  dedupe_key VARCHAR(80) NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  sent_at DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_notif_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_notif_company ON notifications (company_id, status, created_at);
CREATE INDEX ix_notif_dedupe ON notifications (company_id, dedupe_key);

CREATE TABLE alert_reads (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  alert_key VARCHAR(40) NOT NULL,
  seen_count INT NOT NULL,
  seen_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_alert_reads_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_alert_reads ON alert_reads (user_id, alert_key);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('notifications', 'پیامک‌ها', 'mail', '/notifications', 'customers.view', 56, 'عملیات');
