-- حسابداری پیشرفته: سال مالی، اسناد موقت/قطعی، ابطال سند، حساب‌های درختی
CREATE TABLE fiscal_years (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(100) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  closed_by BIGINT UNSIGNED NULL,
  closed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_fy_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_fy_company_start ON fiscal_years (company_id, start_date);

ALTER TABLE accounts ADD COLUMN parent_id BIGINT UNSIGNED NULL;
ALTER TABLE accounts ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1;
CREATE INDEX ix_accounts_parent ON accounts (parent_id);
ALTER TABLE journal_entries ADD COLUMN status VARCHAR(10) NOT NULL DEFAULT 'final';
ALTER TABLE journal_entries ADD COLUMN reference VARCHAR(60) NULL;
ALTER TABLE journal_entries ADD COLUMN fiscal_year_id BIGINT UNSIGNED NULL;
ALTER TABLE journal_entries ADD COLUMN reversal_of BIGINT UNSIGNED NULL;
ALTER TABLE journal_entries ADD COLUMN reversed_by BIGINT UNSIGNED NULL;
CREATE INDEX ix_je_status ON journal_entries (company_id, status, entry_date);
ALTER TABLE journal_lines ADD COLUMN description VARCHAR(250) NULL;

INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('fiscal', 'سال‌های مالی', 'calendar', '/fiscal-years', 'accounting.view', 68, 'مالی');
