-- پشت‌نویسی (واگذاری) چک دریافتی به شخص ثالث
ALTER TABLE cheques ADD COLUMN endorsed_to VARCHAR(120) NULL;
ALTER TABLE cheques ADD COLUMN endorse_entry_id BIGINT UNSIGNED NULL;
