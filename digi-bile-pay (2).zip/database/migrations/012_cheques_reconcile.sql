-- چک‌های دریافتی/صادره و تطبیق بانکی
CREATE TABLE cheques (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  direction VARCHAR(10) NOT NULL,
  cheque_no VARCHAR(30) NOT NULL,
  bank_name VARCHAR(60) NOT NULL,
  amount BIGINT UNSIGNED NOT NULL,
  issue_date DATE NOT NULL,
  due_date DATE NOT NULL,
  party VARCHAR(120) NOT NULL,
  detail_id BIGINT UNSIGNED NULL,
  counter_account_id BIGINT UNSIGNED NOT NULL,
  bank_account_id BIGINT UNSIGNED NULL,
  status VARCHAR(20) NOT NULL,
  description VARCHAR(250) NULL,
  reg_entry_id BIGINT UNSIGNED NULL,
  final_entry_id BIGINT UNSIGNED NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_cheques_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_cheques_no ON cheques (company_id, direction, bank_name, cheque_no);
CREATE INDEX ix_cheques_due ON cheques (company_id, status, due_date);

CREATE TABLE bank_reconciliations (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  account_id BIGINT UNSIGNED NOT NULL,
  statement_date DATE NOT NULL,
  statement_balance BIGINT NOT NULL,
  lines_count INT NOT NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'active',
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_bank_rec_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_bank_rec_account ON bank_reconciliations (company_id, account_id);

ALTER TABLE journal_lines ADD COLUMN reconciliation_id BIGINT UNSIGNED NULL;
CREATE INDEX ix_journal_lines_rec ON journal_lines (reconciliation_id);

INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('cheques', 'چک‌ها', 'banknote', '/cheques', 'accounting.view', 70, 'مالی');
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('reconcile', 'تطبیق بانکی', 'check', '/reconciliation', 'accounting.view', 71, 'مالی');
