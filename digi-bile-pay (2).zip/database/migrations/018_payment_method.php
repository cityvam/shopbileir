<?php
declare(strict_types=1);

use App\Core\Database as DB;

// روش پرداخت «online» برای وصول از درگاه. SQLite (تست) ENUM را اعمال نمی‌کند.
return static function (): void {
    if (!DB::isSqlite()) {
        DB::exec("ALTER TABLE payments MODIFY method ENUM('wallet','cash','online') NOT NULL");
    }
};
