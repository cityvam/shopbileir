-- بازارگاه: فروشندگان، محصولات، سفارش، تسویه؛ یادداشت پیگیری وصول؛ گروه‌بندی منو
ALTER TABLE menu_items ADD COLUMN section VARCHAR(60) NULL;
UPDATE menu_items SET section = 'عملیات' WHERE menu_key IN ('dashboard', 'customers', 'plans', 'loans', 'installments');
UPDATE menu_items SET section = 'مدیریت', sort_order = sort_order + 20 WHERE menu_key IN ('companies', 'users', 'roles', 'audit');
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('merchants', 'فروشندگان', 'store', '/merchants', 'merchants.view', 22, 'عملیات');
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('products', 'محصولات', 'box', '/products', 'products.view', 24, 'عملیات');
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('orders', 'سفارش‌ها', 'cart', '/orders', 'orders.view', 26, 'عملیات');

CREATE TABLE merchants (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  contact_name VARCHAR(150) NULL,
  mobile VARCHAR(11) NULL,
  commission_percent DECIMAL(5,2) NOT NULL DEFAULT 0,
  status ENUM('active','disabled') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_merchants_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_merchants_company ON merchants (company_id, status);

CREATE TABLE products (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  merchant_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(190) NOT NULL,
  sku VARCHAR(60) NULL,
  price BIGINT UNSIGNED NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  status ENUM('active','disabled') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_products_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_products_merchant FOREIGN KEY (merchant_id) REFERENCES merchants (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_products_merchant ON products (company_id, merchant_id, status);

CREATE TABLE settlements (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  merchant_id BIGINT UNSIGNED NOT NULL,
  gross_amount BIGINT UNSIGNED NOT NULL,
  commission_amount BIGINT UNSIGNED NOT NULL,
  net_amount BIGINT UNSIGNED NOT NULL,
  orders_count INT NOT NULL,
  created_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_settle_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_settle_merchant FOREIGN KEY (merchant_id) REFERENCES merchants (id),
  CONSTRAINT fk_settle_user FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_settle_merchant ON settlements (company_id, merchant_id, created_at);

CREATE TABLE orders (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  merchant_id BIGINT UNSIGNED NOT NULL,
  customer_id BIGINT UNSIGNED NOT NULL,
  payment_type ENUM('cash','installment') NOT NULL,
  total BIGINT UNSIGNED NOT NULL,
  commission_amount BIGINT UNSIGNED NOT NULL DEFAULT 0,
  loan_id BIGINT UNSIGNED NULL,
  settlement_id BIGINT UNSIGNED NULL,
  status ENUM('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  created_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_orders_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_orders_merchant FOREIGN KEY (merchant_id) REFERENCES merchants (id),
  CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers (id),
  CONSTRAINT fk_orders_loan FOREIGN KEY (loan_id) REFERENCES loans (id),
  CONSTRAINT fk_orders_settlement FOREIGN KEY (settlement_id) REFERENCES settlements (id),
  CONSTRAINT fk_orders_user FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_orders_company_status ON orders (company_id, status, created_at);
CREATE INDEX ix_orders_merchant ON orders (merchant_id, status, settlement_id);
CREATE INDEX ix_orders_loan ON orders (loan_id);

CREATE TABLE order_items (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_id BIGINT UNSIGNED NOT NULL,
  product_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(190) NOT NULL,
  unit_price BIGINT UNSIGNED NOT NULL,
  qty INT NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES orders (id),
  CONSTRAINT fk_items_product FOREIGN KEY (product_id) REFERENCES products (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_items_order ON order_items (order_id);

CREATE TABLE collection_notes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  installment_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  note VARCHAR(250) NOT NULL,
  promise_date DATE NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_notes_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_notes_inst FOREIGN KEY (installment_id) REFERENCES installments (id),
  CONSTRAINT fk_notes_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_notes_inst ON collection_notes (installment_id, id);
