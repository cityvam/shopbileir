-- تاریخچه‌ی تغییر وضعیت موجودیت‌ها (مشتری، فروشنده) با دلیل اجباری
CREATE TABLE status_history (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entity VARCHAR(30) NOT NULL,
  entity_id BIGINT UNSIGNED NOT NULL,
  from_status VARCHAR(20) NOT NULL,
  to_status VARCHAR(20) NOT NULL,
  reason VARCHAR(500) NOT NULL,
  user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_status_history_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_status_history_entity ON status_history (company_id, entity, entity_id);
