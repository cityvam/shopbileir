ALTER TABLE loan_plans ADD COLUMN late_fee_daily_percent DECIMAL(5,2) NOT NULL DEFAULT 0;
ALTER TABLE loans ADD COLUMN late_fee_daily_percent DECIMAL(5,2) NOT NULL DEFAULT 0;
ALTER TABLE installments ADD COLUMN late_fee_accrued BIGINT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE installments ADD COLUMN late_fee_paid BIGINT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE installments ADD COLUMN late_fee_until DATE NULL;
INSERT INTO accounts (company_id, code, name, type, is_system) SELECT id, '4103', 'درآمد جریمه تأخیر', 'revenue', 1 FROM companies;
