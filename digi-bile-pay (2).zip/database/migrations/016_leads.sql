-- درخواست‌های اعتبار از صفحه‌ی عمومی سایت
CREATE TABLE leads (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  mobile VARCHAR(11) NOT NULL,
  national_code VARCHAR(10) NULL,
  requested_amount BIGINT UNSIGNED NULL,
  plan_id BIGINT UNSIGNED NULL,
  message VARCHAR(500) NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'new',
  ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_leads_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_leads_company ON leads (company_id, status, created_at);
CREATE INDEX ix_leads_ip ON leads (ip, created_at);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('leads', 'درخواست‌های اعتبار', 'clipboard', '/leads', 'customers.view', 21, 'عملیات');
