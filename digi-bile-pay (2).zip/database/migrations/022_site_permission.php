<?php
declare(strict_types=1);

use App\Core\Database as DB;

// مجوز جدید site.manage برای نقش‌هایی که کاربران را مدیریت می‌کنند (مدیر شرکت)؛ ایدمپوتنت
return static function (): void {
    foreach (DB::all("SELECT DISTINCT role_id FROM role_permissions WHERE permission = 'users.manage'") as $r) {
        if (!DB::scalar("SELECT 1 FROM role_permissions WHERE role_id = ? AND permission = 'site.manage'", [$r['role_id']])) {
            DB::exec("INSERT INTO role_permissions (role_id, permission) VALUES (?, 'site.manage')", [$r['role_id']]);
        }
    }
};
