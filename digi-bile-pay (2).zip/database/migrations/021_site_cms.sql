-- محتوای قابل‌ویرایش صفحه‌ی اصلی عمومی (متن‌ها، تماس و سوالات متداول)
CREATE TABLE site_settings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  skey VARCHAR(40) NOT NULL,
  svalue TEXT NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_site_settings_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_site_settings ON site_settings (company_id, skey);

CREATE TABLE site_faq (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  question VARCHAR(200) NOT NULL,
  answer VARCHAR(800) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  CONSTRAINT fk_site_faq_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_site_faq ON site_faq (company_id, sort_order);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('site-settings', 'محتوای صفحه‌ی اصلی', 'home', '/site-settings', 'site.manage', 22, 'عملیات');
