<?php
declare(strict_types=1);

use App\Core\Database as DB;
use App\Services\Accounting;

// مهاجرت داده‌ای: ایجاد گروه‌های اصلی حساب و سال مالی جاری برای شرکت‌های موجود (ایدمپوتنت)
return static function (): void {
    foreach (DB::all('SELECT id FROM companies') as $c) {
        Accounting::upgradeCompany((int) $c['id']);
    }
};
