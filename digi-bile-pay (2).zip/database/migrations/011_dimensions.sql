-- حساب تفصیلی (اشخاص/طرف‌حساب‌ها) و مرکز هزینه؛ ابعاد اختیاری روی ردیف سند
CREATE TABLE dimensions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  kind VARCHAR(20) NOT NULL,
  code VARCHAR(20) NOT NULL,
  name VARCHAR(120) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_dimensions_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_dimensions_code ON dimensions (company_id, kind, code);

ALTER TABLE journal_lines ADD COLUMN detail_id BIGINT UNSIGNED NULL;
ALTER TABLE journal_lines ADD COLUMN cost_center_id BIGINT UNSIGNED NULL;
CREATE INDEX ix_journal_lines_detail ON journal_lines (detail_id);
CREATE INDEX ix_journal_lines_cc ON journal_lines (cost_center_id);

INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('dimensions', 'تفصیلی و مرکز هزینه', 'users', '/dimensions', 'accounting.view', 69, 'مالی');
