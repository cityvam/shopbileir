-- مشتریان، طرح‌ها، تسهیلات، اقساط، کیف پول و پرداخت‌ها (مبالغ به ریال و عدد صحیح)
CREATE TABLE customers (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  national_code VARCHAR(10) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  mobile VARCHAR(11) NOT NULL,
  credit_limit BIGINT UNSIGNED NOT NULL DEFAULT 0,
  wallet_balance BIGINT UNSIGNED NOT NULL DEFAULT 0,
  status ENUM('active','blocked') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_customers_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_customers_company_nc ON customers (company_id, national_code);
CREATE INDEX ix_customers_mobile ON customers (company_id, mobile);

CREATE TABLE loan_plans (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(150) NOT NULL,
  months INT NOT NULL,
  annual_rate_percent DECIMAL(5,2) NOT NULL,
  fee_percent DECIMAL(5,2) NOT NULL DEFAULT 0,
  min_amount BIGINT UNSIGNED NOT NULL,
  max_amount BIGINT UNSIGNED NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_plans_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_plans_company ON loan_plans (company_id, is_active);

CREATE TABLE loans (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  customer_id BIGINT UNSIGNED NOT NULL,
  plan_id BIGINT UNSIGNED NOT NULL,
  principal BIGINT UNSIGNED NOT NULL,
  months INT NOT NULL,
  annual_rate_percent DECIMAL(5,2) NOT NULL,
  fee_amount BIGINT UNSIGNED NOT NULL DEFAULT 0,
  total_interest BIGINT UNSIGNED NOT NULL DEFAULT 0,
  total_payable BIGINT UNSIGNED NOT NULL DEFAULT 0,
  status ENUM('pending','active','rejected','closed') NOT NULL DEFAULT 'pending',
  requested_by BIGINT UNSIGNED NOT NULL,
  decided_by BIGINT UNSIGNED NULL,
  decided_at DATETIME NULL,
  decision_note VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_loans_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_loans_customer FOREIGN KEY (customer_id) REFERENCES customers (id),
  CONSTRAINT fk_loans_plan FOREIGN KEY (plan_id) REFERENCES loan_plans (id),
  CONSTRAINT fk_loans_requested FOREIGN KEY (requested_by) REFERENCES users (id),
  CONSTRAINT fk_loans_decided FOREIGN KEY (decided_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_loans_company_status ON loans (company_id, status);
CREATE INDEX ix_loans_customer ON loans (customer_id);

CREATE TABLE installments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  loan_id BIGINT UNSIGNED NOT NULL,
  seq INT NOT NULL,
  due_date DATE NOT NULL,
  principal_part BIGINT UNSIGNED NOT NULL,
  interest_part BIGINT UNSIGNED NOT NULL,
  amount BIGINT UNSIGNED NOT NULL,
  paid_amount BIGINT UNSIGNED NOT NULL DEFAULT 0,
  status ENUM('due','partial','paid') NOT NULL DEFAULT 'due',
  paid_at DATETIME NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_inst_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_inst_loan FOREIGN KEY (loan_id) REFERENCES loans (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_inst_loan_seq ON installments (loan_id, seq);
CREATE INDEX ix_inst_company_due ON installments (company_id, status, due_date);

CREATE TABLE wallet_transactions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  customer_id BIGINT UNSIGNED NOT NULL,
  type ENUM('topup','installment','order') NOT NULL,
  amount BIGINT NOT NULL,
  balance_after BIGINT UNSIGNED NOT NULL,
  ref_id BIGINT UNSIGNED NULL,
  created_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_wtx_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_wtx_customer FOREIGN KEY (customer_id) REFERENCES customers (id),
  CONSTRAINT fk_wtx_user FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_wtx_customer ON wallet_transactions (customer_id, created_at);

CREATE TABLE payments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  loan_id BIGINT UNSIGNED NOT NULL,
  installment_id BIGINT UNSIGNED NOT NULL,
  amount BIGINT UNSIGNED NOT NULL,
  method ENUM('wallet','cash') NOT NULL,
  created_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_pay_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_pay_loan FOREIGN KEY (loan_id) REFERENCES loans (id),
  CONSTRAINT fk_pay_inst FOREIGN KEY (installment_id) REFERENCES installments (id),
  CONSTRAINT fk_pay_user FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_pay_company_date ON payments (company_id, created_at);
