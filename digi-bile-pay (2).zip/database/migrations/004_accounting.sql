-- حسابداری دوطرفه: سرفصل حساب‌ها، اسناد و آرتیکل‌ها
CREATE TABLE accounts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  code VARCHAR(20) NOT NULL,
  name VARCHAR(150) NOT NULL,
  type ENUM('asset','liability','equity','revenue','expense') NOT NULL,
  is_system TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_accounts_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_accounts_company_code ON accounts (company_id, code);

CREATE TABLE journal_entries (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  entry_no INT NOT NULL,
  entry_date DATE NOT NULL,
  description VARCHAR(250) NOT NULL,
  source_type VARCHAR(30) NOT NULL,
  source_id BIGINT UNSIGNED NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_je_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_je_user FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_je_company_no ON journal_entries (company_id, entry_no);
CREATE INDEX ix_je_date ON journal_entries (company_id, entry_date);
CREATE INDEX ix_je_source ON journal_entries (source_type, source_id);

CREATE TABLE journal_lines (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  entry_id BIGINT UNSIGNED NOT NULL,
  account_id BIGINT UNSIGNED NOT NULL,
  debit BIGINT UNSIGNED NOT NULL DEFAULT 0,
  credit BIGINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  CONSTRAINT fk_jl_entry FOREIGN KEY (entry_id) REFERENCES journal_entries (id),
  CONSTRAINT fk_jl_account FOREIGN KEY (account_id) REFERENCES accounts (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX ix_jl_entry ON journal_lines (entry_id);
CREATE INDEX ix_jl_account ON journal_lines (account_id);

INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('accounts', 'سرفصل حساب‌ها', 'book', '/accounts', 'accounting.view', 60, 'مالی');
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('journal', 'اسناد حسابداری', 'file-text', '/journal', 'accounting.view', 62, 'مالی');
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('trial', 'تراز آزمایشی', 'scale', '/trial-balance', 'accounting.view', 64, 'مالی');
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('reports', 'گزارش‌ها', 'chart', '/reports', 'reports.view', 66, 'مالی');
