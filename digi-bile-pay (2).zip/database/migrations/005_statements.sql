INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('statements', 'صورت‌های مالی', 'clipboard', '/statements', 'accounting.view', 65, 'مالی');
