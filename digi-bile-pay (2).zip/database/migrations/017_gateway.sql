-- درخواست‌های پرداخت آنلاین (لینک پرداخت قسط یا شارژ کیف پول)
CREATE TABLE payment_requests (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  token VARCHAR(40) NOT NULL,
  kind VARCHAR(12) NOT NULL,
  customer_id BIGINT UNSIGNED NOT NULL,
  installment_id BIGINT UNSIGNED NULL,
  amount BIGINT UNSIGNED NOT NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'pending',
  gateway VARCHAR(20) NULL,
  authority VARCHAR(80) NULL,
  ref_id VARCHAR(80) NULL,
  note VARCHAR(250) NULL,
  expires_at DATETIME NOT NULL,
  paid_at DATETIME NULL,
  created_by BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_payreq_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_payreq_customer FOREIGN KEY (customer_id) REFERENCES customers (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_payreq_token ON payment_requests (token);
CREATE INDEX ix_payreq_company ON payment_requests (company_id, status, created_at);
CREATE INDEX ix_payreq_inst ON payment_requests (installment_id);
INSERT INTO menu_items (menu_key, title, icon, url, permission, sort_order, section) VALUES ('payment-links', 'لینک‌های پرداخت', 'wallet', '/payment-links', 'installments.view', 55, 'عملیات');
