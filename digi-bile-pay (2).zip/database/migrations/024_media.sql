-- تصاویر (لوگوی شرکت و عکس کالا)؛ فایل‌ها در storage/uploads (خارج از وب‌روت) و از طریق /media سرو می‌شوند
CREATE TABLE media (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id BIGINT UNSIGNED NOT NULL,
  kind VARCHAR(10) NOT NULL,
  ref_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
  filename VARCHAR(64) NOT NULL,
  mime VARCHAR(20) NOT NULL,
  size INT UNSIGNED NOT NULL,
  width INT NOT NULL,
  height INT NOT NULL,
  created_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_media_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX ux_media_ref ON media (company_id, kind, ref_id);
