<?php
declare(strict_types=1);

use App\Core\Database as DB;
use App\Services\Accounting;

// حساب‌های اسناد دریافتنی/پرداختنی (چک) برای شرکت‌های موجود؛ ایدمپوتنت
return static function (): void {
    foreach (DB::all('SELECT id FROM companies') as $c) {
        Accounting::upgradeCompany((int) $c['id']);
    }
};
