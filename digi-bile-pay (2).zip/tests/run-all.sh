#!/usr/bin/env bash
# اجرای کامل تست‌ها روی SQLite موقت (فقط برای تست؛ محیط عملیاتی MySQL است)
set -euo pipefail
cd "$(dirname "$0")/.."

DB_FILE="$(mktemp -u /tmp/dbp-test-XXXXXX.db)"
PORT=8099
export DB_DSN="sqlite:$DB_FILE"
export DB_FILE
export APP_DEBUG=1
export APP_ENV=local # کپچا در حالت local کد را در هدر آزمایشی می‌دهد
export PAYMENT_GATEWAY=sandbox
export SMS_DRIVER=log

php tests/unit.php
php bin/migrate.php >/dev/null
SEED_OUT="$(php bin/seed.php)"
export PW_SUPER="$(echo "$SEED_OUT" | awk '/superadmin/ {print $3}')"
export PW_ADMIN="$(echo "$SEED_OUT" | awk '/dbp_admin/ {print $3}')"

php -S 127.0.0.1:$PORT -t public tests/dev-router.php >/tmp/dbp-server.log 2>&1 &
SERVER_PID=$!
trap 'kill $SERVER_PID 2>/dev/null; rm -f "$DB_FILE" storage/logs/sms.log' EXIT
sleep 1

BASE_URL="http://127.0.0.1:$PORT" php tests/smoke.php
