<?php
declare(strict_types=1);

// اجرا: DB_DSN=sqlite::memory: php tests/unit.php
putenv('DB_DSN=sqlite::memory:');
require dirname(__DIR__) . '/app/bootstrap.php';

use App\Core\Database as DB;
use App\Core\Jalali;
use App\Core\Migrator;
use App\Core\Validator;
use App\Services\LoanCalculator;

$fails = 0;
$total = 0;
function check(string $name, bool $ok, string $extra = ''): void
{
    global $fails, $total;
    $total++;
    if (!$ok) {
        $fails++;
        echo "FAIL  $name $extra\n";
    }
}

// --- تاریخ شمسی ---
require_once dirname(__DIR__) . '/app/Core/Totp.php';
check('totp RFC6238 vector', \App\Core\Totp::code('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ', 1) === '287082');
check('totp base32 roundtrip', \App\Core\Totp::base32Decode(\App\Core\Totp::base32Encode('hello-world')) === 'hello-world');
check('totp verify window and replay', (function () {
    $s = \App\Core\Totp::newSecret();
    $now = 1_700_000_000;
    $step = intdiv($now, 30);
    $ok = \App\Core\Totp::verify($s, \App\Core\Totp::code($s, $step), null, $now) === $step;
    $replay = \App\Core\Totp::verify($s, \App\Core\Totp::code($s, $step), $step, $now) === null;
    $far = \App\Core\Totp::verify($s, \App\Core\Totp::code($s, $step + 3), null, $now) === null;
    return $ok && $replay && $far;
})());
check('g2j 2026-11-01', Jalali::toJalali(2026, 11, 1) === [1405, 8, 10]);
check('j2g 1404/1/1', Jalali::toGregorian(1404, 1, 1) === [2025, 3, 21]);
check('j2g 1403/1/1 (leap-year start)', Jalali::toGregorian(1403, 1, 1) === [2024, 3, 20]);
check('leap 1403', Jalali::isLeap(1403) && !Jalali::isLeap(1404));
check('roundtrip 3000 days', (function () {
    $t = strtotime('2020-01-01');
    for ($i = 0; $i < 3000; $i++, $t += 86400) {
        [$y, $m, $d] = [(int) date('Y', $t), (int) date('n', $t), (int) date('j', $t)];
        if (Jalali::toGregorian(...Jalali::toJalali($y, $m, $d)) !== [$y, $m, $d]) {
            return false;
        }
    }
    return true;
})());
[$gy, $gm, $gd] = Jalali::toGregorian(1405, 1, 31);
$clamped = Jalali::toJalali(...array_map('intval', explode('-', Jalali::addMonths(sprintf('%04d-%02d-%02d', $gy, $gm, $gd), 6))));
check('addMonths clamps 31 Farvardin + 6 months to 30 Mehr', $clamped === [1405, 7, 30], json_encode($clamped));
check('format', Jalali::format('2026-11-01 14:30:00', true) === '1405/08/10 14:30');

// --- محاسبه اقساط ---
foreach ([[10000000, 6, 24.0], [50000000, 12, 18.5], [1000000, 1, 30.0], [7777777, 24, 0.0], [123456789, 36, 23.99]] as [$p, $n, $r]) {
    $s = LoanCalculator::schedule($p, $n, $r, '2026-11-01');
    check("schedule count $p/$n/$r", count($s) === $n);
    check("principal sums to loan $p/$n/$r", array_sum(array_column($s, 'principal_part')) === $p);
    check("amount = principal+interest $p/$n/$r", array_sum(array_column($s, 'amount')) === $p + array_sum(array_column($s, 'interest_part')));
    check("no negative parts $p/$n/$r", min(array_column($s, 'principal_part')) >= 0 && min(array_column($s, 'interest_part')) >= 0);
    $dates = array_column($s, 'due_date');
    $sorted = $dates;
    sort($sorted);
    check("due dates ascending $p/$n/$r", $dates === $sorted);
}
check('zero-rate has zero interest', LoanCalculator::totals(LoanCalculator::schedule(1200000, 12, 0.0, '2026-11-01'))['interest'] === 0);
check('fee', LoanCalculator::fee(10000000, 2.0) === 200000);
try {
    LoanCalculator::schedule(0, 6, 10.0, '2026-11-01');
    check('rejects zero principal', false);
} catch (InvalidArgumentException) {
    check('rejects zero principal', true);
}

// --- اعتبارسنجی ---
function makeNc(string $nine): string
{
    $sum = 0;
    for ($i = 0; $i < 9; $i++) {
        $sum += (int) $nine[$i] * (10 - $i);
    }
    $r = $sum % 11;
    return $nine . ($r < 2 ? $r : 11 - $r);
}
check('national code valid', Validator::nationalCode(makeNc('123456789')));
check('national code wrong checksum', !Validator::nationalCode(substr(makeNc('123456789'), 0, 9) . '0'));
check('national code repeated digits', !Validator::nationalCode('1111111111'));
check('national code short', !Validator::nationalCode('12345'));
check('amount strips separators', Validator::amount('12,500,000') === 12500000);
check('amount rejects zero/empty/huge', Validator::amount('0') === null && Validator::amount('') === null && Validator::amount('99999999999999') === null);
check('mobile', Validator::mobile('09121234567') && !Validator::mobile('9121234567'));
check('percent', Validator::percent('24.5') === 24.5 && Validator::percent('101') === null && Validator::percent('x') === null);
check('password rules', Validator::password('short1') !== null && Validator::password('onlyletterslong') !== null && Validator::password('Valid-pass-123') === null);

// --- Migration ---
$first = Migrator::run(BASE_PATH . '/database/migrations');
$second = Migrator::run(BASE_PATH . '/database/migrations');
check('migrations apply', count($first) >= 2);
check('migrations idempotent', $second === []);
check('menu seeded', (int) DB::scalar('SELECT COUNT(*) FROM menu_items') >= 9);
check('FK enforced', (function () {
    try {
        DB::exec("INSERT INTO roles (company_id, slug, name) VALUES (999, 'x', 'x')");
        return false;
    } catch (PDOException) {
        return true;
    }
})());

// ---------- فاز ۲: تاریخ شمسی و حسابداری ----------
check('Jalali::parse valid', App\Core\Jalali::parse('1405/01/01') === '2026-03-21');
check('Jalali::parse persian digits invalid month', App\Core\Jalali::parse('1405/13/01') === null);
check('Jalali::parse rejects garbage', App\Core\Jalali::parse('abc') === null && App\Core\Jalali::parse('1405/07/31') === null);
DB::exec("INSERT INTO companies (code, name, status) VALUES ('UT', 'unit', 'active')");
$ut = (int) DB::scalar("SELECT id FROM companies WHERE code = 'UT'");
App\Services\Accounting::provision($ut);
$eid = App\Services\Accounting::post($ut, 'test', [['1101', 100, 0], ['3101', 0, 100]], 'manual', null, null, '2026-01-01');
check('Accounting::post balanced', $eid > 0);
check('Accounting::post unbalanced throws', (function () use ($ut) {
    try {
        App\Services\Accounting::post($ut, 'bad', [['1101', 100, 0], ['3101', 0, 90]], 'manual', null, null);
        return false;
    } catch (Throwable) {
        return true;
    }
})());
check('Accounting::post unknown account throws', (function () use ($ut) {
    try {
        App\Services\Accounting::post($ut, 'bad', [['9999', 5, 0], ['3101', 0, 5]], 'manual', null, null);
        return false;
    } catch (Throwable) {
        return true;
    }
})());
check('failed post leaves no partial entry', (int) DB::scalar('SELECT COUNT(*) FROM journal_entries WHERE company_id = ?', [$ut]) === 1);
check('Accounting::balance by type', App\Services\Accounting::balance('asset', 100, 30) === 70 && App\Services\Accounting::balance('liability', 100, 30) === -70 || App\Services\Accounting::balance('liability', 30, 100) === 70);

// ---------- Excel ----------
$xf = \App\Core\Xlsx::write(['نام', 'موبایل', 'مبلغ'], [['علی <b>&"', '09121234567', 1500000], ['=SUM(A1)', '0012', '25']]);
check('xlsx writer makes a zip', \App\Core\Xlsx::isXlsx($xf));
$csvBack = \App\Core\Xlsx::toCsv($xf);
check('xlsx round-trips text, leading zeros and numbers', str_contains($csvBack, '09121234567') && str_contains($csvBack, '1500000') && str_contains($csvBack, 'علی <b>&"'));
$zx = new ZipArchive();
$zx->open($xf);
$sx = (string) $zx->getFromName('xl/worksheets/sheet1.xml');
check('xlsx is RTL with frozen header and real numbers', str_contains($sx, 'rightToLeft="1"') && str_contains($sx, 'state="frozen"') && str_contains($sx, '<c r="C2" s="2"><v>1500000</v></c>'));
check('xlsx formulas stay text (no <f> element)', !str_contains($sx, '<f>') && str_contains($sx, '=SUM(A1)'));
check('xlsx phone column kept as text', str_contains($sx, 't="inlineStr"><is><t xml:space="preserve">09121234567'));
$zx->close();
unlink($xf);

echo $fails === 0 ? "unit: all $total checks passed\n" : "unit: $fails of $total FAILED\n";
exit($fails === 0 ? 0 : 1);
