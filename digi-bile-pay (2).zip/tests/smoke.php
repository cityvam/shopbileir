<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/app/Core/Jalali.php';
require_once dirname(__DIR__) . '/app/Core/Totp.php';

// تست پذیرش HTTP روی سرور واقعی PHP. اجرا از طریق tests/run-all.sh
$base = getenv('BASE_URL') ?: 'http://127.0.0.1:8099';
$pwSuper = getenv('PW_SUPER');
$pwAdmin = getenv('PW_ADMIN');
$dbFile = getenv('DB_FILE');

$fails = 0;
$total = 0;
function check(string $name, bool $ok, string $extra = ''): void
{
    global $fails, $total;
    $total++;
    if (!$ok) {
        $fails++;
        echo "FAIL  $name $extra\n";
    }
}

final class Client
{
    public string $html = '';
    public int $status = 0;
    public string $url = '';
    private string $jar;

    public function __construct(private string $base)
    {
        $this->jar = tempnam(sys_get_temp_dir(), 'jar');
    }

    public function get(string $path): self
    {
        return $this->req($path, null);
    }

    public function post(string $path, array $data, bool $withCsrf = true): self
    {
        if ($withCsrf) {
            $data['_csrf'] = $this->csrf();
        }
        if (in_array($path, ['/login', '/apply', '/portal/login'], true) && !array_key_exists('captcha', $data) && $withCsrf) {
            $data['captcha'] = $this->captchaCode($path === '/portal/login' ? 'portal' : ltrim($path, '/'));
        }
        return $this->req($path, $data);
    }

    /** کد کپچا را از هدر اشکال‌زدایی (فقط APP_ENV=local) می‌خواند؛ صفحه‌ی فعلی را تغییر نمی‌دهد. */
    public function captchaCode(string $scope): string
    {
        $code = '';
        $ch = curl_init($this->base . '/captcha?scope=' . $scope);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $this->jar, CURLOPT_COOKIEFILE => $this->jar,
            CURLOPT_HEADERFUNCTION => static function ($c, $h) use (&$code) {
                if (stripos($h, 'X-Captcha-Code:') === 0) {
                    $code = trim(substr($h, 15));
                }
                return strlen($h);
            },
        ]);
        $this->lastCaptchaBody = (string) curl_exec($ch);
        curl_close($ch);
        return $code;
    }

    public string $lastCaptchaBody = '';

    public function postRaw(string $path, array $data): self
    {
        return $this->req($path, $data);
    }

    public function postFile(string $path, array $data, string $field, string $file): self
    {
        $data['_csrf'] = $this->csrf();
        $data[$field] = new CURLFile($file, 'text/csv', 'import.csv');
        return $this->req($path, $data);
    }

    public function csrf(): string
    {
        preg_match('/name="_csrf" value="([a-f0-9]+)"/', $this->html, $m);
        return $m[1] ?? '';
    }

    private function req(string $path, ?array $post): self
    {
        $ch = curl_init($this->base . $path);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
            CURLOPT_COOKIEJAR => $this->jar, CURLOPT_COOKIEFILE => $this->jar, CURLOPT_USERAGENT => 'smoke-test',
        ]);
        if ($post !== null) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, array_filter($post, static fn ($v) => $v instanceof CURLFile) ? $post : http_build_query($post));
        }
        $this->html = (string) curl_exec($ch);
        $this->status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $this->url = (string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        return $this;
    }

    public function has(string $needle): bool
    {
        return str_contains($this->html, $needle);
    }

    public function login(string $user, string $pass): self
    {
        $this->get('/login');
        return $this->post('/login', ['username' => $user, 'password' => $pass]);
    }
}

function validNc(string $nine): string
{
    $sum = 0;
    for ($i = 0; $i < 9; $i++) {
        $sum += (int) $nine[$i] * (10 - $i);
    }
    $r = $sum % 11;
    return $nine . ($r < 2 ? $r : 11 - $r);
}

function pdo(): PDO
{
    global $dbFile;
    return new PDO('sqlite:' . $dbFile, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
}

function str_getcsv_all(string $csv): array
{
    $rows = [];
    $csv = ltrim($csv, "\xEF\xBB\xBF");
    $fh = fopen('php://memory', 'r+');
    fwrite($fh, $csv);
    rewind($fh);
    while (($r = fgetcsv($fh)) !== false) {
        $rows[] = $r;
    }
    return $rows;
}

// ---------- احراز هویت ----------
$anon = new Client($base);
$anon->get('/dashboard');
check('anonymous redirected to login', str_ends_with($anon->url, '/login') && $anon->has('ورود به سامانه'));
$anon->post('/login', ['username' => 'dbp_admin', 'password' => 'x'], false);
check('POST without CSRF rejected (419)', $anon->status === 419);
$anon->get('/login');
$anon->post('/login', ['username' => 'dbp_admin', 'password' => 'wrong-password']);
check('wrong password rejected', $anon->has('نام کاربری یا رمز عبور صحیح نیست'));

// کپچای ۶ رقمی
$anon->get('/login');
check('login shows captcha image + input', $anon->has('data-captcha-img') && $anon->has('name="captcha"'));
$cc = $anon->captchaCode('login');
check('captcha is 6 digits and served as SVG', preg_match('/^\d{6}$/', $cc) === 1 && str_starts_with($anon->lastCaptchaBody, '<svg') && !str_contains($anon->lastCaptchaBody, $cc));
$anon->post('/login', ['username' => 'dbp_admin', 'password' => $pwAdmin, 'captcha' => '000000' === $cc ? '111111' : '000000']);
check('wrong captcha blocks login', $anon->has('کد امنیتی اشتباه') && !str_ends_with($anon->url, '/dashboard'));
$anon->get('/login');
$anon->post('/login', ['username' => 'dbp_admin', 'password' => $pwAdmin, 'captcha' => '']);
check('empty captcha blocks login', $anon->has('کد امنیتی اشتباه'));
$anon->get('/login');
$cc = $anon->captchaCode('login');
$anon->post('/login', ['username' => 'dbp_admin', 'password' => 'wrong-password', 'captcha' => $cc]);
$anon->post('/login', ['username' => 'dbp_admin', 'password' => $pwAdmin, 'captcha' => $cc]);
check('captcha is single-use (replay rejected)', $anon->has('کد امنیتی اشتباه'));
$fa = new Client($base);
$fa->get('/login');
$fa->post('/login', ['username' => 'dbp_admin', 'password' => $pwAdmin, 'captcha' => strtr($fa->captchaCode('login'), ['0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹'])]);
check('Persian digits accepted for captcha', str_ends_with($fa->url, '/dashboard'));

$admin = new Client($base);
$admin->login('dbp_admin', $pwAdmin);
check('admin login ok', $admin->has('مشتریان فعال') && str_ends_with($admin->url, '/dashboard'), $admin->url);

// ---------- لاگین برگشتی: قفل پس از ۵ تلاش ناموفق ----------
$brute = new Client($base);
$brute->get('/login');
for ($i = 0; $i < 6; $i++) {
    $brute->post('/login', ['username' => 'nobody_here', 'password' => 'bad' . $i]);
}
check('brute force lockout', $brute->has('تعداد تلاش‌های ناموفق زیاد است'));

// ---------- صفحات اصلی بدون خطای PHP ----------
foreach (['/dashboard', '/customers', '/customers/create', '/plans', '/plans/create', '/loans', '/loans/create', '/installments', '/companies', '/users', '/users/create', '/roles', '/roles/create', '/audit'] as $u) {
    $admin->get($u);
    check("GET $u = 200", $admin->status === 200, (string) $admin->status);
    check("GET $u no PHP errors", !preg_match('/(Fatal error|Warning:|Notice:|Deprecated:|Stack trace)/', $admin->html));
}
check('CSS per page loaded', $admin->get('/plans')->has('css/pages/plans.css') && !$admin->has('css/pages/loans.css'));

// ---------- طرح، مشتری ----------
$admin->get('/plans/create');
$admin->post('/plans', ['name' => 'طرح ۶ ماهه', 'months' => '6', 'annual_rate_percent' => '24', 'fee_percent' => '2', 'min_amount' => '1,000,000', 'max_amount' => '50,000,000', 'is_active' => '1']);
check('plan created', $admin->has('طرح ثبت شد') && $admin->has('طرح ۶ ماهه'));

$admin->get('/customers/create');
$admin->post('/customers', ['national_code' => '1234567890', 'full_name' => 'بد', 'mobile' => '123', 'credit_limit' => '0']);
check('invalid customer rejected', $admin->has('کد ملی معتبر نیست') && $admin->has('شماره موبایل'));

$nc = validNc('123456789');
$admin->get('/customers/create');
$admin->post('/customers', ['national_code' => $nc, 'full_name' => 'علی رضایی', 'mobile' => '09121234567', 'credit_limit' => '20,000,000']);
check('customer created', $admin->has('مشتری ثبت شد') && $admin->has('علی رضایی'));
preg_match('#/customers/(\d+)#', $admin->url, $m);
$customerId = (int) ($m[1] ?? 0);
check('customer id parsed', $customerId > 0);
$admin->get('/customers/create');
$admin->post('/customers', ['national_code' => $nc, 'full_name' => 'تکراری', 'mobile' => '09121234567', 'credit_limit' => '0']);
check('duplicate national code rejected', $admin->has('قبلاً ثبت شده'));

// ---------- کاربر دوم برای تفکیک وظایف ----------
$roleId = (int) pdo()->query("SELECT r.id FROM roles r JOIN companies c ON c.id = r.company_id WHERE c.code = 'DBP' AND r.slug = 'lending_manager'")->fetchColumn();
$admin->get('/users/create');
$admin->post('/users', ['username' => 'lender1', 'full_name' => 'کارشناس تسهیلات', 'mobile' => '09120000000', 'role_id' => (string) $roleId, 'password' => 'Lender-pass-123']);
check('user created', $admin->has('کاربر ثبت شد'));
$admin->get('/users/create');
$admin->post('/users', ['username' => 'weak', 'full_name' => 'ضعیف', 'role_id' => (string) $roleId, 'password' => '123']);
check('weak password rejected', $admin->has('رمز عبور باید'));

$lender = new Client($base);
$lender->login('lender1', 'Lender-pass-123');
check('lender login ok', $lender->has('داشبورد'));
$lender->get('/roles/create');
check('lender denied roles.manage (403)', $lender->status === 403);
$lender->get('/companies/create');
check('lender denied companies.manage (403)', $lender->status === 403);
$lender->get('/audit');
check('lender denied audit (403)', $lender->status === 403);

// ---------- تسهیلات ----------
preg_match('#<option value="(\d+)"[^>]*>\s*طرح ۶ ماهه#u', $lender->get('/loans/create')->html, $m);
$planId = (int) ($m[1] ?? 0);
check('plan listed in loan form', $planId > 0);
$lender->post('/loans', ['customer_id' => (string) $customerId, 'plan_id' => (string) $planId, 'amount' => '60,000,000']);
check('amount above plan max rejected', $lender->has('خارج از بازه مجاز'));
$lender->get('/loans/create');
$lender->post('/loans', ['customer_id' => (string) $customerId, 'plan_id' => (string) $planId, 'amount' => '30,000,000']);
check('amount above available credit rejected', $lender->has('اعتبار آزاد'));
$lender->get('/loans/create');
$lender->post('/loans', ['customer_id' => (string) $customerId, 'plan_id' => (string) $planId, 'amount' => '10,000,000']);
check('loan requested (pending)', $lender->has('در انتظار تأیید') && $lender->has('پیش‌نمایش جدول اقساط'));
preg_match('#/loans/(\d+)#', $lender->url, $m);
$loanId = (int) ($m[1] ?? 0);
check('loan id parsed', $loanId > 0);
check('requester cannot see approve button', !$lender->has('تأیید تسهیلات'));
$lender->post('/loans/' . $loanId . '/approve', []);
check('requester cannot approve own loan', $lender->has('نمی‌تواند همان درخواست را تأیید کند'));

$second = new Client($base);
$second->login('dbp_admin', $pwAdmin);
$second->get('/loans/' . $loanId);
check('other user sees approve button', $second->has('تأیید تسهیلات'));
$second->post('/loans/' . $loanId . '/approve', []);
check('loan approved by other user', $second->has('تسهیلات تأیید و جدول اقساط ایجاد شد'));
$second->post('/loans/' . $loanId . '/approve', []);
check('double approval blocked', $second->has('دیگر در وضعیت انتظار نیست'));
$inst = pdo()->query("SELECT COUNT(*) c, SUM(principal_part) p FROM installments WHERE loan_id = $loanId")->fetch();
check('6 installments created, principal sums to loan', (int) $inst['c'] === 6 && (int) $inst['p'] === 10000000, json_encode($inst));

$lender->get('/loans/create');
$lender->post('/loans', ['customer_id' => (string) $customerId, 'plan_id' => (string) $planId, 'amount' => '15,000,000']);
check('credit used by active loan reduces availability', $lender->has('اعتبار آزاد'));
$lender->get('/loans/create');
$lender->post('/loans', ['customer_id' => (string) $customerId, 'plan_id' => (string) $planId, 'amount' => '5,000,000']);
preg_match('#/loans/(\d+)#', $lender->url, $m);
$loan2 = (int) ($m[1] ?? 0);
$second->get('/loans/' . $loan2);
$second->post('/loans/' . $loan2 . '/reject', ['note' => '']);
check('reject requires reason', $second->has('دلیل رد درخواست را بنویسید'));
$second->post('/loans/' . $loan2 . '/reject', ['note' => 'مدارک ناقص']);
check('loan rejected', $second->has('درخواست رد شد') && $second->has('مدارک ناقص'));

// ---------- اقساط و کیف پول ----------
$second->get('/customers/' . $customerId);
$second->post('/customers/' . $customerId . '/topup', ['amount' => '1,000,000']);
check('wallet topup', $second->has('کیف پول شارژ شد'));
$second->get('/customers/' . $customerId);
$second->post('/customers/' . $customerId . '/topup', ['amount' => 'abc']);
check('invalid topup rejected', $second->has('مبلغ شارژ معتبر نیست'));

$ids = pdo()->query("SELECT id, amount FROM installments WHERE loan_id = $loanId ORDER BY seq")->fetchAll();
$i1 = (int) $ids[0]['id'];
$a1 = (int) $ids[0]['amount'];
$second->get('/installments');
$second->post("/installments/$i1/pay", ['amount' => (string) ($a1 + 1), 'method' => 'cash']);
check('overpayment rejected', $second->has('بیشتر است'));
$second->get('/installments');
$second->post("/installments/$i1/pay", ['amount' => '1', 'method' => 'wallet']);
check('partial wallet payment ok', $second->has('پرداخت ثبت شد'));
$second->get('/installments');
$second->post("/installments/$i1/pay", ['amount' => (string) ($a1 - 1), 'method' => 'wallet']);
check('wallet insufficient funds rejected', $second->has('موجودی کیف پول کافی نیست'));
$second->get('/installments');
$second->post("/installments/$i1/pay", ['amount' => (string) ($a1 - 1), 'method' => 'cash']);
check('rest paid in cash -> installment paid', $second->has('پرداخت ثبت شد'));
$st = pdo()->query("SELECT status, paid_amount, amount FROM installments WHERE id = $i1")->fetch();
check('installment fully paid', $st['status'] === 'paid' && (int) $st['paid_amount'] === (int) $st['amount']);

// پرداخت همه اقساط باقی‌مانده => بسته شدن تسهیلات
foreach (array_slice($ids, 1) as $row) {
    $second->get('/installments');
    $second->post('/installments/' . $row['id'] . '/pay', ['amount' => (string) $row['amount'], 'method' => 'cash']);
}
check('loan closed after all installments paid', pdo()->query("SELECT status FROM loans WHERE id = $loanId")->fetchColumn() === 'closed');
$second->get('/installments');
$second->post("/installments/$i1/pay", ['amount' => '1', 'method' => 'cash']);
check('paying settled installment blocked', $second->has('قسط یافت نشد') || $second->has('قبلاً تسویه شده'));

// ---------- مجوزها: جلوگیری از ارتقای دسترسی ----------
$second->get('/roles/create');
$second->post('/roles', ['name' => 'نقش تست', 'perms' => ['customers.view', 'companies.manage', 'bogus.permission']]);
check('custom role created', $second->has('نقش ثبت شد'));
$perms = pdo()->query("SELECT rp.permission FROM role_permissions rp JOIN roles r ON r.id = rp.role_id WHERE r.name = 'نقش تست'")->fetchAll(PDO::FETCH_COLUMN);
check('cannot grant permission you do not hold / invalid ones', $perms === ['customers.view'], json_encode($perms));
$sysRoleId = $roleId;
$second->get('/roles');
$second->get("/roles/$sysRoleId/edit");
check('system roles not editable', $second->has('نقش‌های سیستمی قابل ویرایش'));

// ---------- جداسازی مستأجرها ----------
$super = new Client($base);
$super->login('superadmin', $pwSuper);
check('superadmin login', $super->has('داشبورد'));
$super->get('/customers/' . $customerId);
check('other tenant customer not visible (404)', $super->status === 404);
$super->get('/loans/' . $loanId);
check('other tenant loan not visible (404)', $super->status === 404);
$super->get('/companies');
check('superadmin sees all companies', $super->has('دیجی بایل پی') && $super->has('نگار آذین فدک ایران'));
$super->get('/companies/create');
$super->post('/companies', ['code' => 'TST', 'name' => 'شرکت آزمایشی', 'brand_name' => '', 'parent_id' => '1', 'admin_username' => 'tst_admin', 'admin_name' => 'مدیر آزمایشی', 'admin_password' => 'Tenant-pass-123']);
check('company + admin created', $super->has('شرکت با نقش‌های پیش‌فرض'));
$other = new Client($base);
$other->login('tst_admin', 'Tenant-pass-123');
check('new tenant admin login', $other->has('داشبورد'));
$other->get('/customers/' . $customerId);
check('new tenant cannot see DBP customer (404)', $other->status === 404);
$other->get('/customers');
check('new tenant customer list empty of DBP data', !$other->has('علی رضایی'));
$other->post("/installments/$i1/pay", ['amount' => '1', 'method' => 'cash']);
check('cross-tenant payment blocked', !$other->has('پرداخت ثبت شد'));
$super->get('/companies');
$tstId = (int) pdo()->query("SELECT id FROM companies WHERE code = 'TST'")->fetchColumn();
$super->post("/companies/$tstId/status", []);
$other2 = new Client($base);
$other2->login('tst_admin', 'Tenant-pass-123');
check('suspended company user cannot login', $other2->has('نام کاربری یا رمز عبور صحیح نیست'));

// ---------- فاز ۲: فروشنده، محصول، سفارش، تسویه، حسابداری ----------
$db = pdo();
$dbp = (int) $db->query("SELECT id FROM companies WHERE code = 'DBP'")->fetchColumn();
foreach (['/merchants', '/merchants/create', '/products', '/products/create', '/orders', '/orders/create', '/accounts', '/trial-balance', '/journal', '/journal/create', '/reports', '/account'] as $u) {
    $admin->get($u);
    check("phase2 page $u", $admin->status === 200 && !str_contains($admin->html, 'Fatal error') && !str_contains($admin->html, 'Warning:'), "status={$admin->status}");
}
check('reports CSS only on reports', $admin->get('/reports')->has('css/components/charts.css') && !$admin->get('/merchants')->has('css/components/charts.css'));

$admin->get('/merchants/create');
$admin->post('/merchants', ['name' => '', 'commission_percent' => '10']);
check('merchant name required', $admin->has('نام فروشنده را وارد کنید'));
$admin->get('/merchants/create');
$admin->post('/merchants', ['name' => 'لوازم خانگی آرین', 'contact_name' => 'آقای آرین', 'mobile' => '09125550000', 'commission_percent' => '10']);
check('merchant created', $admin->has('فروشنده ثبت شد'));
$mid = (int) $db->query("SELECT id FROM merchants WHERE company_id = $dbp ORDER BY id DESC LIMIT 1")->fetchColumn();

$admin->get('/products/create');
$admin->post('/products', ['merchant_id' => (string) $mid, 'name' => 'یخچال', 'price' => '2,000,000', 'stock' => '5']);
check('product created', $admin->has('محصول ثبت شد'));
$pid = (int) $db->query("SELECT id FROM products WHERE merchant_id = $mid")->fetchColumn();
$stock = static fn () => (int) pdo()->query("SELECT stock FROM products WHERE id = $pid")->fetchColumn();

$nc2 = validNc('987654321');
$admin->get('/customers/create');
$admin->post('/customers', ['national_code' => $nc2, 'full_name' => 'مریم احمدی', 'mobile' => '09129990000', 'credit_limit' => '30,000,000']);
$cid2 = (int) $db->query("SELECT id FROM customers WHERE national_code = '$nc2'")->fetchColumn();
check('order customer created', $cid2 > 0);
$wallet2 = static fn () => (int) pdo()->query("SELECT wallet_balance FROM customers WHERE id = $cid2")->fetchColumn();

$admin->get("/orders/create?merchant_id=$mid");
$admin->post('/orders', ['merchant_id' => (string) $mid, 'customer_id' => (string) $cid2, 'payment_type' => 'cash', 'qty' => [(string) $pid => '1']]);
check('cash order blocked without wallet balance', $admin->has('موجودی کیف پول') && $stock() === 5);

$admin->get("/customers/$cid2");
$admin->post("/customers/$cid2/topup", ['amount' => '10,000,000']);
$admin->get("/orders/create?merchant_id=$mid");
$admin->post('/orders', ['merchant_id' => (string) $mid, 'customer_id' => (string) $cid2, 'payment_type' => 'cash', 'qty' => [(string) $pid => '2']]);
check('cash order paid from wallet', $admin->has('سفارش ثبت و از کیف پول پرداخت شد'));
check('cash order effects (stock 3, wallet 6M)', $stock() === 3 && $wallet2() === 6000000);
$acc = static fn (string $code) => (int) pdo()->query("SELECT COALESCE(SUM(l.credit - l.debit), 0) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id JOIN accounts a ON a.id = l.account_id WHERE e.status = 'final' AND a.company_id = $dbp AND a.code = '$code'")->fetchColumn();
check('merchant payable 3.6M and commission 0.4M', $acc('2201') === 3600000 && $acc('4102') === 400000);

$admin->get("/orders/create?merchant_id=$mid");
$admin->post('/orders', ['merchant_id' => (string) $mid, 'customer_id' => (string) $cid2, 'payment_type' => 'cash', 'qty' => [(string) $pid => '4']]);
check('over-stock order rejected', $admin->has('کافی نیست') && $stock() === 3);
$admin->post('/orders', ['merchant_id' => (string) $mid, 'customer_id' => (string) $cid2, 'payment_type' => 'cash', 'qty' => [(string) $pid => '-1']]);
check('negative qty rejected', $stock() === 3);

$lender->get("/orders/create?merchant_id=$mid");
$lender->post('/orders', ['merchant_id' => (string) $mid, 'customer_id' => (string) $cid2, 'payment_type' => 'installment', 'plan_id' => (string) $planId, 'qty' => [(string) $pid => '1']]);
check('installment order pending', $lender->has('در انتظار تأیید است'));
$oidA = (int) $db->query('SELECT MAX(id) FROM orders')->fetchColumn();
$loanA = (int) $db->query("SELECT loan_id FROM orders WHERE id = $oidA")->fetchColumn();
check('stock reserved for pending order', $stock() === 2 && $loanA > 0);
$lender->get("/loans/$loanA");
$lender->post("/loans/$loanA/approve", []);
check('requester cannot approve own order loan', $db->query("SELECT status FROM loans WHERE id = $loanA")->fetchColumn() === 'pending');
$second->get("/loans/$loanA");
$second->post("/loans/$loanA/reject", ['note' => 'عدم احراز']);
check('reject cancels order and restores stock', $db->query("SELECT status FROM orders WHERE id = $oidA")->fetchColumn() === 'cancelled' && $stock() === 3);

$lender->get("/orders/create?merchant_id=$mid");
$lender->post('/orders', ['merchant_id' => (string) $mid, 'customer_id' => (string) $cid2, 'payment_type' => 'installment', 'plan_id' => (string) $planId, 'qty' => [(string) $pid => '1']]);
$oidB = (int) $db->query('SELECT MAX(id) FROM orders')->fetchColumn();
$loanB = (int) $db->query("SELECT loan_id FROM orders WHERE id = $oidB")->fetchColumn();
$second->get("/loans/$loanB");
$second->post("/loans/$loanB/approve", []);
check('approve confirms order', $db->query("SELECT status FROM orders WHERE id = $oidB")->fetchColumn() === 'confirmed' && $stock() === 2);
check('order page renders', $admin->get("/orders/$oidB")->status === 200 && $admin->has('یخچال'));

$admin->get("/merchants/$mid");
check('settle button shown', $admin->has('ثبت تسویه'));
$admin->post("/merchants/$mid/settle", []);
check('settlement recorded', $admin->has('تسویه ثبت شد'), substr(strip_tags($admin->html), 0, 0));
check('orders marked settled', (int) $db->query("SELECT COUNT(*) FROM orders WHERE merchant_id = $mid AND status = 'confirmed' AND settlement_id IS NULL")->fetchColumn() === 0);
$admin->post("/merchants/$mid/settle", []);
check('settlement not repeatable', $admin->has('سفارش تسویه‌نشده‌ای') && (int) $db->query("SELECT COUNT(*) FROM settlements WHERE merchant_id = $mid")->fetchColumn() === 1);
check('merchant payable cleared', $acc('2201') === 0);

$dueId = (int) $db->query("SELECT id FROM installments WHERE loan_id = $loanB ORDER BY seq LIMIT 1")->fetchColumn();
$admin->get('/installments');
$admin->post("/installments/$dueId/note", ['note' => 'تماس گرفته شد', 'promise_date' => '1405/12/10', 'return' => 'unpaid']);
check('collection note saved', $admin->has('پیگیری ثبت شد') && $admin->has('تماس گرفته شد'));
$admin->post("/installments/$dueId/note", ['note' => 'x', 'promise_date' => '', 'return' => 'unpaid']);
check('short note rejected', $admin->has('متن پیگیری را بنویسید'));
$admin->post("/installments/$dueId/note", ['note' => 'تاریخ بد', 'promise_date' => '1405/15/40', 'return' => 'unpaid']);
check('bad promise date rejected', $admin->has('تاریخ قول پرداخت'));

$cashAcc = (int) $db->query("SELECT id FROM accounts WHERE company_id = $dbp AND code = '1101'")->fetchColumn();
$eqAcc = (int) $db->query("SELECT id FROM accounts WHERE company_id = $dbp AND code = '3101'")->fetchColumn();
$admin->get('/journal/create');
$admin->post('/journal', ['entry_date' => '1405/08/10', 'description' => 'افزایش سرمایه', 'status' => 'final', 'account_id' => [(string) $cashAcc, (string) $eqAcc], 'debit' => ['5,000,000', ''], 'credit' => ['', '4,000,000']]);
check('unbalanced final journal rejected', $admin->has('برابر نیست'));
$admin->post('/journal', ['entry_date' => '1405/08/10', 'description' => 'افزایش سرمایه', 'status' => 'final', 'account_id' => [(string) $cashAcc, (string) $eqAcc], 'debit' => ['5,000,000', ''], 'credit' => ['', '5,000,000']]);
check('manual journal saved', $admin->has('سند قطعی ثبت شد') && $admin->has('افزایش سرمایه'));
$admin->post('/journal', ['entry_date' => '1405/15/40', 'status' => 'final', 'description' => 'تاریخ بد', 'account_id' => [(string) $cashAcc, (string) $eqAcc], 'debit' => ['1', ''], 'credit' => ['', '1']]);
check('bad journal date rejected', $admin->has('تاریخ سند'));
$admin->get('/accounts/' . $cashAcc);
check('ledger renders', $admin->status === 200 && $admin->has('دفتر معین'));
check('trial balance balanced', $admin->get('/trial-balance')->has('متوازن') && !$admin->has('نامتوازن'));
$admin->get('/accounts');
$grp1 = (int) $db->query("SELECT id FROM accounts WHERE company_id = $dbp AND code = '1000'")->fetchColumn();
$grp5 = (int) $db->query("SELECT id FROM accounts WHERE company_id = $dbp AND code = '5000'")->fetchColumn();
$admin->post('/accounts', ['parent_id' => (string) $grp1, 'code' => '1101', 'name' => 'تکراری']);
check('duplicate account code rejected', $admin->has('قبلاً تعریف شده'));
$admin->post('/accounts', ['parent_id' => (string) $grp5, 'code' => '5201', 'name' => 'هزینه تبلیغات']);
check('account added', $admin->has('حساب ثبت شد') && $admin->has('هزینه تبلیغات'));

$admin->get('/reports');
check('reports render charts', $admin->has('<svg') && $admin->has('لوازم خانگی آرین'));
$admin->get('/reports/overdue.csv');
check('overdue csv served', $admin->status === 200 && str_starts_with($admin->html, "\xEF\xBB\xBF"));
check('dashboard charts', $admin->get('/dashboard')->has('class="chart"') || $admin->has('class="donut"'));

$pwTmp = new Client($base);
$pwTmp->login('lender1', 'Lender-pass-123');
$pwTmp->get('/account');
$pwTmp->post('/account/password', ['current_password' => 'wrong-pass-123', 'new_password' => 'New-pass-12345', 'confirm_password' => 'New-pass-12345']);
check('wrong current password rejected', $pwTmp->has('رمز عبور فعلی صحیح نیست'));
$pwTmp->post('/account/password', ['current_password' => 'Lender-pass-123', 'new_password' => 'short', 'confirm_password' => 'short']);
check('weak new password rejected', !$pwTmp->has('رمز عبور تغییر کرد'));
$pwTmp->post('/account/password', ['current_password' => 'Lender-pass-123', 'new_password' => 'New-pass-12345', 'confirm_password' => 'New-pass-12345']);
check('password changed', $pwTmp->has('رمز عبور تغییر کرد'));
$relog = new Client($base);
$relog->login('lender1', 'New-pass-12345');
check('login with new password', str_ends_with($relog->get('/dashboard')->url, '/dashboard'));

$lender->get('/journal');
check('lender without accounting.view gets 403', $lender->status === 403);
$lender->post("/merchants/$mid/settle", []);
check('lender cannot settle', $lender->status === 403);

$super->get('/companies');
$super->post("/companies/$tstId/status", []);
$other = new Client($base);
$other->login('tst_admin', 'Tenant-pass-123');
$other->get("/merchants/$mid");
check('tenant isolation: merchant 404', $other->status === 404);
$other->get("/orders/$oidB");
check('tenant isolation: order 404', $other->status === 404);
$other->get("/accounts/$cashAcc");
check('tenant isolation: account 404', $other->status === 404);

// ---------- حسابداری پیشرفته: پیش‌نویس/قطعی، ابطال، سال مالی، درخت حساب‌ها ----------
$net = static fn (string $code) => (int) pdo()->query("SELECT COALESCE(SUM(l.debit - l.credit), 0) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id JOIN accounts a ON a.id = l.account_id WHERE e.status = 'final' AND a.company_id = $dbp AND a.code = '$code'")->fetchColumn();
$lastEntry = static fn () => (int) pdo()->query("SELECT MAX(id) FROM journal_entries WHERE company_id = $dbp")->fetchColumn();
$jv = static fn (array $over) => array_merge(['entry_date' => '1405/08/10', 'description' => 'سند آزمایشی', 'status' => 'draft', 'account_id' => [(string) $cashAcc, (string) $eqAcc], 'debit' => ['1,000', ''], 'credit' => ['', '1,000'], 'line_desc' => ['', '']], $over);

// پیش‌نویس: نامتوازن مجاز، در گزارش‌ها نمی‌آید
$cash0 = $net('1101');
$admin->get('/journal/create');
$admin->post('/journal', $jv(['description' => 'پیش‌نویس ناقص', 'debit' => ['500', ''], 'credit' => ['', '300']]));
check('unbalanced draft saved', $admin->has('سند موقت ذخیره شد'));
$draftId = $lastEntry();
check('draft not counted in reports', $net('1101') === $cash0 && $db->query("SELECT status FROM journal_entries WHERE id = $draftId")->fetchColumn() === 'draft');
$admin->get("/journal/$draftId");
check('draft shows edit/finalize/delete', $admin->has('قطعی‌سازی') && $admin->has('حذف سند موقت') && $admin->has('ویرایش'));
$admin->post("/journal/$draftId/finalize", []);
check('unbalanced draft cannot be finalized', $admin->has('برابر نیست') && $db->query("SELECT status FROM journal_entries WHERE id = $draftId")->fetchColumn() === 'draft');
$admin->get("/journal/$draftId/edit");
check('draft edit form with dynamic editor', $admin->status === 200 && $admin->has('id="jeBody"') && $admin->has('js/pages/accounting.js'));
$admin->post("/journal/$draftId", $jv(['description' => 'پیش‌نویس اصلاح‌شده', 'line_desc' => ['نقد', 'سرمایه'], 'reference' => 'RCT-9']));
check('draft edited', $admin->has('سند موقت ذخیره شد') && $admin->has('پیش‌نویس اصلاح‌شده') && $admin->has('RCT-9') && $admin->has('سرمایه'));
$admin->post("/journal/$draftId/finalize", []);
check('draft finalized and counted', $admin->has('سند قطعی شد') && $net('1101') === $cash0 + 1000);
$admin->post("/journal/$draftId", $jv([]));
check('final entry cannot be edited', $db->query("SELECT description FROM journal_entries WHERE id = $draftId")->fetchColumn() === 'پیش‌نویس اصلاح‌شده');
$admin->post("/journal/$draftId/delete", []);
check('final entry cannot be deleted', (int) $db->query("SELECT COUNT(*) FROM journal_entries WHERE id = $draftId")->fetchColumn() === 1);

// حذف پیش‌نویس
$admin->get('/journal/create');
$admin->post('/journal', $jv(['description' => 'پیش‌نویس حذفی']));
$delId = $lastEntry();
$admin->post("/journal/$delId/delete", []);
check('draft deleted', $admin->has('سند موقت حذف شد') && (int) $db->query("SELECT COUNT(*) FROM journal_entries WHERE id = $delId")->fetchColumn() === 0 && (int) $db->query("SELECT COUNT(*) FROM journal_lines WHERE entry_id = $delId")->fetchColumn() === 0);

// ابطال با سند معکوس
$admin->get("/journal/$draftId");
check('final manual shows reverse form', $admin->has('ابطال با سند معکوس'));
$admin->post("/journal/$draftId/reverse", ['date' => '1405/08/11']);
check('reversal issued', $admin->has('سند معکوس صادر شد') && $net('1101') === $cash0);
$revId = $lastEntry();
check('reversal links', (int) $db->query("SELECT reversed_by FROM journal_entries WHERE id = $draftId")->fetchColumn() === $revId && (int) $db->query("SELECT reversal_of FROM journal_entries WHERE id = $revId")->fetchColumn() === $draftId);
$admin->post("/journal/$draftId/reverse", []);
check('double reversal refused', $admin->has('قبلاً ابطال') && $lastEntry() === $revId);
$admin->get("/journal/$revId");
$admin->post("/journal/$revId/reverse", []);
check('reversal of reversal refused', $admin->has('قبلاً ابطال') || $admin->has('خودش سند ابطال'));
$autoId = (int) $db->query("SELECT id FROM journal_entries WHERE company_id = $dbp AND source_type = 'payment' ORDER BY id LIMIT 1")->fetchColumn();
$admin->get("/journal/$autoId");
$admin->post("/journal/$autoId/reverse", []);
check('auto entry cannot be reversed', $admin->has('اسناد خودکار') && $lastEntry() === $revId);
$admin->post("/journal/$autoId/delete", []);
check('auto entry cannot be deleted', (int) $db->query("SELECT COUNT(*) FROM journal_entries WHERE id = $autoId")->fetchColumn() === 1);

// حساب‌های درختی
$treeTotal = static fn (string $code) => $code;
$admin->get('/accounts');
check('accounts tree shows groups', $admin->has('دارایی‌ها') && $admin->has('tree__group'));
$admin->get('/journal/create');
$admin->post('/journal', $jv(['status' => 'final', 'account_id' => [(string) $grp1, (string) $eqAcc]]));
check('posting to group account refused', $admin->has('روی حساب گروه'));
$admin->get('/accounts');
$admin->post('/accounts', ['parent_id' => (string) $grp5, 'code' => '5301', 'name' => 'هزینه موقت']);
$tmpAcc = (int) $db->query("SELECT id FROM accounts WHERE company_id = $dbp AND code = '5301'")->fetchColumn();
check('child account created with inherited type', $db->query("SELECT type FROM accounts WHERE id = $tmpAcc")->fetchColumn() === 'expense');
$admin->get("/accounts/$tmpAcc/edit");
check('account edit form', $admin->status === 200 && $admin->has('هزینه موقت'));
$admin->post("/accounts/$tmpAcc", ['code' => '5301', 'name' => 'هزینه موقت (ویرایش)', 'parent_id' => (string) $grp5]);
check('account edited, deactivated', $admin->has('حساب ذخیره شد') && (int) $db->query("SELECT is_active FROM accounts WHERE id = $tmpAcc")->fetchColumn() === 0 && $db->query("SELECT name FROM accounts WHERE id = $tmpAcc")->fetchColumn() === 'هزینه موقت (ویرایش)');
$admin->get('/journal/create');
$admin->post('/journal', $jv(['status' => 'final', 'account_id' => [(string) $tmpAcc, (string) $eqAcc]]));
check('posting to inactive account refused', $admin->has('غیرفعال'));
$admin->get("/accounts/$tmpAcc/edit");
$admin->post("/accounts/$tmpAcc", ['code' => '5301', 'name' => 'هزینه موقت', 'parent_id' => (string) $grp1, 'is_active' => '1']);
check('parent of other type refused', $admin->has('نوع حساب والد'));
$admin->get("/accounts/$grp5/edit");
$admin->post("/accounts/$grp5", ['code' => '5000', 'name' => 'هزینه‌ها', 'parent_id' => (string) $tmpAcc, 'is_active' => '1']);
check('account cannot become its own descendant', (int) $db->query("SELECT COALESCE(parent_id, 0) FROM accounts WHERE id = $grp5")->fetchColumn() === 0);
$admin->get("/accounts/$cashAcc/edit");
$admin->post("/accounts/$cashAcc", ['code' => '9999', 'name' => 'صندوق و بانک', 'parent_id' => (string) $grp1, 'is_active' => '0']);
check('system account code/active immutable', $db->query("SELECT code FROM accounts WHERE id = $cashAcc")->fetchColumn() === '1101' && (int) $db->query("SELECT is_active FROM accounts WHERE id = $cashAcc")->fetchColumn() === 1);
$other->get('/dashboard');
$other->get("/accounts/$tmpAcc/edit");
check('tenant isolation: account edit 404', $other->status === 404);
$other->get("/journal/$revId");
check('tenant isolation: journal 404', $other->status === 404);
$other->post("/journal/$revId/reverse", []);
check('tenant isolation: reverse 404', $other->status === 404);

// سال مالی
$admin->get('/fiscal-years');
check('fiscal years page', $admin->status === 200 && $admin->has('سال مالی 1405'));
$admin->get('/journal/create');
$admin->post('/journal', $jv(['entry_date' => '1404/06/15', 'status' => 'draft', 'description' => 'پیش‌نویس سال قبل']));
$oldDraft = $lastEntry();
$fy1404 = (int) $db->query("SELECT id FROM fiscal_years WHERE company_id = $dbp AND title = 'سال مالی 1404'")->fetchColumn();
check('fiscal year auto-created for entry date', $fy1404 > 0);
$admin->get('/fiscal-years');
$admin->post("/fiscal-years/$fy1404/close", []);
check('year with drafts cannot close', $admin->has('سند موقت') && $db->query("SELECT status FROM fiscal_years WHERE id = $fy1404")->fetchColumn() === 'open');
$admin->get("/journal/$oldDraft");
$admin->post("/journal/$oldDraft/delete", []);
$admin->get('/journal/create');
$admin->post('/journal', $jv(['entry_date' => '1404/06/15', 'status' => 'final', 'description' => 'افتتاحیه سال قبل', 'debit' => ['7,000', ''], 'credit' => ['', '7,000']]));
check('entry in previous year saved', $admin->has('سند قطعی ثبت شد'));
$admin->get('/fiscal-years');
$admin->post("/fiscal-years/$fy1404/close", []);
check('year closed', $admin->has('بسته شد') && $db->query("SELECT status FROM fiscal_years WHERE id = $fy1404")->fetchColumn() === 'closed');
$admin->get('/journal/create');
$admin->post('/journal', $jv(['entry_date' => '1404/07/01', 'status' => 'final']));
check('posting into closed year refused', $admin->has('بسته است') && (int) $db->query("SELECT COUNT(*) FROM journal_entries WHERE company_id = $dbp AND entry_date >= '2025-09-23' AND entry_date <= '2025-09-24'")->fetchColumn() === 0);
$admin->post('/journal', $jv(['entry_date' => '1404/07/01', 'status' => 'draft']));
check('draft into closed year refused', $admin->has('بسته است'));
$admin->get('/fiscal-years');
$admin->post("/fiscal-years/$fy1404/reopen", []);
check('year reopened', $admin->has('بازگشایی شد') && $db->query("SELECT status FROM fiscal_years WHERE id = $fy1404")->fetchColumn() === 'open');
$admin->post("/fiscal-years/$fy1404/close", []);
$admin->post('/fiscal-years', []);
check('next fiscal year created', $admin->has('ایجاد شد') && (int) $db->query("SELECT COUNT(*) FROM fiscal_years WHERE company_id = $dbp AND title = 'سال مالی 1406'")->fetchColumn() === 1);
$lender->get('/fiscal-years');
check('lender cannot view fiscal years (403)', $lender->status === 403);

// گزارش‌ها: تراز با مانده اول دوره، دفتر با بازه، CSV
$start1405 = (string) $db->query("SELECT start_date FROM fiscal_years WHERE company_id = $dbp AND title = 'سال مالی 1405'")->fetchColumn();
$expOpen = (int) $db->query("SELECT COALESCE(SUM(l.debit - l.credit), 0) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final' AND e.company_id = $dbp AND l.account_id = $cashAcc AND e.entry_date < '$start1405'")->fetchColumn();
check('previous-year entry exists for opening balance', $expOpen === 7000);
$admin->get('/trial-balance?from=1405/01/01&to=1405/12/29');
check('trial six-column page', $admin->has('مانده اول دوره') && $admin->has('گردش دوره') && $admin->has('متوازن') && !$admin->has('نامتوازن'));
$admin->get('/trial-balance?from=1405/01/01&to=1405/12/29&format=csv');
check('trial csv', $admin->status === 200 && str_starts_with($admin->html, "\xEF\xBB\xBF") && str_contains($admin->html, '1101,'));
preg_match('/^1101,[^,\n]*,(-?\d+),/m', $admin->html, $m);
check('trial opening for cash = 7000', (int) ($m[1] ?? -1) === 7000, $m[0] ?? 'no row');
$admin->get("/accounts/$cashAcc?from=1405/01/01&to=1405/12/29");
check('ledger with period + opening balance', $admin->has('مانده اول دوره') && $admin->has('۷,۰۰۰'));
$admin->get("/accounts/$cashAcc?from=1405/01/01&to=1405/12/29&format=csv");
check('ledger csv', $admin->status === 200 && str_starts_with($admin->html, "\xEF\xBB\xBF"));
$admin->get("/accounts/$grp1");
check('group ledger includes children', $admin->status === 200 && $admin->has('شامل زیرمجموعه'));
$admin->get('/accounts/' . $cashAcc . '?from=1405/12/01&to=1405/01/01');
check('bad period reported', $admin->has('نباید بعد از'));

// فیلتر پیشرفته اسناد
$admin->get('/journal?q=' . urlencode('افزایش سرمایه'));
check('journal text search', $admin->has('افزایش سرمایه') && !$admin->has('افتتاحیه سال قبل'));
$admin->get('/journal?min=4,000,000&max=6,000,000');
check('journal amount range', $admin->has('افزایش سرمایه') && !$admin->has('افتتاحیه سال قبل'));
$admin->get('/journal?min=900,000,000');
check('journal empty result', $admin->has('سندی با این فیلترها یافت نشد'));
$admin->get('/journal?from=1404/01/01&to=1404/12/29');
check('journal date range', $admin->has('افتتاحیه سال قبل') && !$admin->has('افزایش سرمایه'));
$n1 = (int) $db->query("SELECT entry_no FROM journal_entries WHERE company_id = $dbp ORDER BY id LIMIT 1")->fetchColumn();
$admin->get("/journal?no_from=$n1&no_to=$n1");
check('journal number range (single entry)', $admin->has('۱ سند'));
$admin->get('/journal?source=auto');
check('journal auto filter', $admin->has('خودکار') && !$admin->has('افزایش سرمایه'));
$admin->get('/journal?sort=amount&dir=asc&format=csv');
$rowsCsv = array_slice(str_getcsv_all($admin->html), 1);
$amts = array_map(static fn ($r) => (int) end($r), $rowsCsv);
$sorted = $amts;
sort($sorted);
check('journal csv sorted by amount asc', $amts === $sorted && count($amts) > 5);
$admin->get('/journal?status=draft');
check('journal draft tab', $admin->status === 200);
$admin->get('/journal?from=bad');
check('journal bad filter date reported', $admin->has('تاریخ فیلتر'));
$admin->get('/journal?q=' . urlencode('%_!'));
check('journal LIKE wildcards escaped', $admin->status === 200 && $admin->has('سندی با این فیلترها یافت نشد'));
check('new audit actions', (int) $db->query("SELECT COUNT(DISTINCT action) FROM audit_logs WHERE action IN ('journal.finalize','journal.delete_draft','journal.reverse','journal.update','fiscal.close','fiscal.reopen','fiscal.create','account.update')")->fetchColumn() === 8);

// ---------- تسویه زودهنگام و صورت‌های مالی ----------
$admin->get("/loans/$loanB");
check('payoff box shown', $admin->has('تسویه زودهنگام'));
$sumRem = (int) $db->query("SELECT SUM(amount - paid_amount) FROM installments WHERE loan_id = $loanB")->fetchColumn();
$princRem = (int) $db->query("SELECT SUM(principal_part) FROM installments WHERE loan_id = $loanB")->fetchColumn();
$lender->get("/loans/$loanB");
$lender->post("/loans/$loanB/payoff", ['method' => 'cash']);
check('lender cannot payoff', $lender->status === 403);
$other->get('/dashboard');
$other->post("/loans/$loanB/payoff", ['method' => 'cash']);
check('tenant isolation: payoff', in_array($other->status, [403, 404], true) && $db->query("SELECT status FROM loans WHERE id = $loanB")->fetchColumn() === 'active');
$w0 = $wallet2();
$admin->get("/loans/$loanB");
$admin->post("/loans/$loanB/payoff", ['method' => 'wallet']);
check('payoff succeeded', $admin->has('تسویه شد'));
$paidNow = $w0 - $wallet2();
check('payoff = remaining principal (future interest waived)', $paidNow === $princRem && $paidNow < $sumRem, "paid=$paidNow princ=$princRem sum=$sumRem");
check('loan closed, installments paid', $db->query("SELECT status FROM loans WHERE id = $loanB")->fetchColumn() === 'closed' && (int) $db->query("SELECT COUNT(*) FROM installments WHERE loan_id = $loanB AND status <> 'paid'")->fetchColumn() === 0);
$admin->post("/loans/$loanB/payoff", ['method' => 'wallet']);
check('payoff not repeatable', $admin->has('فعال نیست') && $w0 - $wallet2() === $paidNow);
check('payoff audited', (int) $db->query("SELECT COUNT(*) FROM audit_logs WHERE action = 'loan.payoff'")->fetchColumn() >= 1);

// ---------- جریمه تأخیر ----------
$admin->get('/plans/create');
$admin->post('/plans', ['name' => 'جریمه زیاد', 'months' => '3', 'annual_rate_percent' => '10', 'fee_percent' => '0', 'late_fee_daily_percent' => '9', 'min_amount' => '1,000,000', 'max_amount' => '5,000,000', 'is_active' => '1']);
check('late fee percent > 5 rejected', $admin->has('جریمه تأخیر روزانه'));
$lender->get('/loans/create');
$lender->post('/loans', ['customer_id' => (string) $cid2, 'plan_id' => (string) $planId, 'amount' => '5,000,000']);
$loanL = (int) $db->query('SELECT MAX(id) FROM loans')->fetchColumn();
$second->get("/loans/$loanL");
$second->post("/loans/$loanL/approve", []);
check('late-fee loan active', $db->query("SELECT status FROM loans WHERE id = $loanL")->fetchColumn() === 'active');
$db->exec("UPDATE loans SET late_fee_daily_percent = 0.5 WHERE id = $loanL");
$lateInst = (int) $db->query("SELECT id FROM installments WHERE loan_id = $loanL AND status <> 'paid' ORDER BY seq LIMIT 1")->fetchColumn();
$db->exec("UPDATE installments SET due_date = '" . date('Y-m-d', strtotime('-10 days')) . "' WHERE id = $lateInst");
$remLate = (int) $db->query("SELECT amount - paid_amount FROM installments WHERE id = $lateInst")->fetchColumn();
$lender->get('/installments');
$lender->post('/installments/accrue-fees', []);
check('lender cannot accrue fees', $lender->status === 403);
$admin->get('/installments?filter=overdue');
$admin->post('/installments/accrue-fees', []);
$fee1 = (int) $db->query("SELECT late_fee_accrued FROM installments WHERE id = $lateInst")->fetchColumn();
check('late fee = remaining x 0.5% x 10 days', $fee1 === (int) round($remLate * 0.005 * 10) && $fee1 > 0, "fee=$fee1 rem=$remLate");
check('accrual flash shown', $admin->has('جریمه تأخیر برای'));
$admin->post('/installments/accrue-fees', []);
check('accrual idempotent same day', (int) $db->query("SELECT late_fee_accrued FROM installments WHERE id = $lateInst")->fetchColumn() === $fee1 && $admin->has('جریمه جدیدی'));
check('late fee visible in list', $admin->get('/installments?filter=overdue')->has('دریافت'));
$admin->post("/installments/$lateInst/late-fee", ['method' => 'cash', 'return' => 'overdue']);
check('late fee received', $admin->has('دریافت شد') && (int) $db->query("SELECT late_fee_paid FROM installments WHERE id = $lateInst")->fetchColumn() === $fee1);
check('late fee income posted', $acc('4103') === $fee1);
$admin->post("/installments/$lateInst/late-fee", ['method' => 'cash', 'return' => 'overdue']);
check('late fee not receivable twice', $admin->has('جریمه‌ای برای دریافت وجود ندارد') && $acc('4103') === $fee1);
$db->exec("UPDATE installments SET late_fee_until = '" . date('Y-m-d', strtotime('-5 days')) . "' WHERE id = $lateInst");
$admin->post('/installments/accrue-fees', []);
$fee2 = (int) $db->query("SELECT late_fee_accrued FROM installments WHERE id = $lateInst")->fetchColumn();
check('second accrual continues from last date', $fee2 === $fee1 + (int) round($remLate * 0.005 * 5), "fee2=$fee2");
$other->get('/dashboard');
$other->post("/installments/$lateInst/late-fee", ['method' => 'cash']);
check('tenant isolation: late fee 404', $other->status === 404);
$outstandingFee = $fee2 - $fee1;
$admin->get("/loans/$loanL");
$admin->post("/loans/$loanL/payoff", ['method' => 'cash']);
check('payoff includes outstanding late fee', $admin->has('تسویه شد') && $acc('4103') === $fee2 && (int) $db->query("SELECT SUM(late_fee_paid - late_fee_accrued) FROM installments WHERE loan_id = $loanL")->fetchColumn() === 0, 'income=' . $acc('4103') . " expected=$fee2");

$admin->get('/statements');
check('statements page', $admin->status === 200 && $admin->has('ترازنامه') && $admin->has('صورت سود و زیان') && $admin->has('متوازن') && !$admin->has('نامتوازن'));
$admin->get('/statements?from=1405/12/01&to=1405/01/01');
check('statements bad range reported', $admin->has('نباید بعد از'));
check('statements in menu', $admin->has('/statements'));

check('total debits = total credits (final entries)', (int) $db->query("SELECT SUM(l.debit) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final'")->fetchColumn() === (int) $db->query("SELECT SUM(l.credit) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final'")->fetchColumn());
check('wallet liability account = sum of wallets', (int) $db->query("SELECT COALESCE(SUM(l.credit - l.debit),0) FROM journal_lines l JOIN accounts a ON a.id = l.account_id WHERE a.code = '2101'")->fetchColumn() === (int) $db->query('SELECT SUM(wallet_balance) FROM customers')->fetchColumn());
check('loans receivable account = outstanding principal', (int) $db->query("SELECT COALESCE(SUM(l.debit - l.credit),0) FROM journal_lines l JOIN accounts a ON a.id = l.account_id WHERE a.code = '1201'")->fetchColumn() === (int) $db->query('SELECT COALESCE(SUM(principal_part - CASE WHEN paid_amount - interest_part > 0 THEN paid_amount - interest_part ELSE 0 END), 0) FROM installments')->fetchColumn());
check('no negative stock', (int) $db->query('SELECT COUNT(*) FROM products WHERE stock < 0')->fetchColumn() === 0);
check('every final entry balanced', (int) $db->query("SELECT COUNT(*) FROM (SELECT l.entry_id FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final' GROUP BY l.entry_id HAVING SUM(l.debit) <> SUM(l.credit))")->fetchColumn() === 0);

// ---------- سند اختتامیه ----------
$fyNow = (int) pdo()->query("SELECT id FROM fiscal_years WHERE company_id = $dbp AND status = 'open' AND start_date <= '" . date('Y-m-d') . "' AND end_date >= '" . date('Y-m-d') . "'")->fetchColumn();
$plNet = fn (): int => (int) pdo()->query("SELECT COALESCE(SUM(l.credit - l.debit),0) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id JOIN accounts a ON a.id = l.account_id WHERE e.company_id = $dbp AND e.status = 'final' AND a.type IN ('revenue','expense')")->fetchColumn();
$profitBefore = $plNet();
check('there is profit/loss to close', $profitBefore !== 0, "p=$profitBefore");
$admin->get('/fiscal-years');
check('fiscal page offers closing', $admin->has('سند اختتامیه'));
$other->get('/dashboard');
$other->post("/fiscal-years/$fyNow/closing", []);
check('tenant isolation: closing 404', $other->status === 404);
$admin->get('/fiscal-years');
$admin->post("/fiscal-years/$fyNow/closing", []);
check('closing entry issued', $admin->has('سند اختتامیه صادر شد') && (int) pdo()->query("SELECT COUNT(*) FROM journal_entries WHERE company_id = $dbp AND source_type = 'closing' AND reversed_by IS NULL")->fetchColumn() === 1);
check('revenue/expense zeroed after closing', $plNet() === 0);
$retained = (int) pdo()->query("SELECT COALESCE(SUM(l.credit - l.debit),0) FROM journal_lines l JOIN accounts a ON a.id = l.account_id WHERE a.company_id = $dbp AND a.code = '3102'")->fetchColumn();
check('retained earnings = year profit', $retained === $profitBefore, "r=$retained p=$profitBefore");
$admin->get('/statements');
check('statements balanced after closing', $admin->status === 200 && $admin->has('متوازن') && !$admin->has('نامتوازن'));
$admin->get('/fiscal-years');
$admin->post("/fiscal-years/$fyNow/closing", []);
check('second closing rejected', $admin->has('قبلاً سند اختتامیه صادر شده'));
$closingId = (int) pdo()->query("SELECT id FROM journal_entries WHERE company_id = $dbp AND source_type = 'closing' AND reversed_by IS NULL")->fetchColumn();
$admin->get("/journal/$closingId");
$admin->post("/journal/$closingId/reverse", ['date' => '']);
check('closing doc cannot be reversed manually', $admin->has('اسناد خودکار'));
$admin->get('/fiscal-years');
$admin->post("/fiscal-years/$fyNow/closing/undo", []);
check('closing undone with mirror entry', $admin->has('سند اختتامیه ابطال شد') && $plNet() === $profitBefore && (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action IN ('fiscal.closing','fiscal.closing_undo')")->fetchColumn() === 2);
check('every final entry still balanced after closing cycle', (int) pdo()->query("SELECT COUNT(*) FROM (SELECT l.entry_id FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final' GROUP BY l.entry_id HAVING SUM(l.debit) <> SUM(l.credit))")->fetchColumn() === 0);

// ---------- ابزارهای کارشناسی: فیلتر، مرتب‌سازی، خروجی، تغییر وضعیت ----------
$admin->get('/customers?status=blocked');
check('customers filter blocked: none yet', $admin->status === 200 && $admin->has('مشتری‌ای یافت نشد'));
$admin->get('/customers?q=%25');
check('customers LIKE wildcard escaped', $admin->has('مشتری‌ای یافت نشد'));
$admin->get('/customers?credit_min=1&sort=credit&dir=asc');
check('customers credit filter + sort', $admin->status === 200 && $admin->has('sort-link') && !$admin->has('مشتری‌ای یافت نشد'));
$admin->get('/customers?from=garbage');
check('customers bad date reported', $admin->has('تاریخ فیلتر باید شمسی'));
$admin->get('/customers?overdue=1&debt_min=1');
check('customers overdue + debt filters render', $admin->status === 200);
$admin->get('/customers?format=csv');
$hdr = str_getcsv_all($admin->html);
check('customers csv export', str_starts_with($admin->html, "\xEF\xBB\xBF") && ($hdr[0][0] ?? '') === 'نام' && count($hdr) >= 2);
check('csv export audited', (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action = 'report.export'")->fetchColumn() >= 1);

$admin->get("/customers/$customerId");
check('customer 360 sections', $admin->has('مانده اقساط جاری') && $admin->has('آخرین سفارش‌ها') && $admin->has('یادداشت‌های وصول') && $admin->has('وضعیت و تاریخچه'));
$admin->post("/customers/$customerId/status", ['to_status' => 'blocked', 'reason' => 'کم']);
check('status change needs a reason', $admin->has('دلیل تغییر وضعیت') && pdo()->query("SELECT status FROM customers WHERE id = $customerId")->fetchColumn() === 'active');
$admin->get("/customers/$customerId");
$admin->post("/customers/$customerId/status", ['to_status' => 'bogus', 'reason' => 'دلیل معتبر است']);
check('invalid target status rejected', $admin->has('وضعیت مقصد معتبر نیست'));
$admin->get("/customers/$customerId");
$admin->post("/customers/$customerId/status", ['to_status' => 'blocked', 'reason' => 'عدم پرداخت اقساط سررسیدشده']);
check('customer blocked with reason', $admin->has('وضعیت مشتری تغییر کرد') && $admin->has('عدم پرداخت اقساط سررسیدشده') && pdo()->query("SELECT status FROM customers WHERE id = $customerId")->fetchColumn() === 'blocked');
check('status history + audit stored', (int) pdo()->query("SELECT COUNT(*) FROM status_history WHERE entity = 'customer' AND entity_id = $customerId AND from_status = 'active' AND to_status = 'blocked'")->fetchColumn() === 1
    && (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action = 'customer.status'")->fetchColumn() === 1);
$admin->post("/customers/$customerId/status", ['to_status' => 'blocked', 'reason' => 'دوباره همان وضعیت']);
check('same status rejected', $admin->has('وضعیت فعلی همین است'));
$admin->get('/customers?status=blocked');
check('customers filter blocked finds it', !$admin->has('مشتری‌ای یافت نشد'));
$admin->get("/customers/$customerId/edit");
$admin->post("/customers/$customerId", ['full_name' => 'تست ویرایش', 'mobile' => '09121112233', 'credit_limit' => '5,000,000', 'status' => 'active']);
check('edit form cannot bypass status workflow', pdo()->query("SELECT status FROM customers WHERE id = $customerId")->fetchColumn() === 'blocked');
$admin->get("/customers/$customerId");
$admin->post("/customers/$customerId/status", ['to_status' => 'active', 'reason' => 'تسویه بدهی انجام شد']);
check('customer unblocked, history has 2 rows', (int) pdo()->query("SELECT COUNT(*) FROM status_history WHERE entity = 'customer' AND entity_id = $customerId")->fetchColumn() === 2);
$other->get('/dashboard');
$other->post("/customers/$customerId/status", ['to_status' => 'blocked', 'reason' => 'تلاش بین مستأجری']);
check('tenant isolation: status change 404', $other->status === 404);

$admin->get("/merchants/$mid");
$admin->post("/merchants/$mid/status", ['to_status' => 'disabled', 'reason' => 'بررسی مدارک فروشنده']);
check('merchant disabled with reason', pdo()->query("SELECT status FROM merchants WHERE id = $mid")->fetchColumn() === 'disabled' && $admin->has('بررسی مدارک فروشنده'));
$admin->get("/merchants/$mid");
$admin->post("/merchants/$mid/status", ['to_status' => 'active', 'reason' => 'مدارک تکمیل شد']);
check('merchant re-enabled', pdo()->query("SELECT status FROM merchants WHERE id = $mid")->fetchColumn() === 'active');
$admin->get('/merchants?status=active&sort=unsettled&dir=desc');
check('merchants filter/sort', $admin->status === 200 && $admin->has('sort-link'));
$admin->get('/merchants?format=csv');
check('merchants csv', str_starts_with($admin->html, "\xEF\xBB\xBF"));

foreach (['/loans' => 'loans', '/orders' => 'orders', '/installments?filter=all' => 'installments', '/audit' => 'audit'] as $u => $name) {
    $sep = str_contains($u, '?') ? '&' : '?';
    $admin->get($u . $sep . 'format=csv');
    $rowsCsv = str_getcsv_all($admin->html);
    check("$name csv export", $admin->status === 200 && str_starts_with($admin->html, "\xEF\xBB\xBF") && count($rowsCsv) >= 2, 'rows=' . count($rowsCsv));
    $admin->get($u . $sep . 'from=1300/01/01&to=1301/01/01');
    check("$name date filter excludes all", $admin->status === 200 && !$admin->has('جمع مبلغ: ۱') );
    $admin->get($u . $sep . 'from=oops');
    check("$name bad date reported", $admin->has('تاریخ فیلتر باید شمسی'));
}
$admin->get('/loans?status=active&min=1&sort=amount&dir=desc');
check('loans filters', $admin->status === 200 && $admin->has('جمع مبلغ'));
$admin->get('/orders?payment_type=installment&status=confirmed&merchant_id=' . $mid);
check('orders filters', $admin->status === 200 && $admin->has('جمع مبلغ'));
$admin->get('/installments?filter=overdue&q=%25');
check('installments LIKE escaped', $admin->has('موردی یافت نشد'));
$admin->get('/audit?q=customer.status');
check('audit search finds status change', $admin->has('customer.status'));
$admin->get('/audit?entity=customer&user_id=' . (int) pdo()->query("SELECT id FROM users WHERE username = 'admin1' OR 1=1 ORDER BY id LIMIT 1")->fetchColumn());
check('audit entity/user filters render', $admin->status === 200);

// ---------- یادداشت، تاریخچه تغییرات، موجودی، وضعیت‌ها، عملیات گروهی ----------
$admin->get("/customers/$customerId");
$admin->post('/notes', ['entity' => 'customer', 'entity_id' => (string) $customerId, 'body' => 'مشتری درخواست مهلت دو هفته‌ای داد']);
check('note added', $admin->has('یادداشت ثبت شد') && $admin->has('مشتری درخواست مهلت دو هفته‌ای داد'));
$admin->post('/notes', ['entity' => 'customer', 'entity_id' => (string) $customerId, 'body' => 'x']);
check('short note rejected', $admin->has('بین ۳ تا ۲۰۰۰'));
$noteId = (int) pdo()->query("SELECT id FROM entity_notes WHERE entity = 'customer' AND entity_id = $customerId ORDER BY id DESC LIMIT 1")->fetchColumn();
$admin->get("/customers/$customerId");
$admin->post("/notes/$noteId", ['body' => 'مهلت تا پایان ماه تمدید شد']);
check('note edited by author', $admin->has('یادداشت ویرایش شد') && $admin->has('مهلت تا پایان ماه تمدید شد'));
$admin->post("/notes/$noteId/pin", []);
check('note pinned', (int) pdo()->query("SELECT pinned FROM entity_notes WHERE id = $noteId")->fetchColumn() === 1);
$lender->get("/customers/$customerId");
$lender->post("/notes/$noteId", ['body' => 'تلاش ویرایش توسط دیگری']);
check('only author may edit note', $lender->has('فقط نویسنده') && pdo()->query("SELECT body FROM entity_notes WHERE id = $noteId")->fetchColumn() === 'مهلت تا پایان ماه تمدید شد');
$lender->post("/notes/$noteId/delete", []);
check('only author may delete note', $lender->has('فقط نویسنده') && (int) pdo()->query("SELECT COUNT(*) FROM entity_notes WHERE id = $noteId")->fetchColumn() === 1);
$other->get('/dashboard');
$other->post("/notes/$noteId/pin", []);
check('tenant isolation: note 404/err', (int) pdo()->query("SELECT pinned FROM entity_notes WHERE id = $noteId")->fetchColumn() === 1);
$other->post('/notes', ['entity' => 'customer', 'entity_id' => (string) $customerId, 'body' => 'نفوذ بین مستأجری']);
check('tenant isolation: cannot add note to foreign entity', (int) pdo()->query("SELECT COUNT(*) FROM entity_notes WHERE body = 'نفوذ بین مستأجری'")->fetchColumn() === 0);
$admin->get("/customers/$customerId");
$admin->post("/notes/$noteId/delete", []);
check('note deleted by author', (int) pdo()->query("SELECT COUNT(*) FROM entity_notes WHERE id = $noteId")->fetchColumn() === 0);

$admin->get("/customers/$customerId/edit");
$admin->post("/customers/$customerId", ['full_name' => 'نام جدید مشتری', 'mobile' => '09129998877', 'credit_limit' => '7,000,000']);
$admin->get("/customers/$customerId");
check('field-level change history shown', $admin->has('تاریخچه تغییرات') && $admin->has('سقف اعتبار') && $admin->has('نام جدید مشتری') && $admin->has('class="change__old"'));

$pid = (int) pdo()->query("SELECT id FROM products WHERE company_id = $dbp ORDER BY id LIMIT 1")->fetchColumn();
$stock0 = (int) pdo()->query("SELECT stock FROM products WHERE id = $pid")->fetchColumn();
$admin->get("/products/$pid/edit");
check('product page has stock/status/notes panels', $admin->has('موجودی و حرکت کالا') && $admin->has('وضعیت و تاریخچه') && $admin->has('یادداشت‌های داخلی'));
$admin->post("/products/$pid/stock", ['mode' => 'add', 'qty' => '10', 'reason' => 'ورود کالا']);
check('stock add with reason', (int) pdo()->query("SELECT stock FROM products WHERE id = $pid")->fetchColumn() === $stock0 + 10 && $admin->has('موجودی تعدیل شد'));
$admin->post("/products/$pid/stock", ['mode' => 'remove', 'qty' => '999999', 'reason' => 'تست منفی']);
check('stock cannot go negative', $admin->has('منفی') && (int) pdo()->query("SELECT stock FROM products WHERE id = $pid")->fetchColumn() === $stock0 + 10);
$admin->post("/products/$pid/stock", ['mode' => 'set', 'qty' => '7', 'reason' => '']);
check('stock needs reason', $admin->has('دلیل تعدیل') && (int) pdo()->query("SELECT stock FROM products WHERE id = $pid")->fetchColumn() === $stock0 + 10);
$admin->post("/products/$pid/stock", ['mode' => 'set', 'qty' => '7', 'reason' => 'شمارش انبار']);
check('stock set by count + movements logged', (int) pdo()->query("SELECT stock FROM products WHERE id = $pid")->fetchColumn() === 7 && (int) pdo()->query("SELECT COUNT(*) FROM stock_movements WHERE product_id = $pid AND kind IN ('add','set')")->fetchColumn() >= 2);
check('movement balance chain consistent', (int) pdo()->query("SELECT balance_after FROM stock_movements WHERE product_id = $pid ORDER BY id DESC LIMIT 1")->fetchColumn() === 7);
check('order stock movements recorded', (int) pdo()->query("SELECT COUNT(*) FROM stock_movements WHERE kind = 'order'")->fetchColumn() > 0);
$admin->post("/products/$pid/status", ['to_status' => 'disabled', 'reason' => 'توقف عرضه موقت']);
check('product disabled with reason', pdo()->query("SELECT status FROM products WHERE id = $pid")->fetchColumn() === 'disabled');
$admin->get("/products/$pid/edit");
$admin->post("/products/$pid", ['name' => 'نام جدید محصول', 'sku' => 'SKU-1', 'price' => '1,234,000', 'stock' => '999', 'status' => 'active']);
check('product edit cannot change stock/status', (int) pdo()->query("SELECT stock FROM products WHERE id = $pid")->fetchColumn() === 7 && pdo()->query("SELECT status FROM products WHERE id = $pid")->fetchColumn() === 'disabled');
$admin->get("/products/$pid/edit");
$admin->post("/products/$pid/status", ['to_status' => 'active', 'reason' => 'عرضه مجدد']);
$admin->get('/products?status=active&sort=stock&dir=asc');
check('products filters render', $admin->status === 200 && $admin->has('sort-link'));
$admin->get('/products?stock=low&min=1');
check('products stock filter renders', $admin->status === 200);
$admin->get('/products?format=csv');
check('products csv', str_starts_with($admin->html, "\xEF\xBB\xBF"));

$admin->get('/customers');
$cust2 = (int) pdo()->query("SELECT id FROM customers WHERE company_id = $dbp AND id <> $customerId ORDER BY id LIMIT 1")->fetchColumn();
$admin->post('/customers/bulk-status', ['ids' => [(string) $customerId, (string) $cust2], 'to_status' => 'blocked', 'reason' => 'بازبینی گروهی مدارک']);
check('bulk block customers', pdo()->query("SELECT COUNT(*) FROM customers WHERE id IN ($customerId, $cust2) AND status = 'blocked'")->fetchColumn() == 2 && (int) pdo()->query("SELECT COUNT(*) FROM status_history WHERE reason = 'بازبینی گروهی مدارک'")->fetchColumn() === 2);
$admin->get('/customers');
$admin->post('/customers/bulk-status', ['ids' => [(string) $customerId, (string) $cust2], 'to_status' => 'blocked', 'reason' => 'دوباره همان']);
check('bulk skips unchanged with report', $admin->has('ردشده'));
$admin->get('/customers');
$admin->post('/customers/bulk-status', ['ids' => [(string) $customerId], 'to_status' => 'active', 'reason' => 'x']);
check('bulk needs a real reason', $admin->has('دلیل تغییر وضعیت'));
$admin->get('/customers');
$admin->post('/customers/bulk-status', ['ids' => [], 'to_status' => 'active', 'reason' => 'دلیل معتبر است']);
check('bulk needs selection', $admin->has('هیچ موردی انتخاب نشده'));
$admin->get('/customers');
$admin->post('/customers/bulk-status', ['ids' => [(string) $customerId, (string) $cust2], 'to_status' => 'active', 'reason' => 'اتمام بازبینی']);
check('bulk unblock', pdo()->query("SELECT COUNT(*) FROM customers WHERE id IN ($customerId, $cust2) AND status = 'active'")->fetchColumn() == 2);
$other->get('/dashboard');
$other->post('/customers/bulk-status', ['ids' => [(string) $customerId], 'to_status' => 'blocked', 'reason' => 'تلاش بین مستأجری']);
check('tenant isolation: bulk status', pdo()->query("SELECT status FROM customers WHERE id = $customerId")->fetchColumn() === 'active');
$admin->get('/merchants');
$admin->post('/merchants/bulk-status', ['ids' => [(string) $mid], 'to_status' => 'disabled', 'reason' => 'بازبینی گروهی فروشندگان']);
$admin->get('/merchants');
$admin->post('/merchants/bulk-status', ['ids' => [(string) $mid], 'to_status' => 'active', 'reason' => 'پایان بازبینی فروشندگان']);
check('bulk merchants round trip', pdo()->query("SELECT status FROM merchants WHERE id = $mid")->fetchColumn() === 'active' && (int) pdo()->query("SELECT COUNT(*) FROM status_history WHERE entity = 'merchant' AND entity_id = $mid")->fetchColumn() >= 4);

$lid = (int) pdo()->query("SELECT id FROM users WHERE username = 'lender1'")->fetchColumn();
$admin->get("/users/$lid/edit");
$admin->post("/users/$lid/status", ['to_status' => 'disabled', 'reason' => 'مرخصی طولانی']);
check('user disabled with reason', pdo()->query("SELECT status FROM users WHERE id = $lid")->fetchColumn() === 'disabled');
$lenderTry = new Client($base);
$lenderTry->login('lender1', 'New-pass-12345');
check('disabled user cannot log in', !$lenderTry->has('داشبورد'));
$admin->get("/users/$lid/edit");
$admin->post("/users/$lid/status", ['to_status' => 'active', 'reason' => 'بازگشت از مرخصی']);
check('user re-enabled', pdo()->query("SELECT status FROM users WHERE id = $lid")->fetchColumn() === 'active');
$meId = (int) pdo()->query("SELECT id FROM users WHERE username = 'dbp_admin'")->fetchColumn();
$admin->get("/users/$meId/edit");
$admin->post("/users/$meId/status", ['to_status' => 'disabled', 'reason' => 'غیرفعال‌کردن خودم']);
check('cannot disable yourself', $admin->has('خودتان') && pdo()->query("SELECT status FROM users WHERE id = $meId")->fetchColumn() === 'active');
$planId = (int) pdo()->query("SELECT id FROM loan_plans WHERE company_id = $dbp ORDER BY id LIMIT 1")->fetchColumn();
$admin->get("/plans/$planId/edit");
$admin->post("/plans/$planId/status", ['to_status' => 'disabled', 'reason' => 'توقف موقت طرح']);
check('plan disabled with reason + history', (int) pdo()->query("SELECT is_active FROM loan_plans WHERE id = $planId")->fetchColumn() === 0 && (int) pdo()->query("SELECT COUNT(*) FROM status_history WHERE entity = 'plan' AND entity_id = $planId")->fetchColumn() === 1);
$admin->get("/plans/$planId/edit");
$admin->post("/plans/$planId/status", ['to_status' => 'active', 'reason' => 'فعال‌سازی مجدد طرح']);
check('plan re-enabled', (int) pdo()->query("SELECT is_active FROM loan_plans WHERE id = $planId")->fetchColumn() === 1);
$admin->get('/loans/' . $loanId);
check('loan page has notes + history', $admin->has('یادداشت‌های داخلی') && $admin->has('تاریخچه تغییرات'));

// ---------- تفصیلی و مرکز هزینه ----------
$admin->get('/dimensions');
check('dimensions page + menu', $admin->status === 200 && $admin->has('تفصیلی و مرکز هزینه') && $admin->has('/dimensions'));
$admin->post('/dimensions', ['kind' => 'detail', 'code' => 'P100', 'name' => 'شرکت پخش سپهر']);
$admin->post('/dimensions', ['kind' => 'cost_center', 'code' => 'CC1', 'name' => 'واحد بازاریابی']);
$detId = (int) pdo()->query("SELECT id FROM dimensions WHERE company_id = $dbp AND code = 'P100'")->fetchColumn();
$ccId = (int) pdo()->query("SELECT id FROM dimensions WHERE company_id = $dbp AND code = 'CC1'")->fetchColumn();
check('dimensions created', $detId > 0 && $ccId > 0);
$admin->get('/dimensions');
$admin->post('/dimensions', ['kind' => 'detail', 'code' => 'P100', 'name' => 'تکراری']);
check('duplicate dimension code rejected', $admin->has('برای همین نوع') && (int) pdo()->query("SELECT COUNT(*) FROM dimensions WHERE code = 'P100'")->fetchColumn() === 1);
$admin->get('/dimensions');
$admin->post('/dimensions', ['kind' => 'detail', 'code' => 'bad code!', 'name' => 'کد نامعتبر']);
check('invalid dimension code rejected', $admin->has('کد فقط شامل'));
$aCash = (int) pdo()->query("SELECT id FROM accounts WHERE company_id = $dbp AND code = '1101'")->fetchColumn();
$aExp = (int) pdo()->query("SELECT id FROM accounts WHERE company_id = $dbp AND code = '5101'")->fetchColumn();
$admin->get('/journal/create');
check('journal form has dimension selects', $admin->has('name="detail_id[]"') && $admin->has('name="cost_center_id[]"') && $admin->has('P100'));
$admin->post('/journal', ['entry_date' => '1405/08/12', 'description' => 'هزینه تبلیغات با ابعاد', 'status' => 'final', 'account_id' => [(string) $aExp, (string) $aCash],
    'debit' => ['8000000', ''], 'credit' => ['', '8000000'], 'line_desc' => ['', ''], 'detail_id' => [(string) $detId, ''], 'cost_center_id' => [(string) $ccId, (string) $ccId]]);
$dimEntry = (int) pdo()->query("SELECT id FROM journal_entries WHERE description = 'هزینه تبلیغات با ابعاد'")->fetchColumn();
check('entry saved with dimensions', $dimEntry > 0 && (int) pdo()->query("SELECT COUNT(*) FROM journal_lines WHERE entry_id = $dimEntry AND cost_center_id = $ccId")->fetchColumn() === 2 && (int) pdo()->query("SELECT COUNT(*) FROM journal_lines WHERE entry_id = $dimEntry AND detail_id = $detId")->fetchColumn() === 1);
$admin->get("/journal/$dimEntry");
check('journal show displays dimensions', $admin->has('شرکت پخش سپهر') && $admin->has('واحد بازاریابی'));
$admin->get("/dimensions/$ccId");
check('cost center report totals', $admin->status === 200 && $admin->has('ریز اسناد') && $admin->has('هزینه تبلیغات با ابعاد'));
$admin->get("/dimensions/$detId?format=csv");
$dcsv = str_getcsv_all($admin->html);
check('dimension csv export', str_starts_with($admin->html, "\xEF\xBB\xBF") && count($dcsv) === 2 && (int) $dcsv[1][5] === 8000000);
$other->get('/dashboard');
$other->get("/dimensions/$ccId");
check('tenant isolation: dimension 404', $other->status === 404);
$other->get('/journal/create');
$other->post('/journal', ['entry_date' => '1405/08/12', 'description' => 'بعد خارجی', 'status' => 'draft', 'account_id' => ['1'], 'debit' => ['1000'], 'credit' => [''], 'detail_id' => [(string) $detId], 'cost_center_id' => ['']]);
check('foreign dimension id rejected', (int) pdo()->query("SELECT COUNT(*) FROM journal_entries WHERE description = 'بعد خارجی'")->fetchColumn() === 0);
$admin->get("/journal/$dimEntry");
$admin->post("/journal/$dimEntry/reverse", ['date' => '1405/08/13']);
check('reversal copies dimensions', (int) pdo()->query("SELECT COUNT(*) FROM journal_lines WHERE cost_center_id = $ccId")->fetchColumn() === 4);
$admin->get("/dimensions/$ccId");
check('reversed cost center nets to zero', (int) pdo()->query("SELECT SUM(debit) - SUM(credit) FROM journal_lines WHERE cost_center_id = $ccId")->fetchColumn() === 0);
$admin->get('/dimensions');
$admin->post("/dimensions/$detId/toggle", []);
check('dimension deactivated', (int) pdo()->query("SELECT is_active FROM dimensions WHERE id = $detId")->fetchColumn() === 0);
$admin->get('/journal/create');
$admin->post('/journal', ['entry_date' => '1405/08/14', 'description' => 'استفاده از تفصیلی غیرفعال', 'status' => 'draft', 'account_id' => [(string) $aExp], 'debit' => ['1000'], 'credit' => [''], 'detail_id' => [(string) $detId], 'cost_center_id' => ['']]);
check('inactive dimension cannot be used', (int) pdo()->query("SELECT COUNT(*) FROM journal_entries WHERE description = 'استفاده از تفصیلی غیرفعال'")->fetchColumn() === 0 && $admin->has('غیرفعال'));
$admin->get("/dimensions/$detId/edit");
$admin->post("/dimensions/$detId", ['code' => 'P100', 'name' => 'شرکت پخش سپهر (ویرایش)']);
check('dimension edited with change history', pdo()->query("SELECT name FROM dimensions WHERE id = $detId")->fetchColumn() === 'شرکت پخش سپهر (ویرایش)' && (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action = 'dimension.update'")->fetchColumn() === 1);
$admin->post("/dimensions/$detId/toggle", []);
check('final entries still balanced with dimensions', (int) pdo()->query("SELECT COUNT(*) FROM (SELECT l.entry_id FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final' GROUP BY l.entry_id HAVING SUM(l.debit) <> SUM(l.credit))")->fetchColumn() === 0);

// ---------- چک و تطبیق بانکی ----------
$jd = static fn (string $mod): string => \App\Core\Jalali::format(date('Y-m-d', strtotime($mod)));
$acct = static fn (string $code): int => (int) pdo()->query("SELECT COALESCE(SUM(l.debit - l.credit),0) FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id JOIN accounts a ON a.id = l.account_id WHERE a.company_id = $dbp AND a.code = '$code' AND e.status = 'final'")->fetchColumn();
$aLoans = (int) pdo()->query("SELECT id FROM accounts WHERE company_id = $dbp AND code = '1201'")->fetchColumn();
$aMerch = (int) pdo()->query("SELECT id FROM accounts WHERE company_id = $dbp AND code = '2201'")->fetchColumn();
$notes0 = $acct('1103');
$admin->get('/cheques');
check('cheques page + menu', $admin->status === 200 && $admin->has('چک‌ها') && $admin->has('/cheques') && $admin->has('/reconciliation'));
$admin->get('/cheques/create');
$chq = ['direction' => 'received', 'cheque_no' => '123456', 'bank_name' => 'ملی', 'party' => 'علی رضایی', 'amount' => '5,000,000', 'issue_date' => $jd('today'), 'due_date' => $jd('+10 days'), 'counter_account_id' => (string) $aLoans, 'bank_account_id' => (string) $aCash, 'description' => 'قسط اول'];
$admin->post('/cheques', $chq);
$c1 = (int) pdo()->query("SELECT id FROM cheques WHERE company_id = $dbp AND cheque_no = '123456'")->fetchColumn();
check('received cheque registered with accounting entry', $c1 > 0 && $admin->has('سند حسابداری آن صادر شد') && $acct('1103') === $notes0 + 5000000);
$admin->get('/cheques/create');
$admin->post('/cheques', $chq);
check('duplicate cheque rejected', $admin->has('قبلاً ثبت شده') && (int) pdo()->query("SELECT COUNT(*) FROM cheques WHERE cheque_no = '123456'")->fetchColumn() === 1);
$admin->get('/cheques/create');
$admin->post('/cheques', ['due_date' => $jd('-5 days')] + ['cheque_no' => '777', 'issue_date' => $jd('today')] + $chq);
check('due before issue rejected', $admin->has('قبل از تاریخ صدور'));
$admin->get('/cheques/create');
$admin->post('/cheques', ['issue_date' => 'bad'] + ['cheque_no' => '778'] + $chq);
check('bad cheque date rejected', $admin->has('تاریخ صدور و سررسید'));
$admin->get("/cheques/$c1");
check('cheque page shows transitions', $admin->has('تغییر وضعیت چک') && $admin->has('نزد صندوق'));
$admin->post("/cheques/$c1/status", ['to_status' => 'bounced', 'date' => '', 'reason' => 'x']);
check('bounce needs reason', $admin->has('دلیل برگشت') && pdo()->query("SELECT status FROM cheques WHERE id = $c1")->fetchColumn() === 'in_hand');
$admin->get("/cheques/$c1");
$admin->post("/cheques/$c1/status", ['to_status' => 'deposited', 'date' => '', 'bank_account_id' => (string) $aCash, 'reason' => '']);
check('cheque deposited (no entry)', pdo()->query("SELECT status FROM cheques WHERE id = $c1")->fetchColumn() === 'deposited' && $acct('1103') === $notes0 + 5000000);
$cashBefore = $acct('1101');
$admin->get("/cheques/$c1");
$admin->post("/cheques/$c1/status", ['to_status' => 'cleared', 'date' => '', 'bank_account_id' => (string) $aCash, 'reason' => '']);
check('cheque cleared: bank up, notes cleared', pdo()->query("SELECT status FROM cheques WHERE id = $c1")->fetchColumn() === 'cleared' && $acct('1101') === $cashBefore + 5000000 && $acct('1103') === $notes0);
$admin->get("/cheques/$c1");
$admin->post("/cheques/$c1/status", ['to_status' => 'bounced', 'date' => '', 'reason' => 'تلاش بعد از وصول']);
check('terminal cheque cannot change', $admin->has('مجاز نیست') && pdo()->query("SELECT status FROM cheques WHERE id = $c1")->fetchColumn() === 'cleared');
check('cheque status history stored', (int) pdo()->query("SELECT COUNT(*) FROM status_history WHERE entity = 'cheque' AND entity_id = $c1")->fetchColumn() === 2);

$admin->get('/cheques/create');
$admin->post('/cheques', ['cheque_no' => '222', 'amount' => '3,000,000'] + $chq);
$c2 = (int) pdo()->query("SELECT id FROM cheques WHERE cheque_no = '222'")->fetchColumn();
$admin->get("/cheques/$c2");
$admin->post("/cheques/$c2/status", ['to_status' => 'bounced', 'date' => '', 'reason' => 'عدم تأمین موجودی حساب']);
check('bounced cheque reverses registration', pdo()->query("SELECT status FROM cheques WHERE id = $c2")->fetchColumn() === 'bounced' && $acct('1103') === $notes0 && (int) pdo()->query("SELECT COUNT(*) FROM journal_entries WHERE source_type = 'cheque' AND source_id = $c2")->fetchColumn() === 2);

$pay0 = $acct('2103');
$admin->get('/cheques/create');
$admin->post('/cheques', ['direction' => 'issued', 'cheque_no' => '9001', 'bank_name' => 'ملت', 'party' => 'فروشگاه آرین', 'amount' => '8,000,000', 'counter_account_id' => (string) $aMerch] + $chq);
$c3 = (int) pdo()->query("SELECT id FROM cheques WHERE cheque_no = '9001'")->fetchColumn();
check('issued cheque registered (liability up)', $c3 > 0 && $acct('2103') === $pay0 - 8000000);
$admin->get("/cheques/$c3");
check('issued cheque offers pass/cancel', $admin->has('پاس‌شده') && $admin->has('ابطال‌شده'));
$cashBefore = $acct('1101');
$admin->post("/cheques/$c3/status", ['to_status' => 'passed', 'date' => '', 'bank_account_id' => (string) $aCash, 'reason' => '']);
check('issued cheque passed: bank down, liability cleared', pdo()->query("SELECT status FROM cheques WHERE id = $c3")->fetchColumn() === 'passed' && $acct('1101') === $cashBefore - 8000000 && $acct('2103') === $pay0);
$admin->get('/cheques/create');
$admin->post('/cheques', ['direction' => 'issued', 'cheque_no' => '9002', 'bank_name' => 'ملت', 'party' => 'فروشگاه آرین', 'amount' => '1,000,000', 'counter_account_id' => (string) $aMerch] + $chq);
$c4 = (int) pdo()->query("SELECT id FROM cheques WHERE cheque_no = '9002'")->fetchColumn();
$admin->get("/cheques/$c4");
$admin->post("/cheques/$c4/status", ['to_status' => 'cancelled', 'date' => '', 'reason' => 'اشتباه در مبلغ چک']);
check('issued cheque cancelled reverses', pdo()->query("SELECT status FROM cheques WHERE id = $c4")->fetchColumn() === 'cancelled' && $acct('2103') === $pay0);
$admin->get('/cheques/create');
$admin->post('/cheques', ['cheque_no' => '333', 'amount' => '2,000,000', 'due_date' => $jd('-3 days'), 'issue_date' => $jd('-20 days')] + $chq);
$c5 = (int) pdo()->query("SELECT id FROM cheques WHERE cheque_no = '333'")->fetchColumn();
$admin->get('/cheques?due=overdue');
check('overdue filter finds open past-due cheque', $admin->has('سررسید گذشته') && $admin->has('333'));
$admin->get('/cheques?direction=issued&status=passed&min=1&sort=amount');
check('cheque filters render', $admin->status === 200 && $admin->has('9001'));
$admin->get('/cheques?format=csv');
check('cheques csv', str_starts_with($admin->html, "\xEF\xBB\xBF") && count(str_getcsv_all($admin->html)) >= 6);

// ---------- پشت‌نویسی چک ----------
$notesBefore = $acct('1103');
$admin->get('/cheques/create');
$admin->post('/cheques', ['cheque_no' => '444', 'amount' => '4,000,000', 'issue_date' => $jd('today'), 'due_date' => $jd('+20 days')] + $chq);
$c6 = (int) pdo()->query("SELECT id FROM cheques WHERE cheque_no = '444'")->fetchColumn();
$admin->get("/cheques/$c6");
check('in-hand received cheque offers endorsement', $admin->has('پشت‌نویسی به شخص ثالث'));
$admin->post("/cheques/$c6/endorse", ['endorsee' => '', 'counter_account_id' => (string) $aMerch, 'date' => '']);
check('endorsement needs endorsee name', pdo()->query("SELECT status FROM cheques WHERE id = $c6")->fetchColumn() === 'in_hand');
$admin->get("/cheques/$c6");
$admin->post("/cheques/$c6/endorse", ['endorsee' => 'فروشگاه آرین', 'counter_account_id' => '999999', 'date' => '']);
check('endorsement rejects unknown account', pdo()->query("SELECT status FROM cheques WHERE id = $c6")->fetchColumn() === 'in_hand');
$admin->get("/cheques/$c6");
$admin->post("/cheques/$c6/endorse", ['endorsee' => 'فروشگاه آرین', 'counter_account_id' => (string) $aMerch, 'date' => '']);
check('endorsed: status, endorsee, notes account cleared', pdo()->query("SELECT status, endorsed_to FROM cheques WHERE id = $c6")->fetch(PDO::FETCH_NUM) === ['endorsed', 'فروشگاه آرین'] && $acct('1103') === $notesBefore);
$eEntry = (int) pdo()->query("SELECT endorse_entry_id FROM cheques WHERE id = $c6")->fetchColumn();
check('endorsement entry is balanced and final', $eEntry > 0 && (int) pdo()->query("SELECT SUM(debit) - SUM(credit) FROM journal_lines WHERE entry_id = $eEntry")->fetchColumn() === 0 && pdo()->query("SELECT status FROM journal_entries WHERE id = $eEntry")->fetchColumn() === 'final');
$admin->get("/cheques/$c6");
check('endorsed cheque shows endorsee + undo, no status form', $admin->has('پشت‌نویسی‌شده به') && $admin->has('بازگشت به صندوق'));
$admin->post("/cheques/$c6/endorse", ['endorsee' => 'دیگری', 'counter_account_id' => (string) $aMerch, 'date' => '']);
check('endorsed cheque cannot be endorsed again', $admin->has('قابل پشت‌نویسی') && pdo()->query("SELECT endorsed_to FROM cheques WHERE id = $c6")->fetchColumn() === 'فروشگاه آرین');
$admin->post("/cheques/$c6/unendorse", ['reason' => 'x', 'date' => '']);
check('undo endorsement needs a reason', pdo()->query("SELECT status FROM cheques WHERE id = $c6")->fetchColumn() === 'endorsed');
$admin->get("/cheques/$c6");
$admin->post("/cheques/$c6/unendorse", ['reason' => 'شخص ثالث چک را برگرداند', 'date' => '']);
check('undo endorsement restores cheque and reverses entry', pdo()->query("SELECT status FROM cheques WHERE id = $c6")->fetchColumn() === 'in_hand' && $acct('1103') === $notesBefore + 4000000);
check('endorsement history recorded', (int) pdo()->query("SELECT COUNT(*) FROM status_history WHERE entity = 'cheque' AND entity_id = $c6 AND to_status IN ('endorsed', 'in_hand')")->fetchColumn() === 2);

// ---------- ورود صورت‌حساب بانکی و مغایرت‌گیری خودکار ----------
$bl = pdo()->query("SELECT l.id, e.entry_date, l.debit, l.credit FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.company_id = $dbp AND e.status = 'final' AND l.account_id = $aCash AND l.reconciliation_id IS NULL ORDER BY l.id")->fetchAll();
$dep = null;
$wdr = null;
foreach ($bl as $b) {
    if ($dep === null && (int) $b['debit'] > 0) {
        $dep = $b;
    }
    if ($wdr === null && (int) $b['credit'] > 0) {
        $wdr = $b;
    }
}
check('bank import fixture has deposit and withdrawal lines', $dep !== null && $wdr !== null);
$jf = static fn (string $d): string => \App\Core\Jalali::format($d);
$csv = "date,description,deposit,withdrawal,balance\n"
    . $jf($dep['entry_date']) . ",واریز نمونه," . (int) $dep['debit'] . ",,1000\n"
    . $jf($wdr['entry_date']) . ",برداشت نمونه,," . (int) $wdr['credit'] . ",2000\n"
    . $jf(date('Y-m-d')) . ",کارمزد بانک,,12345,987654\n";
$tmp = tempnam(sys_get_temp_dir(), 'stm') . '.csv';
file_put_contents($tmp, $csv);
$admin->get("/reconciliation/$aCash");
check('reconcile page offers statement upload', $admin->has('مغایرت‌گیری خودکار') && $admin->has('name="file"'));
$admin->postFile("/reconciliation/$aCash/import", [], 'file', $tmp);
check('statement import matches book lines automatically', $admin->has('جفت شد') && substr_count($admin->html, 'rec-line') >= 2 && (bool) preg_match_all('/class="rec-line"[^>]*checked/', $admin->html, $mm) && count($mm[0]) >= 2);
check('unmatched bank transaction reported', $admin->has('که در دفتر نیستند') && $admin->has('کارمزد بانک'));
check('closing balance prefilled from statement', $admin->has('value="987654"'));
$admin->post("/reconciliation/$aCash/import-clear", []);
check('import result can be cleared', !$admin->has('جفت شد'));
// همان صورت‌حساب به‌صورت Excel (.xlsx): تاریخ شمسی متنی + سریال تاریخ Excel + اعداد
$serial = (int) floor(strtotime(date('Y-m-d') . ' 00:00:00 UTC') / 86400) + 25569;
$cellS = static fn (string $ref, string $v): string => '<c r="' . $ref . '" t="inlineStr"><is><t>' . htmlspecialchars($v, ENT_XML1) . '</t></is></c>';
$cellN = static fn (string $ref, int|string $v): string => '<c r="' . $ref . '"><v>' . $v . '</v></c>';
$xrows = [
    ['date', 'description', 'deposit', 'withdrawal', 'balance'],
    [$jf($dep['entry_date']), 'واریز نمونه', (int) $dep['debit'], '', 1000],
    [$jf($wdr['entry_date']), 'برداشت نمونه', '', (int) $wdr['credit'], 2000],
    [$serial, 'کارمزد بانک', '', 12345, 987654],
];
$sheet = '<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
foreach ($xrows as $ri => $row) {
    $sheet .= '<row r="' . ($ri + 1) . '">';
    foreach ($row as $ci => $v) {
        $ref = chr(65 + $ci) . ($ri + 1);
        if ($v === '') {
            continue;
        }
        $sheet .= is_int($v) ? $cellN($ref, $v) : $cellS($ref, (string) $v);
    }
    $sheet .= '</row>';
}
$sheet .= '</sheetData></worksheet>';
$xl = tempnam(sys_get_temp_dir(), 'xl') . '.xlsx';
$z = new ZipArchive();
$z->open($xl, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$z->addFromString('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>');
$z->addFromString('xl/worksheets/sheet1.xml', $sheet);
$z->close();
$admin->get("/reconciliation/$aCash");
check('reconcile upload accepts xlsx', $admin->has('.xlsx'));
$admin->postFile("/reconciliation/$aCash/import", [], 'file', $xl);
check('xlsx statement matches book lines like csv', $admin->has('جفت شد') && (bool) preg_match_all('/class="rec-line"[^>]*checked/', $admin->html, $mx) && count($mx[0]) >= 2);
check('xlsx date serial and numbers parsed (closing balance, unmatched fee)', $admin->has('value="987654"') && $admin->has('کارمزد بانک'));
$admin->post("/reconciliation/$aCash/import-clear", []);
$bad = tempnam(sys_get_temp_dir(), 'bx') . '.xlsx';
file_put_contents($bad, "PK\x03\x04garbage-not-a-zip");
$admin->get("/reconciliation/$aCash");
$admin->postFile("/reconciliation/$aCash/import", [], 'file', $bad);
check('corrupt xlsx is rejected with a message', $admin->has('Excel معتبر نیست') && !$admin->has('جفت شد'));
unlink($xl);
unlink($bad);
file_put_contents($tmp, "foo,bar\n1,2\n");
$admin->get("/reconciliation/$aCash");
$admin->postFile("/reconciliation/$aCash/import", [], 'file', $tmp);
check('statement without required columns is rejected', $admin->has('پیدا نشد') && !$admin->has('جفت شد'));
unlink($tmp);
$lender->get("/reconciliation/$aCash");
check('statement upload hidden for users without post permission', $lender->status !== 200 || !$lender->has('name="file"'));

$admin->get("/cheques/$c5");
$admin->post("/cheques/$c5", ['party' => 'علی رضایی (اصلاح)', 'due_date' => $jd('+30 days'), 'description' => 'تمدید']);
check('cheque non-financial edit + diff log', pdo()->query("SELECT party FROM cheques WHERE id = $c5")->fetchColumn() === 'علی رضایی (اصلاح)' && (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action = 'cheque.update'")->fetchColumn() === 1);
$admin->post('/notes', ['entity' => 'cheque', 'entity_id' => (string) $c5, 'body' => 'مشتری قول داد چک را تعویض کند']);
check('notes on cheque', (int) pdo()->query("SELECT COUNT(*) FROM entity_notes WHERE entity = 'cheque' AND entity_id = $c5")->fetchColumn() === 1);
$other->get('/dashboard');
$other->get("/cheques/$c1");
check('tenant isolation: cheque 404', $other->status === 404);
$other->post("/cheques/$c5/status", ['to_status' => 'deposited', 'bank_account_id' => (string) $aCash]);
check('tenant isolation: cheque transition 404', pdo()->query("SELECT status FROM cheques WHERE id = $c5")->fetchColumn() === 'in_hand');
check('all final entries balanced after cheques', (int) pdo()->query("SELECT COUNT(*) FROM (SELECT l.entry_id FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.status = 'final' GROUP BY l.entry_id HAVING SUM(l.debit) <> SUM(l.credit))")->fetchColumn() === 0);

$admin->get('/reconciliation');
check('reconciliation index lists cash account', $admin->status === 200 && $admin->has('تطبیق بانکی') && $admin->has('صندوق و بانک'));
$admin->get("/reconciliation/$aCash");
check('reconciliation page has lines', $admin->status === 200 && $admin->has('class="rec-line"') && $admin->has('مانده تطبیق‌شده'));
$unrec = pdo()->query("SELECT l.id, l.debit - l.credit AS net FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id WHERE e.company_id = $dbp AND e.status = 'final' AND l.account_id = $aCash AND l.reconciliation_id IS NULL AND e.entry_date <= '" . date('Y-m-d') . "'")->fetchAll(PDO::FETCH_ASSOC);
$ids = array_map(static fn ($r) => (string) $r['id'], $unrec);
$net = array_sum(array_map(static fn ($r) => (int) $r['net'], $unrec));
check('has unreconciled lines to match', count($ids) >= 3);
$admin->post("/reconciliation/$aCash", ['ids' => $ids, 'statement_date' => $jd('today'), 'statement_balance' => (string) ($net + 1000)]);
check('reconciliation rejects mismatched balance', $admin->has('اختلاف') && (int) pdo()->query("SELECT COUNT(*) FROM bank_reconciliations WHERE account_id = $aCash")->fetchColumn() === 0);
$admin->get("/reconciliation/$aCash");
$admin->post("/reconciliation/$aCash", ['ids' => [], 'statement_date' => $jd('today'), 'statement_balance' => '0']);
check('reconciliation needs selection', $admin->has('هیچ ردیفی'));
$admin->get("/reconciliation/$aCash");
$admin->post("/reconciliation/$aCash", ['ids' => $ids, 'statement_date' => $jd('today'), 'statement_balance' => (string) $net]);
check('reconciliation saved', $admin->has('تطبیق بانکی ثبت شد') && (int) pdo()->query("SELECT COUNT(*) FROM journal_lines WHERE account_id = $aCash AND reconciliation_id IS NOT NULL")->fetchColumn() === count($ids));
$admin->get("/reconciliation/$aCash");
$admin->post("/reconciliation/$aCash", ['ids' => [$ids[0]], 'statement_date' => $jd('today'), 'statement_balance' => (string) $net]);
check('already reconciled lines rejected', $admin->has('نامعتبر یا قبلاً') && (int) pdo()->query("SELECT COUNT(*) FROM bank_reconciliations WHERE account_id = $aCash")->fetchColumn() === 1);
$other->get('/dashboard');
$other->get("/reconciliation/$aCash");
check('tenant isolation: reconciliation 404', $other->status === 404);
$recId = (int) pdo()->query("SELECT id FROM bank_reconciliations WHERE account_id = $aCash")->fetchColumn();
$admin->get("/reconciliation/$aCash");
$admin->post("/reconciliation/$recId/undo", []);
check('reconciliation undone, lines reopened', $admin->has('تطبیق لغو شد') && (int) pdo()->query("SELECT COUNT(*) FROM journal_lines WHERE account_id = $aCash AND reconciliation_id IS NOT NULL")->fetchColumn() === 0 && pdo()->query("SELECT status FROM bank_reconciliations WHERE id = $recId")->fetchColumn() === 'undone');

// ---------- حسابرسی و سازگاری داده ----------
$second->get('/audit');
foreach (['loan.approve', 'loan.reject', 'installment.pay', 'wallet.topup', 'role.create', 'customer.create', 'order.create', 'merchant.settle', 'journal.manual', 'collection.note', 'loan.payoff', 'latefee.accrue', 'latefee.receive', 'journal.manual'] as $a) {
    check("audit has $a", (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action = '$a'")->fetchColumn() > 0);
}
$db = pdo();
check('wallet balance = sum of wallet transactions', (int) $db->query("SELECT wallet_balance FROM customers WHERE id = $customerId")->fetchColumn() === (int) $db->query("SELECT SUM(amount) FROM wallet_transactions WHERE customer_id = $customerId")->fetchColumn());
check('installment paid_amount = sum of payments', (int) $db->query('SELECT SUM(paid_amount) FROM installments')->fetchColumn() === (int) $db->query('SELECT SUM(amount) FROM payments')->fetchColumn());
check('no negative wallet', (int) $db->query('SELECT COUNT(*) FROM customers WHERE wallet_balance < 0')->fetchColumn() === 0);
check('no password stored in clear text', (int) $db->query("SELECT COUNT(*) FROM users WHERE password_hash NOT LIKE '$2y$%'")->fetchColumn() === 0);

// ---------- تأیید دومرحله‌ای (TOTP) ----------
$admin->get('/users/create');
$admin->post('/users', ['username' => 'mfauser', 'full_name' => 'کاربر امن', 'role_id' => (string) $roleId, 'password' => 'Mfa-pass-12345']);
$mfa = new Client($base);
$mfa->login('mfauser', 'Mfa-pass-12345');
$mfa->get('/account/mfa');
preg_match('/class="mfa-secret ltr">([A-Z2-7 ]+)</', $mfa->html, $m);
$sec = str_replace(' ', '', $m[1] ?? '');
check('mfa setup shows secret', strlen($sec) >= 16);
$now = intdiv(time(), 30);
$mfa->post('/account/mfa/enable', ['code' => '000000']);
check('mfa enable rejects wrong code', $mfa->has('صحیح نیست') && (int) pdo()->query("SELECT mfa_enabled FROM users WHERE username = 'mfauser'")->fetchColumn() === 0);
$mfa->get('/account/mfa');
$mfa->post('/account/mfa/enable', ['code' => \App\Core\Totp::code($sec, $now)]);
preg_match_all('/<li>([0-9a-f]{6}-[0-9a-f]{6})<\/li>/', $mfa->html, $m);
$rec = $m[1];
check('mfa enabled with 8 recovery codes', count($rec) === 8 && (int) pdo()->query("SELECT mfa_enabled FROM users WHERE username = 'mfauser'")->fetchColumn() === 1);
check('secret stored encrypted', (string) pdo()->query("SELECT mfa_secret FROM users WHERE username = 'mfauser'")->fetchColumn() !== $sec);
check('recovery codes stored hashed', (int) pdo()->query("SELECT COUNT(*) FROM mfa_recovery_codes WHERE code_hash = '" . $rec[0] . "'")->fetchColumn() === 0);

$c2 = new Client($base);
$c2->login('mfauser', 'Mfa-pass-12345');
check('login asks for second factor', str_ends_with($c2->url, '/login/mfa'));
$c2->get('/dashboard');
check('no access before second factor', str_ends_with($c2->url, '/login'));
$c2->login('mfauser', 'Mfa-pass-12345');
$c2->post('/login/mfa', ['code' => '123456']);
check('wrong code rejected', $c2->has('صحیح نیست') && !$c2->has('داشبورد'));
$c2->post('/login/mfa', ['code' => \App\Core\Totp::code($sec, $now)]);
$c2->get('/dashboard');
check('replay of last used step rejected', str_ends_with($c2->url, '/login/mfa') || str_ends_with($c2->url, '/login'));
$c2 = new Client($base);
$c2->login('mfauser', 'Mfa-pass-12345');
$c2->post('/login/mfa', ['code' => \App\Core\Totp::code($sec, $now + 1)]);
check('valid next-step code logs in', $c2->has('داشبورد'));

$c3 = new Client($base);
$c3->login('mfauser', 'Mfa-pass-12345');
$c3->post('/login/mfa', ['code' => $rec[0]]);
check('recovery code logs in', $c3->has('داشبورد'));
$c4 = new Client($base);
$c4->login('mfauser', 'Mfa-pass-12345');
$c4->post('/login/mfa', ['code' => $rec[0]]);
check('recovery code is single-use', $c4->has('صحیح نیست') && !$c4->has('داشبورد'));
for ($i = 0; $i < 5; $i++) {
    $c4->post('/login/mfa', ['code' => '654321']);
}
$c4->post('/login/mfa', ['code' => $rec[1]]);
$c4->get('/dashboard');
check('mfa brute-force lockout', !$c4->has('داشبورد'));
pdo()->exec("DELETE FROM login_attempts WHERE username LIKE 'mfa:%'");

$c3->get('/account');
$c3->post('/account/mfa/disable', ['current_password' => 'wrong']);
check('disable requires password', $c3->has('رمز عبور فعلی صحیح نیست') && (int) pdo()->query("SELECT mfa_enabled FROM users WHERE username = 'mfauser'")->fetchColumn() === 1);
$c3->post('/account/mfa/recovery', ['current_password' => 'Mfa-pass-12345']);
check('recovery regeneration invalidates old codes', substr_count($c3->html, 'class="mfa-codes') === 1 && (int) pdo()->query("SELECT COUNT(*) FROM mfa_recovery_codes WHERE code_hash = '" . hash('sha256', $rec[2]) . "'")->fetchColumn() === 0);

$uid = (int) pdo()->query("SELECT id FROM users WHERE username = 'mfauser'")->fetchColumn();
$admin->get("/users/$uid/edit");
check('admin sees mfa status', $admin->has('بازنشانی (مثلاً گم‌شدن گوشی)'));
$admin->post("/users/$uid/mfa-reset", []);
check('admin reset disables mfa', (int) pdo()->query("SELECT mfa_enabled FROM users WHERE id = $uid")->fetchColumn() === 0 && (int) pdo()->query("SELECT COUNT(*) FROM mfa_recovery_codes WHERE user_id = $uid")->fetchColumn() === 0);
$admin->post('/users/999999/mfa-reset', []);
check('mfa reset of unknown user -> 404', $admin->status === 404);
$c5 = new Client($base);
$c5->login('mfauser', 'Mfa-pass-12345');
check('login without mfa after reset', $c5->has('داشبورد'));
foreach (['mfa.enable', 'mfa.reset', 'mfa.recovery_used'] as $a) {
    check("audit has $a", (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action = '$a'")->fetchColumn() > 0);
}

// ---------- مرکز هشدارها ----------
$admin->get('/alerts');
check('alerts page renders for admin', $admin->status === 200 && $admin->has('هشدارها'));
check('alerts lists mfa recommendation', $admin->has('بدون تأیید دومرحله‌ای'));
pdo()->exec("INSERT INTO cheques (company_id, direction, cheque_no, bank_name, party, amount, issue_date, due_date, counter_account_id, status, created_at) SELECT id, 'received', 'ALERT-1', 'ملی', 'تست', 1000, '2019-12-01', '2020-01-01', (SELECT MIN(id) FROM accounts WHERE company_id = companies.id), 'in_hand', '2020-01-01 00:00:00' FROM companies WHERE code = 'DBP'");
$admin->get('/alerts');
check('overdue cheque alert appears', $admin->has('چک‌های سررسیدگذشته'));
check('bell badge in topbar', $admin->has('topbar__badge'));
pdo()->exec("DELETE FROM cheques WHERE cheque_no = 'ALERT-1'");
$lender->get('/alerts');
check('alerts hide items without permission', $lender->status === 200 && !$lender->has('چک‌های سررسیدگذشته') && !$lender->has('بدون تأیید دومرحله‌ای'));
$anon->get('/alerts');
check('alerts require login', str_ends_with($anon->url, '/login'));

// ---------- درون‌ریزی مشتریان ----------
$gen = static function (string $nine): string { return validNc($nine); };
$ncA = $gen('600000011'); $ncB = $gen('600000022'); $ncC = $gen('600000033');
$tmp = tempnam(sys_get_temp_dir(), 'imp');
$mk = static function (string $body) use ($tmp): string { file_put_contents($tmp, "\xEF\xBB\xBF" . $body); return $tmp; };
$admin->get('/customers/import');
check('import form renders', $admin->status === 200 && $admin->has('درون‌ریزی گروهی'));
$admin->get('/customers/import/template');
check('import template csv', $admin->has('national_code,full_name,mobile,credit_limit'));
$admin->get('/customers/import');
$admin->postFile('/customers/import', ['mode' => 'import'], 'file', $mk("national_code,full_name,mobile,credit_limit\n$ncA,الف الف,09121110001,1000000\n123,بد,0912,x\n"));
check('import with bad rows commits nothing', $admin->has('چیزی ثبت نشد') && (int) pdo()->query("SELECT COUNT(*) FROM customers WHERE national_code = '$ncA'")->fetchColumn() === 0);
$admin->get('/customers/import');
$admin->postFile('/customers/import', ['mode' => 'check'], 'file', $mk("national_code;full_name;mobile;credit_limit\n$ncA;الف الف;9121110001;۱٬۰۰۰٬۰۰۰\n"));
check('dry-run validates without saving (semicolon, persian digits, missing leading zero)', $admin->has('سالم است') && (int) pdo()->query("SELECT COUNT(*) FROM customers WHERE national_code = '$ncA'")->fetchColumn() === 0);
$admin->get('/customers/import');
$admin->postFile('/customers/import', ['mode' => 'import'], 'file', $mk("کد ملی,نام,موبایل,سقف اعتبار\n$ncA,الف الف,09121110001,1000000\n$ncB,ب ب,09121110002,\n"));
check('import commits all valid rows', $admin->has('۲ مشتری ثبت شد') && (int) pdo()->query("SELECT credit_limit FROM customers WHERE national_code = '$ncA'")->fetchColumn() === 1000000 && (int) pdo()->query("SELECT COUNT(*) FROM customers WHERE national_code = '$ncB'")->fetchColumn() === 1);
$admin->get('/customers/import');
$admin->postFile('/customers/import', ['mode' => 'import'], 'file', $mk("national_code,full_name,mobile\n$ncA,تکراری,09121110009\n$ncC,ج ج,09121110003\n$ncC,ج دوباره,09121110004\n"));
check('duplicates (db and in-file) rejected', $admin->has('قبلاً ثبت شده') && $admin->has('تکراری در همین فایل') && (int) pdo()->query("SELECT COUNT(*) FROM customers WHERE national_code = '$ncC'")->fetchColumn() === 0);
$admin->get('/customers/import');
$admin->postFile('/customers/import', ['mode' => 'import'], 'file', $mk("foo,bar\n1,2\n"));
check('missing columns reported', $admin->has('پیدا نشد'));
check('import audited', (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action = 'customer.import'")->fetchColumn() === 1);
$lender->get('/customers/import');
check('import available to role with customers.manage', $lender->status === 200);
$anon->get('/customers/import');
check('import requires login', str_ends_with($anon->url, '/login'));
unlink($tmp);

// ---------- صفحه‌ی اصلی عمومی و درخواست اعتبار ----------
$pub = new Client($base);
$pub->get('/');
check('public home renders for guests', $pub->status === 200 && $pub->has('خرید اقساطی هوشمند') && $pub->has('site-footer') && $pub->has('site-header'));
check('home lists active plans', $pub->has('طرح ۶ ماهه') || $pub->has('طرح‌های تسهیلاتی'));
$planIdPub = (int) pdo()->query("SELECT p.id FROM loan_plans p JOIN companies c ON c.id = p.company_id WHERE c.code = 'DBP' AND p.is_active = 1 ORDER BY p.id LIMIT 1")->fetchColumn();
$pub->get("/?plan=$planIdPub&amount=" . urlencode('۲۰,۰۰۰,۰۰۰') . '#calc');
check('server-side quote renders without JS', $pub->has('قسط ماهانه') && $pub->has('جدول اقساط'));
$pub->get("/calc?plan=$planIdPub&amount=20000000");
$j = json_decode($pub->html, true);
check('calc json ok', is_array($j) && isset($j['monthly'], $j['rows']) && count($j['rows']) > 0);
$pub->get("/calc?plan=$planIdPub&amount=1");
$j = json_decode($pub->html, true);
check('calc rejects amount outside plan range', is_array($j) && isset($j['error']));
$pub->get('/calc?plan=99999&amount=20000000');
check('calc rejects unknown plan', isset(json_decode($pub->html, true)['error']));

$pub->get('/');
$pub->post('/apply', ['full_name' => 'متقاضی نمونه', 'mobile' => '09125550001', 'website' => '', 'captcha' => '000000']);
check('lead needs correct captcha', $pub->has('کد امنیتی اشتباه') && (int) pdo()->query('SELECT COUNT(*) FROM leads')->fetchColumn() === 0);
$pub->get('/');
$pub->post('/apply', ['full_name' => 'متقاضی نمونه', 'mobile' => '123', 'website' => '']);
check('lead with bad mobile rejected', $pub->has('شماره موبایل') && (int) pdo()->query('SELECT COUNT(*) FROM leads')->fetchColumn() === 0);
$pub->get('/');
$pub->post('/apply', ['full_name' => 'ربات', 'mobile' => '09125550000', 'website' => 'http://spam']);
check('honeypot silently ignored', (int) pdo()->query('SELECT COUNT(*) FROM leads')->fetchColumn() === 0);
$pub->get('/');
$pub->post('/apply', ['full_name' => 'متقاضی نمونه', 'mobile' => '09125551234', 'national_code' => '', 'requested_amount' => '۳۰,۰۰۰,۰۰۰', 'plan_id' => (string) $planIdPub, 'message' => 'تماس بعد از ظهر', 'website' => '']);
check('lead created from public form', $pub->has('درخواست شما ثبت شد') && (int) pdo()->query("SELECT requested_amount FROM leads WHERE mobile = '09125551234'")->fetchColumn() === 30000000);
$pub->get('/');
$pub->post('/apply', ['full_name' => 'متقاضی نمونه', 'mobile' => '09125551234', 'website' => '']);
check('duplicate pending lead blocked', $pub->has('قبلاً ثبت شده'));
for ($i = 0; $i < 5; $i++) {
    pdo()->exec("INSERT INTO leads (company_id, full_name, mobile, status, ip, created_at) SELECT company_id, 'x', '0912000000$i', 'rejected', '127.0.0.1', '" . date('Y-m-d H:i:s', time() + 28800) . "' FROM leads LIMIT 1");
}
$pub->get('/');
$pub->post('/apply', ['full_name' => 'متقاضی دیگر', 'mobile' => '09125559999', 'website' => '']);
check('lead rate limit per IP', $pub->has('زیاد است'));
pdo()->exec("DELETE FROM leads WHERE full_name = 'x'");

$admin->get('/leads');
check('admin sees leads list', $admin->status === 200 && $admin->has('متقاضی نمونه'));
$leadId = (int) pdo()->query("SELECT id FROM leads WHERE mobile = '09125551234'")->fetchColumn();
$admin->get("/leads/$leadId");
check('lead detail renders', $admin->has('تماس بعد از ظهر') && $admin->has('ایجاد مشتری از این درخواست'));
$admin->post("/leads/$leadId/status", ['to_status' => 'contacted', 'reason' => 'تماس گرفته شد و مدارک خواسته شد']);
check('lead status change with history', (string) pdo()->query("SELECT status FROM leads WHERE id = $leadId")->fetchColumn() === 'contacted' && (int) pdo()->query("SELECT COUNT(*) FROM status_history WHERE entity = 'lead' AND entity_id = $leadId")->fetchColumn() === 1);
$admin->post("/leads/$leadId/status", ['to_status' => 'qualified', 'reason' => 'x']);
check('lead status change needs reason', (string) pdo()->query("SELECT status FROM leads WHERE id = $leadId")->fetchColumn() === 'contacted');
$admin->get("/leads/$leadId");
$admin->post("/leads/$leadId/convert", []);
check('convert prefills customer form', str_ends_with($admin->url, '/customers/create') && $admin->has('متقاضی نمونه') && $admin->has('09125551234'));
$admin->get('/leads?status=contacted');
check('lead filter by status', $admin->has('متقاضی نمونه'));
$admin->get('/leads?status=new');
check('lead filter excludes other status', !$admin->has('متقاضی نمونه'));
$admin->get('/leads?format=csv');
check('lead csv export', $admin->has('نام,موبایل,"کد ملی"') || $admin->has('موبایل'));
$anon->get('/leads');
check('leads require login', str_ends_with($anon->url, '/login'));
$admin->get('/alerts');
check('alerts mention new leads', pdo()->query("SELECT COUNT(*) FROM leads WHERE status = 'new'")->fetchColumn() == 0 || $admin->has('درخواست‌های اعتبار جدید'));


// ---------- درگاه پرداخت آنلاین (درگاه آزمایشی داخلی) ----------
$pcid = (int) pdo()->query("SELECT company_id FROM customers WHERE id = $customerId")->fetchColumn();
$fx = (int) pdo()->query("SELECT i.id FROM installments i WHERE i.company_id = $pcid ORDER BY i.id DESC LIMIT 1")->fetchColumn();
pdo()->exec("UPDATE installments SET paid_amount = 0, status = 'due', paid_at = NULL WHERE id = $fx");
pdo()->exec("UPDATE loans SET status = 'active' WHERE id = (SELECT loan_id FROM installments WHERE id = $fx)");
$pi = pdo()->query("SELECT i.id, i.amount - i.paid_amount AS rem, l.customer_id FROM installments i JOIN loans l ON l.id = i.loan_id WHERE i.id = $fx")->fetch();
check('online pay: fixture installment found', (bool) $pi);
$piId = (int) $pi['id'];
$pRem = (int) $pi['rem'];
$tok = static fn (int $reqId): string => (string) pdo()->query("SELECT token FROM payment_requests WHERE id = $reqId")->fetchColumn();
$admin->post("/installments/$piId/pay-link", ['amount' => (string) ($pRem + 1)]);
check('pay link above remaining rejected', (int) pdo()->query('SELECT COUNT(*) FROM payment_requests')->fetchColumn() === 0);
$admin->get('/installments');
$admin->post("/installments/$piId/pay-link", ['amount' => (string) $pRem]);
check('pay link created for installment', preg_match('#/payment-links/(\d+)$#', $admin->url, $pm) === 1 && $admin->has('کپی لینک'));
$req1 = (int) ($pm[1] ?? 0);
$t1 = $tok($req1);
check('token is 40 hex chars', preg_match('/^[a-f0-9]{40}$/', $t1) === 1);

$cust = new Client($base);
$cust->get('/pay?t=' . $t1);
check('public pay page shows amount, no login needed', $cust->status === 200 && $cust->has('پرداخت امن آنلاین') && $cust->has(strtr(number_format($pRem), ['0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹'])));
$cust->get('/pay?t=' . str_repeat('a', 40));
check('unknown token is 404', $cust->status === 404);
$cust->get('/pay?t=' . $t1);
$cust->post('/pay/start?t=' . $t1, []);
check('start redirects to sandbox gateway', $cust->has('درگاه آزمایشی') && $cust->has('پرداخت موفق'));
$auth1 = (string) pdo()->query("SELECT authority FROM payment_requests WHERE id = $req1")->fetchColumn();
check('authority stored', str_starts_with($auth1, 'SBX'));
$cust->get("/pay/return?t=$t1&Status=OK&Authority=WRONG");
check('wrong authority is rejected', (string) pdo()->query("SELECT status FROM payment_requests WHERE id = $req1")->fetchColumn() === 'failed' && (int) pdo()->query("SELECT COUNT(*) FROM payments WHERE method = 'online'")->fetchColumn() === 0);

$admin->post("/installments/$piId/pay-link", ['amount' => (string) $pRem]);
preg_match('#/payment-links/(\d+)$#', $admin->url, $pm);
$req2 = (int) $pm[1];
$t2 = $tok($req2);
check('new link cancels older pending link for same installment', (int) pdo()->query("SELECT COUNT(*) FROM payment_requests WHERE installment_id = $piId AND status = 'pending'")->fetchColumn() === 1);
$cust->get('/pay?t=' . $t2);
$cust->post('/pay/start?t=' . $t2, []);
$auth2 = (string) pdo()->query("SELECT authority FROM payment_requests WHERE id = $req2")->fetchColumn();
$cust->get("/pay/return?t=$t2&Status=NOK&Authority=$auth2");
check('cancelled by customer marks failed, no payment', (string) pdo()->query("SELECT status FROM payment_requests WHERE id = $req2")->fetchColumn() === 'failed' && (int) pdo()->query("SELECT COUNT(*) FROM payments WHERE method = 'online'")->fetchColumn() === 0);

$admin->post("/installments/$piId/pay-link", ['amount' => (string) $pRem]);
preg_match('#/payment-links/(\d+)$#', $admin->url, $pm);
$req3 = (int) $pm[1];
$t3 = $tok($req3);
$cust->get('/pay?t=' . $t3);
$cust->post('/pay/start?t=' . $t3, []);
$auth3 = (string) pdo()->query("SELECT authority FROM payment_requests WHERE id = $req3")->fetchColumn();
$cust->get("/pay/return?t=$t3&Status=OK&Authority=$auth3");
$ist = pdo()->query("SELECT status, paid_amount, amount FROM installments WHERE id = $piId")->fetch();
check('successful online payment settles installment', $ist['status'] === 'paid' && (int) $ist['paid_amount'] === (int) $ist['amount'] && $cust->has('پرداخت شما با موفقیت ثبت شد'));
check('payment recorded with method online', (int) pdo()->query("SELECT COUNT(*) FROM payments WHERE method = 'online' AND installment_id = $piId")->fetchColumn() === 1);
$jeId = (int) pdo()->query("SELECT id FROM journal_entries WHERE source_type = 'payment' ORDER BY id DESC LIMIT 1")->fetchColumn();
check('online payment journal entry is balanced', (int) pdo()->query("SELECT SUM(debit) - SUM(credit) FROM journal_lines WHERE entry_id = $jeId")->fetchColumn() === 0);
$cust->get("/pay/return?t=$t3&Status=OK&Authority=$auth3");
check('replayed return does not double-post', (int) pdo()->query("SELECT COUNT(*) FROM payments WHERE method = 'online' AND installment_id = $piId")->fetchColumn() === 1 && (int) pdo()->query("SELECT paid_amount FROM installments WHERE id = $piId")->fetchColumn() === (int) $ist['amount']);
$cust->get('/pay?t=' . $t3);
check('paid link shows reference', $cust->has('کد پیگیری'));
$admin->get("/payment-links/$req3");
check('staff sees paid link with history', $admin->has('پرداخت‌شده') && $admin->has('ساخت لینک پرداخت'));

// شارژ کیف پول با لینک
$w0 = (int) pdo()->query("SELECT wallet_balance FROM customers WHERE id = $customerId")->fetchColumn();
$admin->get('/customers/' . $customerId);
$admin->post('/customers/' . $customerId . '/pay-link', ['amount' => '2,500,000']);
preg_match('#/payment-links/(\d+)$#', $admin->url, $pm);
$req4 = (int) ($pm[1] ?? 0);
$t4 = $tok($req4);
$cust->get('/pay?t=' . $t4);
$cust->post('/pay/start?t=' . $t4, []);
$auth4 = (string) pdo()->query("SELECT authority FROM payment_requests WHERE id = $req4")->fetchColumn();
$cust->get("/pay/return?t=$t4&Status=OK&Authority=$auth4");
check('wallet topup via link credits wallet', (int) pdo()->query("SELECT wallet_balance FROM customers WHERE id = $customerId")->fetchColumn() === $w0 + 2500000);

// منقضی و لغو
$admin->get('/customers/' . $customerId);
$admin->post('/customers/' . $customerId . '/pay-link', ['amount' => '1,000,000']);
preg_match('#/payment-links/(\d+)$#', $admin->url, $pm);
$req5 = (int) $pm[1];
$t5 = $tok($req5);
pdo()->exec("UPDATE payment_requests SET expires_at = '2000-01-01 00:00:00' WHERE id = $req5");
$cust->get('/pay?t=' . $t5);
check('expired link cannot be paid', $cust->has('منقضی') && !$cust->has('پرداخت امن آنلاین'));
$admin->get('/customers/' . $customerId);
$admin->post('/customers/' . $customerId . '/pay-link', ['amount' => '1,000,000']);
preg_match('#/payment-links/(\d+)$#', $admin->url, $pm);
$req6 = (int) $pm[1];
$admin->post("/payment-links/$req6/cancel", []);
check('staff can cancel a pending link', (string) pdo()->query("SELECT status FROM payment_requests WHERE id = $req6")->fetchColumn() === 'cancelled');
$cust->get('/pay?t=' . $tok($req6));
check('cancelled link cannot be paid', !$cust->has('پرداخت امن آنلاین'));

$admin->get('/payment-links');
check('payment links list renders', $admin->status === 200 && $admin->has('لینک‌های پرداخت آنلاین') && $admin->has('پرداخت‌شده'));
$admin->get('/payment-links?status=paid');
check('payment links filter by status', $admin->has('badge--ok') && !$admin->has('badge--muted'));
$admin->get('/payment-links?format=csv');
check('payment links csv export', $admin->has('مشتری') && $admin->has('درگاه'));
$anon2 = new Client($base);
$anon2->get('/payment-links');
check('payment links require login', str_ends_with($anon2->url, '/login'));
$other->get("/payment-links/$req3");
check('other tenant cannot open the link', $other->status === 404);


// ---------- پیامک، یادآوری و هشدارهای خوانده‌شده ----------
$sms = static fn (string $w) => (int) pdo()->query("SELECT COUNT(*) FROM notifications WHERE $w")->fetchColumn();
$admin->get('/notifications');
check('notifications list renders', $admin->status === 200 && $admin->has('پیامک‌ها و یادآوری اقساط'));
check('payment confirmation SMS was queued by online payment', $sms("template = 'payment_ok'") >= 1);
pdo()->exec("UPDATE customers SET mobile = '09127770011', status = 'active' WHERE id = $customerId");
pdo()->exec("UPDATE installments SET paid_amount = 0, status = 'due', paid_at = NULL, due_date = '" . date('Y-m-d', strtotime('+1 day')) . "' WHERE id = $piId");
pdo()->exec("UPDATE loans SET status = 'active' WHERE id = (SELECT loan_id FROM installments WHERE id = $piId)");
$before = $sms("template = 'inst_due'");
$admin->get('/notifications');
$admin->post('/notifications/run', []);
check('reminder generated for installment due soon', $sms("template = 'inst_due'") > $before && $admin->has('یادآوری جدید'));
$row = pdo()->query("SELECT status, body FROM notifications WHERE template = 'inst_due' ORDER BY id DESC LIMIT 1")->fetch();
check('reminder sent through log driver with filled template', $row['status'] === 'sent' && !str_contains($row['body'], '{') && str_contains($row['body'], 'ریال'));
$n1 = $sms("template = 'inst_due'");
$admin->get('/notifications');
$admin->post('/notifications/run', []);
check('reminders are not duplicated (dedupe)', $sms("template = 'inst_due'") === $n1);
pdo()->exec("UPDATE installments SET due_date = '" . date('Y-m-d', strtotime('-10 days')) . "' WHERE id = $piId");
$admin->get('/notifications');
$admin->post('/notifications/run', []);
check('overdue warning generated once per period', $sms("template = 'inst_overdue'") === 1);
$admin->get('/notifications');
$admin->post('/notifications/run', []);
check('overdue warning not repeated same period', $sms("template = 'inst_overdue'") === 1);
$admin->get('/customers/' . $customerId);
$admin->post('/customers/' . $customerId . '/sms', ['body' => 'سلام؛ تماس بگیرید']);
check('manual SMS to customer sent', $sms("template = 'manual' AND status = 'sent'") === 1);
$admin->get('/customers/' . $customerId);
$admin->post('/customers/' . $customerId . '/sms', ['body' => '']);
check('manual SMS needs text', $sms("template = 'manual'") === 1);
pdo()->exec("UPDATE notifications SET status = 'failed', attempts = 3, last_error = 'x' WHERE template = 'manual'");
$admin->get('/notifications?status=failed');
check('failed SMS shows retry', $admin->has('تلاش مجدد'));
$mid = (int) pdo()->query("SELECT id FROM notifications WHERE template = 'manual'")->fetchColumn();
$admin->post("/notifications/$mid/retry", []);
check('retry puts failed SMS back in queue', (string) pdo()->query("SELECT status FROM notifications WHERE id = $mid")->fetchColumn() === 'queued');
$admin->get('/notifications?template=inst_overdue');
check('notifications filter by template', $admin->has('اخطار معوقه') && !$admin->has('تأیید پرداخت</td>'));
$admin->get('/notifications?format=csv');
check('notifications csv export', $admin->has('متن') && $admin->has('وضعیت'));
$anon2->get('/notifications');
check('notifications require login', str_ends_with($anon2->url, '/login'));

$admin->get('/alerts');
check('alerts show unread actions', $admin->has('علامت‌گذاری همه') || !$admin->has('alert-item'));
if ($admin->has('name="key"')) {
    preg_match('/name="key" value="([a-f0-9]+)"/', $admin->html, $km);
    $admin->post('/alerts/read', ['key' => $km[1]]);
    check('single alert marked read', $admin->has('is-read'));
}
$admin->post('/alerts/read', []);
check('mark all alerts read clears bell badge', !$admin->has('topbar__badge'));


// ---------- CMS صفحه‌ی اصلی ----------
$admin->get('/site-settings');
check('site settings page renders with menu entry', $admin->status === 200 && $admin->has('پرسش‌های متداول') && $admin->has('/site-settings'));
$admin->post('/site-settings', ['hero_title' => "عنوان تست یک\nعنوان تست دو", 'phone' => 'abc', 'email' => 'x@y.ir', 'faq_q' => ['q'], 'faq_a' => ['a']]);
check('invalid phone rejected', $admin->has('تلفن فقط') && (int) pdo()->query('SELECT COUNT(*) FROM site_settings')->fetchColumn() === 0);
$admin->get('/site-settings');
$admin->post('/site-settings', ['hero_title' => 'x', 'email' => 'not-an-email', 'faq_q' => [''], 'faq_a' => ['']]);
check('invalid email rejected', $admin->has('ایمیل معتبر نیست'));
$admin->get('/site-settings');
$admin->post('/site-settings', ['faq_q' => ['فقط پرسش'], 'faq_a' => ['']]);
check('FAQ row needs both question and answer', $admin->has('هم پرسش و هم پاسخ'));
$admin->get('/site-settings');
$admin->post('/site-settings', [
    'hero_title' => "عنوان تست یک\n<script>alert(1)</script>", 'hero_lead' => 'توضیح تازه‌ی صفحه', 'phone' => '021-12345678', 'email' => 'info@example.ir', 'address' => 'تهران، خیابان آزمون',
    'faq_q' => ['پرسش سفارشی اول؟', '', 'پرسش دوم؟'], 'faq_a' => ['پاسخ سفارشی اول', '', 'پاسخ دوم'],
]);
check('site content saved', $admin->has('ذخیره شد') && (int) pdo()->query('SELECT COUNT(*) FROM site_faq')->fetchColumn() === 2);
$pubSite = new Client($base);
$pubSite->get('/');
check('landing shows custom hero, lead, contact and FAQ', $pubSite->has('عنوان تست یک') && $pubSite->has('توضیح تازه‌ی صفحه') && $pubSite->has('021-12345678') && $pubSite->has('info@example.ir') && $pubSite->has('پرسش سفارشی اول؟') && !$pubSite->has('چه کسانی می‌توانند اعتبار بگیرند'));
check('CMS text is escaped', !$pubSite->has('<script>alert(1)</script>') && $pubSite->has('&lt;script&gt;'));
$admin->get('/site-settings');
check('stored values appear in the form', $admin->has('021-12345678') && $admin->has('پرسش دوم؟'));
$admin->post('/site-settings', ['hero_title' => '', 'hero_lead' => '', 'phone' => '', 'email' => '', 'address' => '', 'footer_note' => '', 'eyebrow' => '', 'faq_q' => [''], 'faq_a' => ['']]);
$pubSite->get('/');
check('clearing fields falls back to defaults', $pubSite->has('امروز بخرید') && $pubSite->has('چه کسانی می‌توانند اعتبار بگیرند') && !$pubSite->has('021-12345678'));
$lender->get('/site-settings');
check('site settings need site.manage permission', $lender->status === 403);
$anon2->get('/site-settings');
check('site settings require login', str_ends_with($anon2->url, '/login'));
check('site update audited', (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action = 'site.update'")->fetchColumn() === 2);

// ---------- پرتال مشتری ----------
$smsLog = dirname(__DIR__) . '/storage/logs/sms.log';
$lastOtp = static function () use ($smsLog): string {
    $t = is_file($smsLog) ? (string) file_get_contents($smsLog) : '';
    preg_match_all('/کد ورود شما: (\d{6})/u', $t, $mm);
    return $mm[1] ? end($mm[1]) : '';
};
$pMobile = (string) pdo()->query("SELECT mobile FROM customers WHERE id = $customerId")->fetchColumn();
$pMobileFa = strtr($pMobile, ['0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹']);
$pc = new Client($base);
$pc->get('/portal');
check('portal home requires customer login', str_ends_with($pc->url, '/portal/login'));
$pc->get('/portal/login');
check('portal login page renders with captcha', $pc->status === 200 && $pc->has('name="captcha"') && $pc->has('ورود مشتریان'));
$pc->get('/');
check('landing links to customer portal', $pc->has('/portal'));
$pc->get('/portal/login');
$pc->post('/portal/login', ['mobile' => $pMobile, 'captcha' => '000000']);
check('portal login rejects wrong captcha', $pc->has('کد امنیتی اشتباه') && $lastOtp() === '');
$pc->get('/portal/login');
$pc->post('/portal/login', ['mobile' => '123', 'captcha' => $pc->captchaCode('portal')]);
check('portal login rejects invalid mobile', $pc->has('موبایل معتبر نیست'));
$pc->get('/portal/login');
$pc->post('/portal/login', ['mobile' => '09350000000', 'captcha' => $pc->captchaCode('portal')]);
check('unknown mobile gets the same neutral reply (no enumeration)', str_ends_with($pc->url, '/portal/code') && $pc->has('اگر این شماره') && $lastOtp() === '');
$pc->get('/portal/login');
$pc->post('/portal/login', ['mobile' => $pMobileFa, 'captcha' => $pc->captchaCode('portal')]);
$otp = $lastOtp();
check('known mobile receives a 6-digit code by SMS', str_ends_with($pc->url, '/portal/code') && strlen($otp) === 6);
check('OTP is stored hashed only', (int) pdo()->query("SELECT COUNT(*) FROM customer_otps WHERE code_hash = '$otp'")->fetchColumn() === 0 && (int) pdo()->query('SELECT COUNT(*) FROM customer_otps')->fetchColumn() === 1);
$pc->get('/portal/login');
$pc->post('/portal/login', ['mobile' => $pMobile, 'captcha' => $pc->captchaCode('portal')]);
check('code resend within 60 seconds is refused', $pc->has('ثانیه بعد'));
$pc->get('/portal/code');
$wrong = $otp === '111111' ? '222222' : '111111';
$pc->post('/portal/code', ['code' => $wrong]);
check('wrong code rejected', $pc->has('کد اشتباه یا منقضی') && str_ends_with($pc->url, '/portal/code'));
$pc->get('/portal');
check('wrong code does not log in', str_ends_with($pc->url, '/portal/login') || str_ends_with($pc->url, '/portal/code') === false && $pc->has('name="captcha"'));
// نشست پس از تلاش ناموفق هنوز موبایل را دارد
$pc->get('/portal/code');
$pc->post('/portal/code', ['code' => $otp]);
check('correct code logs the customer in', str_ends_with($pc->url, '/portal') && $pc->has('موجودی کیف پول') && $pc->has('نام جدید مشتری'));
$pc->get('/portal/code');
$pc2 = new Client($base);
$pc2->get('/portal/login');
$pc2->post('/portal/code', ['code' => $otp]);
check('code is single-use and needs the session mobile', !$pc2->has('موجودی کیف پول'));
$pc->get('/dashboard');
check('customer session grants no staff access', str_ends_with($pc->url, '/login') && !str_contains($pc->url, 'portal'));
$pc->get('/portal');

// قسط تازه برای پرداخت از پرتال
pdo()->exec("UPDATE installments SET paid_amount = 0, status = 'due', paid_at = NULL WHERE id = $piId");
pdo()->exec("UPDATE loans SET status = 'active', customer_id = $customerId WHERE id = (SELECT loan_id FROM installments WHERE id = $piId)");
$pi['customer_id'] = $customerId;
$pc->get('/portal');
check('portal lists the open installment with pay button', $pc->has('name="installment_id" value="' . $piId . '"'));
$pc->post('/portal/pay', ['kind' => 'installment', 'installment_id' => (string) $piId, 'amount' => (string) $pRem]);
check('portal pay creates a link and opens the pay page', str_contains($pc->url, '/pay?t=') && $pc->has('پرداخت'));
check('portal link is recorded for the same customer', (int) pdo()->query("SELECT COUNT(*) FROM payment_requests WHERE installment_id = $piId AND status = 'pending' AND customer_id = {$pi['customer_id']}")->fetchColumn() === 1);
preg_match('/t=([a-f0-9]{40})/', $pc->url, $tm);
$tp = $tm[1];
$pc->post('/pay/start?t=' . $tp, []);
$authP = (string) pdo()->query("SELECT authority FROM payment_requests WHERE token = '$tp'")->fetchColumn();
$pc->get("/pay/return?t=$tp&Status=OK&Authority=$authP");
check('portal payment settles the installment', pdo()->query("SELECT status FROM installments WHERE id = $piId")->fetchColumn() === 'paid');
$pc->get('/portal');
check('portal shows the finished online payment', $pc->has('پرداخت‌شده'));
$pc->post('/portal/pay', ['kind' => 'installment', 'installment_id' => (string) $piId, 'amount' => (string) $pRem]);
check('paying an already settled installment is refused', $pc->has('تسویه شده') || $pc->has('یافت نشد'));
$pc->post('/portal/pay', ['kind' => 'topup', 'amount' => '50']);
check('portal top-up below the minimum is refused', $pc->has('باید بین'));
$pc->post('/portal/pay', ['kind' => 'topup', 'amount' => '5,000,000']);
check('portal top-up opens a pay page', str_contains($pc->url, '/pay?t='));
// مشتری نمی‌تواند قسط دیگران را پرداخت کند
$otherInst = (int) pdo()->query("SELECT i.id FROM installments i JOIN loans l ON l.id = i.loan_id WHERE l.customer_id <> {$pi['customer_id']} LIMIT 1")->fetchColumn();
if ($otherInst) {
    $pc->post('/portal/pay', ['kind' => 'installment', 'installment_id' => (string) $otherInst, 'amount' => '1000']);
    check('customer cannot pay someone else\'s installment', !str_contains($pc->url, '/pay?t='));
}
$pc->post('/portal/logout', []);
$pc->get('/portal');
check('portal logout ends the customer session', str_ends_with($pc->url, '/portal/login'));
check('portal login and OTP are audited', (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action IN ('portal.otp_sent','portal.login')")->fetchColumn() >= 2);

// ---------- آپلود تصویر (لوگو و کالا) ----------
$mk = static function (string $type): string {
    $im = imagecreatetruecolor(1200, 800);
    imagefill($im, 0, 0, imagecolorallocate($im, 30, 90, 200));
    $f = tempnam(sys_get_temp_dir(), 'img') . '.' . $type;
    $type === 'png' ? imagepng($im, $f) : imagejpeg($im, $f);
    return $f;
};
$png = $mk('png');
$postImg = static function (Client $c, string $path, array $data, string $field, string $file, string $mime) {
    $data['_csrf'] = $c->csrf();
    $data[$field] = new CURLFile($file, $mime, 'x.' . pathinfo($file, PATHINFO_EXTENSION));
    return $c->postRaw($path, $data);
};
$admin->get('/site-settings');
check('logo upload field present', $admin->has('name="logo"') && $admin->has('multipart/form-data'));
$postImg($admin, '/site-settings', ['hero_title' => '', 'hero_lead' => '', 'phone' => '', 'email' => '', 'address' => '', 'footer_note' => '', 'eyebrow' => ''], 'logo', $png, 'image/png');
$lm = pdo()->query("SELECT * FROM media WHERE kind = 'logo'")->fetch();
check('logo stored (re-encoded, resized to max 480px)', $lm && (int) $lm['width'] === 480 && (int) $lm['height'] === 320 && $lm['mime'] === 'image/png');
check('logo file lives outside the web root', $lm && is_file(dirname(__DIR__) . '/storage/uploads/' . $lm['company_id'] . '/' . $lm['filename']) && !is_dir(dirname(__DIR__) . '/public/uploads'));
$pubM = new Client($base);
$pubM->get('/');
check('landing header shows the logo', $pubM->has('/media?id=' . $lm['id']) && $pubM->has('brand-logo'));
$pubM->get('/media?id=' . $lm['id']);
check('media is served as image/png', $pubM->status === 200 && str_starts_with($pubM->html, "\x89PNG"));
$pubM->get('/media?id=999999');
check('unknown media id is 404', $pubM->status === 404);
$txt = tempnam(sys_get_temp_dir(), 'bad') . '.png';
file_put_contents($txt, '<?php echo 1; ?>' . str_repeat('x', 100));
$postImg($admin, '/site-settings', ['hero_title' => '', 'hero_lead' => '', 'phone' => '', 'email' => '', 'address' => '', 'footer_note' => '', 'eyebrow' => ''], 'logo', $txt, 'image/png');
check('non-image disguised as png is rejected, old logo kept', $admin->has('فقط تصویر') && (int) pdo()->query("SELECT COUNT(*) FROM media WHERE kind = 'logo'")->fetchColumn() === 1);
$gif = tempnam(sys_get_temp_dir(), 'gif') . '.gif';
file_put_contents($gif, base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'));
$postImg($admin, '/site-settings', ['hero_title' => '', 'hero_lead' => '', 'phone' => '', 'email' => '', 'address' => '', 'footer_note' => '', 'eyebrow' => ''], 'logo', $gif, 'image/gif');
check('gif is rejected (type whitelist)', $admin->has('فقط تصویر'));
$big = tempnam(sys_get_temp_dir(), 'big') . '.png';
file_put_contents($big, "\x89PNG\r\n\x1a\n" . str_repeat("\0", 2 * 1024 * 1024 + 10));
$postImg($admin, '/site-settings', ['hero_title' => '', 'hero_lead' => '', 'phone' => '', 'email' => '', 'address' => '', 'footer_note' => '', 'eyebrow' => ''], 'logo', $big, 'image/png');
check('oversize image is rejected', $admin->has('بیش از') || $admin->has('حجم'));
$lender->get('/site-settings');
check('lender still cannot reach site settings', $lender->status === 403);
// تصویر محصول
$prodId = (int) pdo()->query('SELECT id FROM products ORDER BY id LIMIT 1')->fetchColumn();
$jpg = $mk('jpg');
$prow = pdo()->query("SELECT name, sku, price FROM products WHERE id = $prodId")->fetch();
$admin->get("/products/$prodId/edit");
check('product form has image field', $admin->has('name="image"'));
$postImg($admin, "/products/$prodId", ['name' => $prow['name'], 'sku' => (string) $prow['sku'], 'price' => (string) $prow['price']], 'image', $jpg, 'image/jpeg');
$pm2 = pdo()->query("SELECT * FROM media WHERE kind = 'product' AND ref_id = $prodId")->fetch();
check('product image stored and shown on edit page', $pm2 && (int) $pm2['width'] === 960 && $admin->has('/media?id=' . $pm2['id']));
$postImg($admin, "/products/$prodId", ['name' => $prow['name'], 'sku' => (string) $prow['sku'], 'price' => (string) $prow['price'], 'crop_square' => '1'], 'image', $png, 'image/png');
$cropped = pdo()->query("SELECT width, height FROM media WHERE kind = 'product' AND ref_id = $prodId")->fetch();
check('square crop produces a centered 800x800 image', $cropped && (int) $cropped['width'] === 800 && (int) $cropped['height'] === 800);
clearstatcache();
check('replacing product image keeps a single row and deletes the old file', (int) pdo()->query("SELECT COUNT(*) FROM media WHERE kind = 'product' AND ref_id = $prodId")->fetchColumn() === 1 && !is_file(dirname(__DIR__) . '/storage/uploads/' . $pm2['company_id'] . '/' . $pm2['filename']));
$admin->post("/products/$prodId", ['name' => $prow['name'], 'sku' => (string) $prow['sku'], 'price' => (string) $prow['price'], 'remove_image' => '1']);
check('product image removed on request', (int) pdo()->query("SELECT COUNT(*) FROM media WHERE kind = 'product' AND ref_id = $prodId")->fetchColumn() === 0);
$admin->post('/site-settings', ['hero_title' => '', 'hero_lead' => '', 'phone' => '', 'email' => '', 'address' => '', 'footer_note' => '', 'eyebrow' => '', 'remove_logo' => '1', 'faq_q' => [''], 'faq_a' => ['']]);
clearstatcache();
check('logo removed on request and files cleaned', (int) pdo()->query('SELECT COUNT(*) FROM media')->fetchColumn() === 0 && !is_file(dirname(__DIR__) . '/storage/uploads/' . $lm['company_id'] . '/' . $lm['filename']));
check('uploads are audited', (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action IN ('media.upload','media.remove')")->fetchColumn() >= 4);

// ---------- خروجی Excel ----------
$xlsxGet = static function (Client $c, string $path) use ($base): array {
    $ch = curl_init($base . $path);
    $jar = (new ReflectionProperty($c, 'jar'));
    $jar->setAccessible(true);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEFILE => $jar->getValue($c), CURLOPT_USERAGENT => 'smoke-test', CURLOPT_HEADER => true]);
    $raw = (string) curl_exec($ch);
    $hs = (int) curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    unset($ch);
    return [$code, substr($raw, 0, $hs), substr($raw, $hs)];
};
foreach (['/customers', '/loans', '/installments', '/journal', '/reports/overdue.csv', '/trial-balance?from=1405/01/01&to=1405/12/29'] as $xp) {
    $sep = str_contains($xp, '?') ? '&' : '?';
    [$xc, $xh, $xb] = $xlsxGet($admin, $xp . $sep . 'format=xlsx');
    check("xlsx export works for $xp", $xc === 200 && stripos($xh, 'spreadsheetml.sheet') !== false && str_starts_with($xb, 'PK'));
}
[$xc, $xh, $xb] = $xlsxGet($admin, '/customers?format=xlsx');
$xt = tempnam(sys_get_temp_dir(), 'ex') . '.xlsx';
file_put_contents($xt, $xb);
$zz = new ZipArchive();
$zz->open($xt);
$shx = (string) $zz->getFromName('xl/worksheets/sheet1.xml');
check('customers xlsx has header and data rows', str_contains($shx, 'کد ملی') && substr_count($shx, '<row ') >= 2);
check('customers xlsx keeps mobile numbers as text', (bool) preg_match('/t="inlineStr"><is><t xml:space="preserve">09\d{9}</', $shx));
$zz->close();
unlink($xt);
$admin->get('/customers');
check('list pages offer an Excel button', $admin->has('format=xlsx'));
$lender->get('/audit?format=xlsx');
check('xlsx export respects permissions', $lender->status === 403);
check('xlsx exports are audited like csv', (int) pdo()->query("SELECT COUNT(*) FROM audit_logs WHERE action = 'report.export'")->fetchColumn() >= 5);

// ---------- فونت محلی ----------
$fetch = static function (string $u): string { $c = curl_init($u); curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true]); $r = (string) curl_exec($c); unset($c); return $r; };
$fontCss = $fetch($base . '/assets/css/core/typography.css');
check('typography.css declares local Vazirmatn faces', substr_count((string) $fontCss, '@font-face') === 3 && str_contains((string) $fontCss, 'Vazirmatn-Bold.woff2'));
foreach (['Regular', 'SemiBold', 'Bold'] as $fw) {
    $hdr = substr($fetch($base . '/assets/fonts/Vazirmatn-' . $fw . '.woff2'), 0, 4);
    check("font file $fw is served as woff2", $hdr === 'wOF2');
}

// ---------- خروج ----------
$second->post('/logout', []);
$second->get('/dashboard');
check('logout ends session', str_ends_with($second->url, '/login'));

echo $fails === 0 ? "smoke: all $total checks passed\n" : "smoke: $fails of $total FAILED\n";
exit($fails === 0 ? 0 : 1);
