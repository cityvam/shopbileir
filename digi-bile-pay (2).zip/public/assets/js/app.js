(function () {
    'use strict';

    // کپی متن یک فیلد
    document.addEventListener('click', function (e) {
        var b = e.target.closest ? e.target.closest('[data-copy]') : null;
        if (!b) { return; }
        var el = document.querySelector(b.getAttribute('data-copy'));
        if (!el) { return; }
        el.select();
        var done = function () { var t = b.querySelector('span'); if (t) { var old = t.textContent; t.textContent = 'کپی شد'; setTimeout(function () { t.textContent = old; }, 1500); } };
        if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(el.value).then(done, function () { document.execCommand('copy'); done(); }); }
        else { document.execCommand('copy'); done(); }
    });

    // کپچا: دریافت تصویر جدید
    document.addEventListener('click', function (e) {
        var b = e.target.closest ? e.target.closest('[data-captcha-refresh]') : null;
        if (!b) { return; }
        var box = b.closest('.captcha');
        var img = box && box.querySelector('[data-captcha-img]');
        var inp = box && box.querySelector('.captcha__input');
        if (img) { img.src = img.getAttribute('data-captcha-src') + '&r=' + Math.random().toString(36).slice(2, 8); }
        if (inp) { inp.value = ''; inp.focus(); }
    });

    // تأیید عملیات حساس
    document.addEventListener('submit', function (e) {
        var form = e.target;
        var msg = form.getAttribute('data-confirm');
        if (msg && !window.confirm(msg)) {
            e.preventDefault();
            return;
        }
        // حالت Loading و جلوگیری از ثبت دوباره
        var btn = form.querySelector('button[type="submit"]');
        if (btn && !e.defaultPrevented) {
            setTimeout(function () {
                btn.classList.add('is-loading');
                btn.disabled = true;
            }, 0);
        }
    });

    // قالب‌بندی مبلغ هنگام تایپ (سرور فقط ارقام را می‌خواند)
    document.querySelectorAll('input[data-money]').forEach(function (input) {
        var fmt = function () {
            var digits = input.value.replace(/\D/g, '');
            input.value = digits ? digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',') : '';
        };
        input.addEventListener('input', fmt);
        fmt();
    });

    // بستن خودکار پیام‌های موفقیت
    document.querySelectorAll('.notice--success').forEach(function (n) {
        setTimeout(function () {
            n.classList.add('is-hidden');
            setTimeout(function () { n.remove(); }, 400);
        }, 5000);
    });

    // انتخاب گروهی ردیف‌ها (چک‌باکس‌های [data-bulk] و [data-check-all])
    var bulkCount = document.querySelector('[data-bulk-count]');
    var boxes = document.querySelectorAll('input[data-bulk]');
    function refreshBulk() {
        var n = 0;
        boxes.forEach(function (b) { if (b.checked) { n++; } });
        if (bulkCount) {
            bulkCount.textContent = n.toLocaleString('fa-IR') + ' مورد انتخاب شد';
            var bar = bulkCount.closest('.bulk-bar');
            if (bar) { bar.classList.toggle('is-active', n > 0); }
        }
    }
    boxes.forEach(function (b) { b.addEventListener('change', refreshBulk); });
    document.querySelectorAll('input[data-check-all]').forEach(function (all) {
        all.addEventListener('change', function () {
            boxes.forEach(function (b) { b.checked = all.checked; });
            refreshBulk();
        });
    });

    // برچسب ستون برای نمایش کارتی جدول‌ها در موبایل
    document.querySelectorAll('table.table--stack').forEach(function (t) {
        var heads = Array.prototype.map.call(t.querySelectorAll('thead th'), function (th) { return th.textContent.replace(/[▲▼]/g, '').trim(); });
        t.querySelectorAll('tbody tr').forEach(function (tr) {
            Array.prototype.forEach.call(tr.children, function (td, i) { if (td.tagName === 'TD') { td.setAttribute('data-label', heads[i] || ''); } });
        });
    });

    // منوی موبایل: بازشدن، بستن با پس‌زمینه/دکمه/Esc/انتخاب لینک
    var toggle = document.getElementById('sidebarToggle');
    var sidebar = document.getElementById('sidebar');
    function setNav(open) {
        document.body.classList.toggle('nav-open', open);
        if (toggle) { toggle.setAttribute('aria-expanded', open ? 'true' : 'false'); }
        if (open && sidebar) {
            var a = sidebar.querySelector('.sidebar__link.is-active') || sidebar.querySelector('.sidebar__link');
            if (a && a.scrollIntoView) { a.scrollIntoView({ block: 'center' }); }
        }
    }
    if (toggle && sidebar) {
        toggle.addEventListener('click', function () { setNav(!document.body.classList.contains('nav-open')); });
        document.querySelectorAll('[data-nav-close]').forEach(function (el) { el.addEventListener('click', function () { setNav(false); }); });
        sidebar.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('a')) { setNav(false); } });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { setNav(false); } });
        window.matchMedia('(min-width: 901px)').addEventListener('change', function (m) { if (m.matches) { setNav(false); } });
        window.addEventListener('pageshow', function () { setNav(false); });
    }

    // پوسته‌ی روشن/تیره
    var themeBtn = document.querySelector('[data-theme-toggle]');
    if (themeBtn) {
        themeBtn.addEventListener('click', function () {
            var root = document.documentElement;
            var cur = root.getAttribute('data-theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
            var next = cur === 'dark' ? 'light' : 'dark';
            root.setAttribute('data-theme', next);
            try { localStorage.setItem('dbp-theme', next); } catch (e) { /* ignore */ }
        });
    }
})();
