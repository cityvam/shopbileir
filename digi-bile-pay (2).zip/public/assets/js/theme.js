// اعمال پوسته پیش از رندر صفحه (جلوگیری از چشمک‌زدن)
(function () {
    document.documentElement.classList.add('js');
    try {
        var t = localStorage.getItem('dbp-theme');
        if (t === 'dark' || t === 'light') { document.documentElement.setAttribute('data-theme', t); }
    } catch (e) { /* حافظه‌ی مرورگر در دسترس نیست */ }
})();
