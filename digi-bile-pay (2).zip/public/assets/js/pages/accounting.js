(function () {
    'use strict';

    // چاپ صفحه (دکمه‌های data-print)
    document.addEventListener('click', function (e) {
        var b = e.target.closest('[data-print]');
        if (b) { window.print(); }
    });

    // تطبیق بانکی: جمع زنده‌ی ردیف‌های انتخاب‌شده و اختلاف با مانده‌ی صورت‌حساب
    var recForm = document.getElementById('recForm');
    if (recForm) {
        var recFmt = new Intl.NumberFormat('fa-IR');
        var prev = parseInt(document.getElementById('recPrev').getAttribute('data-value'), 10) || 0;
        var recBoxes = recForm.querySelectorAll('.rec-line');
        var balInput = document.getElementById('statement_balance');
        var recCalc = function () {
            var net = 0;
            recBoxes.forEach(function (b) { if (b.checked) { net += parseInt(b.getAttribute('data-net'), 10) || 0; } });
            document.getElementById('recSel').textContent = recFmt.format(net);
            var raw = (balInput ? balInput.value : '').trim();
            var neg = raw.charAt(0) === '-';
            var digits = parseInt(raw.replace(/\D/g, ''), 10);
            var diffEl = document.getElementById('recDiff');
            if (!diffEl) { return; }
            if (isNaN(digits)) { diffEl.textContent = '—'; diffEl.className = 'je-diff'; return; }
            var diff = (neg ? -digits : digits) - (prev + net);
            diffEl.textContent = diff === 0 ? 'برابر' : recFmt.format(Math.abs(diff));
            diffEl.className = 'je-diff ' + (diff === 0 ? 'is-ok' : 'is-bad');
        };
        recBoxes.forEach(function (b) { b.addEventListener('change', recCalc); });
        if (balInput) { balInput.addEventListener('input', recCalc); }
        var all = document.getElementById('recAll');
        if (all) { all.addEventListener('change', function () { recBoxes.forEach(function (b) { b.checked = all.checked; }); recCalc(); }); }
        recCalc();
    }

    var body = document.getElementById('jeBody');
    if (!body) { return; }
    var tpl = document.getElementById('jeTemplate');
    var fmt = new Intl.NumberFormat('fa-IR');

    function num(v) { return parseInt(String(v || '').replace(/\D/g, ''), 10) || 0; }

    function recalc() {
        var d = 0, c = 0;
        body.querySelectorAll('.je-row').forEach(function (r) {
            d += num(r.querySelector('.je-debit').value);
            c += num(r.querySelector('.je-credit').value);
        });
        document.getElementById('jeDebit').textContent = fmt.format(d);
        document.getElementById('jeCredit').textContent = fmt.format(c);
        var diff = document.getElementById('jeDiff');
        var delta = d - c;
        diff.classList.toggle('is-ok', delta === 0 && d > 0);
        diff.classList.toggle('is-bad', delta !== 0);
        diff.textContent = delta === 0 ? (d > 0 ? 'متوازن' : '—') : fmt.format(Math.abs(delta)) + (delta > 0 ? ' بدهکار بیشتر' : ' بستانکار بیشتر');
    }

    // ورود مبلغ در یک سمت، سمت دیگر همان ردیف را خالی می‌کند
    body.addEventListener('input', function (e) {
        var t = e.target;
        var row = t.closest('.je-row');
        if (!row) { return; }
        if (t.classList.contains('je-debit') && num(t.value) > 0) { row.querySelector('.je-credit').value = ''; }
        if (t.classList.contains('je-credit') && num(t.value) > 0) { row.querySelector('.je-debit').value = ''; }
        recalc();
    });

    // با ورود فیلد مبلغ، اختلاف فعلی به‌صورت پیشنهاد در ردیف خالی قرار می‌گیرد
    body.addEventListener('dblclick', function (e) {
        var t = e.target;
        if (!(t.classList.contains('je-debit') || t.classList.contains('je-credit')) || t.value) { return; }
        var d = 0, c = 0;
        body.querySelectorAll('.je-row').forEach(function (r) {
            d += num(r.querySelector('.je-debit').value);
            c += num(r.querySelector('.je-credit').value);
        });
        var delta = d - c;
        if (t.classList.contains('je-credit') && delta > 0) { t.value = String(delta).replace(/\B(?=(\d{3})+(?!\d))/g, ','); t.dispatchEvent(new Event('input', { bubbles: true })); }
        if (t.classList.contains('je-debit') && delta < 0) { t.value = String(-delta).replace(/\B(?=(\d{3})+(?!\d))/g, ','); t.dispatchEvent(new Event('input', { bubbles: true })); }
    });

    body.addEventListener('click', function (e) {
        var rm = e.target.closest('.je-remove');
        if (!rm) { return; }
        if (body.querySelectorAll('.je-row').length <= 2) { return; }
        rm.closest('.je-row').remove();
        recalc();
    });

    function bindMoney(input) {
        input.addEventListener('input', function () {
            var digits = input.value.replace(/\D/g, '');
            input.value = digits ? digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',') : '';
        });
    }

    document.getElementById('jeAdd').addEventListener('click', function () {
        body.appendChild(tpl.content.cloneNode(true));
        body.querySelectorAll('input[data-money]').forEach(function (i) { if (!i.dataset.bound) { i.dataset.bound = '1'; bindMoney(i); } });
        recalc();
    });

    recalc();
})();
