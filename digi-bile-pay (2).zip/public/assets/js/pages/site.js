(function () {
    'use strict';

    // ---------- منوی موبایل و سایه‌ی هدر ----------
    var header = document.querySelector('.site-header');
    var toggle = document.querySelector('[data-site-nav-toggle]');
    function setNav(open) {
        document.body.classList.toggle('site-nav-open', open);
        if (toggle) { toggle.setAttribute('aria-expanded', open ? 'true' : 'false'); }
    }
    if (toggle) {
        toggle.addEventListener('click', function () { setNav(!document.body.classList.contains('site-nav-open')); });
        document.querySelectorAll('.site-nav a').forEach(function (a) { a.addEventListener('click', function () { setNav(false); }); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { setNav(false); } });
        window.matchMedia('(min-width: 901px)').addEventListener('change', function (m) { if (m.matches) { setNav(false); } });
    }
    function onScroll() { if (header) { header.classList.toggle('is-stuck', window.scrollY > 8); } }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    // ---------- ماشین‌حساب قسط (نتیجه از همان محاسبه‌ی سمت سرور می‌آید) ----------
    var form = document.getElementById('calcForm');
    if (!form) { return; }
    var planSel = document.getElementById('calcPlan');
    var amountIn = document.getElementById('calcAmount');
    var box = document.getElementById('quote');
    var elErr = box.querySelector('[data-q-error]');
    var elIdle = box.querySelector('[data-q-idle]');
    var elRes = box.querySelector('[data-q-result]');
    var rows = box.querySelector('[data-q-rows]');
    var timer = null, seq = 0;

    function digits(v) { return String(v).replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/\D/g, ''); }
    function show(state, msg) {
        elErr.hidden = state !== 'error'; elIdle.hidden = state !== 'idle'; elRes.hidden = state !== 'result';
        if (state === 'error') { elErr.textContent = msg; }
    }
    function render(q) {
        ['monthly', 'first_due', 'months', 'interest', 'fee', 'total'].forEach(function (k) {
            var n = box.querySelector('[data-q="' + k + '"]'); if (n) { n.textContent = q[k]; }
        });
        rows.textContent = '';
        q.rows.forEach(function (r) {
            var tr = document.createElement('tr');
            [r.seq, r.due, r.amount].forEach(function (t) { var td = document.createElement('td'); td.textContent = t; tr.appendChild(td); });
            rows.appendChild(tr);
        });
        show('result');
    }
    function calc() {
        var amount = digits(amountIn.value);
        if (!amount) { show('idle'); return; }
        var my = ++seq;
        fetch('/calc?plan=' + encodeURIComponent(planSel.value) + '&amount=' + encodeURIComponent(amount), { headers: { Accept: 'application/json' }, credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (q) { if (my !== seq) { return; } if (q.error) { show('error', q.error); } else { render(q); } })
            .catch(function () { if (my === seq) { show('error', 'ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.'); } });
    }
    function later() { clearTimeout(timer); timer = setTimeout(calc, 250); }
    form.addEventListener('submit', function (e) { e.preventDefault(); calc(); });
    amountIn.addEventListener('input', later);
    planSel.addEventListener('change', function () { calc(); });

    // انتخاب طرح/کالا از کارت‌ها بدون بارگذاری مجدد
    document.querySelectorAll('a[data-plan]').forEach(function (a) {
        a.addEventListener('click', function (e) {
            e.preventDefault();
            planSel.value = a.getAttribute('data-plan');
            amountIn.value = Number(a.getAttribute('data-amount')).toLocaleString('en-US');
            calc();
            document.getElementById('calc').scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });

    // ثبت درخواست با طرح و مبلغ محاسبه‌شده
    var applyBtn = document.querySelector('[data-apply-from-quote]');
    if (applyBtn) {
        applyBtn.addEventListener('click', function () {
            var p = document.getElementById('a_plan'), m = document.getElementById('a_amount');
            if (p) { p.value = planSel.value; }
            if (m && !m.value) { m.value = amountIn.value; }
        });
    }
    if (amountIn.value) { calc(); }
})();
